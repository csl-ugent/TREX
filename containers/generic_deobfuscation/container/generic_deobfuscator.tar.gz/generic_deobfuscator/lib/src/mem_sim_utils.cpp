#include "mem_sim_utils.h"

#include <tuple>

#include "utils.h"

using namespace deobf::library::utils;

using pageTableIndices = std::pair<uint64_t , uint8_t>;

namespace deobf::library::memory_simulation {

/*
 * clear all memory tags used to determine
 * a memory location is constant or not.
 * Also could be used in liveness analysis
 * (as well as in taint analysis) 0 indicating
 * dead locations and 1 for live  (tainted) memory locations.
 */
void ClearConstantPages(const std::shared_ptr<InstrList>& iList) {
    for (uint64_t i = 0; i < iList->constantNumPageEntries; i++) {
        memset(iList->constantPageDir[i].Constants, MEMORY_DEAD, utils::pageSize());
    }
}

void ClearMemoryPages(const std::shared_ptr<InstrList>& iList) {
    for (uint64_t r = 0; r < iList->constantNumPageEntries; r++) {
        for (int j = 0; j < B2B_MAP_PAGESIZE && iList->constantPageDir[r].pages[j]; j++) {
            memset(iList->constantPageDir[r].pages[j], MEMORY_DEAD, utils::pageSize() * sizeof(uint64_t));
        }
    }
}

bool MemoryPageTableLookup(const std::shared_ptr<InstrList>& iList, ADDRESS addr, pageTableIndices *indices) {
    for (uint64_t i = 0; i < iList->constantNumPageEntries; i++) {
        for (uint8_t j = 0; j < B2B_MAP_PAGESIZE; j++) {
            ADDRESS startAddr = iList->constantPageDir[i].startAddrs[j];
            if (addr >= startAddr && addr < startAddr + utils::pageSize()) {
                indices->first = i;
                indices->second = j;
                return true;
            }
        }
    }
    logger.log(fmt::format("[MemoryPageTableLookup] Error: could not find a page table for address {:#x}", addr));
    indices->first = 0;
    indices->second = 0;
    return false;
}

inline uint64_t getPageIdx(uint8_t idx, uint64_t i) {
    return (idx * utils::pageSize() / 8) + (i >> 3);
}

/**
 * Returns which bit we should be looking at by creating an appropriate mask.
 *
 * @param i
 * @return
 */
inline uint8_t getPageMask(uint64_t i) {
    return (1 << (7 - (i & 0x7)));
}

void SetAddrAsConst(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    pageTableIndices indices{};
    if (!MemoryPageTableLookup(iList, addr, &indices)) {
        return;
    }

    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];

    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] |= getPageMask(i); // right? right?
    }
}

void removeConstAddr(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, bool resetMem, int line) {
    DEBUG(11, fmt::format("Unsetting addr const: {:#x} -- origin {}", addr, line));
    pageTableIndices indices{};
    if (!MemoryPageTableLookup(iList, addr, &indices)) {
        return;
    }

    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = ((addr - iList->constantPageDir[indices.first].startAddrs[indices.second]));
    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] &= ~getPageMask(i);
    }

    if (resetMem) {
        unsigned char *valuepage = iList->constantPageDir[indices.first].pages[indices.second];
        for (int i = 0; i < numBytes; i++) {
            *(valuepage + offset + i) = 0;
        }
    }
}

void SetAddrAsConstWithValue(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, DEOBF_GENERIC_VALUE val, int line) {
    DEBUG(3, fmt::format("Setting addr const: {:#x} - origin {}", addr, line));
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);

    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    unsigned char *valuepage = iList->constantPageDir[indices.first].pages[indices.second];
    for (uint8_t i = 0; i < numBytes; i++) {
        *(valuepage + offset + i) = val;
        val = val >> 8;
    }

    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    for (uint64_t i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] |= getPageMask(i); // right? right?
    }
}

bool MemLocIsConstant(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    if (addr == 0) {
        DEBUG(3, fmt::format("Mem loc const? {:#x} - no", addr));
        return false;
    }

    bool memState = true;
    pageTableIndices indices{};
    if (!MemoryPageTableLookup(iList, addr, &indices)) {
        DEBUG(3, fmt::format("Mem loc const? {:#x} - no", addr));
        return false;
    }

    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        memState = (page[(getPageIdx(indices.second, i))] & getPageMask(i)) != 0;
    }
    DEBUG(3, fmt::format("Mem loc const? {:#x} - {}", addr, (bool)memState));
    return memState;
}

bool PartialMemLocIsConstant(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    if (addr == 0) {
        return false;
    }

    bool memState = false;
    pageTableIndices indices{};
    if (!MemoryPageTableLookup(iList, addr, &indices)) {
        return false;
    }
    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        memState |= (page[getPageIdx(indices.second, i)] & getPageMask(i)) != 0;
    }

    return memState;
}

uint GetMemoryLocValue(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    uint value = 0;
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);
    unsigned char *page = iList->constantPageDir[indices.first].pages[indices.second];
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    for (int i = numBytes - 1; i >= 0; i--) {
        value = value << 8;
        value = value + page[offset + i];
    }

    return value;
}

size_t GetMemoryLocPointer(const std::shared_ptr<InstrList>& iList, ADDRESS addr) {
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);
    auto valuePage = (size_t *)iList->constantPageDir[indices.first].pages[indices.second];
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    size_t pointer = *(valuePage + offset);
    return pointer;
}

void SetMemoryLocPointer(const std::shared_ptr<InstrList>& iList, ADDRESS addr, void *pointer) {
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);
    auto valuePage = (size_t *)iList->constantPageDir[indices.first].pages[indices.second];
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    *(valuePage + offset) = (size_t)pointer;
}

/////////////////////////////////////////////
/////// Helpers for DependencyAnalysis////////
/////////////////////////////////////////////
void DependencyMemSetConstWithSrc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, uint64_t src) {
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);
    auto valuePage = (uint64_t *)iList->constantPageDir[indices.first].pages[indices.second];
    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] |= getPageMask(i); // right? right?
    }
    *(valuePage + offset) = src;
}

uint64_t DependencyMemGetConstLocSrc(const std::shared_ptr<InstrList>& iList, ADDRESS addr) {
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);
    auto page = (uint64_t *)iList->constantPageDir[indices.first].pages[indices.second];
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];
    return page[offset];
}

////////////////////////////////////////
/////// Helpers for TaintAnalysis///////
////////////////////////////////////////
uint TaintMemoryMask(uint8_t numBytes) {
    // FIXME: This function behaves incorrectly as soon as numBytes >= 4 (overflow!)
    uint mask = 0xff;
    for (uint8_t i = 1; i < numBytes; i++) {
        mask |= (0xff << (i * 8));
    }
    return mask;
}

void TaintMemoryLoc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, uint8_t taint) {
    DEBUG(3, fmt::format("TaintMemoryLoc {:#x} for {}", addr, numBytes));
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);

    auto valuePage = (uint64_t *)iList->constantPageDir[indices.first].pages[indices.second];
    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];

    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] |= getPageMask(i); // right? right?
    }
    taint = taint & TaintMemoryMask(numBytes);
    uint *p2ValPage = (uint *)(valuePage + offset);
    *p2ValPage = taint;
}

void SetMemoryLocTainted(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    DEBUG(3, fmt::format("SetMemoryLocTainted {:#x} for {}", addr, numBytes));
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);

    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];

    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] |= getPageMask(i); // right? right?
    }
}

void UntaintMemoryLoc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    DEBUG(3, fmt::format("Untaint memory loc {:#x} for {}", addr, numBytes));
    // it is like tainting the memory location with 0!
    pageTableIndices indices{};
    MemoryPageTableLookup(iList, addr, &indices);
    auto valuePage = (uint64_t *)iList->constantPageDir[indices.first].pages[indices.second];
    unsigned char *page = iList->constantPageDir[indices.first].Constants;
    ADDRESS offset = addr - iList->constantPageDir[indices.first].startAddrs[indices.second];

    for (ADDRESS i = offset; i < offset + numBytes; i++) {
        page[getPageIdx(indices.second, i)] &= ~getPageMask(i); // right? right?
    }
    *(valuePage + offset) = 0;
}

bool MemoryLocIsTainted(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    return PartialMemLocIsConstant(iList, addr, numBytes);
}

bool MemoryLocationIsLive(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    return PartialMemLocIsConstant(iList, addr, numBytes);
}

void SetMemoryLocationLive(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    SetAddrAsConst(iList, addr, numBytes);
}

void SetMemoryLocationDead(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    UnsetConstAddr(iList, addr, numBytes, __LINE__);
}
}
