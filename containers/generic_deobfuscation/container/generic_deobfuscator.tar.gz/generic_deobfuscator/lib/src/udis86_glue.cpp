/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */
#include "udis86_glue.h"

#include <cstring>
#include <iostream>

#include "utils.h"

namespace deobf::library::glue {

/**
 * Converts a UDis86 UD_FLAG_xx value to a PSW bitmask.
 *
 * @param UDFlag
 * @return
 */
PSW_BITVECTOR convertUDFlagToPSWBitMask(uint8_t UDFlag) {
    switch (UDFlag) {
    case UD_FLAG_OF:
        return PSW_OF;
    case UD_FLAG_SF:
        return PSW_SF;
    case UD_FLAG_ZF:
        return PSW_ZF;
    case UD_FLAG_AF:
        return PSW_AF;
    case UD_FLAG_PF:
        return PSW_PF;
    case UD_FLAG_CF:
        return PSW_CF;
    case UD_FLAG_TF:
        return PSW_TF;
    case UD_FLAG_IF:
        return PSW_IF;
    case UD_FLAG_DF:
        return PSW_DF;
    case UD_FLAG_NF:
        return PSW_NT;
    case UD_FLAG_RF:
        return PSW_RF;
    case UD_FLAG_AC:
        return PSW_AC;
    default:
        utils::logger.log(fmt::format("Received an unknown index flag {}, cannot convert!", UDFlag));
        return 0;
    }
}

/**
 * Adds a set of workarounds where we need to preserve old generic deobfuscator behaviour which can't be retrieved
 * from Udis86.
 *
 * @param uIns
 * @param udIns
 */
void addWorkarounds(ins_structure *uIns, ud_t *udIns) {
    // Workaround: if the first operand has read access but is not in the impl_src, add it
    if ((udIns->mnemonic == UD_Idec || udIns->mnemonic == UD_Ibswap) && udIns->operand[0].type == UD_OP_REG && udIns->operand[0].access & UD_OP_ACCESS_WRITE) {
        uIns->impl_src1 = udIns->operand[0].base;
    }
    // Workaround: Generic Deobfuscator doesn't know sysenter
    if (udIns->mnemonic == UD_Isysenter) {
        uIns->psw = 0;
    }
    // Workaround: Udis can't both modify and test a register flag while some operations do both. This should only
    // be added IF the operation uses CF before it's written to (use pseudocode of the op to determine).
    // TODO: this list might be incomplete.
    if (udIns->mnemonic == UD_Isbb || udIns->mnemonic == UD_Ircr || udIns->mnemonic == UD_Iadc || udIns->mnemonic == UD_Ircl || udIns->mnemonic == UD_Icmc) {
        uIns->pswUsed |= PSW_CF;
    }
}

void populateInsStructureFromUDisObject(ins_structure *uIns, ud_t *udIns, DeobfRegisterWidth maxRegisterWidth) {
    uint8_t i;
    const unsigned char *ptr;

    uIns->mnemonic = udIns->mnemonic;

    // FIXME: There might be more than 2 implicit sources, we should take that into account.
    const enum ud_type *impl_src = ud_lookup_implicit_reg_used_list(udIns);
    uIns->impl_src1 = UD_NONE;
    uIns->impl_src2 = UD_NONE;
    if (impl_src != nullptr) {
        uIns->impl_src1 = correctRegisterWidth(impl_src[0], utils::getRegisterWidth(udIns->adr_mode));
        if (impl_src[0] != UD_NONE) {
            uIns->impl_src2 = correctRegisterWidth(impl_src[1], utils::getRegisterWidth(udIns->adr_mode));
        }
    }

    // FIXME: There might be more than 2 implicit destinations, we should take that into account.
    const enum ud_type *impl_dst = ud_lookup_implicit_reg_defined_list(udIns);
    uIns->impl_dst1 = UD_NONE;
    uIns->impl_dst2 = UD_NONE;
    if (impl_dst != nullptr) {
        uIns->impl_dst1 = correctRegisterWidth(impl_dst[0], utils::getRegisterWidth(udIns->adr_mode));
        if (impl_dst[0] != UD_NONE) {
            uIns->impl_dst2 = correctRegisterWidth(impl_dst[1], utils::getRegisterWidth(udIns->adr_mode));
        }
    }

    if (maxRegisterWidth == DeobfRegisterWidth::lower32bit) {
        if (uIns->impl_src1 == UD_R_RIP) {
            uIns->impl_src1 = UD_NONE;
        }
        if (uIns->impl_src2 == UD_R_RIP) {
            uIns->impl_src2 = UD_NONE;
        }
        if (uIns->impl_dst1 == UD_R_RIP) {
            uIns->impl_dst1 = UD_NONE;
        }
        if (uIns->impl_dst2 == UD_R_RIP) {
            uIns->impl_dst2 = UD_NONE;
        }
    }

    const struct ud_eflags *flags = ud_lookup_eflags(udIns);
    uIns->psw = 0;
    uIns->pswUsed = 0;
    if (flags != nullptr) {
        for (i = 0; i < UD_FLAG_MAX; i++) {
            if (flags->flag[i] == UD_FLAG_MODIFIED || flags->flag[i] == UD_FLAG_RESET || flags->flag[i] == UD_FLAG_UNDEFINED || flags->flag[i] == UD_FLAG_SET ||
                flags->flag[i] == UD_FLAG_PRIOR) {
                uIns->psw |= convertUDFlagToPSWBitMask(i);
            }
            if (flags->flag[i] == UD_FLAG_TESTED) {
                uIns->pswUsed |= convertUDFlagToPSWBitMask(i);
            }
        }
    }

    addWorkarounds(uIns, udIns);

    for (i = 0; i < MAX_X86_OPS; i++) {
        memcpy(&(uIns->operand[i]), &(udIns->operand[i]), sizeof(struct ud_operand));
        /*
         * udis86 objects have the unexpected behavior that, if the scale is not
         * explicitly mentioned in the instruction, the scale value in the udis86
         * object is set to 0.  We fix this here.
         */
        if (uIns->operand[i].type == UD_OP_MEM && uIns->operand[i].scale == 0) {
            uIns->operand[i].scale = 1;
        }
    }

    uIns->length = ud_insn_len(udIns);

    // copy instruction bytes
    for (i = 0, ptr = ud_insn_ptr(udIns); i < uIns->length; i++, ptr++) {
        uIns->bytes[i] = *ptr;
    }

    uIns->pfx_seg = static_cast<ud_type>(udIns->pfx_seg);
    uIns->has_rep = udIns->pfx_rep != 0 || udIns->pfx_repe != 0 || udIns->pfx_repne != 0;
    uIns->adr_mode = udIns->adr_mode;
    uIns->opr_mode = udIns->opr_mode;
}

ud_type correctRegisterWidth(ud_type reg, DeobfRegisterWidth maxRegisterWidth) {
    switch (maxRegisterWidth) {
    case DeobfRegisterWidth::lower32bit:
        switch (reg) {
        case UD_R_RAX:
            return UD_R_EAX;
        case UD_R_RCX:
            return UD_R_ECX;
        case UD_R_RDX:
            return UD_R_EDX;
        case UD_R_RBX:
            return UD_R_EBX;
        case UD_R_RSP:
            return UD_R_ESP;
        case UD_R_RBP:
            return UD_R_EBP;
        case UD_R_RSI:
            return UD_R_ESI;
        case UD_R_RDI:
            return UD_R_EDI;
        default:
            break;
        }
        break;
    case DeobfRegisterWidth::lower16bit:
        switch (reg) {
        case UD_R_RAX:
        case UD_R_EAX:
            return UD_R_AX;
        case UD_R_RCX:
        case UD_R_ECX:
            return UD_R_CX;
        case UD_R_RDX:
        case UD_R_EDX:
            return UD_R_DX;
        case UD_R_RBX:
        case UD_R_EBX:
            return UD_R_BX;
        case UD_R_RSP:
        case UD_R_ESP:
            return UD_R_SP;
        case UD_R_RBP:
        case UD_R_EBP:
            return UD_R_BP;
        case UD_R_RSI:
        case UD_R_ESI:
            return UD_R_SI;
        case UD_R_RDI:
        case UD_R_EDI:
            return UD_R_DI;
        default:
            break;
        }
        break;
    default:
        break;
    }
    // All other cases: return unmodified
    return reg;
}

DeobfRegister toDeobfRegister(ud_type reg) {
    if (reg > DEOBF_REGISTER_LAST_UDIS) {
        assert(reg <= UD_R_RIP); // This should always be the case, or else the "reg" is actually a type.
        if (reg == UD_R_RIP) {
            return DeobfRegister::RIP; // RIP (for now) does not follow the same indexing as other registers.
        } else if (reg >= UD_R_XMM0 && reg <= UD_R_XMM15) {
            return static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_XMM + (reg - UD_R_XMM0));
        }
        utils::logger.verbose(fmt::format("Unsupported register {}", ud_type_to_value(reg)));
        return DeobfRegister::NONE;
    }
    return static_cast<DeobfRegister>(reg);
}
int64_t getSizedLval(const ud_operand_t &op) {
    switch (op.offset) {
    case 0:
        return 0;
    case 8:
        return op.lval.sbyte;
    case 16:
        return op.lval.sword;
    case 32:
        return op.lval.sdword;
    case 64:
        utils::logger.log("WARNING: 64 bit offsets not implemented");
        return op.lval.sqword;
    default:
        utils::logger.log(fmt::format("WARNING: unknown offset {}", op.offset));
        return 0;
    }
};

ud_t *freeUDStructure(ud_t *toFree, bool freeBuffer) {
    if (!toFree) {
        return nullptr;
    }
    if (freeBuffer) {
        free((void *)toFree->inp_buf);
    }
    free(toFree);
    return nullptr;
}
} // namespace deobf::library::glue
