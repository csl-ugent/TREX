#include "taint.h"

#include "csv_writer.h"
#include "flags.h"
#include "instr_utils.h"
#include "mem_sim_utils.h"
#include "persistent_storage.h"
#include "utils.h"

namespace deobf::library::taint {

using namespace deobf::library::memory_simulation;
using namespace deobf::library::instruction_utils;

using deobf::library::utils::logger;

inline bool isStartMarker(const std::shared_ptr<InstrList>& iList, const Instruction *ins) {
    return ins->order >= iList->startMarker && ins->order <= utils::lastStartMarkerOrder(iList);
}

/**
 * An operand is not tainted if it is:
 * - An immediate
 * - A register and that register is not marked as tainted
 * - Memory and that memory location is not marked as tainted
 */
inline bool opIsNotTainted(ud_operand_t *op, const std::shared_ptr<InstrList>& iList, const Instruction *ins, const std::shared_ptr<BitDataDep>& dataBitLevel) {
    return op->type == UD_OP_IMM || (op->type == UD_OP_REG && !dataBitLevel->isRegisterTainted(glue::toDeobfRegister(op->base))) ||
           (op->type == UD_OP_MEM && !MemoryLocIsTainted(iList, ins->memUsedMin, ins->memUsedSize));
}

void ClearMemAddrTaint(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t size) {
    UntaintMemoryLoc(iList, addr, size);
    SetMemoryLocPointer(iList, addr, nullptr);
}

void AddMemAddrTaint(const std::shared_ptr<InstrList>& iList, ADDRESS addr, TaintBlock *b) {
    for (uint i = 0; i < b->Size(); i++) {
        TaintMemoryLoc(iList, addr + i, 1, 0);
        SetMemoryLocPointer(iList, addr + i, reinterpret_cast<void *>(b->GetTByte(i)));
    }
}

TaintBlock *GetMemAddrTaint(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint size) {
    auto *block = new TaintBlock();
    for (uint i = 0; i < size; i++) {
        auto *tmp = (TByte *)GetMemoryLocPointer(iList, addr + i);
        if (tmp == nullptr) {
            tmp = new TByte(DATAFLAG_CONST, 0);
            SetMemoryLocPointer(iList, addr + i, reinterpret_cast<void *>(tmp));
        }
        block->AddByte(tmp);
    }
    return block;
}

bool HandleArithmeticBitsWithMapping(const std::shared_ptr<InstrList>& iList, Instruction *ins, const std::shared_ptr<BitDataDep>& dataDep) {
    ud_mnemonic_code_t opcode = ins->uInstr.mnemonic;
    ud_operand_t *op0 = &(ins->uInstr.operand[0]);
    ud_operand_t *op1 = &(ins->uInstr.operand[1]);
    ud_operand_t *op2 = &(ins->uInstr.operand[2]);

    TaintBlock *op0Val {};
    TaintBlock *op1Val {};
    TaintBlock *op2Val {};
    uint op1ConstVal = 0;
    uint op0ConstVal = 0;
    uint op2ConstVal = 0;

    bool op1Const = false;
    bool op0Const = false;
    bool op2Const = false;

    if (op0->type == UD_OP_MEM) {
        uint64_t addr = ins->memDefMin;
        uint8_t size = ins->memDefSize;
        if (op0->access == UD_OP_ACCESS_READ) {
            addr = ins->memUsedMin;
            size = ins->memUsedSize;
        }
        op0Val = GetMemAddrTaint(iList, addr, size);
        op0ConstVal = GetMemoryLocValue(iList, addr, size);
        if (!MemoryLocIsTainted(iList, addr, size)) {
            op0Const = true;
        }
    } else if (op0->type == UD_OP_REG) {
        DeobfRegister op0R = glue::toDeobfRegister(op0->base);
        op0Val = dataDep->getRegBitVars(op0R);
        op0ConstVal = GetRegisterValue(ins, op0R);
        if (!dataDep->isRegisterTainted(op0R)) {
            op0Const = true;
        }
    }

    if (op1->type == UD_OP_MEM) {
        op1Val = GetMemAddrTaint(iList, ins->memUsedMin, ins->memUsedSize);
        op1ConstVal = GetMemoryLocValue(iList, ins->memUsedMin, ins->memUsedSize);
        if (!MemoryLocIsTainted(iList, ins->memUsedMin, ins->memUsedSize)) {
            op1Const = true;
        }
    } else if (op1->type == UD_OP_REG) {
        DeobfRegister op1R = glue::toDeobfRegister(op1->base);
        op1Val = dataDep->getRegBitVars(op1R);
        op1ConstVal = GetRegisterValue(ins, op1R);
        if (!dataDep->isRegisterTainted(op1R)) {
            op1Const = true;
        }
    } else if (op1->type != UD_NONE) { // constant
        op1Const = true;
        op1ConstVal = op1->lval.sdword; // the const value itself if the operand is constant
    }
    if (op2->type == UD_OP_MEM) {
        op2Val = GetMemAddrTaint(iList, ins->memUsedMin, ins->memUsedSize);
        op2ConstVal = GetMemoryLocValue(iList, ins->memUsedMin, ins->memUsedSize);
        if (!MemoryLocIsTainted(iList, ins->memUsedMin, ins->memUsedSize)) {
            op1Const = true;
        }
    } else if (op2->type == UD_OP_REG) {
        DeobfRegister op2R = glue::toDeobfRegister(op2->base);
        op2Val = dataDep->getRegBitVars(op2R);
        op2ConstVal = GetRegisterValue(ins, op2R);
        if (!dataDep->isRegisterTainted(op2R)) {
            op2Const = true;
        }
    }
    switch (opcode) {
    case UD_Iadc:
        if (op1Const) {
            op0Val->Adc(op0Const, op1ConstVal, *dataDep->getFlags()); // FIXME: is this correct? op0Const doesn't seem to be correct
        } else if (op0Const) {
            (*op0Val) = op1Val->Adc(*op0Val, op0ConstVal, op1ConstVal, *dataDep->getFlags());
        } else {
            op0Val->Adc(*op1Val, op0ConstVal, op1ConstVal, *dataDep->getFlags());
        }
        break;
    case UD_Inot:
        (*op0Val) = !(*op0Val);
        return op0Val->Tainted();
    case UD_Ishr:
        // not really possible if the second operand is not constant
        (*op0Val) >> op1ConstVal;
        return op0Val->Tainted();
    case UD_Ishl:
        (*op0Val) << op1ConstVal;
        return op0Val->Tainted();
    case UD_Iror:
    case UD_Ircr:
        (*op0Val).Ror(op1ConstVal);
        break;
    case UD_Irol:
    case UD_Ircl:
        (*op0Val).Rol(op1ConstVal);
        if (!(*op0Val)[0].Tainted()) {
            dataDep->removeFlagTaint(PSW_CF);
            ins->flagsDef &= ~PSW_CF;
        }
        break;
    case UD_Iadd:
    case UD_Isub:
    case UD_Imul:
        if (op1Val == nullptr /*&& !op1Const*/) {
            op1Val = op0Val;
            // op0Val = getRegBitVars(dataDep, resizeBaseRegister(DeobfRegister::RAX, getRegisterWidth(op0Val->Size() * 8)));
            // FIXME: this might not cover all cases.
            DeobfRegister implR = DeobfRegister::RAX;
            [[maybe_unused]] TaintBlock *old {};
            if (opcode == UD_Imul) {
                implR = glue::toDeobfRegister(ins->uInstr.impl_dst1);
                old = dataDep->getRegBitVars(utils::resizeBaseRegister(DeobfRegister::RAX, utils::getRegisterWidth(op0Val->Size() * 8)));
            }
            DeobfRegister impl = utils::resizeBaseRegister(utils::getBaseRegister(implR), utils::getRegisterWidth(op0Val->Size() * 8));
            op0Val = dataDep->getRegBitVars(impl);
            if (opcode == UD_Imul) {
                assert(*op0Val == *old);
            }
        }
        if (op1Const) {
            op0Val->Add(op0ConstVal, op1ConstVal);
        } else {
            op0Val->Add(*op1Val, op0ConstVal, op1ConstVal);
        }
        return op0Val->Tainted();
    case UD_Ixor:
        if (op1Const) {
            (*op0Val) = (*op0Val) ^ op1ConstVal;
        } else if (op0Const) {
            (*op0Val) = (*op1Val) ^ op0ConstVal;
        } else {
            op0Val->Xor(*op1Val, op0ConstVal, op1ConstVal);
        }
        return op0Val->Tainted();
    case UD_Iand:
        if (op1Const) {
            (*op0Val) = (*op0Val) & op1ConstVal;
        } else if (op0Const) {
            (*op0Val) = (*op1Val) & op0ConstVal;
        } else {
            (*op0Val) &= (*op1Val);
        }
        return op0Val->Tainted();
    case UD_Ior:
        if (op1Const) {
            (*op0Val) = (*op0Val) | op1ConstVal;
        } else if (op0Const) {
            (*op0Val) = (*op1Val) | op0ConstVal;
        } else {
            (*op0Val) = (*op0Val) | (*op1Val);
        }
        return op0Val->Tainted();
    case UD_Ipor:
        (*op0Val) = (*op0Val) | (*op1Val);
        return op0Val->Tainted();
    case UD_Ivpor:
        (*op0Val) = (*op1Val) | (*op2Val);
        return op0Val->Tainted();
    case UD_Ipsubb:
        op0Val->Add(*op1Val, op0ConstVal, op1ConstVal);
        return op0Val->Tainted();
    case UD_Ivpandn:
        *op0Val = ((!*op1Val) & *op2Val);
        return op0Val->Tainted();
    case UD_Ivpand:
        *op0Val = (*op1Val & *op2Val);
        return op0Val->Tainted();
    case UD_Ivpsubb:
        op1Val->Add(*op2Val, op1ConstVal, op2ConstVal);
        *op0Val = *op1Val;
        return op0Val->Tainted();
    case UD_Ivpaddd:
        op1Val->Add(*op2Val, op1ConstVal, op2ConstVal);
        *op0Val = *op1Val;
        return op0Val->Tainted();
    case UD_Ivpxor:
        if (op2Const) {
            (*op0Val) = (*op1Val) ^ op2ConstVal;
        } else if (op1Const) {
            (*op0Val) = (*op2Val) ^ op1ConstVal;
        } else {
            *op0Val = *op1Val;
            op0Val->Xor(*op2Val, op1ConstVal, op2ConstVal);
        }
        return op0Val->Tainted();
    case UD_Ipxor:
        op0Val->Xor(*op1Val, op0ConstVal, op1ConstVal);
        return op0Val->Tainted();
    case UD_Ibswap: {
        auto *tmp = new TaintBlock();
        for (int idx = op0Val->Size() - 1; idx > 0; idx--) {
            tmp->AddByte(op0Val->GetTByte(idx));
        }
        *op0Val = *tmp;
        return op0Val->Tainted();
    }
    default:
        logger.verbose(fmt::format("[HandleArithmeticBits] Warning: arithmetic opcode {} not handled: {}", ud_lookup_mnemonic(opcode), ins->order));
        break;
    }
    return true; // Consider all non-handled cases as tainted
}

void ForwardTaintAnalysis::annotate() {
    if (taintInputs != nullptr && !taintInputs->empty()) {
        logger.log("Skipping forward annotation due to taintInputs");
        return;
    }
    if (logger.isDebugEnabled()) {
        logger.startPhase("Forward annotation");
    }
    std::vector<std::string> inputFtnToSkip{"lstrcpy", "strcpy", "malloc", "toupper"};
    Instruction *iins = nullptr;
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};

    ClearConstantPages(iList);

    setCurrentInstr(iList, iList->lastBaseModuleInstr);
    while ((iins = fetchPrevInstr(iList)) != nullptr && iins->order > 0) {
        /**
         * Process library/system code. Taint all instructions that write to constant memory locations or that define RAX.
         */
        if (!instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
            // Current position
            int afterFunc = iins->order;

            // Find start of function to identify the name (if possible)
            Instruction *prev = nullptr;
            while (iins != nullptr && !instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
                prev = iins;
                iins = fetchPrevInstr(iList);
            }
            std::string ftnName = persistentStorage.functionNameForIdx(prev->funcName);
            if (std::any_of(inputFtnToSkip.cbegin(), inputFtnToSkip.cend(), [ftnName](const std::string &ftnToSkip) { return ftnToSkip == ftnName; })) {
                ClearConstantPages(iList);
                break;
            }

            // Go back to the end of the library/system code.
            setCurrentInstr(iList, afterFunc);
            iins = fetchInstr(iList, afterFunc);

            // Apply taint until we reach program code.
            bool eaxMarked = false;
            do {
                regsDefined = definedRegistersForInstruction(iList, iins).resetRelated(DeobfRegister::RSP);
                regsUsed = usedRegistersForInstruction(iList, iins).resetRelated(DeobfRegister::RSP);

                if (regsUsed.none() && regsDefined.none() && iins->memUsedMin == 0 && iins->memDefMin == 0) {
                    if (iins->uInstr.mnemonic == UD_Inop) {
                        instrSetFlag(iins, INSTR_IS_DELETED, __LINE__);
                        SaveInstrChange(iList, iins);
                    }
                    iins = fetchPrevInstr(iList);
                    continue;
                }

                regsDefined = definedRegistersForInstruction(iList, iins);
                bool writesToConstMemLoc = instrHasFlag(iins, INSTR_WRITES_MEM) && MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize);
                bool definesRAX = regsDefined.hasAnyOf(relatedRegistersLower(DeobfRegister::RAX));
                if (writesToConstMemLoc || (!eaxMarked && definesRAX)) {
                    instrSetFlag(iins, INSTR_FORWARD_TAINTED, __LINE__);
                    instrSetFlag(iins, INSTR_INPUT_SYMBOLIC, __LINE__);
                    instrSetFlag(iins, INSTR_UNSIMPLIFIABLE, __LINE__);
                    SaveInstrChange(iList, iins);
                    if (definesRAX) {
                        eaxMarked = true;
                    }
                }

                if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                    UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                }

                iins = fetchPrevInstr(iList);
            } while (iins != nullptr && !instrHasFlag(iins, INSTR_IN_BASE_MODULE));
        }
        if (iins == nullptr) {
            return;
        }
        if (iins->order == utils::lastStartMarkerOrder(iList)) {
            setCurrentInstr(iList, iins->order - 3);
            continue;
        }

        regsDefined = definedRegistersForInstruction(iList, iins).resetRelated(DeobfRegister::RSP);

        if (instrHasFlag(iins, INSTR_READS_MEM) && regsDefined.any()) {
            SetAddrAsConst(iList, iins->memUsedMin, iins->memUsedSize);
        }

        if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
            UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
        }
    }
    if (logger.isDebugEnabled()) {
        logger.endPhase();
    }
}

void ForwardTaintAnalysis::propagate() {
    if (logger.isDebugEnabled()) {
        logger.startPhase("Forward propagation");
    }
    Instruction *iins {};
    Instruction *prev {};
    ud_operand_t *op0 {};
    ud_operand_t *op1 {};
    enum ud_mnemonic_code opcode;
    DeobfRegisterUses regsDefined {};
    DeobfRegisterUses regsUsed {};
    DeobfRegisterUses regsNonMemory {};

    PSW_BITVECTOR flagsDef {};
    PSW_BITVECTOR flagsUsed {};

    auto dataBitLevel = std::make_shared<BitDataDep>();
    std::map<DeobfRegister, ADDRESS> taintRegOrigin {};
    std::map<ADDRESS, ADDRESS> taintMemOrigin {};

    auto calleeSaved = std::make_unique<std::map<DeobfRegister, TaintBlock *>>();

    TaintBlock *op0Val {};
    TaintBlock *op1Val {};
    bool forwardTainted = false;

    bool onlyAnnotateGiven = taintInputs != nullptr && !taintInputs->empty();
    std::map<std::string, uint8_t> syscallCounts {};
    if (onlyAnnotateGiven) {
        for (const auto& taintInput : *taintInputs) {
            syscallCounts.emplace(taintInput.first, 1);
        }
    }

    ClearConstantPages(iList);

    setCurrentInstr(iList, start);
    while ((iins = fetchNextInstr(iList)) != nullptr) {
        DEBUG(3, fmt::format("FT Processing {} - {:#x} - {}", iins->order, iins->addr, *iins));

        // Test for babrath_switch_std_trace to taint argc/argv (argc in RDI, argv at 0x7fff7564fa02)
        /*if (iins->addr == 0x00401060) {
            dataBitLevel->taintRegister(DeobfRegister::RDI);
            dataBitLevel->applyRegTaintWithMask(0xffffffff, relatedRegistersLower(DeobfRegister::RDI), iins->order);
            TaintBlock taint;
            for (uint8_t i = 0; i < 15; i++) {
                taint.AddByte(new TByte(0xffffffffff, iins->order));
            }
            AddMemAddrTaint(iList, 0x7fff7564fa02, &taint); // TODO: determine this from trace, possibly add this in meta data?
            if (logger.isDebugEnabled()) {
                taintMemOrigin[iins->memDefMin] = iins->addr;
            }
        }*/

        if (prev != nullptr && (instrHasFlag(prev, INSTR_IN_BASE_MODULE) && !instrHasFlag(iins, INSTR_IN_BASE_MODULE))) {
            instrSetFlag(prev, INSTR_USED_AS_CALL, __LINE__);
            SaveInstrChange(iList, prev);
        }

        if (isStartMarker(iList, iins)) {
            continue;
        }

        if (onlyAnnotateGiven && SyscallTaint::isSyscall(utils::traceInfo.is64bit(), iins)) {
            DEBUG(2, fmt::format("Process syscall, eax = {}", iins->eax));
            auto [syscallName, syscallHandler] = syscallTaint.findHandler(utils::traceInfo.is64bit(), iins->eax);
            if (!syscallName.empty()) {
                DEBUG(2, fmt::format("Found handler for syscall, current count is at {}", syscallCounts[syscallName]));
                auto &indexes = (*taintInputs)[syscallName];
                if (indexes.find(syscallCounts[syscallName]) != indexes.end()) {
                    DEBUG(2, "Handle syscall, it is in the list");
                    auto specialValue = indexes[syscallCounts[syscallName]];
                    auto result = syscallHandler(iins, utils::traceInfo.is64bit());
                    for (const auto &r : result.registers.affectedRegisters()) {
                        dataBitLevel->taintRegisterRelated(r);
                        dataBitLevel->applyRegTaintWithMask(TAINT_GENERIC, relatedRegistersLower(r), iins->order);
                        if (logger.isDebugEnabled()) {
                            taintRegOrigin[r] = iins->addr;
                        }
                    }
                    for (const auto &memLoc : result.memory) {
                        size_t taintSize = memLoc.second;
                        if (syscallName == "read" && specialValue != SyscallTaint::NO_EXTRA_VALUE) {
                            taintSize = specialValue;
                        }
                        DEBUG(2, fmt::format("Tainting memory at {:#x} for {}", memLoc.first, taintSize));
                        TaintBlock taint;
                        for (size_t i = 0; i < taintSize; i++) {
                            taint.AddByte(new TByte(TAINT_GENERIC, iins->order));
                        }
                        AddMemAddrTaint(iList, memLoc.first, &taint);
                        if (logger.isDebugEnabled()) {
                            taintMemOrigin[memLoc.first] = iins->addr;
                        }
                    }
                }
                syscallCounts[syscallName]++;
            } else {
                DEBUG(3, "No handler for syscall, ignore");
            }
            continue;
        }

        regsDefined = definedRegistersForInstruction(iList, iins);
        regsUsed = usedRegistersForInstruction(iList, iins);
        regsNonMemory = definedNonMemoryRegistersForInstruction(iList, iins);

        opcode = iins->uInstr.mnemonic;
        op0 = &(iins->uInstr.operand[0]);
        op1 = &(iins->uInstr.operand[1]);

        if (isXorOfSameReg(iins)) {
            ud_t *udins_new = UDCreate::movImmToReg(op0->base, 0, iins, __LINE__);

            carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udins_new, true, __LINE__);
            SaveInstrChange(iList, iins);

            regsDefined = definedRegistersForInstruction(iList, iins);
            regsUsed = usedRegistersForInstruction(iList, iins);

            opcode = iins->uInstr.mnemonic;
            op0 = &(iins->uInstr.operand[0]);
            op1 = &(iins->uInstr.operand[1]);
        }

        /* Transform 3 xors to a xchg instruction */
        if (opcode == UD_Ixor) {
            Instruction *tmp = nullptr;
            if ((tmp = ThreeXorsToXchg(iList, iins)) != nullptr) {
                regsDefined = definedRegistersForInstruction(iList, iins);
                regsUsed = usedRegistersForInstruction(iList, iins);

                opcode = iins->uInstr.mnemonic;
                op0 = &(iins->uInstr.operand[0]);
                op1 = &(iins->uInstr.operand[1]);
            } else {
                setCurrentInstr(iList, iins->next);
            }
        }

        // transform xchg op1,op2, not op2, xchg op1,op2 to not op1!
        if (opcode == UD_Ixchg) {
            Instruction *tmp = nullptr;
            if ((tmp = TransformXchgNotXchgToNot(iList, iins)) != nullptr) {
                regsDefined = definedRegistersForInstruction(iList, iins);
                regsUsed = usedRegistersForInstruction(iList, iins);

                opcode = iins->uInstr.mnemonic;
                op0 = &(iins->uInstr.operand[0]);
                op1 = &(iins->uInstr.operand[1]);
            } else {
                setCurrentInstr(iList, iins->next);
            }
        }

        if ((isPush(iins) || isPop(iins))) {
            if (UDOpIsRegister(op0) == UD_R_ESP) {
                if (iins->uInstr.mnemonic == UD_Ipop) {
                    regsUsed.resetRelated(DeobfRegister::RSP);
                } else if (iins->uInstr.mnemonic == UD_Ipush) {
                    regsDefined.resetRelated(DeobfRegister::RSP);
                }
            } else {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }

        // remove tainted registers when returning from an API except EAX!
        if (!onlyAnnotateGiven && prev != nullptr && (instrHasFlag(iins, INSTR_IN_BASE_MODULE) && !instrHasFlag(prev, INSTR_IN_BASE_MODULE))) {
            DEBUG(3, "Reset taint due return from API call");
            auto returnRegs = utils::ABITool::returnRegisters().affectedRegisters();

            dataBitLevel->removeTaintForAllRegisters();
            for (auto r : returnRegs) {
                DEBUG(5, fmt::format("Mark {} as tainted (return value register)", r));
                dataBitLevel->taintRegisterRelated(r);
                dataBitLevel->applyRegTaintWithMask(TAINT_GENERIC, relatedRegistersLower(r), iins->order);
            }
            for (auto &saved : *calleeSaved) {
                DEBUG(5, fmt::format("Restoring taint of {}", saved.first));
                dataBitLevel->taintRegisterRelated(saved.first);
                int regIndex = BitDataDep::getTaintIndex(saved.first);
                uint8_t size = utils::getRegisterByteWidth(saved.first);
                for (uint8_t i = 0; i < size; i++) {
                    dataBitLevel->setRegsTByteAtIndex(regIndex + i, saved.second->GetTByte(i));
                }
                delete saved.second;
            }
            calleeSaved->clear();
        }

        // remove tainted registers when entering an API!
        if (!onlyAnnotateGiven && prev != nullptr && (!instrHasFlag(iins, INSTR_IN_BASE_MODULE) && instrHasFlag(prev, INSTR_IN_BASE_MODULE))) {
            DEBUG(3, "Clear taint; entering API");
            dataBitLevel->removeTaintForNonParameterRegisters();
        }

        forwardTainted = false;
        opcode = iins->uInstr.mnemonic;
        op0 = &(iins->uInstr.operand[0]);
        op1 = &(iins->uInstr.operand[1]);

        flagsDef = FlagsDef(iins);
        flagsUsed = FlagsUsed(iins);

        if ((isCondJump(iins) && !dataBitLevel->allUsedFlagsTainted(flagsUsed)) && !instrHasFlag(iins, INSTR_UNTOUCHABLE)) {
            instrSetFlag(iins, INSTR_IS_DELETED, __LINE__);
            SaveInstrChange(iList, iins);
            continue;
        }
        if (opcode == UD_Ior || opcode == UD_Iand || opcode == UD_Itest || opcode == UD_Ixor) {
            flagsDef &= ~(PSW_CF | PSW_OF);
        }

        if (instrHasFlag(iins, INSTR_FORWARD_TAINTED)) {
            if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                TaintBlock taint;
                for (uint8_t i = 0; i < iins->memDefSize; i++) {
                    taint.AddByte(new TByte(0xffffffffff, iins->order));
                }
                AddMemAddrTaint(iList, iins->memDefMin, &taint);
                if (logger.isDebugEnabled()) {
                    taintMemOrigin[iins->memDefMin] = iins->addr;
                }
            }
            if (regsDefined.any()) {
                const DeobfRegisterUses related = relatedRegistersLower(regsDefined);
                dataBitLevel->taintRegisters(related);
                dataBitLevel->applyRegTaintWithMask(0xffffffff, regsDefined, iins->order);
                if (logger.isDebugEnabled()) {
                    for (auto &reg : related.affectedRegisters()) {
                        taintRegOrigin[reg] = iins->addr;
                    }
                }
            }
        } else {
            if (!(opcode == UD_Ixor && op0->base == iins->uInstr.operand[1].base)) {
                if (instrHasFlag(iins, INSTR_READS_MEM) && MemoryLocIsTainted(iList, iins->memUsedMin, iins->memUsedSize)) {
                    instrSetFlag(iins, INSTR_FORWARD_TAINTED, __LINE__);
                    DEBUG(3, fmt::format("Setting FT (mem) on {:#x} from source {:#x} (tainted mem: {:#x} - {:#x})", iins->addr, taintMemOrigin[iins->memUsedMin], iins->memUsedMin, iins->memUsedMin + iins->memUsedSize));
                    if (dumpAsDot) {
                        ADDRESS origin = taintMemOrigin[iins->memUsedMin];
                        if (origin == 0x0) {
                            // FIXME: exact source might not be fully correct;
                            ADDRESS lowest = iins->memUsedMin > 1024 ? iins->memUsedMin - 1024 : 0;
                            for (ADDRESS taintSource = iins->memUsedMin + iins->memUsedSize; taintSource >= lowest; taintSource--) {
                                if (!MemoryLocIsTainted(iList, taintSource, 1)) {
                                    continue;
                                }
                                origin = taintMemOrigin[taintSource];
                                if (origin != 0x0) {
                                    break;
                                }
                            }
                            if (origin == 0x0) {
                                origin = 0xDEADBEEF;
                            }
                        }
                        *dotOutput << fmt::format(R"("{:#x}" -> "{:#x}" [style=dotted])", origin, iins->addr) << std::endl;
                    }
                }
                if (dataBitLevel->taintedRegistersFor(regsUsed).any()) {
                    instrSetFlag(iins, INSTR_FORWARD_TAINTED, __LINE__);
                    if (logger.isDebugEnabled()) {
                        auto actual = dataBitLevel->taintedRegistersFor(regsUsed);
                        for (auto &ar : actual.affectedRegisters()) {
                            if (taintRegOrigin.find(ar) != taintRegOrigin.end()) {
                                DEBUG(3, fmt::format("Setting FT (reg) on {:#x} from source {:#x} - reg {}", iins->addr, taintRegOrigin[ar], ar));
                                if (dumpAsDot) {
                                    *dotOutput << fmt::format(R"("{:#x}" -> "{:#x}" [style=dashed])", taintRegOrigin[ar], iins->addr) << std::endl;
                                }
                            }
                        }
                    }
                }
                if (dataBitLevel->anyUsedFlagTainted(flagsUsed)) {
                    instrSetFlag(iins, INSTR_FORWARD_TAINTED, __LINE__);
                    DEBUG(3, fmt::format("Setting FT (flag) on {:#x}", iins->addr));
                    if (dumpAsDot) {
                        *dotOutput << fmt::format(R"("FIXME" -> "{:#x}" [style=bold])", iins->addr) << std::endl;
                    }
                }
            }
            if (instrHasFlag(iins, INSTR_FORWARD_TAINTED) && !(opcode == UD_Ixor && op0->base == iins->uInstr.operand[1].base)) {
                SaveInstrChange(iList, iins);

                DeobfRegister op1Base = glue::toDeobfRegister(op1->base);
                DeobfRegister op0Base = glue::toDeobfRegister(op0->base);
                if (opcode == UD_Ixchg) {
                    bool op0Tainted = false;
                    bool op1Tainted = false;
                    int opSize = 0;
                    if (op0->type == UD_OP_REG) {
                        op0Val = dataBitLevel->getRegBitVars(op0Base);
                        opSize = utils::getRegisterByteWidth(op0Base);
                        if (dataBitLevel->isRegisterTainted(op0Base)) {
                            op0Tainted = true;
                        }
                    } else {
                        op0Val = GetMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                        op0Tainted = MemoryLocIsTainted(iList, iins->memDefMin, iins->memDefSize);
                        opSize = iins->memDefSize;
                    }
                    if (op1->type == UD_OP_REG) {
                        op1Val = dataBitLevel->getRegBitVars(op1Base);
                        if (dataBitLevel->isRegisterTainted(op1Base)) {
                            op1Tainted = true;
                        }
                    } else {
                        op1Val = GetMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                        op1Tainted = MemoryLocIsTainted(iList, iins->memDefMin, iins->memDefSize);
                    }

                    if (op1Tainted || op0Tainted) {
                        TaintBlock tmp(opSize, 0, 0);
                        tmp = *op0Val;
                        *op0Val = *op1Val;
                        *op1Val = tmp;

                        if (op0->type == UD_OP_MEM) {
                            if (op1Tainted) {
                                SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                                if (logger.isDebugEnabled()) {
                                    taintMemOrigin[iins->memDefMin] = iins->addr;
                                }
                            } else {
                                ClearMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                                if (logger.isDebugEnabled()) {
                                    taintMemOrigin.erase(iins->memDefMin);
                                }
                            }
                        }
                        if (op1->type == UD_OP_MEM) {
                            if (op0Tainted) {
                                SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                                if (logger.isDebugEnabled()) {
                                    taintMemOrigin[iins->memDefMin] = iins->addr;
                                }
                            } else {
                                ClearMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                                if (logger.isDebugEnabled()) {
                                    taintMemOrigin.erase(iins->memDefMin);
                                }
                            }
                        }

                        if (op0->type == UD_OP_REG) {
                            const DeobfRegisterUses related = relatedRegistersLower(op0Base);
                            if (op1Tainted) {
                                dataBitLevel->taintRegisters(related);
                                if (logger.isDebugEnabled()) {
                                    for (auto &reg : related.affectedRegisters()) {
                                        taintRegOrigin[reg] = iins->addr;
                                    }
                                }
                            } else {
                                dataBitLevel->removeTaintForRegisters(related);
                                if (logger.isDebugEnabled()) {
                                    for (auto &reg : related.affectedRegisters()) {
                                        taintRegOrigin.erase(reg);
                                    }
                                }
                            }
                        }
                        if (op1->type == UD_OP_REG) {
                            const DeobfRegisterUses related = relatedRegistersLower(op1Base);
                            if (op0Tainted) {
                                dataBitLevel->taintRegisters(related);
                                if (logger.isDebugEnabled()) {
                                    for (auto &reg : related.affectedRegisters()) {
                                        taintRegOrigin[reg] = iins->addr;
                                    }
                                }
                            } else {
                                dataBitLevel->removeTaintForRegisters(related);
                                if (logger.isDebugEnabled()) {
                                    for (auto &reg : related.affectedRegisters()) {
                                        taintRegOrigin.erase(reg);
                                    }
                                }
                            }
                        }
                    }
                    prev = iins;
                    continue;

                }
                if (opcode == UD_Ipushad) {
                    uint8_t registerWidth = utils::getByteWidth(DeobfRegisterWidth::lower32bit);
                    for (uint8_t k = 0; k < 8; k++) {
                        auto reg = static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + k);
                        if (dataBitLevel->isRegisterTainted(reg)) {
                            TaintBlock *b = dataBitLevel->getRegBitVars(reg);
                            AddMemAddrTaint(iList, iins->esp - (k + 1) * registerWidth, b);
                            forwardTainted = true;
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                        }
                    }
                } else if (opcode == UD_Ipopad) {
                    uint8_t registerWidth = utils::getByteWidth(DeobfRegisterWidth::lower32bit);
                    for (uint8_t k = 0; k < 8; k++) {
                        // Go from EDI to EAX
                        auto reg = static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + (7 - k));
                        if (k == 3) {
                            continue; // skip esp!
                        }
                        ADDRESS address = iins->esp + (k + 0) * registerWidth;
                        if (MemoryLocIsTainted(iList, address, registerWidth)) {
                            forwardTainted = true;
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                            const DeobfRegisterUses related = relatedRegistersLower(reg);
                            dataBitLevel->taintRegisters(related);
                            if (logger.isDebugEnabled()) {
                                for (auto &ar : related.affectedRegisters()) {
                                    taintRegOrigin[ar] = iins->addr;
                                }
                            }
                            TaintBlock *regTaint = dataBitLevel->getRegBitVars(reg);
                            TaintBlock *memTaint = GetMemAddrTaint(iList, address, registerWidth);
                            *regTaint = *memTaint;
                        }
                    }

                } else if (opcode == UD_Ipopfd) {
                    TaintBlock *flags {};
                    flags = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);
                    dataBitLevel->resetTaintedFlags();
                    for (uint8_t i = 0; i < PSW_MAX_INDEX; i++) {
                        if ((*flags)[i].Tainted()) {
                            dataBitLevel->setFlagTaint(1 << i);
                            forwardTainted = true;
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                        }
                    }
                    dataBitLevel->setFlags(*flags);
                } else if (opcode == UD_Ipushfd) {
                    TaintBlock *write {};
                    write = GetMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                    forwardTainted = true;
                    for (uint8_t i = 0; i < PSW_MAX_INDEX; i++) {
                        if (dataBitLevel->isFlagTainted(1 << i)) {
                            (*write)[i] = (*dataBitLevel->getFlags())[i];
                            forwardTainted = true;
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                        } else {
                            (*write)[i].tag = DATAFLAG_CONST;
                        }
                    }
                    if (forwardTainted) {
                        SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                        if (logger.isDebugEnabled()) {
                            taintMemOrigin[iins->memDefMin] = iins->addr;
                        }
                    }
                } else if ((opcode == UD_Itest || opcode == UD_Icmp || opcode == UD_Icmpxchg) &&
                           (opIsNotTainted(op0, iList, iins, dataBitLevel) || opIsNotTainted(op1, iList, iins, dataBitLevel))) {
                    DEBUGLINE(3, fmt::format("test, cmp or cmpxchg and no tainted ops - {} - {}", iins->order, *iins));
                    TaintBlock *t = nullptr;
                    DEOBF_REGISTER_VALUE c = 0;
                    DEOBF_REGISTER_VALUE tMask = 0;
                    uint16_t opSize = 0;
                    if (op0->type == UD_OP_REG) {
                        opSize = utils::getRegisterByteWidth(op0Base);
                        if (dataBitLevel->isRegisterTainted(op0Base)) {
                            t = dataBitLevel->getRegBitVars(op0Base);
                            DEBUG(3, fmt::format("Taint for {} - {}", op0Base, (t == nullptr)));
                        } else {
                            c = GetRegisterValue(iins, op0Base);
                            DEBUG(3, fmt::format("Const value reg set to {}", c));
                        }
                    } else if (op0->type == UD_OP_MEM) {
                        opSize = iins->memUsedSize;
                        if (MemoryLocIsTainted(iList, iins->memUsedMin, iins->memUsedSize)) {
                            t = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);
                            DEBUG(3, fmt::format("Taint for mem {} - {}", iins->memUsedMin, (t == nullptr)));
                        } else {
                            c = GetMemoryLocValue(iList, iins->memUsedMin, iins->memUsedSize);
                            DEBUG(3, fmt::format("Const value mem set to {}", c));
                        }
                    } else {
                        DEBUG(3, fmt::format("Const value set to {}", op0->lval.sdword));
                        opSize = op0->size;
                        c = op0->lval.sdword;
                    }

                    if (op1->type == UD_OP_REG) {
                        if (dataBitLevel->isRegisterTainted(op1Base)) {
                            t = dataBitLevel->getRegBitVars(op1Base);
                            DEBUG(3, fmt::format("Taint for {} - {}", op0Base, (t == nullptr)));
                        } else {
                            c = GetRegisterValue(iins, op1Base);
                            DEBUG(3, fmt::format("Const value reg set to {}", c));
                        }
                    } else if (op1->type == UD_OP_MEM) {
                        if (MemoryLocIsTainted(iList, iins->memUsedMin, iins->memUsedSize)) {
                            t = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);
                            DEBUG(3, fmt::format("Taint for mem {} - {}", iins->memUsedMin, (t == nullptr)));
                        } else {
                            c = GetMemoryLocValue(iList, iins->memUsedMin, iins->memUsedSize);
                            DEBUG(3, fmt::format("Const value mem set to {}", c));
                        }
                    } else {
                        DEBUG(3, fmt::format("Const value set to {}", op1->lval.sdword));
                        c = op1->lval.sdword; // FIXME: does this hold for 64 bit?
                    }
                    if (t != nullptr) {
                        TaintBlock tmp1(opSize, 0, 0);
                        tmp1 = *t;
                        for (uint16_t i = 0; i < opSize * 8; i++) {
                            if (tmp1[i].Tainted()) {
                                DEBUG(3, fmt::format("Tainted for {}", static_cast<DEOBF_REGISTER_VALUE>(1) << i));
                                tMask |= (static_cast<DEOBF_REGISTER_VALUE>(1) << i);
                            }
                        }
                        if (opcode == UD_Itest) {
                            forwardTainted = (tmp1 & c).Tainted();
                        } else { // cmp or cmpxchg
                            forwardTainted = (tMask > c);
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                        }
                    } else {
                        forwardTainted = false;
                        DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                    }
                } else if (opcodeIsArith(opcode) &&
                           (dataBitLevel->taintedRegistersFor(regsUsed).any() || MemoryLocIsTainted(iList, iins->memUsedMin, iins->memUsedSize) ||
                            dataBitLevel->anyUsedFlagTainted(flagsUsed))) {
                    forwardTainted = HandleArithmeticBitsWithMapping(iList, iins, dataBitLevel);
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                    if (!forwardTainted) {
                        instrSetFlag(iins, INSTR_TAINT_CLEARED, __LINE__);
                        Instruction *nextTmp = fetchInstr(iList, iins->next);
                        if (op0->type == UD_OP_MEM) {
                            uint val = GetMemoryLocValue(iList, iins->memDefMin, iins->memDefSize);
                            ud_t *udnew = UDCreate::movImmToOffset(iins->memDefMin, val, iins->memDefSize, iins->eip);
                            carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udnew, false, __LINE__);
                            glue::freeUDStructure(udnew, true);
                        } else {
                            DEOBF_REGISTER_VALUE val = GetRegisterValue(nextTmp, op0->base);
                            ud_t *udnew = UDCreate::movImmToReg(op0->base, val, iins, __LINE__);
                            carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udnew, false, __LINE__);
                            glue::freeUDStructure(udnew, true);
                        }
                        SaveInstrChange(iList, iins);
                    }
                } else if (opcode == UD_Ilea && dataBitLevel->taintedRegistersFor(regsUsed).any()) {
                    forwardTainted = true;
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Ibtc) { // sets cf based on the first operand
                    if (!dataBitLevel->isRegisterTainted(op0Base)) {
                        dataBitLevel->removeFlagTaint(PSW_CF);
                        flagsDef &= ~PSW_CF;
                    }
                    forwardTainted = true;
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Ibswap) {

                } else if (isStringOperation(iins)) {

                } else if (opcode == UD_Icwd || opcode == UD_Icdq) {

                } else if (instrIsSetOnCondition(opcode)) {
                    if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                        forwardTainted = true;
                        DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                        SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                        if (logger.isDebugEnabled()) {
                            taintMemOrigin[iins->memDefMin] = iins->addr;
                        }
                    } else {
                        DeobfRegister definedReg = regsDefined.toDeobfRegister();
                        TaintBlock *bitVars = dataBitLevel->getRegBitVars(definedReg);
                        assert(bitVars != nullptr);
                        for (uint idx = 0; idx < utils::getRegisterByteWidth(definedReg) * 8; idx++) {
                            if (dataBitLevel->isFlagTainted(1 << idx)) {
                                (*bitVars)[idx].tag = (1 << idx);
                                (*bitVars)[idx].src_instr = iins->order;
                                forwardTainted = true;
                                DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                            }
                        }
                    }
                } else if (opcode == UD_Imovzx) {
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    if (iins->uInstr.operand[1].type == UD_OP_REG) {
                        op1Val = dataBitLevel->getRegBitVars(op1Base);
                    } else if (iins->memUsedSize != 0) {
                        op1Val = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);
                    }
                    *op0Val = *op1Val;
                    forwardTainted = op0Val->Tainted();
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if ((opcode == UD_Ipmovmskb || opcode == UD_Ivpmovmskb) && op1->base < UD_R_YMM0) {
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    uint8_t bm;
                    /**
                     * r32[0] ← SRC[7];
                     * r32[1] ← SRC[15];
                     * (* Repeat operation for bytes 2 through 14 *)
                     * r32[15] ← SRC[127];
                     * r32[31:16] ← ZERO_FILL;
                     */
                    for (bm = 0; bm <= 15; bm++) {
                        (*op0Val)[bm] = (*op1Val)[8 * (bm + 1) - 1];
                    }
                    for (; bm <= 31; bm++) {
                        (*op0Val)[bm] = Taint(DATAFLAG_CONST, iins->order);
                    }
                    forwardTainted = op0Val->Tainted();
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Ivpminub && op1->base < UD_R_YMM0) {
                    /**
                     *     IF DEST[7:0] > SRC[7:0] THEN
                     *       DEST[7:0]←SRC[7:0]; FI;
                     *     (* Repeat operation for 2nd through 15th bytes in source and destination operands *)
                     *     IF DEST[127:120] > SRC[127:120] THEN
                     *       DEST[127:120]←SRC[127:120]; FI;
                     */
                    DeobfRegister op2Base = glue::toDeobfRegister(iins->uInstr.operand[2].base);
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    TaintBlock *op2Val = dataBitLevel->getRegBitVars(op2Base);
                    DEOBF_REGISTER_VALUE op1Content = Registers(iins).getRegisterValue(op1Base);
                    DEOBF_REGISTER_VALUE op2Content = Registers(iins).getRegisterValue(op2Base);
                    for (uint8_t b = 0; b <= 15; b++) {
                        uint8_t val1 = (op1Content >> b * 8) & 0xFF;
                        uint8_t val2 = (op2Content >> b * 8) & 0xFF;
                        if (val2 < val1) {
                            *op0Val->GetTByte(b) = *op2Val->GetTByte(b);
                        } else {
                            *op0Val->GetTByte(b) = *op1Val->GetTByte(b);
                        }
                    }
                    forwardTainted = op0Val->Tainted();
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Ivpminud && op1->base < UD_R_YMM0) {
                    /**
                     * IF SRC1[31:0] < SRC2[31:0] THEN
                     *      DEST[31:0] ← SRC1[31:0];
                     * ELSE
                     *      DEST[31:0]←SRC2[31:0]; FI;
                     * (* Repeat operation for 2nd through 3rd dwords in source and destination operands *)
                     * IF SRC1[127:96] < SRC2[127:96] THEN
                     *      DEST[127:96] ← SRC1[127:96];
                     * ELSE
                     *      DEST[127:96]←SRC2[127:96]; FI;
                     */
                    DeobfRegister op2Base = glue::toDeobfRegister(iins->uInstr.operand[2].base);
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    TaintBlock *op2Val = dataBitLevel->getRegBitVars(op2Base);
                    DEOBF_REGISTER_VALUE op1Content = Registers(iins).getRegisterValue(op1Base);
                    DEOBF_REGISTER_VALUE op2Content = Registers(iins).getRegisterValue(op2Base);
                    for (uint8_t b = 0; b <= 3; b++) {
                        uint16_t val1 = (op1Content >> b * 32) & 0xFFFFFFFF;
                        uint16_t val2 = (op2Content >> b * 32) & 0xFFFFFFFF;
                        TaintBlock *min = op1Val;
                        if (val2 < val1) {
                            min = op2Val;
                        }
                        *op0Val->GetTByte(b * 4) = *min->GetTByte(b * 4);
                        *op0Val->GetTByte(b * 4 + 1) = *min->GetTByte(b * 4 + 1);
                        *op0Val->GetTByte(b * 4 + 2) = *min->GetTByte(b * 4 + 2);
                        *op0Val->GetTByte(b * 4 + 3) = *min->GetTByte(b * 4 + 3);
                    }
                    forwardTainted = op0Val->Tainted();
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Ipcmpeqb || opcode == UD_Ivpcmpgtb || opcode == UD_Ivpcmpeqb) {
                    forwardTainted = true;
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Icvtsi2sd || opcode == UD_Imovq || opcode == UD_Icvttsd2si) {
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    uint smallest = std::min(op0Val->Size(), op1Val->Size());
                    TaintBlock *source = (op0->access & UD_OP_ACCESS_WRITE) != 0 ? op0Val : op1Val;
                    TaintBlock *dest = (op0->access & UD_OP_ACCESS_WRITE) != 0 ? op1Val : op0Val;
                    // Copy over first half
                    for (uint i = 0; i < smallest * 8; i++) {
                        (*dest)[i] = (*source)[i];
                    }
                    forwardTainted = dest->Tainted();
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Imovlpd) {
                    TaintBlock *dest = dataBitLevel->getRegBitVars(op0Base);
                    if (op0->type == UD_OP_MEM) {
                        dest = GetMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                    }
                    TaintBlock *source = nullptr;
                    if (op1->type == UD_OP_MEM) {
                        if (MemoryLocIsTainted(iList, iins->memUsedMin, iins->memUsedSize)) {
                            source = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);
                        }
                    } else {
                        source = dataBitLevel->getRegBitVars(op1Base);
                    }
                    forwardTainted = false;
                    if (source != nullptr) {
                        uint smallest = std::min(dest->Size(), source->Size());
                        // Copy over first half
                        for (uint i = 0; i < smallest * 8; i++) {
                            (*dest)[i] = (*source)[i];
                        }
                        forwardTainted = dest->Tainted();
                    }
                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                } else if (opcode == UD_Ivpshufb) {
                    /**
                     * for i = 0 to 15 {
                     *   if (SRC2[(i * 8)+7] = 1) then
                     *     DEST[(i*8)+7..(i*8)+0] := 0;
                     *   else
                     *     index[3..0] := SRC2[(i*8)+3 .. (i*8)+0];
                     *     DEST[(i*8)+7..(i*8)+0] := SRC1[(index*8+7)..(index*8+0)];
                     *   endif
                     * }
                     */
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    auto *op2 = &iins->uInstr.operand[2];
                    DEOBF_REGISTER_VALUE op2Val = 0;
                    if (op2->type == UD_OP_MEM) {
                        op2Val = GetMemoryLocValue(iList, iins->memUsedMin, iins->memUsedSize);
                    } else {
                        Registers r(iins);
                        op2Val = r.getRegisterValue(op2->base);
                    }

                    constexpr uint8_t bit_groups = 15;
                    for (uint8_t i = 0; i <= bit_groups; i++) {
                        if ((op2Val & (1 << (bit_groups - i) * 8)) == 1) {
                            // Mark bits DEST[(i*8)+7..(i*8)+0] as not tainted
                            for (uint8_t bit = 0; bit <= 7; bit++) {
                                (*op0Val)[i * 8 + bit].tag = DATAFLAG_CONST;
                            }
                        } else {
                            // index[3..0] := SRC2[(i*8)+3 .. (i*8)+0];
                            auto tmp = op2Val >> ((bit_groups - i) * 8);
                            uint8_t index = tmp & 0xf;

                            // DEST[(i*8)+7..(i*8)+0] := SRC1[(index*8+7)..(index*8+0)];
                            for (uint8_t bit = 0; bit <= 7; bit++) {
                                (*op0Val)[i * 8 + bit] = (*op1Val)[index * 8 + bit];
                            }
                        }
                    }
                } else if (opcode == UD_Ivpsrld) {
                    /**
                     * (KL, VL) = (4, 128), (8, 256), (16, 512)
                     * FOR j := 0 TO KL-1
                     *     i := j * 32
                     *     IF k1[j] OR *no writemask* THEN
                     *         IF (EVEX.b = 1) AND (SRC1 *is memory*)
                     *             THEN // Not supported
                     *             ELSE DEST[i+31:i] := LOGICAL_RIGHT_SHIFT_DWORDS1(SRC1[i+31:i], imm8)
                     *         FI;
                     *     ELSE
                     *         // Not supported
                     *     FI;
                     * ENDFOR
                     * DEST[MAXVL-1:VL] := 0
                     */
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    if (op1->type == UD_OP_MEM) {
                        logger.log("UD_Ivpsrld: op1 as mem is not supported");
                        exit(1);
                    }
                    if (iins->uInstr.operand[2].type != UD_OP_IMM) {
                        logger.log("UD_Ivpsrld: op2 is not an immediate!");
                        exit(1);
                    }
                    uint8_t shiftBy = iins->uInstr.operand[2].lval.ubyte;

                    if (opcode == UD_Ivpsrld && shiftBy > 31) {
                        auto cleared = new TaintBlock(utils::getRegisterByteWidth(op0Base), TAINT_NONE, iins->order);
                        *op0Val = *cleared;
                    } else {
                        auto result = new TaintBlock();
                        for (uint8_t i = 0; i <= 3; i++) {
                            // DEST[i+31:i] := LOGICAL_RIGHT_SHIFT_DWORDS1(SRC1[i+31:i], imm8)

                            // Grab dword, shift it with shiftBy
                            auto tmp = new TaintBlock();
                            tmp->AddByte(op1Val->GetTByte(i*4));
                            tmp->AddByte(op1Val->GetTByte(i*4+1));
                            tmp->AddByte(op1Val->GetTByte(i*4+2));
                            tmp->AddByte(op1Val->GetTByte(i*4+3));
                            *tmp >> shiftBy;
                            // Copy to result
                            result->AddByte(tmp->GetTByte(0));
                            result->AddByte(tmp->GetTByte(1));
                            result->AddByte(tmp->GetTByte(2));
                            result->AddByte(tmp->GetTByte(3));
                        }
                        *op0Val = *result;
                    }
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Ivpslld) {
                    /**
                     * (KL, VL) = (4, 128), (8, 256), (16, 512)
                     * FOR j := 0 TO KL-1
                     *     i := j * 32
                     *     IF k1[j] OR *no writemask* THEN
                     *         IF (EVEX.b = 1) AND (SRC1 *is memory*)
                     *             THEN // Not supported
                     *             ELSE DEST[i+31:i] := LOGICAL_LEFT_SHIFT_DWORDS1(SRC1[i+31:i], imm8)
                     *         FI;
                     *     ELSE
                     *         // Not supported
                     *     FI;
                     * ENDFOR
                     * DEST[MAXVL-1:VL] := 0
                     */
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    if (op1->type == UD_OP_MEM) {
                        logger.log("UD_Ivpslld: op1 as mem is not supported");
                        exit(1);
                    }
                    if (iins->uInstr.operand[2].type != UD_OP_IMM) {
                        logger.log("UD_Ivpslld: op2 is not an immediate!");
                        exit(1);
                    }
                    uint8_t shiftBy = iins->uInstr.operand[2].lval.ubyte;

                    if (opcode == UD_Ivpslld && shiftBy > 31) {
                        auto cleared = new TaintBlock(utils::getRegisterByteWidth(op0Base), TAINT_NONE, iins->order);
                        *op0Val = *cleared;
                    } else {
                        auto result = new TaintBlock();
                        for (uint8_t i = 0; i <= 3; i++) {
                            // DEST[i+31:i] := LOGICAL_LEFT_SHIFT_DWORDS1(SRC1[i+31:i], imm8)

                            // Grab dword, shift it with shiftBy
                            auto tmp = new TaintBlock();
                            tmp->AddByte(op1Val->GetTByte(i*4));
                            tmp->AddByte(op1Val->GetTByte(i*4+1));
                            tmp->AddByte(op1Val->GetTByte(i*4+2));
                            tmp->AddByte(op1Val->GetTByte(i*4+3));
                            *tmp << shiftBy;
                            // Copy to result
                            result->AddByte(tmp->GetTByte(0));
                            result->AddByte(tmp->GetTByte(1));
                            result->AddByte(tmp->GetTByte(2));
                            result->AddByte(tmp->GetTByte(3));
                        }
                        *op0Val = *result;
                    }
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Ivpsrldq) {
                    /**
                     * TEMP := COUNT
                     * IF (TEMP > 15) THEN TEMP := 16; FI
                     * DEST := SRC >> (TEMP * 8)
                     * DEST[MAXVL-1:128] := 0;
                     */
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    if (op1->type == UD_OP_MEM) {
                        logger.log("UD_Ivpsrldq: op1 as mem is not supported");
                        exit(1);
                    }
                    if (iins->uInstr.operand[2].type != UD_OP_IMM) {
                        logger.log("UD_Ivpsrldq: op2 is not an immediate!");
                        exit(1);
                    }
                    uint8_t shiftBy = iins->uInstr.operand[2].lval.ubyte;

                    if (opcode == UD_Ivpsrldq && shiftBy > 15) {
                        shiftBy = 16;
                    }
                    *op1Val >> shiftBy;
                    *op0Val = *op1Val;
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Ivpslldq) {
                    /**
                     * TEMP := COUNT
                     * IF (TEMP > 15) THEN TEMP := 16; FI
                     * DEST := SRC << (TEMP * 8)
                     * DEST[MAXVL-1:128] := 0;
                     */
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    if (op1->type == UD_OP_MEM) {
                        logger.log("UD_Ivpslldq: op1 as mem is not supported");
                        exit(1);
                    }
                    if (iins->uInstr.operand[2].type != UD_OP_IMM) {
                        logger.log("UD_Ivpslldq: op2 is not an immediate!");
                        exit(1);
                    }
                    uint8_t shiftBy = iins->uInstr.operand[2].lval.ubyte;

                    if (opcode == UD_Ivpslldq && shiftBy > 15) {
                        shiftBy = 16;
                    }
                    *op1Val << shiftBy;
                    *op0Val = *op1Val;
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Ivpalignr) {
                    /**
                     * temp1[255:0] := ((SRC1[127:0] << 128) OR SRC2[127:0])>>(imm8*8);
                     * DEST[127:0] := temp1[127:0]
                     * DEST[MAXVL-1:128] := 0
                     */
                    op0Val = dataBitLevel->getRegBitVars(op0Base);
                    op1Val = dataBitLevel->getRegBitVars(op1Base);
                    if (iins->uInstr.operand[2].type == UD_OP_MEM) {
                        logger.log("UD_Ivpalignr: op3 as mem is not supported");
                        exit(1);
                    }
                    auto op2Val = dataBitLevel->getRegBitVars(glue::toDeobfRegister(iins->uInstr.operand[2].base));
                    if (iins->uInstr.operand[3].type != UD_OP_IMM) {
                        logger.log("UD_Ivpalignr: op4 is not an immediate!");
                        exit(1);
                    }
                    uint8_t shiftBy = iins->uInstr.operand[3].lval.ubyte;

                    if (shiftBy > 32) {
                        auto cleared = new TaintBlock(utils::getRegisterByteWidth(op0Base), TAINT_NONE, iins->order);
                        *op0Val = *cleared;
                    } else {
                        auto result = new TaintBlock();
                        for (uint8_t i = 0; i < op1Val->Size(); i++) {
                            result->AddByte(op1Val->GetTByte(i));
                        }
                        for (uint8_t i = 0; i < op2Val->Size(); i++) {
                            result->AddByte(op2Val->GetTByte(i));
                        }
                        *result >> (shiftBy * 8);
                        uint8_t resultSize = result->Size();
                        auto finalResult = new TaintBlock();
                        for (int i = op0Val->Size(); i > 0; i--) {
                            finalResult->AddByte(result->GetTByte(resultSize - i));
                        }
                        *op0Val = *finalResult;
                    }
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Iaeskeygenassist) {
                    /**
                     * X3[31:0] := SRC [127: 96];
                     * X2[31:0] := SRC [95: 64];
                     * X1[31:0] := SRC [63: 32];
                     * X0[31:0] := SRC [31: 0];
                     * RCON[31:0] := ZeroExtend(Imm8[7:0]);
                     * DEST[31:0] := SubWord(X1);
                     * DEST[63:32 ] := RotWord( SubWord(X1) ) XOR RCON;
                     * DEST[95:64] := SubWord(X3);
                     * DEST[127:96] := RotWord( SubWord(X3) ) XOR RCON;
                     * DEST[MAXVL-1:128] (Unmodified)
                     */
                    *op0Val = *op1Val;
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Iaesenc) {
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Iaesdec) {
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Iaesenclast) {
                    forwardTainted = op0Val->Tainted();
                } else if (opcode == UD_Iaesdeclast) {
                    forwardTainted = op0Val->Tainted();
                } else {
                    // extract the taint by looking at things an instruction uses
                    if (instrHasFlag(iins, INSTR_WRITES_MEM) || regsDefined.any()) {
                        TaintBlock *source = nullptr;
                        if (instrHasFlag(iins, INSTR_READS_MEM)) {
                            if (MemoryLocIsTainted(iList, iins->memUsedMin, iins->memUsedSize)) {
                                source = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);
                            } else if (dataBitLevel->taintedRegistersFor(definedMemoryRegistersForInstruction(iins)).any()) {
                                uint8_t blockSize = op0->base == UD_NONE ? utils::traceInfo.getTraceWidthBytes() : utils::getRegisterByteWidth(op0Base);
                                source = new TaintBlock(blockSize, TAINT_GENERIC, iins->order);
                            }
                        }
                        if (opcode == UD_Icmpxchg || opcode == UD_Icmpxchg8b) {
                            // remove 'eax' from the nonMemRegUsed set
                            // so that the next call to GetRegBitVars succeeds with the correct 'source' register
                            // (according to the x86 spec, 'eax' is not a 'source' register)
                            regsNonMemory.reset(utils::resizeBaseRegister(DeobfRegister::RAX, utils::traceInfo.getTraceWidth()));
                            if (opcode == UD_Icmpxchg8b) {
                                regsNonMemory.reset(utils::resizeBaseRegister(DeobfRegister::RDX, utils::traceInfo.getTraceWidth()));
                            }
                        }
                        if (dataBitLevel->taintedRegistersFor(regsNonMemory).any()) {
                            delete source;
                            source = dataBitLevel->getRegBitVars(dataBitLevel->taintedRegistersFor(regsNonMemory).toDeobfRegister());
                            assert(source);
                        }

                        if (instrHasFlag(iins, INSTR_WRITES_MEM) && source != nullptr) {
                            if (opcode == UD_Icmpxchg) {
                                DeobfRegister resized = utils::resizeBaseRegister(DeobfRegister::RAX, utils::traceInfo.getTraceWidth());
                                // value in 'eax' influences the behavior of this instruction
                                DEOBF_REGISTER_VALUE eax_value = GetRegisterValue(iins, resized);

                                // assume used and defed memory are the same
                                assert(iins->memUsedMin == iins->memDefMin);

                                // memory involved in this operation: concrete value and taint information
                                uint dst_value = GetMemoryLocValue(iList, iins->memUsedMin, iins->memUsedSize);
                                TaintBlock *memTaint = GetMemAddrTaint(iList, iins->memUsedMin, iins->memUsedSize);

                                if (eax_value == dst_value) {
                                    // eax==dst: source -> destination
                                    *memTaint = *source;
                                    forwardTainted = memTaint->Tainted();
                                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                                    if (forwardTainted) {
                                        SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                                        if (logger.isDebugEnabled()) {
                                            taintMemOrigin[iins->memDefMin] = iins->addr;
                                        }
                                    }
                                } else {
                                    // eax!=dst: destination -> eax
                                    TaintBlock *regVars = dataBitLevel->getRegBitVars(resized);
                                    *regVars = *memTaint;
                                    forwardTainted = memTaint->Tainted();
                                    DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                                    delete regVars;
                                }

                                delete memTaint;
                            } else if (opcode == UD_Imovsd && source->Size() == 16) {
                                TaintBlock *memWriteVars = nullptr;
                                memWriteVars = GetMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                                // Copy over first half
                                for (uint i = 0; i < memWriteVars->Size() * 8; i++) {
                                    (*memWriteVars)[i] = (*source)[i];
                                }
                                forwardTainted = memWriteVars->Tainted();
                                DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                                delete memWriteVars;
                                if (forwardTainted) {
                                    SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                                    if (logger.isDebugEnabled()) {
                                        taintMemOrigin[iins->memDefMin] = iins->addr;
                                    }
                                }
                            } else {
                                TaintBlock *memWriteVars = nullptr;
                                memWriteVars = GetMemAddrTaint(iList, iins->memDefMin, iins->memDefSize);
                                *memWriteVars = *source;
                                forwardTainted = memWriteVars->Tainted();
                                DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                                delete memWriteVars;
                                if (forwardTainted) {
                                    SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                                    if (logger.isDebugEnabled()) {
                                        taintMemOrigin[iins->memDefMin] = iins->addr;
                                    }
                                }
                            }
                        } else if (regsDefined.any() && source != nullptr) {
                            TaintBlock *regWriteVars = dataBitLevel->getRegBitVars(regsDefined.firstDeobfRegister());
                            *regWriteVars = *source;
                            forwardTainted = regWriteVars->Tainted();
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                            delete regWriteVars;
                            if (!forwardTainted) {
                                DEOBF_REGISTER_VALUE val = 0;
                                if (op0->type == UD_OP_REG) {
                                    val = GetRegisterValue(iins, op1->base);
                                } else if (op1->type == UD_OP_MEM) {
                                    val = GetMemoryLocValue(iList, iins->memUsedMin, iins->memUsedSize);
                                }
                                ud_t *newud = UDCreate::movImmToReg(regsDefined.firstUDRegister(), val, iins, __LINE__);
                                carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), newud, false, __LINE__);
                            }
                        }
                        delete source;
                    } else { // writes flags
                        if (flagsDef != 0) {
                            forwardTainted = true;
                            DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                            dataBitLevel->setFlagsFor(iins->order, flagsDef);
                            dataBitLevel->setFlagTaint(flagsDef);
                        }
                    }

                    if (dataBitLevel->anyUsedFlagTainted(flagsUsed)) {
                        forwardTainted = true;
                        DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                    }
                    if (isControlFlowInstr(iins)) {
                        forwardTainted = true;
                        DEBUGLINE(3, fmt::format("Setting forwardTainted to {} for {:#x}", forwardTainted, iins->addr));
                    }
                }
            }

            if (forwardTainted && opcode != UD_Ipopad) {
                instrSetFlag(iins, INSTR_FORWARD_TAINTED, __LINE__);
                DEBUG(3, fmt::format("Setting FT for {:#x}", iins->addr));
                SaveInstrChange(iList, iins);
                forwardTainted = false;
                const DeobfRegisterUses related = allRelatedRegisters(regsDefined);
                dataBitLevel->taintRegisters(related);
                if (logger.isDebugEnabled()) {
                    for (auto &reg : related.affectedRegisters()) {
                        taintRegOrigin[reg] = iins->addr;
                    }
                }

                if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                    SetMemoryLocTainted(iList, iins->memDefMin, iins->memDefSize);
                    if (logger.isDebugEnabled()) {
                        taintMemOrigin[iins->memDefMin] = iins->addr;
                    }
                }

                if (flagsDef != 0 && opcode != UD_Ipopfd) {
                    dataBitLevel->setFlagTaint(iins->flagsDef);
                }

                if (isCondJump(iins)) {
                    /*
                     * exploit the fact that after a conditional jump, used
                     * flags by conditional are known (e.g., a jnz after a jz
                     * acts like an opaque conditional!)
                     */
                    dataBitLevel->removeFlagTaint(flagsUsed);
                }
            } else {
                const DeobfRegisterUses related = allRelatedRegisters(regsDefined);
                dataBitLevel->removeTaintForRegisters(related);
                if (logger.isDebugEnabled()) {
                    for (auto &reg : related.affectedRegisters()) {
                        taintRegOrigin.erase(reg);
                    }
                }
                instrRemoveFlag(iins, INSTR_FORWARD_TAINTED);
                SaveInstrChange(iList, iins);
                DEBUG(3, fmt::format("Remove FT for {:#x}", iins->addr));
                if (instrHasFlag(iins, INSTR_WRITES_MEM) && MemoryLocIsTainted(iList, iins->memDefMin, iins->memDefSize)) {
                    UntaintMemoryLoc(iList, iins->memDefMin, iins->memDefSize);
                    if (logger.isDebugEnabled()) {
                        taintMemOrigin.erase(iins->memDefMin);
                    }
                }
                if (dataBitLevel->isFlagTainted(flagsDef)) {
                    dataBitLevel->removeFlagTaint(flagsDef);
                }
            }
        }
        prev = iins;
    }
    if (logger.isDebugEnabled()) {
        logger.endPhase();
    }
}
ForwardTaintAnalysis::~ForwardTaintAnalysis() {
    if (dumpAsDot) {
        *dotOutput << "}" << std::endl;
    }
}

void BackwardTaintAnalysis::annotate() {
    if (logger.isDebugEnabled()) {
        logger.startPhase("Backward annotation");
    }
    Instruction *iins {};
    ud_mnemonic_code_t opcode;
    // Assumed convention on 64 bit only: RDI, RSI, RDX, RCX, R8, R9
    DeobfRegisterUses usedRegisters{};

    ClearConstantPages(iList);
    setCurrentInstr(iList, iList->lastInstr);
    iins = fetchPrevInstr(iList);
    while (iins != nullptr) {
        if (logger.isDebugEnabled()) {
            logger.startPhase("Library instructions");
            DEBUG(3, fmt::format("Starting at # {} - {}", (iins ? iins->order : 0), *iins));
        }
        while (iins != nullptr && !instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
            opcode = iins->uInstr.mnemonic;
            if (opcode != UD_Iret && instrHasFlag(iins, INSTR_READS_MEM)) {
                SetMemoryLocationLive(iList, iins->memUsedMin, iins->memUsedSize);
                DEBUG(11, fmt::format("[Mem][{}][{:#x}] alive: {}", iins->order, iins->addr, *iins));
            }

            if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                SetMemoryLocationDead(iList, iins->memDefMin, iins->memDefSize);
                DEBUG(11, fmt::format("[Mem][{}][{:#x}] dead: {}", iins->order, iins->addr, *iins));
            }

            if (utils::traceInfo.is64bit()) {
                auto sources = DeobfRegisterUses(iins->sourceNonMemoryRegisters).resetNonParameterRegisters();
                if (sources.any()) {
                    usedRegisters.set(utils::getBaseRegister(sources.firstDeobfRegister()));
                    DEBUG(3, fmt::format("[Reg][{}][{:#x}] alive: {}", iins->order, iins->addr, sources));
                }

                auto destinations = DeobfRegisterUses(iins->destinationRegisters).resetNonParameterRegisters();
                if (destinations.any()) {
                    usedRegisters.reset(utils::getBaseRegister(destinations.firstDeobfRegister()));
                    DEBUG(3, fmt::format("[Reg][{}][{:#x}] dead: {}", iins->order, iins->addr, destinations));
                }
            }

            iins = fetchPrevInstr(iList);
        }
        if (logger.isDebugEnabled()) {
            DEBUG(3, fmt::format("Ending at # {}", ((iins ? iins->order : 0) + 1)));
            logger.endPhase();
            DEBUG(2, fmt::format("Alive registers: {}", usedRegisters));
            logger.startPhase("Program instructions");
            DEBUG(3, fmt::format("Starting at at # {} - {}", (iins ? iins->order : 0), *iins));
        }
        while (iins != nullptr && instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
            bool writesToLiveMemLoc = instrHasFlag(iins, INSTR_WRITES_MEM) && MemoryLocationIsLive(iList, iins->memDefMin, iins->memDefSize);
            bool untouchable = instrHasFlag(iins, INSTR_UNTOUCHABLE) && iins->order != iList->endMarker + 2 && iins->order != utils::lastStartMarkerOrder(iList);
            if ((iins->uInstr.mnemonic != UD_Ixchg && writesToLiveMemLoc) || untouchable) {
                instrSetFlag(iins, INSTR_BACKWARD_TAINTED, __LINE__);
                instrSetFlag(iins, INSTR_UNSIMPLIFIABLE, __LINE__);
                SaveInstrChange(iList, iins);
                DEBUG(1, fmt::format("Taint {:#x} @ {}: mem ({})", iins->addr, iins->order, *iins));
                SetMemoryLocationDead(iList, iins->memDefMin, iins->memDefSize);
            }
            if (utils::traceInfo.is64bit()) {
                auto destinations = DeobfRegisterUses(iins->destinationRegisters);
                if (destinations.hasAnyOf(relatedRegistersLower(usedRegisters)) || untouchable) {
                    instrSetFlag(iins, INSTR_BACKWARD_TAINTED, __LINE__);
                    instrSetFlag(iins, INSTR_UNSIMPLIFIABLE, __LINE__);
                    SaveInstrChange(iList, iins);
                    DEBUGLINE(1, fmt::format("Taint {:#x} @ {}: reg ({})", iins->addr, iins->order, *iins));
                    usedRegisters.reset(baseRegisters(destinations));
                }
            }
            iins = fetchPrevInstr(iList);
        }
        if (logger.isDebugEnabled()) {
            DEBUG(3, fmt::format("Ending at # {}", ((iins ? iins->order : 0) + 1)));
            logger.endPhase();
        }

        ClearMemoryPages(iList);
        usedRegisters.reset();
    }
    if (logger.isDebugEnabled()) {
        logger.endPhase();
    }
}

void BackwardTaintAnalysis::propagate() {
    if (logger.isDebugEnabled()) {
        logger.startPhase("Backward propagation");
    }
    Instruction *iins {};
    ud_operand_t *op0 {};
    enum ud_mnemonic_code opcode;
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    DeobfRegisterUses regsTainted{};
    DeobfRegisterUses regsNonMemoryUsed{};
    PSW_BITVECTOR flagsUsed {};
    PSW_BITVECTOR flagsDef {};
    PSW_BITVECTOR flagsTainted {};

    if (!checkSumDetection) {
        ClearConstantPages(iList);
    }

    setCurrentInstr(iList, start);

    while ((iins = fetchPrevInstr(iList)) != nullptr) {
        opcode = iins->uInstr.mnemonic;

        regsDefined = relatedRegistersLower(definedRegistersForInstruction(iList, iins));
        regsUsed = relatedRegistersLower(usedRegistersForInstruction(iList, iins));
        regsNonMemoryUsed = relatedRegistersLower(definedNonMemoryRegistersForInstruction(iList, iins));
        flagsUsed = FlagsUsed(iins);
        flagsDef = FlagsDef(iins);
        op0 = &(iins->uInstr.operand[0]);

        if (opcodeIsArith(opcode) && iins->uInstr.operand[1].type == UD_OP_REG && GetRegisterValue(iins, iins->uInstr.operand[1].base) == 0) {
            continue;
        }

        DEBUG(3, fmt::format("BT propagation processing {} - {} - Tainted regs {}", iins->order, *iins, regsTainted));

        if ((isPush(iins) || isPop(iins))) {
            if (UDOpIsRegister(op0) == UD_R_ESP) {
                if (iins->uInstr.mnemonic == UD_Ipop) {
                    regsUsed.resetRelated(DeobfRegister::RSP);
                } else if (iins->uInstr.mnemonic == UD_Ipush) {
                    regsDefined.resetRelated(DeobfRegister::RSP);
                }
            } else {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }

        if (instrHasFlag(iins, INSTR_BACKWARD_TAINTED)) {
            if (instrHasFlag(iins, INSTR_READS_MEM)) {
                SetAddrAsConst(iList, iins->memUsedMin, iins->memUsedSize);
                DEBUG(4, fmt::format("[Mem][{}][{:#x}] alive: {}", iins->order, iins->addr, *iins));
            }
            if (regsNonMemoryUsed.any()) {
                regsTainted.set(regsNonMemoryUsed);
                DEBUG(4, fmt::format("[Reg][{}][{:#x}] alive: {}", iins->order, iins->addr, *iins));
            }
            if (flagsUsed != 0) {
                flagsTainted |= flagsUsed;
                DEBUG(4, fmt::format("[Flag][{}][{:#x}] {}", iins->order, iins->addr, *iins));
            }
            if (instrHasFlag(iins, INSTR_WRITES_MEM) && MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize)) {
                UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                DEBUG(4, fmt::format("[Mem][{}][{:#x}] dead: {}", iins->order, iins->addr, *iins));
            }
        } else {
            bool memLocConstant = MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize);
            if (checkSumDetection) {
                memLocConstant = PartialMemLocIsConstant(iList, iins->memDefMin, iins->memDefSize);
            }
            if (instrHasFlag(iins, INSTR_WRITES_MEM) && memLocConstant) {
                instrSetFlag(iins, INSTR_BACKWARD_TAINTED, __LINE__);
                DEBUG(1, fmt::format("Taint {:#x} @ {}: mem ({})", iins->addr, iins->order, *iins));
            }
            if (regsDefined.hasAnyOf(regsTainted)) {
                instrSetFlag(iins, INSTR_BACKWARD_TAINTED, __LINE__);
                DEBUG(1, fmt::format("Taint {:#x} @ {}: reg ({})", iins->addr, iins->order, *iins));
            }
            if ((flagsDef & flagsTainted) != 0) {
                instrSetFlag(iins, INSTR_BACKWARD_TAINTED, __LINE__);
                DEBUG(1, fmt::format("Taint {:#x} @ {}: flag ({})", iins->addr, iins->order, *iins));
            }
            if (instrHasFlag(iins, INSTR_BACKWARD_TAINTED) && !(opcode == UD_Ixor && op0->base == iins->uInstr.operand[1].base)) {
                SaveInstrChange(iList, iins);
                if (instrHasFlag(iins, INSTR_READS_MEM)) {
                    if (opcode == UD_Ipopad) {
                        uint8_t registerWidth = utils::getByteWidth(DeobfRegisterWidth::lower32bit);
                        for (uint8_t k = 0; k < 8; k++) {
                            // Go from EDI to EAX
                            auto uses = static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + (7 - k));
                            if (regsTainted.test(uses)) {
                                SetAddrAsConst(iList, iins->esp + (k + 0) * registerWidth, registerWidth);
                            }
                        }
                    } else if (opcode != UD_Ixchg) {
                        regsTainted.reset(allRelatedRegisters(regsDefined));
                        if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                            UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                        }
                        SetAddrAsConst(iList, iins->memUsedMin, iins->memUsedSize);
                    }
                }
                if (regsNonMemoryUsed.any()) {
                    if (opcode == UD_Ipushad) {
                        uint8_t offset = 0;
                        uint8_t registerWidth = utils::getByteWidth(DeobfRegisterWidth::lower32bit);
                        for (auto reg : registers32bitMode32bit) {
                            if (MemLocIsConstant(iList, iins->esp - (offset + 1) * registerWidth, registerWidth)) {
                                regsTainted.set(reg);
                            }
                            offset++;
                        }
                    } else if (opcode == UD_Ixchg) {
                        bool regIsTainted = false;
                        if (op0->type == UD_OP_MEM) { // op0 is memory
                            if (MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) {
                                regIsTainted = true;
                            }
                            if (regsTainted.hasNoneOf(regsDefined)) {
                                UnsetConstAddr(iList, iins->memDefMin, iins->memUsedSize, __LINE__);
                            } else {
                                SetAddrAsConst(iList, iins->memDefMin, iins->memDefSize);
                                regsTainted.reset(allRelatedRegisters(regsDefined));
                            }
                            if (regIsTainted) {
                                regsTainted.set(regsDefined);
                            }
                        } else if (iins->uInstr.operand[1].type == UD_OP_MEM) { // op0 is reg
                            if (MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) {
                                regIsTainted = true;
                            }
                            if (regsTainted.hasNoneOf(regsDefined)) {
                                UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                            } else {
                                SetAddrAsConst(iList, iins->memDefMin, iins->memDefSize);
                                regsTainted.reset(allRelatedRegisters(regsDefined));
                            }
                            if (regIsTainted) {
                                regsTainted.set(regsDefined);
                            }
                        } else { // op0 and op1 are regs
                            ud_operand op1 = iins->uInstr.operand[1];
                            auto reg0 = glue::toDeobfRegister(op0->base);
                            auto reg1 = glue::toDeobfRegister(op1.base);
                            if (regsTainted.test(op0->base) && !regsTainted.test(op1.base)) {
                                regsTainted.set(allRelatedRegisters(reg1));
                                regsTainted.reset(allRelatedRegisters(reg0));
                            } else if (regsTainted.hasAnyOf(relatedRegistersLower(reg1)) && regsTainted.hasNoneOf(relatedRegistersLower(reg0))) {
                                regsTainted.set(allRelatedRegisters(reg0));
                                regsTainted.reset(allRelatedRegisters(reg1));
                            }
                        }
                    } else {
                        if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                            UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                        }
                        regsTainted.reset(allRelatedRegisters(regsDefined)).set(regsNonMemoryUsed);
                    }
                }
                if (regsNonMemoryUsed.none() && regsDefined.any()) {
                    regsTainted.reset(allRelatedRegisters(regsDefined));
                }
                if (instrHasFlag(iins, INSTR_WRITES_MEM) && MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize) && opcode != UD_Ixchg) {
                    UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                }
                if (instrHasFlag(iins, INSTR_READS_MEM) && !(opcode == UD_Ipopad || opcode == UD_Ixchg)) {
                    SetAddrAsConst(iList, iins->memUsedMin, iins->memUsedSize);
                }
                if (flagsDef != 0 || flagsUsed != 0) {
                    flagsTainted |= flagsUsed;
                    flagsTainted &= ~flagsDef;
                }
            } else {
                if (instrHasFlag(iins, INSTR_WRITES_MEM) && MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize)) {
                    UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                }
                if (regsDefined.hasAnyOf(regsTainted)) {
                    regsTainted.reset(allRelatedRegisters(regsDefined));
                }
                if ((flagsDef & flagsTainted) != 0) {
                    flagsTainted &= ~flagsDef;
                }
            }
        }
    }
    if (logger.isDebugEnabled()) {
        logger.endPhase();
    }
}

TaintBlock *BitDataDep::getRegBitVars(DeobfRegister reg) {
    auto *tmp = new TaintBlock();
    int regIndex = getTaintIndex(reg);
    if (regIndex == -1) {
        return nullptr;
    }
    uint8_t size = utils::getRegisterByteWidth(reg);
    for (uint8_t i = 0; i < size; i++) {
        tmp->AddByte(&(regsTaint[regIndex + i]));
    }
    return tmp;
}

int BitDataDep::getTaintIndex(const DeobfRegister reg) {
    if (reg == DeobfRegister::NONE) {
        return -1;
    }
    if (reg == DeobfRegister::RIP) {
        return 128; // position 128-135, after the 16 regular 64-bit registers
    }
    if (utils::isXMM(reg)) {
        return 136 + (static_cast<DEOBF_REGISTER>(reg) - DEOBF_REGISTER_OFFSET_XMM) * 16; // after RIP
    }
    auto base = utils::getBaseRegister(reg);
    uint8_t size = 8; // This is linked to the size we reserve in the BitDataDep to hold all taint bytes, and not dependent on the trace size.

    return ((static_cast<DEOBF_REGISTER>(base) - DEOBF_REGISTER_OFFSET_64BITS) * size) + utils::getRegisterLowOrHighOrder(reg);
}

void BitDataDep::applyRegTaintWithMask(uint64_t taint, const DeobfRegisterUses &regs, uint order) {
    for (auto r : regs.affectedRegisters()) {
        auto *regvars = getRegBitVars(r);

        for (uint8_t j = 0; j < utils::getRegisterByteWidth(r) * 8; j++) {
            (*regvars)[j].tag = taint;
            (*regvars)[j].src_instr = order;
        }

        const DeobfRegisterUses related = relatedRegistersLower(r);
        if (taint == DATAFLAG_CONST) {
            taintedRegisters.reset(related);
        } else {
            taintedRegisters.set(related);
        }

        delete regvars;
    }
}
std::unique_ptr<std::map<DeobfRegister, TaintBlock *>> BitDataDep::getTaintForAffectedRegisters(const DeobfRegisterUses& regs) {
    auto result = std::make_unique<std::map<DeobfRegister, TaintBlock *>>();
    auto taintedCalleeSaved = (taintedRegisters & regs).affectedRegisters();
    for (auto r : taintedCalleeSaved) {
        DEBUG(5, fmt::format("Saving taint for {}", r));
        auto *taint = getRegBitVars(r);
        result->emplace(r, taint);
    }
    return result;
}
void BitDataDep::setFlagsFor(uint64_t order, PSW_BITVECTOR usedFlags) {
    for (uint idx = 0; idx < PSW_MAX_INDEX; idx++) {
        uint mask = (1 << idx) & usedFlags;
        if (mask != 0) {
            (*flags)[idx] = *(new Taint(mask, order));
        }
    }
}

std::map<ADDRESS, uint8_t> createTaintOverview(const std::shared_ptr<InstrList>& iList) {
    std::map<ADDRESS, uint8_t> result {};
    Instruction *ins {};

    iList->currentInstr = 0;
    while ((ins = fetchNextInstr(iList)) != nullptr) {
        if(instrHasFlag(ins, INSTR_FORWARD_TAINTED)) {
            result[ins->addr] |= FORWARD_TAINT;
        } else {
            result[ins->addr] |= NO_FORWARD_TAINT;
        }
        if(instrHasFlag(ins, INSTR_BACKWARD_TAINTED)) {
            result[ins->addr] |= BACKWARD_TAINT;
        } else {
            result[ins->addr] |= NO_BACKWARD_TAINT;
        }
    }

    return result;
}

std::string forwardTaintStatus(uint8_t taint) {
    if (hasForwardTaint(taint) && hasNoForwardTaint(taint)) {
        return "partial";
    }
    if (hasForwardTaint(taint)) {
        return "yes";
    }
    return "no";
}
std::string backwardTaintStatus(uint8_t taint) {
    if (hasBackwardTaint(taint) && hasNoBackwardTaint(taint)) {
        return "partial";
    }
    if (hasBackwardTaint(taint)) {
        return "yes";
    }
    return "no";
}
void exportTaintOverview(const std::string &filename, const std::map<ADDRESS, uint8_t>& taints) {
    auto writer = csv_writer::CSVWriter(filename, "address,ft,bt");
    for (auto taint: taints) {
        writer.appendLine(fmt::format("{:#x},{},{}", taint.first, forwardTaintStatus(taint.second), backwardTaintStatus(taint.second)));
        DEBUG(10, fmt::format("Taint for address {:#x}: forward: {} - backward: {}", taint.first, forwardTaintStatus(taint.second), backwardTaintStatus(taint.second)));
    }
}

}