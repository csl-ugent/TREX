/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */
#include "register.h"

#include <cassert>
#include <iostream>

#include "udis86_glue.h"
#include "utils.h"

namespace deobf::library {

DEOBF_REGISTER_VALUE Register::getRegisterValue(DeobfRegisterWidth registerWidth) const {
    switch (registerWidth) {
    case DeobfRegisterWidth::lower128bit:
        return value;
    case DeobfRegisterWidth::lower64bit:
        return value & 0xFFFFFFFFFFFFFFFF;
    case DeobfRegisterWidth::lower32bit:
        return value & 0xFFFFFFFF;
    case DeobfRegisterWidth::lower16bit:
        return value & 0xFFFF;
    case DeobfRegisterWidth::higher8bit:
        return value >> 8 & 0xFF;
    case DeobfRegisterWidth::lower8bit:
        return value & 0xFF;
    }
    utils::logger.log("Unsupported register width; Returning 0, might cause issues!");
    return 0;
}

void Register::setRegisterValue(DeobfRegisterWidth registerWidth, DEOBF_REGISTER_VALUE newValue) {
    switch (registerWidth) {
    case DeobfRegisterWidth::lower128bit:
        value = newValue;
        break;
    case DeobfRegisterWidth::lower64bit:
        value = (value >> 64) << 64;
        value |= (newValue & 0xFFFFFFFFFFFFFFFF);
        break;
    case DeobfRegisterWidth::lower32bit:
        value = value & 0xFFFFFFFF00000000;
        value |= (newValue & 0xFFFFFFFF);
        break;
    case DeobfRegisterWidth::lower16bit:
        value = value & 0xFFFFFFFFFFFF0000;
        value |= (newValue & 0xFFFF);
        break;
    case DeobfRegisterWidth::higher8bit:
        value = value & 0xFFFFFFFFFFFF00FF;
        value |= (newValue & 0xFF) << 8;
        break;
    case DeobfRegisterWidth::lower8bit:
        value = value & 0xFFFFFFFFFFFFFF00;
        value |= (newValue & 0xFF);
        break;
    }
}

DeobfRegisterUses &DeobfRegisterUses::setRelated(DeobfRegister r) {
    set(relatedRegisters(r));
    return *this;
}

DeobfRegisterUses &DeobfRegisterUses::resetRelated(DeobfRegister r) {
    reset(relatedRegisters(r));
    return *this;
}

DeobfRegisterUses &DeobfRegisterUses::resetNonParameterRegisters() {
    *this &= utils::ABITool::parameterRegisters();
    return *this;
}

DEOBF_REGISTER_BITMASK DeobfRegisterUses::toRegisterBitmask() const {
    DEOBF_REGISTER_BITMASK result = 0;
    for (size_t i = 0; i < items.size(); i++) {
        if (items.test(i)) {
            result += (static_cast<DEOBF_REGISTER_BITMASK>(1) << i);
        }
    }
    return result;
}

DeobfRegisterUses::DeobfRegisterUses(DEOBF_REGISTER_BITMASK bitmask) {
    items.reset();
    DEOBF_REGISTER_BITMASK mask;
    for (size_t i = 0; i < items.size(); i++) {
        mask = static_cast<DEOBF_REGISTER_BITMASK>(1) << i;
        items[i] = (bitmask & mask) >> i;
    }
}

DeobfRegister DeobfRegisterUses::toDeobfRegister() const {
    assert(items.count() < 2);
    for (size_t i = 0; i < items.size(); i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
    }
    return DeobfRegister::NONE;
}

DeobfRegister DeobfRegisterUses::firstDeobfRegister() const {
    for (size_t i = DEOBF_REGISTER_OFFSET_XMM - 1; i < DEOBF_REGISTER_OFFSET_RIP; i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
    }
    for (size_t i = DEOBF_REGISTER_OFFSET_64BITS - 1; i < DEOBF_REGISTER_OFFSET_SEGMENT; i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
    }
    for (size_t i = DEOBF_REGISTER_OFFSET_32BITS - 1; i < DEOBF_REGISTER_OFFSET_64BITS; i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
    }
    for (size_t i = DEOBF_REGISTER_OFFSET_16BITS - 1; i < DEOBF_REGISTER_OFFSET_32BITS; i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
    }
    // We need to follow the old definition order of registers here, where xL xH was the order.
    // So if both AH and BL are set, the old code would return AH. This setup mimics that. We need the second loop further
    // down below to go through the newer 8 bit variants of the 64 bit registers (e.g. R8B), which are "part of" the 8 bit
    // high registers (due to following udis86 ordering convention).
    size_t highOffset = 0;
    for (size_t i = DEOBF_REGISTER_OFFSET_8BITS_L - 1; i < DEOBF_REGISTER_OFFSET_8BITS_H; i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
        size_t high = DEOBF_REGISTER_OFFSET_8BITS_H - 1 + highOffset;
        if (items.test(high)) {
            return static_cast<DeobfRegister>(high + 1);
        }
        highOffset++;
    }
    for (size_t i = DEOBF_REGISTER_OFFSET_8BITS_H - 1 + highOffset; i < DEOBF_REGISTER_OFFSET_16BITS; i++) {
        if (items.test(i)) {
            return static_cast<DeobfRegister>(i + 1);
        }
    }
    if (items.test(static_cast<size_t>(DeobfRegister::RIP) - 1)) {
        return DeobfRegister::RIP;
    }
    return DeobfRegister::NONE;
}

std::vector<DeobfRegister> DeobfRegisterUses::affectedRegisters() const {
    std::vector<DeobfRegister> r{};
    for (size_t i = 0; i < items.size(); i++) {
        if (items.test(i)) {
            r.push_back(static_cast<DeobfRegister>(i + 1));
        }
    }
    return r;
}

std::string DeobfRegisterUses::toString() const {
    std::stringstream ss{};
    ss << *this;
    return ss.str();
}

Registers::Registers() {
    // Add 64 bit registers, segment registers, xmm registers & rip.
    for (DEOBF_REGISTER r = DEOBF_REGISTER_OFFSET_64BITS; r <= DEOBF_REGISTER_COUNT; r++) {
        registers.emplace(static_cast<DeobfRegister>(r), new Register());
    }
}

DEOBF_REGISTER_VALUE Registers::getRegisterValue(DeobfRegister r) {
    auto baseRegister = utils::getBaseRegister(r);
    if (baseRegister == DeobfRegister::NONE) {
        return 0;
    }
    auto registerWidth = utils::getRegisterWidth(r);
    return registers[baseRegister]->getRegisterValue(registerWidth);
}

DeobfRegisterUses Registers::setRegisterValue(DeobfRegister r, DEOBF_REGISTER_VALUE value) {
    auto baseRegister = utils::getBaseRegister(r);
    assert(baseRegister != DeobfRegister::NONE);
    auto registerWidth = utils::getRegisterWidth(r);
    registers[baseRegister]->setRegisterValue(registerWidth, value);
    return relatedRegisters(r);
}

void Registers::setRegisterValues(Instruction *ins) {
    registers[DeobfRegister::RAX]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->eax);
    registers[DeobfRegister::RCX]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->ecx);
    registers[DeobfRegister::RBX]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->ebx);
    registers[DeobfRegister::RDX]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->edx);
    registers[DeobfRegister::RBP]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->ebp);
    registers[DeobfRegister::RSP]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->esp);
    registers[DeobfRegister::RSI]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->esi);
    registers[DeobfRegister::RDI]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->edi);
    registers[DeobfRegister::R8]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r8);
    registers[DeobfRegister::R9]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r9);
    registers[DeobfRegister::R10]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r10);
    registers[DeobfRegister::R11]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r11);
    registers[DeobfRegister::R12]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r12);
    registers[DeobfRegister::R13]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r13);
    registers[DeobfRegister::R14]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r14);
    registers[DeobfRegister::R15]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->r15);
    registers[DeobfRegister::RIP]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->eip);
    registers[DeobfRegister::FS]->setRegisterValue(DeobfRegisterWidth::lower64bit, ins->fs);
    registers[DeobfRegister::XMM0]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm0);
    registers[DeobfRegister::XMM1]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm1);
    registers[DeobfRegister::XMM2]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm2);
    registers[DeobfRegister::XMM3]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm3);
    registers[DeobfRegister::XMM4]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm4);
    registers[DeobfRegister::XMM5]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm5);
    registers[DeobfRegister::XMM6]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm6);
    registers[DeobfRegister::XMM7]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm7);
    registers[DeobfRegister::XMM8]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm8);
    registers[DeobfRegister::XMM9]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm9);
    registers[DeobfRegister::XMM10]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm10);
    registers[DeobfRegister::XMM11]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm11);
    registers[DeobfRegister::XMM12]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm12);
    registers[DeobfRegister::XMM13]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm13);
    registers[DeobfRegister::XMM14]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm14);
    registers[DeobfRegister::XMM15]->setRegisterValue(DeobfRegisterWidth::lower128bit, ins->xmm15);
}

DeobfRegisterUses relatedRegisters(DeobfRegister r, bool ignoreUpper, bool ignoreLower) {
    DeobfRegisterUses modified{};
    auto idx = static_cast<size_t>(r);
    size_t offset;
    switch (r) {
    case DeobfRegister::NONE:
        break;
    case DeobfRegister::RIP:
        modified.set(r);
        break;
    case DeobfRegister::AL:
    case DeobfRegister::CL:
    case DeobfRegister::DL:
    case DeobfRegister::BL:
        offset = idx - DEOBF_REGISTER_OFFSET_8BITS_L;
        modified.set(r);
        if (!ignoreUpper) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_16BITS + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_64BITS + offset));
        }
        break;
    case DeobfRegister::AH:
    case DeobfRegister::CH:
    case DeobfRegister::DH:
    case DeobfRegister::BH:
    case DeobfRegister::SPL:
    case DeobfRegister::BPL:
    case DeobfRegister::SIL:
    case DeobfRegister::DIL:
    case DeobfRegister::R8B:
    case DeobfRegister::R9B:
    case DeobfRegister::R10B:
    case DeobfRegister::R11B:
    case DeobfRegister::R12B:
    case DeobfRegister::R13B:
    case DeobfRegister::R14B:
    case DeobfRegister::R15B:
        offset = idx - DEOBF_REGISTER_OFFSET_8BITS_H;
        modified.set(r);
        if (!ignoreUpper) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_16BITS + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_64BITS + offset));
        }
        break;
    case DeobfRegister::AX:
    case DeobfRegister::CX:
    case DeobfRegister::DX:
    case DeobfRegister::BX:
        offset = idx - DEOBF_REGISTER_OFFSET_16BITS;
        if (!ignoreLower) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_L + offset));
        }
        [[fallthrough]];
    case DeobfRegister::SP:
    case DeobfRegister::BP:
    case DeobfRegister::SI:
    case DeobfRegister::DI:
    case DeobfRegister::R8W:
    case DeobfRegister::R9W:
    case DeobfRegister::R10W:
    case DeobfRegister::R11W:
    case DeobfRegister::R12W:
    case DeobfRegister::R13W:
    case DeobfRegister::R14W:
    case DeobfRegister::R15W:
        offset = idx - DEOBF_REGISTER_OFFSET_16BITS;
        if (!ignoreLower) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_H + offset));
        }
        modified.set(r);
        if (!ignoreUpper) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_64BITS + offset));
        }
        break;
    case DeobfRegister::EAX:
    case DeobfRegister::ECX:
    case DeobfRegister::EDX:
    case DeobfRegister::EBX:
        offset = idx - DEOBF_REGISTER_OFFSET_32BITS;
        if (!ignoreLower) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_L + offset));
        }
        [[fallthrough]];
    case DeobfRegister::ESP:
    case DeobfRegister::EBP:
    case DeobfRegister::ESI:
    case DeobfRegister::EDI:
    case DeobfRegister::R8D:
    case DeobfRegister::R9D:
    case DeobfRegister::R10D:
    case DeobfRegister::R11D:
    case DeobfRegister::R12D:
    case DeobfRegister::R13D:
    case DeobfRegister::R14D:
    case DeobfRegister::R15D:
        offset = idx - DEOBF_REGISTER_OFFSET_32BITS;
        if (!ignoreLower) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_H + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_16BITS + offset));
        }
        modified.set(r);
        if (!ignoreUpper) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_64BITS + offset));
        }
        break;
    case DeobfRegister::RAX:
    case DeobfRegister::RCX:
    case DeobfRegister::RDX:
    case DeobfRegister::RBX:
        offset = idx - DEOBF_REGISTER_OFFSET_64BITS;
        if (!ignoreLower) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_L + offset));
        }
        [[fallthrough]];
    case DeobfRegister::RSP:
    case DeobfRegister::RBP:
    case DeobfRegister::RSI:
    case DeobfRegister::RDI:
    case DeobfRegister::R8:
    case DeobfRegister::R9:
    case DeobfRegister::R10:
    case DeobfRegister::R11:
    case DeobfRegister::R12:
    case DeobfRegister::R13:
    case DeobfRegister::R14:
    case DeobfRegister::R15:
        offset = idx - DEOBF_REGISTER_OFFSET_64BITS;
        if (!ignoreLower) {
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_H + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_16BITS + offset));
            modified.set(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + offset));
        }
        modified.set(r);
        break;
    case DeobfRegister::ES:
    case DeobfRegister::CS:
    case DeobfRegister::SS:
    case DeobfRegister::DS:
    case DeobfRegister::FS:
    case DeobfRegister::GS:
    case DeobfRegister::XMM0:
    case DeobfRegister::XMM1:
    case DeobfRegister::XMM2:
    case DeobfRegister::XMM3:
    case DeobfRegister::XMM4:
    case DeobfRegister::XMM5:
    case DeobfRegister::XMM6:
    case DeobfRegister::XMM7:
    case DeobfRegister::XMM8:
    case DeobfRegister::XMM9:
    case DeobfRegister::XMM10:
    case DeobfRegister::XMM11:
    case DeobfRegister::XMM12:
    case DeobfRegister::XMM13:
    case DeobfRegister::XMM14:
    case DeobfRegister::XMM15:
        modified.set(r);
        break;
    }

    return modified;
}

DeobfRegisterUses relatedRegistersLower(const DeobfRegisterUses &uses) {
    DeobfRegisterUses r{};

    for (size_t i = 0; i < uses.size(); i++) {
        auto reg = static_cast<DeobfRegister>(i + 1);
        if (uses.test(reg)) {
            r |= relatedRegistersLower(reg);
        }
    }

    return r;
}

DeobfRegisterUses relatedRegistersHigher(const DeobfRegisterUses &uses) {
    DeobfRegisterUses r{};

    for (size_t i = 0; i < uses.size(); i++) {
        auto reg = static_cast<DeobfRegister>(i + 1);
        if (uses.test(reg)) {
            r |= relatedRegistersHigher(reg);
        }
    }

    return r;
}

DeobfRegisterUses allRelatedRegisters(const DeobfRegisterUses &uses) {
    DeobfRegisterUses r{};

    for (size_t i = 0; i < uses.size(); i++) {
        auto reg = static_cast<DeobfRegister>(i + 1);
        if (uses.test(reg)) {
            r |= allRelatedRegisters(reg);
        }
    }

    return r;
}

DeobfRegisterUses baseRegisters(const DeobfRegisterUses &uses) {
    DeobfRegisterUses r{};

    for (size_t i = 0; i < uses.size(); i++) {
        auto reg = static_cast<DeobfRegister>(i + 1);
        if (uses.test(reg)) {
            r.set(utils::getBaseRegister(reg));
        }
    }

    return r;
}

} // namespace deobf::library
