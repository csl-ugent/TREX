/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */
#include "utils.h"

#include <iostream>

namespace deobf::library::utils {

TraceInfo traceInfo{};
Logger logger{};

bool isGPR(DeobfRegister r) {
    return is64bitGPR(r) || is32bitGPR(r) || is16bitGPR(r) || is8bitGPR(r);
}

bool is8bitGPR(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::AL:
    case DeobfRegister::CL:
    case DeobfRegister::DL:
    case DeobfRegister::BL:
    case DeobfRegister::AH:
    case DeobfRegister::CH:
    case DeobfRegister::DH:
    case DeobfRegister::BH:
    case DeobfRegister::SPL:
    case DeobfRegister::BPL:
    case DeobfRegister::SIL:
    case DeobfRegister::DIL:
    case DeobfRegister::R8B:
    case DeobfRegister::R9B:
    case DeobfRegister::R10B:
    case DeobfRegister::R11B:
    case DeobfRegister::R12B:
    case DeobfRegister::R13B:
    case DeobfRegister::R14B:
    case DeobfRegister::R15B:
        return true;
    default:
        return false;
    }
}

bool is16bitGPR(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::AX:
    case DeobfRegister::CX:
    case DeobfRegister::DX:
    case DeobfRegister::BX:
    case DeobfRegister::SP:
    case DeobfRegister::BP:
    case DeobfRegister::SI:
    case DeobfRegister::DI:
    case DeobfRegister::R8W:
    case DeobfRegister::R9W:
    case DeobfRegister::R10W:
    case DeobfRegister::R11W:
    case DeobfRegister::R12W:
    case DeobfRegister::R13W:
    case DeobfRegister::R14W:
    case DeobfRegister::R15W:
        return true;
    default:
        return false;
    }
}

bool is32bitGPR(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::EAX:
    case DeobfRegister::ECX:
    case DeobfRegister::EDX:
    case DeobfRegister::EBX:
    case DeobfRegister::ESP:
    case DeobfRegister::EBP:
    case DeobfRegister::ESI:
    case DeobfRegister::EDI:
    case DeobfRegister::R8D:
    case DeobfRegister::R9D:
    case DeobfRegister::R10D:
    case DeobfRegister::R11D:
    case DeobfRegister::R12D:
    case DeobfRegister::R13D:
    case DeobfRegister::R14D:
    case DeobfRegister::R15D:
        return true;
    default:
        return false;
    }
}

bool is64bitGPR(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::RAX:
    case DeobfRegister::RCX:
    case DeobfRegister::RDX:
    case DeobfRegister::RBX:
    case DeobfRegister::RSP:
    case DeobfRegister::RBP:
    case DeobfRegister::RSI:
    case DeobfRegister::RDI:
    case DeobfRegister::R8:
    case DeobfRegister::R9:
    case DeobfRegister::R10:
    case DeobfRegister::R11:
    case DeobfRegister::R12:
    case DeobfRegister::R13:
    case DeobfRegister::R14:
    case DeobfRegister::R15:
        return true;
    default:
        return false;
    }
}

bool isXMM(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::XMM0:
    case DeobfRegister::XMM1:
    case DeobfRegister::XMM2:
    case DeobfRegister::XMM3:
    case DeobfRegister::XMM4:
    case DeobfRegister::XMM5:
    case DeobfRegister::XMM6:
    case DeobfRegister::XMM7:
    case DeobfRegister::XMM8:
    case DeobfRegister::XMM9:
    case DeobfRegister::XMM10:
    case DeobfRegister::XMM11:
    case DeobfRegister::XMM12:
    case DeobfRegister::XMM13:
    case DeobfRegister::XMM14:
    case DeobfRegister::XMM15:
        return true;
    default:
        return false;
    }
}

bool is64bitLowExtension(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::SPL:
    case DeobfRegister::BPL:
    case DeobfRegister::SIL:
    case DeobfRegister::DIL:
        return true;
    default:
        return false;
    }
}

bool is64bitSpecific(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::R8B:
    case DeobfRegister::R9B:
    case DeobfRegister::R10B:
    case DeobfRegister::R11B:
    case DeobfRegister::R12B:
    case DeobfRegister::R13B:
    case DeobfRegister::R14B:
    case DeobfRegister::R15B:
    case DeobfRegister::R8W:
    case DeobfRegister::R9W:
    case DeobfRegister::R10W:
    case DeobfRegister::R11W:
    case DeobfRegister::R12W:
    case DeobfRegister::R13W:
    case DeobfRegister::R14W:
    case DeobfRegister::R15W:
    case DeobfRegister::R8D:
    case DeobfRegister::R9D:
    case DeobfRegister::R10D:
    case DeobfRegister::R11D:
    case DeobfRegister::R12D:
    case DeobfRegister::R13D:
    case DeobfRegister::R14D:
    case DeobfRegister::R15D:
    case DeobfRegister::R8:
    case DeobfRegister::R9:
    case DeobfRegister::R10:
    case DeobfRegister::R11:
    case DeobfRegister::R12:
    case DeobfRegister::R13:
    case DeobfRegister::R14:
    case DeobfRegister::R15:
        return true;
    default:
        return is64bitLowExtension(r);
    }
}

DeobfRegister getBaseRegister(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::AL:
    case DeobfRegister::AH:
    case DeobfRegister::AX:
    case DeobfRegister::EAX:
    case DeobfRegister::RAX:
        return DeobfRegister::RAX;
    case DeobfRegister::CL:
    case DeobfRegister::CH:
    case DeobfRegister::CX:
    case DeobfRegister::ECX:
    case DeobfRegister::RCX:
        return DeobfRegister::RCX;
    case DeobfRegister::DL:
    case DeobfRegister::DH:
    case DeobfRegister::DX:
    case DeobfRegister::EDX:
    case DeobfRegister::RDX:
        return DeobfRegister::RDX;
    case DeobfRegister::BL:
    case DeobfRegister::BH:
    case DeobfRegister::BX:
    case DeobfRegister::EBX:
    case DeobfRegister::RBX:
        return DeobfRegister::RBX;
    case DeobfRegister::SPL:
    case DeobfRegister::SP:
    case DeobfRegister::ESP:
    case DeobfRegister::RSP:
        return DeobfRegister::RSP;
    case DeobfRegister::BPL:
    case DeobfRegister::BP:
    case DeobfRegister::EBP:
    case DeobfRegister::RBP:
        return DeobfRegister::RBP;
    case DeobfRegister::SIL:
    case DeobfRegister::SI:
    case DeobfRegister::ESI:
    case DeobfRegister::RSI:
        return DeobfRegister::RSI;
    case DeobfRegister::DIL:
    case DeobfRegister::DI:
    case DeobfRegister::EDI:
    case DeobfRegister::RDI:
        return DeobfRegister::RDI;
    case DeobfRegister::R8B:
    case DeobfRegister::R8W:
    case DeobfRegister::R8D:
    case DeobfRegister::R8:
        return DeobfRegister::R8;
    case DeobfRegister::R9B:
    case DeobfRegister::R9W:
    case DeobfRegister::R9D:
    case DeobfRegister::R9:
        return DeobfRegister::R9;
    case DeobfRegister::R10B:
    case DeobfRegister::R10W:
    case DeobfRegister::R10D:
    case DeobfRegister::R10:
        return DeobfRegister::R10;
    case DeobfRegister::R11B:
    case DeobfRegister::R11W:
    case DeobfRegister::R11D:
    case DeobfRegister::R11:
        return DeobfRegister::R11;
    case DeobfRegister::R12B:
    case DeobfRegister::R12W:
    case DeobfRegister::R12D:
    case DeobfRegister::R12:
        return DeobfRegister::R12;
    case DeobfRegister::R13B:
    case DeobfRegister::R13W:
    case DeobfRegister::R13D:
    case DeobfRegister::R13:
        return DeobfRegister::R13;
    case DeobfRegister::R14B:
    case DeobfRegister::R14W:
    case DeobfRegister::R14D:
    case DeobfRegister::R14:
        return DeobfRegister::R14;
    case DeobfRegister::R15B:
    case DeobfRegister::R15W:
    case DeobfRegister::R15D:
    case DeobfRegister::R15:
        return DeobfRegister::R15;
    case DeobfRegister::ES:
    case DeobfRegister::CS:
    case DeobfRegister::SS:
    case DeobfRegister::DS:
    case DeobfRegister::FS:
    case DeobfRegister::GS:
    case DeobfRegister::RIP:
    case DeobfRegister::XMM0:
    case DeobfRegister::XMM1:
    case DeobfRegister::XMM2:
    case DeobfRegister::XMM3:
    case DeobfRegister::XMM4:
    case DeobfRegister::XMM5:
    case DeobfRegister::XMM6:
    case DeobfRegister::XMM7:
    case DeobfRegister::XMM8:
    case DeobfRegister::XMM9:
    case DeobfRegister::XMM10:
    case DeobfRegister::XMM11:
    case DeobfRegister::XMM12:
    case DeobfRegister::XMM13:
    case DeobfRegister::XMM14:
    case DeobfRegister::XMM15:
        return r;
    case DeobfRegister::NONE:
        break;
    }
    return DeobfRegister::NONE;
}

DeobfRegister resizeBaseRegister(DeobfRegister base, DeobfRegisterWidth size) {
    switch (base) {
    case DeobfRegister::RAX:
    case DeobfRegister::RCX:
    case DeobfRegister::RDX:
    case DeobfRegister::RBX:
    case DeobfRegister::RSP:
    case DeobfRegister::RBP:
    case DeobfRegister::RSI:
    case DeobfRegister::RDI:
    case DeobfRegister::R8:
    case DeobfRegister::R9:
    case DeobfRegister::R10:
    case DeobfRegister::R11:
    case DeobfRegister::R12:
    case DeobfRegister::R13:
    case DeobfRegister::R14:
    case DeobfRegister::R15: {
        size_t offset = static_cast<size_t>(base) - DEOBF_REGISTER_OFFSET_64BITS;
        switch (size) {
        case DeobfRegisterWidth::lower128bit:
            break; // Cannot be resized
        case DeobfRegisterWidth::lower64bit:
            return base;
        case DeobfRegisterWidth::lower32bit:
            return static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + offset);
        case DeobfRegisterWidth::lower16bit:
            return static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_16BITS + offset);
        case DeobfRegisterWidth::higher8bit:
            // We don't support 8 bit high.
            break;
        case DeobfRegisterWidth::lower8bit:
            return static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_8BITS_L + offset);
        }
    } break;
    default:
        break;
    }
    return DeobfRegister::NONE;
}

DeobfRegisterWidth getRegisterWidth(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::AL:
    case DeobfRegister::CL:
    case DeobfRegister::DL:
    case DeobfRegister::BL:
    case DeobfRegister::SPL:
    case DeobfRegister::BPL:
    case DeobfRegister::SIL:
    case DeobfRegister::DIL:
    case DeobfRegister::R8B:
    case DeobfRegister::R9B:
    case DeobfRegister::R10B:
    case DeobfRegister::R11B:
    case DeobfRegister::R12B:
    case DeobfRegister::R13B:
    case DeobfRegister::R14B:
    case DeobfRegister::R15B:
        return DeobfRegisterWidth::lower8bit;
    case DeobfRegister::AH:
    case DeobfRegister::CH:
    case DeobfRegister::DH:
    case DeobfRegister::BH:
        return DeobfRegisterWidth::higher8bit;
    case DeobfRegister::AX:
    case DeobfRegister::CX:
    case DeobfRegister::DX:
    case DeobfRegister::BX:
    case DeobfRegister::SP:
    case DeobfRegister::BP:
    case DeobfRegister::SI:
    case DeobfRegister::DI:
    case DeobfRegister::R8W:
    case DeobfRegister::R9W:
    case DeobfRegister::R10W:
    case DeobfRegister::R11W:
    case DeobfRegister::R12W:
    case DeobfRegister::R13W:
    case DeobfRegister::R14W:
    case DeobfRegister::R15W:
    case DeobfRegister::ES:
    case DeobfRegister::CS:
    case DeobfRegister::SS:
    case DeobfRegister::DS:
    case DeobfRegister::FS:
    case DeobfRegister::GS:
        return DeobfRegisterWidth::lower16bit;
    case DeobfRegister::EAX:
    case DeobfRegister::ECX:
    case DeobfRegister::EDX:
    case DeobfRegister::EBX:
    case DeobfRegister::ESP:
    case DeobfRegister::EBP:
    case DeobfRegister::ESI:
    case DeobfRegister::EDI:
    case DeobfRegister::R8D:
    case DeobfRegister::R9D:
    case DeobfRegister::R10D:
    case DeobfRegister::R11D:
    case DeobfRegister::R12D:
    case DeobfRegister::R13D:
    case DeobfRegister::R14D:
    case DeobfRegister::R15D:
        return DeobfRegisterWidth::lower32bit;
    case DeobfRegister::RAX:
    case DeobfRegister::RCX:
    case DeobfRegister::RDX:
    case DeobfRegister::RBX:
    case DeobfRegister::RSP:
    case DeobfRegister::RBP:
    case DeobfRegister::RSI:
    case DeobfRegister::RDI:
    case DeobfRegister::R8:
    case DeobfRegister::R9:
    case DeobfRegister::R10:
    case DeobfRegister::R11:
    case DeobfRegister::R12:
    case DeobfRegister::R13:
    case DeobfRegister::R14:
    case DeobfRegister::R15:
    case DeobfRegister::RIP:
        break;
    case DeobfRegister::XMM0:
    case DeobfRegister::XMM1:
    case DeobfRegister::XMM2:
    case DeobfRegister::XMM3:
    case DeobfRegister::XMM4:
    case DeobfRegister::XMM5:
    case DeobfRegister::XMM6:
    case DeobfRegister::XMM7:
    case DeobfRegister::XMM8:
    case DeobfRegister::XMM9:
    case DeobfRegister::XMM10:
    case DeobfRegister::XMM11:
    case DeobfRegister::XMM12:
    case DeobfRegister::XMM13:
    case DeobfRegister::XMM14:
    case DeobfRegister::XMM15:
        return DeobfRegisterWidth::lower128bit;
    case DeobfRegister::NONE:
        return traceInfo.getTraceWidth();
    }
    return DeobfRegisterWidth::lower64bit;
}

DeobfRegisterWidth getRegisterWidth(uint8_t bitsSize) {
    switch (bitsSize) {
    case 8:
        return DeobfRegisterWidth::lower8bit;
    case 16:
        return DeobfRegisterWidth::lower16bit;
    case 32:
        return DeobfRegisterWidth::lower32bit;
    case 64:
        return DeobfRegisterWidth::lower64bit;
    case 128:
        return DeobfRegisterWidth::lower128bit;
    default:
        utils::logger.verbose(fmt::format("Unknown bitsSize {}! Returning 64 bit.", bitsSize));
        return DeobfRegisterWidth::lower64bit;
    }
}

uint8_t getByteWidth(DeobfRegisterWidth registerWidth) {
    switch (registerWidth) {
    case DeobfRegisterWidth::lower128bit:
        return 16;
    case DeobfRegisterWidth::lower64bit:
        return 8;
    case DeobfRegisterWidth::lower32bit:
        return 4;
    case DeobfRegisterWidth::lower16bit:
        return 2;
    case DeobfRegisterWidth::higher8bit:
    case DeobfRegisterWidth::lower8bit:
        return 1;
    }
    utils::logger.log("Unknown register width!");
    return 0;
}

std::string stringifyRegister(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::NONE:
        return "None";
    case DeobfRegister::AL:
        return "AL";
    case DeobfRegister::CL:
        return "CL";
    case DeobfRegister::DL:
        return "DL";
    case DeobfRegister::BL:
        return "BL";
    case DeobfRegister::AH:
        return "AH";
    case DeobfRegister::CH:
        return "CH";
    case DeobfRegister::DH:
        return "DH";
    case DeobfRegister::BH:
        return "BH";
    case DeobfRegister::SPL:
        return "SPL";
    case DeobfRegister::BPL:
        return "BPL";
    case DeobfRegister::SIL:
        return "SIL";
    case DeobfRegister::DIL:
        return "DIL";
    case DeobfRegister::R8B:
        return "R8B";
    case DeobfRegister::R9B:
        return "R9B";
    case DeobfRegister::R10B:
        return "R10B";
    case DeobfRegister::R11B:
        return "R11B";
    case DeobfRegister::R12B:
        return "R12B";
    case DeobfRegister::R13B:
        return "R13B";
    case DeobfRegister::R14B:
        return "R14B";
    case DeobfRegister::R15B:
        return "R15B";
    case DeobfRegister::AX:
        return "AX";
    case DeobfRegister::CX:
        return "CX";
    case DeobfRegister::DX:
        return "DX";
    case DeobfRegister::BX:
        return "BX";
    case DeobfRegister::SP:
        return "SP";
    case DeobfRegister::BP:
        return "BP";
    case DeobfRegister::SI:
        return "SI";
    case DeobfRegister::DI:
        return "DI";
    case DeobfRegister::R8W:
        return "R8W";
    case DeobfRegister::R9W:
        return "R9W";
    case DeobfRegister::R10W:
        return "R10W";
    case DeobfRegister::R11W:
        return "R11W";
    case DeobfRegister::R12W:
        return "R12W";
    case DeobfRegister::R13W:
        return "R13W";
    case DeobfRegister::R14W:
        return "R14W";
    case DeobfRegister::R15W:
        return "R15W";
    case DeobfRegister::EAX:
        return "EAX";
    case DeobfRegister::ECX:
        return "ECX";
    case DeobfRegister::EDX:
        return "EDX";
    case DeobfRegister::EBX:
        return "EBX";
    case DeobfRegister::ESP:
        return "ESP";
    case DeobfRegister::EBP:
        return "EBP";
    case DeobfRegister::ESI:
        return "ESI";
    case DeobfRegister::EDI:
        return "EDI";
    case DeobfRegister::R8D:
        return "R8D";
    case DeobfRegister::R9D:
        return "R9D";
    case DeobfRegister::R10D:
        return "R10D";
    case DeobfRegister::R11D:
        return "R11D";
    case DeobfRegister::R12D:
        return "R12D";
    case DeobfRegister::R13D:
        return "R13D";
    case DeobfRegister::R14D:
        return "R14D";
    case DeobfRegister::R15D:
        return "R15D";
    case DeobfRegister::RAX:
        return "RAX";
    case DeobfRegister::RCX:
        return "RCX";
    case DeobfRegister::RDX:
        return "RDX";
    case DeobfRegister::RBX:
        return "RBX";
    case DeobfRegister::RSP:
        return "RSP";
    case DeobfRegister::RBP:
        return "RBP";
    case DeobfRegister::RSI:
        return "RSI";
    case DeobfRegister::RDI:
        return "RDI";
    case DeobfRegister::R8:
        return "R8";
    case DeobfRegister::R9:
        return "R9";
    case DeobfRegister::R10:
        return "R10";
    case DeobfRegister::R11:
        return "R11";
    case DeobfRegister::R12:
        return "R12";
    case DeobfRegister::R13:
        return "R13";
    case DeobfRegister::R14:
        return "R14";
    case DeobfRegister::R15:
        return "R15";
    case DeobfRegister::ES:
        return "ES";
    case DeobfRegister::CS:
        return "CS";
    case DeobfRegister::SS:
        return "SS";
    case DeobfRegister::DS:
        return "DS";
    case DeobfRegister::FS:
        return "FS";
    case DeobfRegister::GS:
        return "GS";
    case DeobfRegister::XMM0:
        return "XMM0";
    case DeobfRegister::XMM1:
        return "XMM1";
    case DeobfRegister::XMM2:
        return "XMM2";
    case DeobfRegister::XMM3:
        return "XMM3";
    case DeobfRegister::XMM4:
        return "XMM4";
    case DeobfRegister::XMM5:
        return "XMM5";
    case DeobfRegister::XMM6:
        return "XMM6";
    case DeobfRegister::XMM7:
        return "XMM7";
    case DeobfRegister::XMM8:
        return "XMM8";
    case DeobfRegister::XMM9:
        return "XMM9";
    case DeobfRegister::XMM10:
        return "XMM10";
    case DeobfRegister::XMM11:
        return "XMM11";
    case DeobfRegister::XMM12:
        return "XMM12";
    case DeobfRegister::XMM13:
        return "XMM13";
    case DeobfRegister::XMM14:
        return "XMM14";
    case DeobfRegister::XMM15:
        return "XMM15";
    case DeobfRegister::RIP:
        return "RIP";
    }
    return "Unknown";
}

bool insStructureEqual(ins_structure *a, ins_structure *b) {
    if (a->length == b->length) {
        for (int i = 0; i < a->length; ++i) {
            if (a->bytes[i] != b->bytes[i]) {
                return false;
            }
        }
        return true;
    }
    return false;
}

TracePlatform strToPlatform(const char *platform) {
    std::string p(platform);
    if (p == "LINUX") {
        return TracePlatform::Linux;
    }
    if (p == "WINDOWS") {
        return TracePlatform::Windows;
    }
    logger.log(fmt::format("ERROR: {} is not a known platform! Defaulting to Linux", platform));
    return TracePlatform::Linux;
}
} // namespace deobf::library::utils
