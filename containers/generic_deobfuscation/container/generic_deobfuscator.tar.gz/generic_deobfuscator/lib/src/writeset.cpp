#include "writeset.h"

#include <algorithm>
#include <cinttypes>

#include "utils.h"

using namespace deobf::library::utils;

namespace deobf::library::writeset {
// Private methods

void WriteSet::pAddRange(Range range) {
    auto tmpRange = range;
    auto r = ranges.cbegin();
    while (r != ranges.cend()) {
        // If an existing range overlaps with the new range, merge them and delete the existing one.
        if (tmpRange.max + 1 >= r->min && tmpRange.min - 1 <= r->max) {
            if (r->min < tmpRange.min) {
                tmpRange.min = r->min;
            }
            if (r->max > tmpRange.max) {
                tmpRange.max = r->max;
            }
            r = ranges.erase(r);
        } else {
            ++r;
        }
    }
    // TODO: switch to std::remove_if
    ranges.push_back(tmpRange);
}

Range WriteSet::pRangeFor(uint64_t rangeValue) const {
    for (auto r : ranges) {
        if (r.contains(rangeValue)) {
            return r;
        }
    }
    return {1, 0};
}

// Public

void WriteSet::addRange(uint64_t min, uint64_t max) {
    if (max < min) {
        return;
    }
    pAddRange(Range(min, max));
}

void WriteSet::addRange(std::unique_ptr<Range> range) {
    if (range) {
        pAddRange(*range);
    }
}

bool WriteSet::isSubsetOf(const std::unique_ptr<WriteSet>& superSet) const {
    if (empty()) {
        return true;
    }
    if (superSet->empty()) {
        return false;
    }
    return std::all_of(ranges.begin(), ranges.end(), [&superSet](const Range &r) { return superSet->contains(r); });
}

void WriteSet::merge(std::unique_ptr<WriteSet>& otherSet) {
    for (auto r : otherSet->ranges) {
        pAddRange(r);
    }
}

bool WriteSet::empty() const {
    if (ranges.empty()) {
        return true;
    }
    return ranges.front().empty();
}

bool WriteSet::contains(const Range &range) const {
    if (empty() || range.empty()) {
        return false;
    }
    return std::any_of(ranges.begin(), ranges.end(), [range](const Range &r) { return (range.min >= r.min && range.min <= r.max) || (range.max >= r.min && range.max <= r.max); });
}

[[maybe_unused]] bool WriteSet::hasExactRange(const Range &range) const {
    if (empty() || range.empty()) {
        return false;
    }
    return std::any_of(ranges.begin(), ranges.end(), [range](const Range &r) { return range == r; });
}

bool compareRanges(const Range &r1, const Range &r2) {
    return r1.min < r2.min;
}

void WriteSet::sort() {
    ranges.sort(compareRanges);
}

void WriteSet::mergePageRange(uint64_t pageSize) {
    for (auto curr = ranges.begin(); curr != ranges.end(); ++curr) {
        auto next = std::next(curr, 1);
        if (next == ranges.end()) {
            break;
        }
        uint64_t diff = 0;
        if (curr->min < next->min) {
            diff = next->min - curr->max;
        } else {
            logger.verbose("Warning: arraylist of ranges is not sorted!");
        }
        if (diff <= pageSize) {
            DEBUG(3, fmt::format("{:#x} -- {:#x} combined with {:#x} -- {:#x}", curr->min, curr->max, next->min, next->max));
            curr->max = next->max;
            DEBUG(3, fmt::format(" resulting in {:#x} -- {:#x}", curr->min, curr->max));
            ranges.erase(next);
            curr--;
            if (diff <= 0) {
                logger.verbose(fmt::format("Error calculating ranges: Range 1: {:#x} -- {:#x}, Range 2: {:#x} -- {:#x}", curr->min, curr->max, next->min, next->max));
            }
        }
    }
}

void WriteSet::breakPageRange(uint64_t pageSize) {
    std::vector<Range> newRanges {};
    for (auto & range : ranges) {
        uint64_t pages = (range.max - range.min) / pageSize;
        if (pages >= 1) {
            uint64_t nextMin = range.min + pageSize;
            range.max = nextMin - 1;
            for (uint64_t newPages = 0; newPages < pages; newPages++) {
                newRanges.emplace_back(nextMin, nextMin + pageSize - 1);
                nextMin = nextMin + pageSize;
            }
        }
    }
    ranges.insert(ranges.end(), newRanges.begin(), newRanges.end());
}

void WriteSet::fPrint(FILE *fp) const {
    for (const auto &r: ranges) {
        fprintf(fp, "0x%08" PRIx64 "--0x%08" PRIx64 "; ", r.min, r.max);
    }
}

bool WriteSet::operator==(const WriteSet &rhs) const {
    for (const auto &r: ranges) {
        for (uint64_t rv = r.min; rv <= r.max; rv++) {
            auto otherR = rhs.pRangeFor(rv);
            if (otherR.empty()) {
                return false; // rv not found
            }
            if (r.max <= otherR.max) {
                break; // range contained within, continue to next range
            } else {
                rv = otherR.max; // skip all values in this range
                continue;
            }
        }
    }
    for (const auto &r: rhs.ranges) {
        for (uint64_t rv = r.min; rv <= r.max; rv++) {
            auto otherR = pRangeFor(rv);
            if (otherR.empty()) {
                return false; // rv not found
            }
            if (r.max <= otherR.max) {
                break; // range contained within, continue to next range
            } else {
                rv = otherR.max;
                continue;
            }
        }
    }

    return true;
}

bool WriteSet::operator!=(const WriteSet &rhs) const {
    return !(rhs == *this);
}

bool WriteSet::overlapsWith(const std::unique_ptr<WriteSet> &other) const {
    for (auto range : ranges) {
        for (auto otherRange : other->ranges) {
            if (std::max(range.min, otherRange.min) <= std::min(range.max, otherRange.max)) {
                return true;
            }
        }
    }
    return false;
}

void WriteSet::subtract(const std::unique_ptr<WriteSet> &other) {
    /* Algorithm is currently somewhat inefficient. Subtract Ranges in other
     * from each Range in this WriteSet. In one case, this may result in two separate
     * Ranges. If this happens, we modify existing range to account for first,
     * create a new Range for second, then add new Range to the WriteSet.
     *
     * This requires that we reset the iterator to the beginning. However, since
     * WriteSets do not contain overlapping Ranges, this is safe and will
     * terminate. It just causes some redundant calculation.
     */
    auto rangeIt = ranges.begin();
    while (rangeIt != ranges.end()) {
        for (const auto &otherRange : other->ranges) {
            uint64_t newMin = 1, newMax = 0;
            if ((rangeIt->max < otherRange.min) || (rangeIt->min > otherRange.max)) {
                rangeIt++;
                continue; // No intersection
            } else if ((rangeIt->min <= otherRange.min) && (rangeIt->max < otherRange.max)) {
                //   |------|
                //       |------|
                rangeIt->max = otherRange.min - 1;
            } else if ((rangeIt->min > otherRange.min) && (rangeIt->max >= otherRange.max)) {
                //       |------|
                //   |------|
                rangeIt->min = otherRange.max + 1;
            } else if ((rangeIt->min <= otherRange.min) && (rangeIt->max >= otherRange.max)) {
                //   |---------|
                //      |---|
                // result of subtract is two ranges
                newMin = otherRange.max + 1;
                newMax = rangeIt->max;
                rangeIt->max = otherRange.min - 1;
            } else if ((rangeIt->min > otherRange.min) && (rangeIt->max < otherRange.max)) {
                //      |---|
                //   |---------|
                // result of subtract is empty, use empty range notation
                rangeIt->min = 1;
                rangeIt->max = 0;
            } else {
                logger.log("write set 1");
                fPrint(stdout);
                logger.log("write set 2");
                other->fPrint(stdout);
                logger.log("UNKNOWN RANGE SUBTRACT CASE");
            }

            if (newMin <= newMax) {
                addRange(newMin, newMax);
                rangeIt = ranges.begin(); // Reset iterator
            } else {
                rangeIt++;
            }
        }
    }
    ranges.remove_if([](const Range &r) { return r.empty(); });
}
} // namespace deobf::library::writeset
