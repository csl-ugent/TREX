/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2022 University of Ghent
 */
#include <sys/stat.h>
#include <stdexcept>

#include <utils.h>

#include "directory_utils.h"

namespace fs = std::filesystem;

using deobf::library::utils::logger;
using deobf::library::utils::Logger;

DirectoryUtils directoryUtils{};

void DirectoryUtils::prepareOutputFolder() {
    std::error_code ec;
    if (!fs::is_directory(outputPath)) {
        logger.log(fmt::format("Creating output directory {}", outputPath.string()));
        fs::create_directory(outputPath);
    }
    if (!fs::exists(outputPath)) {
        throw fs::filesystem_error("Output directory not accessible", outputPath, ec);
    }
}
std::filesystem::path DirectoryUtils::getOutputFile(std::string &fileName, std::string fileExtension, std::string &prefix, std::string &suffix) {
    return outputPath / (prefix + fileName + suffix + fileExtension);
}
void DirectoryUtils::parseBaseName(fs::path &inputPath) {
    auto stem = inputPath.stem().string();
    unsigned long pos = stem.rfind("_std_trace");
    if (pos == std::string::npos || inputPath.extension().string() != ".txt") {
        logger.log("ERROR: trace filename must end with _std_trace.txt");
        exit(0);
    }
    baseName = stem.erase(pos, 10);
}
std::string DirectoryUtils::getBaseName(const std::string& appendix) {
    return std::string(baseName).append(appendix);
}
void DirectoryUtils::setBaseName(char *base_name) {
    baseName = std::string(base_name);
}
