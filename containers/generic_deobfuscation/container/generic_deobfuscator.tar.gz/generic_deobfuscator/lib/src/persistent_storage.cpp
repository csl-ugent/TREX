/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */
#include "persistent_storage.h"

#include <algorithm>
#include <fstream>
#include <iostream>

PersistentStorage persistentStorage{};

uint16_t PersistentStorage::functionNameIdx(const std::string &functionName) {
    auto result = std::find(functionNames.begin(), functionNames.end(), functionName);
    if (result != functionNames.end()) {
        return std::distance(functionNames.begin(), result) + 1;
    }
    return 0;
}

uint16_t PersistentStorage::appendFunctionName(const std::string &functionName) {
    functionNames.push_back(functionName);

    std::fstream fs(FUNCTION_NAME_FILE, std::ios::out | std::ios::app);
    fs << functionName << std::endl;
    fs.close();

    return functionNames.size();
}

std::string PersistentStorage::functionNameForIdx(uint16_t idx) {
    if (idx == 0 || idx > functionNames.size()) {
        return "";
    }
    return functionNames[idx - 1];
}

void PersistentStorage::loadFunctionNamesFromFile() {
    std::fstream fs(FUNCTION_NAME_FILE, std::ios::in);
    if (fs.is_open()) {
        std::string functionName;
        while (getline(fs, functionName)) {
            functionNames.push_back(functionName);
        }
        fs.close();
    }
}

uint16_t PersistentStorage::moduleNameIdx(const std::string &moduleName) {
    auto result = std::find(moduleNames.begin(), moduleNames.end(), moduleName);
    if (result != moduleNames.end()) {
        return std::distance(moduleNames.begin(), result) + 1;
    }
    return 0;
}

uint16_t PersistentStorage::appendModuleName(const std::string &moduleName) {
    moduleNames.push_back(moduleName);

    std::fstream fs(MODULE_NAME_FILE, std::ios::out | std::ios::app);
    fs << moduleName << std::endl;
    fs.close();

    return moduleNames.size();
}

std::string PersistentStorage::moduleNameForIdx(uint16_t idx) {
    if (idx == 0 || idx > moduleNames.size()) {
        return "";
    }
    return moduleNames[idx - 1];
}

void PersistentStorage::loadModuleNamesFromFile() {
    std::fstream fs(MODULE_NAME_FILE, std::ios::in);
    if (fs.is_open()) {
        std::string functionName;
        while (getline(fs, functionName)) {
            moduleNames.push_back(functionName);
        }
        fs.close();
    }
}
