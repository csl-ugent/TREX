/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */

#include "udis86_create.h"

#include <array>
#include <cstring>
#include <iostream>
#include <string>

#include "types.h"
#include "udis86_glue.h"
#include "utils.h"

using namespace deobf::library;
using namespace deobf::library::glue;
using namespace deobf::library::utils;

using UDBuffer = std::array<unsigned char, MAX_X86_INSTR_LEN>;

namespace deobf::library::UDCreate {

bool printCreateErrors = false;

// private helper methods

inline void printSizeMisfitWarning(const std::string &ftnName) {
    if (!printCreateErrors) {
        return;
    }
    utils::logger.log(fmt::format("[{}] Unsupported on 64 bit / 32 bit offset too big", ftnName));
}

inline void printGPRWarning(const std::string &methodName, const ud_type &reg, const Instruction *instr = nullptr, int caller = 0) {
    if (!printCreateErrors) {
        return;
    }
    utils::logger.log(fmt::format("[{}]: Register {} is not valid", methodName, reg));
    if (instr) {
        utils::logger.log(fmt::format("(opcode {} at {:#x} - caller {}", ud_lookup_mnemonic(instr->uInstr.mnemonic), instr->addr, caller));
    }
}

inline void printGPRWarning(const std::string &methodName, const DeobfRegister reg, const Instruction *instr = nullptr, int caller = 0) {
    printGPRWarning(methodName, toUDRegister(reg), instr, caller);
}

uint8_t createPrefixes(UDBuffer *buff, DeobfRegister r, DeobfRegisterWidth traceWidth) {
    DeobfRegisterWidth rw = getRegisterWidth(r);
    uint8_t next = 0;
    // Operand size override prefix for group 3 always goes first
    if (rw == DeobfRegisterWidth::lower16bit) {
        (*buff)[next++] = 0x66;
    }
    // Add prefixes for REX(W) if in 64 bit trace mode
    if (traceWidth == DeobfRegisterWidth::lower64bit) {
        if (is64bitLowExtension(r)) {
            (*buff)[next++] = 0x40;
        } else {
            int rex = 0;
            if (is64bitSpecific(r)) {
                rex |= 0x1;
            }
            if (rw == DeobfRegisterWidth::lower64bit) {
                rex |= 0x8;
            }
            if (rex != 0) {
                (*buff)[next++] = 0x40 | rex;
            }
        }
    }
    return next;
}

inline uint8_t createPrefixes(UDBuffer *buff, uint8_t size, DeobfRegisterWidth traceWidth) {
    // If no specific register is known, use RAX/EAX/AX/AL to determine prefixes.
    return createPrefixes(buff, resizeBaseRegister(DeobfRegister::RAX, getRegisterWidth(size * 8)), traceWidth);
}

inline bool fitsIn32bit(DEOBF_GENERIC_VALUE val) {
    return val <= static_cast<uint32_t>(-1);
}

uint8_t convertToBuffer(UDBuffer *buf, uint8_t bufIdx, uint8_t byteWidth, DEOBF_GENERIC_VALUE toConvert) {
    (*buf)[bufIdx++] = (toConvert >> 0) & 0xff;
    if (byteWidth >= 2) {
        (*buf)[bufIdx++] = (toConvert >> 8) & 0xff;
    }
    if (byteWidth >= 4) {
        (*buf)[bufIdx++] = (toConvert >> 16) & 0xff;
        (*buf)[bufIdx++] = (toConvert >> 24) & 0xff;
    }
    if (byteWidth >= 8) {
        (*buf)[bufIdx++] = (toConvert >> 32) & 0xff;
        (*buf)[bufIdx++] = (toConvert >> 40) & 0xff;
        (*buf)[bufIdx++] = (toConvert >> 48) & 0xff;
        (*buf)[bufIdx++] = (toConvert >> 56) & 0xff;
    }
    return bufIdx;
}

inline ud_t *createFromBuffer(const UDBuffer &buf) {
    auto chBuf = static_cast<unsigned char *>(malloc(sizeof(unsigned char) * buf.size()));
    memcpy(chBuf, buf.data(), buf.size());
    return createDisassembledUD(chBuf, buf.size());
}

inline uint8_t limitTo32bits(uint8_t byteWidth) {
    return std::min(byteWidth, static_cast<uint8_t>(4));
}

inline uint8_t limitTo32bits(DeobfRegister r) {
    return limitTo32bits(getRegisterByteWidth(r));
}

// end of private helper methods

// public helper methods
DEOBF_REGISTER registerOffset(DeobfRegister r) {
    switch (r) {
    case DeobfRegister::AL:
    case DeobfRegister::CL:
    case DeobfRegister::DL:
    case DeobfRegister::BL:
    case DeobfRegister::AH:
    case DeobfRegister::CH:
    case DeobfRegister::DH:
    case DeobfRegister::BH:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - DEOBF_REGISTER_OFFSET_8BITS_L;
    case DeobfRegister::SPL:
    case DeobfRegister::BPL:
    case DeobfRegister::SIL:
    case DeobfRegister::DIL:
        // Should range between 0-4
        return static_cast<DEOBF_REGISTER>(r) - DEOBF_REGISTER_OFFSET_8BITS_L - 4;
    case DeobfRegister::R8B:
    case DeobfRegister::R9B:
    case DeobfRegister::R10B:
    case DeobfRegister::R11B:
    case DeobfRegister::R12B:
    case DeobfRegister::R13B:
    case DeobfRegister::R14B:
    case DeobfRegister::R15B:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - static_cast<DEOBF_REGISTER>(DeobfRegister::R8B);
    case DeobfRegister::AX:
    case DeobfRegister::CX:
    case DeobfRegister::DX:
    case DeobfRegister::BX:
    case DeobfRegister::SP:
    case DeobfRegister::BP:
    case DeobfRegister::SI:
    case DeobfRegister::DI:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - DEOBF_REGISTER_OFFSET_16BITS;
    case DeobfRegister::R8W:
    case DeobfRegister::R9W:
    case DeobfRegister::R10W:
    case DeobfRegister::R11W:
    case DeobfRegister::R12W:
    case DeobfRegister::R13W:
    case DeobfRegister::R14W:
    case DeobfRegister::R15W:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - static_cast<DEOBF_REGISTER>(DeobfRegister::R8W);
    case DeobfRegister::EAX:
    case DeobfRegister::ECX:
    case DeobfRegister::EDX:
    case DeobfRegister::EBX:
    case DeobfRegister::ESP:
    case DeobfRegister::EBP:
    case DeobfRegister::ESI:
    case DeobfRegister::EDI:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - DEOBF_REGISTER_OFFSET_32BITS;
    case DeobfRegister::R8D:
    case DeobfRegister::R9D:
    case DeobfRegister::R10D:
    case DeobfRegister::R11D:
    case DeobfRegister::R12D:
    case DeobfRegister::R13D:
    case DeobfRegister::R14D:
    case DeobfRegister::R15D:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - static_cast<DEOBF_REGISTER>(DeobfRegister::R8D);
    case DeobfRegister::RAX:
    case DeobfRegister::RCX:
    case DeobfRegister::RDX:
    case DeobfRegister::RBX:
    case DeobfRegister::RSP:
    case DeobfRegister::RBP:
    case DeobfRegister::RSI:
    case DeobfRegister::RDI:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - DEOBF_REGISTER_OFFSET_64BITS;
    case DeobfRegister::R8:
    case DeobfRegister::R9:
    case DeobfRegister::R10:
    case DeobfRegister::R11:
    case DeobfRegister::R12:
    case DeobfRegister::R13:
    case DeobfRegister::R14:
    case DeobfRegister::R15:
        // Should range between 0-8
        return static_cast<DEOBF_REGISTER>(r) - static_cast<DEOBF_REGISTER>(DeobfRegister::R8);
    default:
        return 0;
    }
}

ud_t *createDisassembledUD(const unsigned char *buf, uint8_t bufSize, ADDRESS address) {
    auto UDins = static_cast<ud_t *>(malloc(sizeof(ud_t)));
    initializeUDObject(UDins, traceInfo.getTraceWidthBits());
    ud_set_input_buffer(UDins, buf, bufSize);
    ud_set_pc(UDins, address);
    ud_disassemble(UDins);
    return UDins;
}

// end of public helper methods

ud_t *movImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val, Instruction *ins, int line) {
    /**
     * Examples of valid returns:
     * b0 ff                          mov    al,0xff
     * 41 b0 ff                       mov    r8b,0xff
     * 66 b8 ff ff                    mov    ax,0xffff
     * b8 ff ff ff ff                 mov    eax,0xffffffff
     * 48 b8 ff ff ff ff ff ff ff ff  movabs rax,0xffffffffffffffff
     */
    DeobfRegister r = toDeobfRegister(reg);
    if (!isGPR(r)) {
        printGPRWarning(__func__, reg, ins, line);
        return nullptr;
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = (is8bitGPR(r) ? 0xb0 : 0xb8) + registerOffset(r);
    convertToBuffer(&buff, next, getRegisterByteWidth(r), val);

    return createFromBuffer(buff);
}

ud_t *arithmeticImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val, uint8_t type) {
    DeobfRegister r = toDeobfRegister(reg);
    if (!isGPR(r)) {
        printGPRWarning(__func__, reg);
        return nullptr;
    }
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(val)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = (is8bitGPR(r) ? 0x80 : 0x81);
    buff[next++] = type + registerOffset(r);
    convertToBuffer(&buff, next, limitTo32bits(r), val);

    return createFromBuffer(buff);
}

ud_t *shiftRotateImmToReg(ud_type reg, uint8_t val, uint8_t type) {
    DeobfRegister r = toDeobfRegister(reg);
    if (!isGPR(r)) {
        printGPRWarning(__func__, reg);
        return nullptr;
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = is8bitGPR(r) ? 0xc0 : 0xc1;
    buff[next++] = 0xc0 + ((registerOffset(r) + type) << 3);
    convertToBuffer(&buff, next, 1, val); // imm values are just 1 byte size in all instruction formats

    return createFromBuffer(buff);
}

ud_t *imulImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples:
     * 66 69 c0 ff ff          imul   ax,ax,0xffff
     * 69 c0 ff ff ff ff       imul   eax,eax,0xffffffff
     * 48 69 c0 ff ff ff ff    imul   rax,rax,0xffffffffffffffff (32 bit sign extended)
     */
    DeobfRegister r = toDeobfRegister(reg);
    if (!isGPR(r) || is8bitGPR(r)) {
        printGPRWarning(__func__, reg);
        return nullptr;
    }
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(val)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = 0x69;
    buff[next++] = 0xc0 + ((registerOffset(r) + 0x0) << 3) + (registerOffset(r) + 0x0);
    convertToBuffer(&buff, next, limitTo32bits(r), val);

    return createFromBuffer(buff);
}

ud_t *notOnReg(ud_type reg) {
    /**
     * Examples of valid return values:
     * f6 d0                   not    al
     * 41 f6 d0                not    r8b
     * 66 f7 d0                not    ax
     * f7 d0                   not    eax
     * 48 f7 d0                not    rax
     */
    DeobfRegister r = toDeobfRegister(reg);
    if (!isGPR(r)) {
        printGPRWarning(__func__, reg);
        return nullptr;
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = is8bitGPR(r) ? 0xf6 : 0xf7;
    buff[next++] = 0xd0 + registerOffset(r);

    return createFromBuffer(buff);
}

ud_t *notMem(DEOBF_GENERIC_VALUE offset, uint8_t size) {
    /**
     * Valid return values:
     * 64 bit trace:
     * f6 14 25 ff ff ff ff      not    BYTE PTR ds:0xffffffffffffffff
     * 66 f7 14 25 ff ff ff ff   not    WORD PTR ds:0xffffffffffffffff
     * f7 14 25 ff ff ff ff      not    DWORD PTR ds:0xffffffffffffffff
     * 48 f7 14 25 ff ff ff ff   not    QWORD PTR ds:0xffffffffffffffff
     *
     * 32 bit trace:
     * f6 15 ff ff ff ff       not    BYTE PTR ds:0xffffffff
     * 66 f7 15 ff ff ff ff    not    WORD PTR ds:0xffffffff
     * f7 15 ff ff ff ff       not    DWORD PTR ds:0xffffffff
     */
    DeobfRegisterWidth traceWidth = traceInfo.getTraceWidth();
    if (traceWidth == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(offset)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
    }
    UDBuffer buff{};

    uint8_t next = createPrefixes(&buff, size, traceInfo.getTraceWidth());
    buff[next++] = (size == 1) ? 0xf6 : 0xf7;
    if (traceWidth == DeobfRegisterWidth::lower64bit) {
        buff[next++] = 0x14;
        buff[next++] = 0x25;
    } else {
        buff[next++] = 0x15;
    }
    convertToBuffer(&buff, next, 4, offset);

    return createFromBuffer(buff);
}

ud_t *movImmToOffset(DEOBF_GENERIC_VALUE absoluteOffset, DEOBF_GENERIC_VALUE value, uint8_t size, DEOBF_REGISTER_VALUE rip) {
    /**
     * Examples of return values:
     * c6 05 ff ff ff ff 11               mov    BYTE PTR [rip+0xffffffffffffffff],0x11
     * 66 c7 05 ff ff ff ff 11 11         mov    WORD PTR [rip+0xffffffffffffffff],0x1111
     * c7 05 ff ff ff ff 11 11 11 11      mov    DWORD PTR [rip+0xffffffffffffffff],0x11111111
     * 48 c7 05 ff ff ff ff 11 11 11 11   mov    QWORD PTR [rip+0xffffffffffffffff],0x11111111
     */
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(absoluteOffset - rip)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
        absoluteOffset -= rip; // Change absolute to relative.
    }
    UDBuffer buff{};

    uint8_t next = createPrefixes(&buff, size, traceInfo.getTraceWidth());
    buff[next++] = (size == 1) ? 0xc6 : 0xc7;
    buff[next++] = 0x05;
    next = convertToBuffer(&buff, next, 4, absoluteOffset); // Offset is always 32 bit
    convertToBuffer(&buff, next, size, value);

    return createFromBuffer(buff);
}

ud_t *movOffsetToReg(ud_type dest, DEOBF_GENERIC_VALUE offset, bool regToOffset, DEOBF_REGISTER_VALUE rip) {
    /**
     * Examples of return values:
     * reg to offset:
     * 88 05 ff ff ff ff       mov    BYTE PTR [rip+0xffffffffffffffff],al
     * 66 89 05 ff ff ff ff    mov    WORD PTR [rip+0xffffffffffffffff],ax
     * 89 05 ff ff ff ff       mov    DWORD PTR [rip+0xffffffffffffffff],eax
     * 48 89 05 ff ff ff ff    mov    QWORD PTR [rip+0xffffffffffffffff],rax
     * offset to reg:
     * 8a 05 ff ff ff ff       mov    al,BYTE PTR [rip+0xffffffffffffffff]
     * 66 8b 05 ff ff ff ff    mov    ax,WORD PTR [rip+0xffffffffffffffff]
     * 8b 05 ff ff ff ff       mov    eax,DWORD PTR [rip+0xffffffffffffffff]
     * 48 8b 05 ff ff ff ff    mov    rax,QWORD PTR [rip+0xffffffffffffffff]
     */
    DeobfRegister r = toDeobfRegister(dest);
    if (!isGPR(r)) {
        printGPRWarning(__func__, dest);
        return nullptr;
    }
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(offset - rip)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
        offset -= rip; // Change absolute to relative.
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    if (regToOffset) {
        buff[next++] = (is8bitGPR(r) ? 0x88 : 0x89);
    } else {
        buff[next++] = (is8bitGPR(r) ? 0x8a : 0x8b);
    }
    buff[next++] = 0x05 | (registerOffset(r) << 3);
    convertToBuffer(&buff, next, 4, offset);

    return createFromBuffer(buff);
}

ud_t *pushImm(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of return values:
     * 6a ff                   push   0xffffffffffffffff
     * 66 68 ff ff             pushw  0xffff
     * 68 ff ff ff ff          push   0xffffffffffffffff
     */
    DeobfRegister r = toDeobfRegister(reg);
    if (!isGPR(r)) {
        printGPRWarning(__func__, reg);
        return nullptr;
    }
    if (!fitsIn32bit(val)) {
        printSizeMisfitWarning(__func__);
        return nullptr;
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, DeobfRegisterWidth::lower32bit); // push does not support imm 64.
    buff[next++] = is8bitGPR(r) ? 0x6A : 0x68;
    convertToBuffer(&buff, next, limitTo32bits(getRegisterByteWidth(r)), val);

    return createFromBuffer(buff);
}

ud_t *jumpNear(DEOBF_GENERIC_VALUE jumpAddress, DEOBF_REGISTER_VALUE rip) {
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(jumpAddress)) {
            if (!fitsIn32bit(jumpAddress - rip)) {
                printSizeMisfitWarning(__func__);
                return nullptr;
            }
            jumpAddress -= rip;
        }
    }
    UDBuffer buff{};
    uint8_t next = 0;
    buff[next++] = 0xe9;
    convertToBuffer(&buff, next, 4, jumpAddress);

    return createFromBuffer(buff);
}

ud_t *nop() {
    UDBuffer buff{};
    buff[0] = 0x90;

    return createFromBuffer(buff);
}

ud_t *pushReg(DeobfRegister r) {
    /**
     * Examples of return values:
     * 66 50                   push   ax
     * 50                      push   rax
     */
    if (!isGPR(r) || is8bitGPR(r)) {
        printGPRWarning(__func__, r);
        return nullptr;
    }
    UDBuffer buff{};
    uint8_t next =
        createPrefixes(&buff, r, DeobfRegisterWidth::lower32bit); // push does not need rex.w, it's either push eax (32 bit trace) or push rax (64 bit trace).
    buff[next] = 0x50 + registerOffset(r);

    return createFromBuffer(buff);
}

ud_t *callAddr(DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of return values:
     * e8 ff ff ff ff          call   0x8
     */
    if (!fitsIn32bit(val)) {
        printSizeMisfitWarning(__func__);
        return nullptr;
    }
    UDBuffer buff{};
    uint8_t next = 0;
    buff[next++] = 0xe8;
    convertToBuffer(&buff, next, 4, val);

    return createFromBuffer(buff);
}

ud_t *popReg(DeobfRegister r) {
    /**
     * Examples of return values:
     * 66 58                   pop   ax
     * 58                      pop   rax
     */
    if (!isGPR(r) || is8bitGPR(r)) {
        printGPRWarning(__func__, r);
        return nullptr;
    }

    UDBuffer buff{};
    uint8_t next =
        createPrefixes(&buff, r, DeobfRegisterWidth::lower32bit); // pop does not need rex.w, it's either pop eax (32 bit trace) or pop rax (64 bit trace).
    buff[next] = 0x58 + registerOffset(r);

    return createFromBuffer(buff);
}

ud_t *movRegToReg(ud_type destination, ud_type source) {
    /**
     * Examples of return values:
     * 88 c8                   mov    al,cl
     * 66 89 c8                mov    ax,cx
     * 89 c8                   mov    eax,ecx
     * 48 89 c8                mov    rax,rcx
     * 88 c9                   mov    cl,cl
     */
    if (UDRegSize(source) != UDRegSize(destination)) {
        utils::logger.log(fmt::format("[{}] Operands are not the same size!", __func__));
        return nullptr;
    }

    DeobfRegister r = toDeobfRegister(destination);

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = (is8bitGPR(r) ? 0x88 : 0x89);
    buff[next++] = 0xc0 | registerOffset(r) | (registerOffset(toDeobfRegister(source)) << 3); // mod/reg/rm

    return createFromBuffer(buff);
}

ud_t *cmpOffsetWithReg(DEOBF_GENERIC_VALUE offset, ud_type dest, uint8_t type) {
    /**
     * Example of return values:
     * 32 bit trace:
     * 3a 05 ff ff ff ff       cmp    al,BYTE PTR ds:0xffffffff
     * 66 3b 05 ff ff ff ff    cmp    ax,WORD PTR ds:0xffffffff
     * 3b 05 ff ff ff ff       cmp    eax,DWORD PTR ds:0xffffffff
     *
     * 64 bit trace:
     * 3a 05 ff ff ff ff       cmp    al,BYTE PTR [rip+0xffffffffffffffff]
     * 66 3b 05 ff ff ff ff    cmp    ax,WORD PTR [rip+0xffffffffffffffff]
     * 3b 05 ff ff ff ff       cmp    eax,DWORD PTR [rip+0xffffffffffffffff]
     * 48 3b 05 ff ff ff ff    cmp    rax,QWORD PTR [rip+0xffffffffffffffff]
     */
    DeobfRegister r = toDeobfRegister(dest);
    if (!isGPR(r)) {
        printGPRWarning(__func__, dest);
        return nullptr;
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, r, traceInfo.getTraceWidth());
    buff[next++] = type;
    buff[next++] = 0x05 + (registerOffset(r) << 3);
    convertToBuffer(&buff, next, 4, offset);

    return createFromBuffer(buff);
}

ud_t *cmpOffsetWithImm(DEOBF_GENERIC_VALUE offset, DEOBF_GENERIC_VALUE value, uint8_t size, DEOBF_REGISTER_VALUE rip) {
    /**
     * Possible return values are:
     * 80 3d 00 00 00 00 01                cmp    BYTE PTR [rip+0x0],0x1
     * 66 81 3d 00 00 00 00 01 01          cmp    WORD PTR [rip+0x0],0x101
     * 81 3d 00 00 00 00 01 01 01 01       cmp    DWORD PTR [rip+0x0],0x1010101
     * 48 81 3d 00 00 00 00 01 01 01 01    cmp    QWORD PTR [rip+0x0],0x1010101
     */
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(offset - rip)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
        offset -= rip; // Change absolute to relative.
    }
    UDBuffer buff{};

    uint8_t next = createPrefixes(&buff, size, traceInfo.getTraceWidth());
    buff[next++] = (size == 1) ? 0x80 : 0x81;
    buff[next++] = 0x3d;
    next = convertToBuffer(&buff, next, 4, offset); // Offset is always 32 bit
    convertToBuffer(&buff, next, size, value);

    return createFromBuffer(buff);
}

ud_t *popOffset(uint8_t size, DEOBF_GENERIC_VALUE offset, DEOBF_REGISTER_VALUE rip) {
    /**
     * Examples of return values:
     * 66 8f 05 ff ff ff ff    pop   WORD PTR [rip+0xffffffffffffffff]
     * 8f 05 ff ff ff ff       pop   QWORD PTR [rip+0xffffffffffffffff]
     * 48 8f 05 ff ff ff ff    rex.W pop QWORD PTR [rip+0xffffffffffffffff]
     */
    if (size == 1 && printCreateErrors) {
        utils::logger.log(fmt::format("[{}] 8 bit not supported for pop offset", __func__));
    }
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(offset - rip)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
        offset -= rip; // Change absolute to relative.
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, size, traceInfo.getTraceWidth());
    buff[next++] = 0x8f;
    buff[next++] = 0x05;
    convertToBuffer(&buff, next, 4, offset);

    return createFromBuffer(buff);
}

ud_t *pushOffset(uint8_t size, DEOBF_GENERIC_VALUE offset, DEOBF_REGISTER_VALUE rip) {
    /**
     * Examples of return values:
     * 66 ff 35 ff ff ff ff    push   WORD PTR [rip+0xffffffffffffffff]
     * ff 35 ff ff ff ff       push   QWORD PTR [rip+0xffffffffffffffff]
     * 48 ff 35 ff ff ff ff    rex.W push QWORD PTR [rip+0xffffffffffffffff]
     */
    if (size == 1 && printCreateErrors) {
        utils::logger.log(fmt::format("[{}] 8 bit is not supported for push offset", __func__));
    }
    if (traceInfo.getTraceWidth() == DeobfRegisterWidth::lower64bit) {
        if (!fitsIn32bit(offset - rip)) {
            printSizeMisfitWarning(__func__);
            return nullptr;
        }
        offset -= rip; // Change absolute to relative.
    }

    UDBuffer buff{};
    uint8_t next = createPrefixes(&buff, size, traceInfo.getTraceWidth());
    buff[next++] = 0xff;
    buff[next++] = 0x35;
    convertToBuffer(&buff, next, 4, offset);

    return createFromBuffer(buff);
}

ud_t *createModRMEncodedAndImm(const unsigned char *bytes, const ud_type &dest, DEOBF_GENERIC_VALUE val, uint8_t encoded_operation, uint8_t opcode = 0x81,
                               uint8_t eightBOpcode = 0x80, bool override = false, uint8_t modrO = 0, uint8_t rmO = 0) {
    if (!isGPR(toDeobfRegister(dest))) {
        printGPRWarning(__func__, dest);
        return nullptr;
    }

    auto *buf = static_cast<unsigned char *>(malloc(sizeof(unsigned char) * MAX_X86_INSTR_LEN));
    int SIB = 0, MODR = 0, RM = 0;
    size_t i;

    auto currentUD = static_cast<ud_t *>(malloc(sizeof(ud_t)));
    initializeUDObject(currentUD, traceInfo.getTraceWidthBits());
    ud_set_input_buffer(currentUD, bytes, MAX_X86_INSTR_LEN);
    ud_clear_insn(currentUD);
    ud_decode_prefixes(currentUD);
    size_t prefixCnt = currentUD->inp_ctr - 1;
    free(currentUD);

    for (i = 0; i < prefixCnt; i++) {
        buf[i] = bytes[i];
    }

    size_t nonPfxIdx = prefixCnt + 1;

    MODR |= (bytes[nonPfxIdx] & 0xc0);
    RM |= (bytes[nonPfxIdx] & 0x07);
    SIB |= bytes[nonPfxIdx + 1];
    if (override) {
        MODR = modrO;
        RM = rmO;
        nonPfxIdx--;
    }
    int encodedModRM = MODR | (encoded_operation << 3) | RM;
    if (RM == 0x4) {
        nonPfxIdx++;
    }
    if ((MODR >> 6) == 1) {
        if (dest >= UD_R_EAX && dest <= UD_R_EDI) {
            buf[i++] = opcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            buf[i++] = bytes[nonPfxIdx + 1]; // displacement
            buf[i++] = (val >> 0) & 0xff;
            buf[i++] = (val >> 8) & 0xff;
            buf[i++] = (val >> 16) & 0xff;
            buf[i++] = (val >> 24) & 0xff;
        } else if (dest >= UD_R_AX && dest <= UD_R_DI) {
            buf[i++] = opcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            buf[i++] = bytes[nonPfxIdx + 1]; // displacement
            buf[i++] = (val >> 0) & 0xff;
            buf[i++] = (val >> 8) & 0xff;
        } else {
            buf[i++] = eightBOpcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            buf[i++] = bytes[nonPfxIdx + 1]; // displacement
            buf[i++] = val & 0xff;
        }
    } else if ((MODR >> 6) == 0x2) {
        if (dest >= UD_R_EAX && dest <= UD_R_EDI) {
            buf[i++] = opcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            buf[i++] = bytes[nonPfxIdx + 1]; // displacement
            buf[i++] = bytes[nonPfxIdx + 2];
            buf[i++] = bytes[nonPfxIdx + 3];
            buf[i++] = bytes[nonPfxIdx + 4];
            buf[i++] = (val >> 0) & 0xff;
            buf[i++] = (val >> 8) & 0xff;
            buf[i++] = (val >> 16) & 0xff;
            buf[i++] = (val >> 24) & 0xff;
        } else if (dest >= UD_R_AX && dest <= UD_R_DI) {
            buf[i++] = opcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            buf[i++] = bytes[nonPfxIdx + 1]; // displacement
            buf[i++] = bytes[nonPfxIdx + 2];
            buf[i++] = bytes[nonPfxIdx + 3];
            buf[i++] = bytes[nonPfxIdx + 4];
            buf[i++] = (val >> 0) & 0xff;
            buf[i++] = (val >> 8) & 0xff;
        } else {
            buf[i++] = eightBOpcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            buf[i++] = bytes[nonPfxIdx + 1]; // displacement
            buf[i++] = bytes[nonPfxIdx + 2];
            buf[i++] = bytes[nonPfxIdx + 3];
            buf[i++] = bytes[nonPfxIdx + 4];
            buf[i++] = (val >> 0) & 0xff;
        }

    } else if (MODR == 0) {
        if (dest >= UD_R_EAX && dest <= UD_R_EDI) {
            buf[i++] = opcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            if (RM == 0x5) {
                buf[i++] = bytes[nonPfxIdx + 1]; // displacement
                buf[i++] = bytes[nonPfxIdx + 2];
                buf[i++] = bytes[nonPfxIdx + 3];
                buf[i++] = bytes[nonPfxIdx + 4];
            }
            buf[i++] = (val >> 0) & 0xff;
            buf[i++] = (val >> 8) & 0xff;
            buf[i++] = (val >> 16) & 0xff;
            buf[i++] = (val >> 24) & 0xff;
        } else if (dest >= UD_R_AX && dest <= UD_R_DI) {
            buf[i++] = opcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            if (RM == 0x5) {
                buf[i++] = bytes[nonPfxIdx + 1]; // displacement
                buf[i++] = bytes[nonPfxIdx + 2];
                buf[i++] = bytes[nonPfxIdx + 3];
                buf[i++] = bytes[nonPfxIdx + 4];
            }
            buf[i++] = (val >> 0) & 0xff;
            buf[i++] = (val >> 8) & 0xff;
        } else {
            buf[i++] = eightBOpcode;
            buf[i++] = encodedModRM;
            if (RM == 0x4) {
                buf[i++] = SIB;
            }
            if (RM == 0x5) {
                buf[i++] = bytes[nonPfxIdx + 1]; // displacement
                buf[i++] = bytes[nonPfxIdx + 2];
                buf[i++] = bytes[nonPfxIdx + 3];
                buf[i++] = bytes[nonPfxIdx + 4];
            }
            buf[i++] = (val >> 0) & 0xff;
        }
    }

    return createDisassembledUD(buf, MAX_X86_INSTR_LEN);
}

ud_t *cmpMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    return createModRMEncodedAndImm(bytes, dest, val, 7);
}

ud_t *xorMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    return createModRMEncodedAndImm(bytes, dest, val, 6);
}

ud_t *andMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    return createModRMEncodedAndImm(bytes, dest, val, 4);
}

ud_t *orMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    return createModRMEncodedAndImm(bytes, dest, val, 1);
}

ud_t *subImmFromMem(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    return createModRMEncodedAndImm(bytes, dest, val, 5);
}

ud_t *movImmToMem(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    uint8_t MODR = 0, RM = 0;
    bool override = false;
    if (bytes[0] == 0xa3 || bytes[0] == 0xa2) {
        // Override MODR/M encoding for mov moffs, AL
        override = true;
        RM = 0x5;
        MODR = 0;
    }
    return createModRMEncodedAndImm(bytes, dest, val, 0, 0xc7, 0xc6, override, MODR, RM);
}

ud_t *addImmToMem(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val) {
    return createModRMEncodedAndImm(bytes, dest, val, 0);
}

ud_t *changeOperandToImm(unsigned char *instrBytes, uint8_t opIdx, DEOBF_GENERIC_VALUE immVal) {
    // FIXME: check this for 64 bit

    auto UDins = static_cast<ud_t *>(malloc(sizeof(ud_t)));
    initializeUDObject(UDins, traceInfo.getTraceWidthBits());
    ud_set_input_buffer(UDins, instrBytes, MAX_X86_INSTR_LEN);
    ud_decode(UDins);
    UDins->operand[opIdx].type = UD_OP_IMM;
    UDins->operand[opIdx].lval.sdword = immVal;
    UDins->translator(UDins);
    return UDins;
}

const std::string operandToString(ud_type type) {
    switch (type) {
    case UD_OP_REG:
        return "Register";
    case UD_OP_MEM:
        return "Memory";
    case UD_OP_PTR:
        return "Pointer";
    case UD_OP_IMM:
        return "Immediate";
    case UD_OP_JIMM:
        return "Jump immediate";
    case UD_OP_CONST:
        return "Constant";
    default:
        return "Invalid!";
    }
}
}; // namespace deobf::library::UDCreate
