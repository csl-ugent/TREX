#include "instr_utils.h"
#include "flags.h"
#include "persistent_storage.h"
#include "register.h"
#include "utils.h"

namespace deobf::library::instruction_utils {

inline uint8_t getPtrSize() {
    return utils::traceInfo.getTraceWidthBytes();
}

/* udis86 does not tell us if operands are sources or destinations.  Some can
 * be both. For example, add eax, $4.
 * This function uses two methods to determine if the first operand
 * is a source.  First, if x_op1 for the table entry is null, then the first
 * operand is NOT a source.  Next, op1 for mov instructions are always dest
 * only.  Also lea instructions.
 */
bool FirstOpIsSrc(Instruction *instr) {
    // FIXME: check if not possible with udis86 anyway
    switch (instr->uInstr.mnemonic) {
    case UD_Imovsxd:
    case UD_Icmovo:
    case UD_Icmovno:
    case UD_Icmovb:
    case UD_Icmovae:
    case UD_Icmove:
    case UD_Icmovne:
    case UD_Icmovbe:
    case UD_Icmova:
    case UD_Icmovs:
    case UD_Icmovns:
    case UD_Icmovp:
    case UD_Icmovnp:
    case UD_Icmovl:
    case UD_Icmovge:
    case UD_Icmovle:
    case UD_Icmovg:
    case UD_Ifcmovb:
    case UD_Ifcmove:
    case UD_Ifcmovbe:
    case UD_Ifcmovu:
    case UD_Ifcmovnb:
    case UD_Ifcmovne:
    case UD_Ifcmovnbe:
    case UD_Ifcmovnu:
    case UD_Imaskmovq:
    case UD_Imov:
    case UD_Imovapd:
    case UD_Imovaps:
    case UD_Imovd:
    case UD_Imovddup:
    case UD_Imovdqa:
    case UD_Imovdqu:
    case UD_Imovdq2q:
    case UD_Imovhpd:
    case UD_Imovhps:
    case UD_Imovlhps:
    case UD_Imovlpd:
    case UD_Imovlps:
    case UD_Imovhlps:
    case UD_Imovmskpd:
    case UD_Imovmskps:
    case UD_Imovntdq:
    case UD_Imovnti:
    case UD_Imovntpd:
    case UD_Imovntps:
    case UD_Imovntq:
    case UD_Imovq:
    case UD_Imovq2dq:
    case UD_Imovsb:
    case UD_Imovsw:
    case UD_Imovsd:
    case UD_Imovsq:
    case UD_Imovsldup:
    case UD_Imovshdup:
    case UD_Imovss:
    case UD_Imovsx:
    case UD_Imovupd:
    case UD_Imovups:
    case UD_Imovzx:
    case UD_Ipmovmskb:
    case UD_Ipop:
    case UD_Ipopa:
    case UD_Ipopad:
    case UD_Ipopfw:
    case UD_Ipopfd:
    case UD_Ipopfq:
    case UD_Ilds:
    case UD_Ilea:
    case UD_Iles:
    case UD_Ilfs:
    case UD_Ilgs:
    case UD_Ilss:
    case UD_Ilodsb: // Added by Babak. al/ax/eax is just defined in these instruction.
    case UD_Ilodsw:
    case UD_Ilodsd:
    case UD_Ilodsq:

    case UD_Iseto:
    case UD_Isetno:
    case UD_Isetb:
    case UD_Isetae:
    case UD_Isete:
    case UD_Isetne:
    case UD_Isetbe:
    case UD_Iseta:
    case UD_Isets:
    case UD_Isetns:
    case UD_Isetp:
    case UD_Isetnp:
    case UD_Isetl:
    case UD_Isetge:
    case UD_Isetle:
    case UD_Isetg:
        assert(!(instr->uInstr.operand[0].access & UD_OP_ACCESS_READ));
        return false;
    default:
        return (instr->uInstr.operand[0].access & UD_OP_ACCESS_READ) != 0;
        //return true;
    }
}

/*
 * GetInstruction
 *  Given instruction index, get the instruction object
 *
 *  NOTE: since file instructions are stored in a cache, and the
 *  cache may change while the instr is still needed, we malloc
 *  space for a new instruction and copy the found instruction into
 *  it.  This means that calls to GetInstruction must be paired
 *  with a free.
 */
Instruction *fetchInstr(const std::shared_ptr<InstrList>& iList, uint64_t index) {
    if (index >= instructionCount) {
        return nullptr;
    }

    auto *byte_buf = reinterpret_cast<unsigned char *>(iList->iMMap);
    byte_buf += InstrFileHeaderSize;
    auto *instr_array = reinterpret_cast<Instruction *>(byte_buf);
    return &(instr_array[index]);
}
Instruction *fetchPrevInstr(const std::shared_ptr<InstrList>& iList) {
    if (iList->currentInstr == -1) {
        return nullptr;
    }
    Instruction *i = fetchInstr(iList, iList->currentInstr);
    iList->currentInstr = i->prev;
    return i;
}
Instruction *fetchNextInstr(const std::shared_ptr<InstrList>& iList) {
    if (iList->currentInstr == -1) {
        return nullptr;
    }
    Instruction *i = fetchInstr(iList, iList->currentInstr);
    iList->currentInstr = i->next;
    return i;
}

bool isStringOperation(Instruction *instr) {
    switch (instr->uInstr.mnemonic) {
    case UD_Iscasb:
    case UD_Iscasw:
    case UD_Iscasd:
    case UD_Iscasq:

    case UD_Istosb:
    case UD_Istosw:
    case UD_Istosd:
    case UD_Istosq:

    case UD_Icmpsb:
    case UD_Icmpsw:
    case UD_Icmpsd:
    case UD_Icmpsq:

    case UD_Imovsb:
    case UD_Imovsw:
    case UD_Imovsq:

    case UD_Ilodsb:
    case UD_Ilodsw:
    case UD_Ilodsd:
    case UD_Ilodsq:
        return true;

    case UD_Imovsd:
        // Imovsd can both be Move Data from String to String or Move or Merge Scalar Double-Precision Floating-Point Value
        return isMoveDataFromStringToString(instr);

    default:
        return false;
    }
}

DeobfRegisterUses getImplicitNonMemoryDestinationRegisters(Instruction *instr) {
    DeobfRegisterUses bv{};
    if (isStringOperation(instr) && instr->uInstr.operand[0].type != UD_NONE) {
        utils::logger.log("unhandled explicit string operation");
        return bv;
    }
    // A rep prefix defines ECX implicitly, but not in all cases (i.e. rep* ret).
    if (hasREPPrefix(instr) && instr->uInstr.mnemonic != UD_Iret) {
        bv.set(DeobfRegister::ECX);
    }
    switch (instr->uInstr.mnemonic) {
    case UD_Istosb:
    case UD_Iscasb:
    case UD_Istosw:
    case UD_Iscasw:
    case UD_Istosd:
    case UD_Iscasd:
    case UD_Istosq:
    case UD_Iscasq:
        break;
    case UD_Imovsb:
    case UD_Imovsw:
    case UD_Imovsd:
    case UD_Imovsq:
        break;
    case UD_Ilodsb:
        bv.set(DeobfRegister::AL);
        break;
    case UD_Ilodsw:
        bv.set(DeobfRegister::AX);
        break;
    case UD_Ilodsd:
    case UD_Ilodsq:
        bv.set(DeobfRegister::EAX);
        // FIXME: split up!
        break;
    default:
        break;
    }

    return bv;
}

DeobfRegisterUses getImplicitMemoryDestinationRegisters(Instruction *instr) {
    DeobfRegisterUses bv{};
    if (isStringOperation(instr) && instr->uInstr.operand[0].type != UD_NONE) {
        utils::logger.log("unhandled explicit string operation");
        return bv;
    }
    switch (instr->uInstr.mnemonic) {
    case UD_Istosb:
    case UD_Iscasb:
    case UD_Istosw:
    case UD_Iscasw:
    case UD_Istosd:
    case UD_Iscasd:
    case UD_Istosq:
    case UD_Iscasq:
        switch (instr->uInstr.opr_mode) {
        case 64:
            bv.set(DeobfRegister::RDI);
            break;
        case 32:
            bv.set(DeobfRegister::EDI);
            break;
        case 16:
            bv.set(DeobfRegister::DI);
        }
        break;
    case UD_Imovsd:
        // Imovsd can both be Move Data from String to String or Move or Merge Scalar Double-Precision Floating-Point Value
        if (!isMoveDataFromStringToString(instr)) {
            break;
        }
        [[fallthrough]];
    case UD_Imovsb:
    case UD_Imovsw:
    case UD_Imovsq:
        bv.set(DeobfRegister::ESI);
        bv.set(DeobfRegister::EDI);
        break;
    case UD_Ilodsb:
    case UD_Ilodsw:
    case UD_Ilodsd:
    case UD_Ilodsq:
        bv.set(DeobfRegister::ESI);
        break;
    default:
        break;
    }
    return bv;
}

inline DeobfRegisterUses getImplicitDestinationRegisters(Instruction *instr) {
    return getImplicitNonMemoryDestinationRegisters(instr) | getImplicitMemoryDestinationRegisters(instr);
};

DeobfRegisterUses getImplicitMemorySourceRegisters(Instruction *instr) {
    DeobfRegisterUses bv{};
    if (isStringOperation(instr) && instr->uInstr.operand[0].type != UD_NONE) {
        utils::logger.log("unhandled explicit string operation");
        return bv;
    }
    switch (instr->uInstr.mnemonic) {
    case UD_Istosb:
    case UD_Iscasb:
    case UD_Istosw:
    case UD_Iscasw:
    case UD_Istosd:
    case UD_Iscasd:
    case UD_Istosq:
    case UD_Iscasq:
        bv.set(DeobfRegister::EDI);
        break;
    case UD_Imovsd:
        // Imovsd can both be Move Data from String to String or Move or Merge Scalar Double-Precision Floating-Point Value
        if (!isMoveDataFromStringToString(instr)) {
            break;
        }
        [[fallthrough]];
    case UD_Icmpsb:
    case UD_Icmpsw:
    case UD_Icmpsd:
    case UD_Icmpsq:

    case UD_Imovsb:
    case UD_Imovsw:
    case UD_Imovsq:
        bv.set(DeobfRegister::ESI).set(DeobfRegister::EDI);
        break;
    case UD_Ilodsb:
    case UD_Ilodsw:
    case UD_Ilodsd:
    case UD_Ilodsq:
        bv.set(DeobfRegister::ESI);
        break;
    default:
        break;
    }

    return bv;
}

DeobfRegisterUses getImplicitNonMemorySourceRegisters(Instruction *instr) {
    DeobfRegisterUses bv{};
    if (isStringOperation(instr) && instr->uInstr.operand[0].type != UD_NONE) {
        utils::logger.log("unhandled explicit string operation");
        return bv;
    }
    // rep prefix which defines ecx register. Added by Babak.
    if (hasREPPrefix(instr)) {
        bv.set(DeobfRegister::ECX);
    }
    switch (instr->uInstr.mnemonic) {
    case UD_Istosb:
    case UD_Iscasb:
        bv.set(DeobfRegister::AL); // FIXME: we can probably remove this
        break;
    case UD_Istosw:
    case UD_Iscasw:
        bv.set(DeobfRegister::AX);
        break;
    case UD_Istosd:
    case UD_Iscasd:
    case UD_Istosq:
    case UD_Iscasq:
        bv.set(DeobfRegister::EAX);
        // FIXME: break up
        break;
    case UD_Icmpsb:
    case UD_Icmpsw:
    case UD_Icmpsd:
    case UD_Icmpsq:
    case UD_Imovsb:
    case UD_Imovsw:
    case UD_Imovsd:
    case UD_Imovsq:
        break;
    case UD_Ilodsb:
    case UD_Ilodsw:
    case UD_Ilodsd:
    case UD_Ilodsq:
        break;
    default:
        break;
    }
    return bv;
}

DeobfRegisterUses calculateDestinationRegisters(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    DeobfRegisterUses def{};
    ud_operand_t op0 = instr->uInstr.operand[0];
    ud_operand_t op1 = instr->uInstr.operand[1];

    // if x_op1 is not null, it represents a destination
    if (op0.type == UD_OP_REG && (op0.access & UD_OP_ACCESS_WRITE)) {
        def.set(glue::toDeobfRegister(glue::correctRegisterWidth(op0.base, utils::getRegisterWidth(instr->uInstr.opr_mode))));
    }

    // both xchg and xadd use the second operand as destination, so add them.
    if (instr->uInstr.mnemonic == UD_Ixchg || instr->uInstr.mnemonic == UD_Ixadd) {
        if (op1.type == UD_OP_REG) {
            def.set(glue::toDeobfRegister(glue::correctRegisterWidth(op1.base, utils::getRegisterWidth(instr->uInstr.opr_mode))));
        }
    }

    // op2 will never have dest registers, so can be skipped

    // add implicit destinations if they are defined
    if (instr->uInstr.impl_dst1 != UD_NONE) {
        def.set(glue::toDeobfRegister(instr->uInstr.impl_dst1));
    }
    if (instr->uInstr.impl_dst2 != UD_NONE) {
        def.set(glue::toDeobfRegister(instr->uInstr.impl_dst2));
    }

    // Handle special cases such as string ops
    def |= getImplicitDestinationRegisters(instr);

    // Some operands change all registers (except (E)SP.
    // TODO: check if this behaviour is correct
    if (instr->uInstr.mnemonic == UD_Ipopa || instr->uInstr.mnemonic == UD_Ipopad) {
        def.set(registers32bitMode32bit);
    }

    // For cmpxchg, the destination depends on the ZF flag in the next instruction
    if (instr->uInstr.mnemonic == UD_Icmpxchg || instr->uInstr.mnemonic == UD_Icmpxchg8b) {
        DEOBF_REGISTER_VALUE eax1, eax2;
        eax1 = instr->eax;
        Instruction *temp_ins = fetchInstr(iList, instr->order + 1);
        eax2 = temp_ins->eax;
        if (eax1 == eax2) {
            DeobfRegister resized = utils::resizeBaseRegister(DeobfRegister::RAX, utils::traceInfo.getTraceWidth());
            if (instr->uInstr.operand[0].type == UD_OP_REG) {
                if (instr->uInstr.operand[0].base != glue::toUDRegister(resized)) {
                    def.reset(resized);
                }
            } else {
                // op type is memory, unset EAX
                def.reset(resized);
                if (instr->uInstr.mnemonic == UD_Icmpxchg8b) {
                    def.reset(utils::resizeBaseRegister(DeobfRegister::RDX, utils::traceInfo.getTraceWidth()));
                }
            }
        } else {
            // ZF is cleared in next flag, i.e. OP1 != AL/AX/EAX/RAX
            if (instr->uInstr.operand[0].type == UD_OP_REG) {
                def.reset(glue::toDeobfRegister(instr->uInstr.operand[0].base));
            }
        }
    }

    if (instr->uInstr.mnemonic == UD_Icall) {
        def.set(utils::resizeBaseRegister(DeobfRegister::RSP, utils::traceInfo.getTraceWidth()));
    }

    if (instr->uInstr.mnemonic == UD_Iaam) {
        def.reset().set(DeobfRegister::AX);
    }

    return def;
}

DeobfRegisterUses definedRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    if (instr->regFlagsKnown & RegDefKnown) {
        DeobfRegisterUses r(instr->destinationRegisters);
        return r;
    }
    return calculateDestinationRegisters(iList, instr);
}

DeobfRegisterUses calculateMemorySourceRegisters(Instruction *instr) {
    DeobfRegisterUses use{};
    for (int i = 0; i < 3; i++) {
        // skip lea as we treat it as non-memory
        if ((instr->uInstr.mnemonic != UD_Ilea) && (instr->uInstr.operand[i].type == UD_OP_MEM)) {
            use.set(glue::toDeobfRegister(instr->uInstr.operand[i].base));
            use.set(glue::toDeobfRegister(instr->uInstr.operand[i].index));
        }
    }
    // handle implicit memory reg sources TODO: others?
    if (isPush(instr) || isPop(instr) || (instr->uInstr.mnemonic == UD_Iret) || (instr->uInstr.mnemonic == UD_Ileave) || (instr->uInstr.mnemonic == UD_Icall)) {
        use.set(glue::toDeobfRegister(instr->uInstr.impl_src1));
        use.set(glue::toDeobfRegister(instr->uInstr.impl_src2));
    }

    // handle special cases (e.g. string operations)
    use |= getImplicitMemorySourceRegisters(instr);
    return use;
}

DeobfRegisterUses calculateNonMemorySourceRegisters(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    DeobfRegisterUses use{};
    ud_operand_t op0 = instr->uInstr.operand[0];

    // first (0th) operand may be src, dest, or both. Handle as special case
    if (FirstOpIsSrc(instr)) {
        if (op0.type == UD_OP_REG) {
            use.set(glue::toDeobfRegister(glue::correctRegisterWidth(op0.base, utils::getRegisterWidth(op0.size))));
            // FIXME: validate for 16 bit reg
        }
    }

    for (int i = 1; i < 3; i++) {
        ud_operand_t op = instr->uInstr.operand[i];
        if (op.type == UD_OP_REG) {
            use.set(glue::toDeobfRegister(op.base));
        } else if (instr->uInstr.mnemonic == UD_Ilea && op.type == UD_OP_MEM) {
            // handle lea as non-memory use of registers
            use.set(glue::toDeobfRegister(op.base));
            use.set(glue::toDeobfRegister(op.index));
        }
    }

    // handle implicit sources TODO: Other exceptions besides push/pop?
    if (!isPush(instr) && !isPop(instr) && (instr->uInstr.mnemonic != UD_Iret) && (instr->uInstr.mnemonic != UD_Ileave) &&
        (instr->uInstr.mnemonic != UD_Icall)) {
        if (instr->uInstr.impl_src1 != UD_NONE) {
            use.set(glue::toDeobfRegister(instr->uInstr.impl_src1));
        }
        if (instr->uInstr.impl_src2 != UD_NONE) {
            use.set(glue::toDeobfRegister(instr->uInstr.impl_src2));
        }
    }

    // handle special cases (e.g. string operations)
    use |= getImplicitNonMemorySourceRegisters(instr);

    /* Special Cases:
     *
     * CMPXCHG
     * The reg-used depends on the ZF flag of next instruction in dynamic trace
     * (OP2 must be a register)
     */
    if (instr->uInstr.mnemonic == UD_Icmpxchg) {
        DEOBF_REGISTER_VALUE eax1, eax2;
        eax1 = instr->eax;
        Instruction *temp_ins = fetchInstr(iList, (instr->order) + 1);
        eax2 = temp_ins->eax;
        if (eax1 != eax2) {
            // ZF is cleared in next flag, i.e. OP1 != AL/AX/EAX/RAX
            // then we have to remove OP2 from reg use-set
            use.reset(glue::toDeobfRegister(instr->uInstr.operand[1].base));
        }
    }
    if (instr->uInstr.mnemonic == UD_Iaam) {
        use.reset().set(DeobfRegister::AX);
    }

    // TODO: should we include ENTER and LEAVE?
    return use;
}

void calculateFlagsAndRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    instr->destinationRegisters = calculateDestinationRegisters(iList, instr).toRegisterBitmask();
    instr->regFlagsKnown |= RegDefKnown;

    instr->sourceMemoryRegisters = calculateMemorySourceRegisters(instr).toRegisterBitmask();
    instr->regFlagsKnown |= MemRegUsedKnown;

    instr->sourceNonMemoryRegisters = calculateNonMemorySourceRegisters(iList, instr).toRegisterBitmask();

    if (instr->uInstr.mnemonic == UD_Ipushad) {
        instr->sourceNonMemoryRegisters = instr->sourceMemoryRegisters;
        instr->sourceMemoryRegisters = 0;
    }

    instr->regFlagsKnown |= NonMemRegUsedKnown;

    // UDis86 sets no flags for call instructions, but a task switch might set all.
    if (ALLOW_TASK_SWITCH_CALLS && instr->uInstr.mnemonic == UD_Icall) {
        instr->flagsDef = PSW_ALL;
    } else {
        instr->flagsDef = instr->uInstr.psw;
    }
    instr->regFlagsKnown |= FlagsDefKnown;

    instr->flagsUsed = instr->uInstr.pswUsed;
    instr->regFlagsKnown |= FlagsUsedKnown;
}

DeobfRegisterUses definedMemoryRegistersForInstruction(Instruction *instr) {
    if (instr->regFlagsKnown & MemRegUsedKnown) {
        DeobfRegisterUses r(instr->sourceMemoryRegisters);
        return r;
    }
    return calculateMemorySourceRegisters(instr);
}

/*
 * calculate any registers used by instruction that do NOT
 * contribute to calculation of a memory address
 */
DeobfRegisterUses definedNonMemoryRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    if (instr->regFlagsKnown & NonMemRegUsedKnown) {
        DeobfRegisterUses r(instr->sourceNonMemoryRegisters);
        return r;
    }
    return calculateNonMemorySourceRegisters(iList, instr);
}

bool SaveInstrChange(const std::shared_ptr<InstrList>& iList, Instruction *instr, bool ignoreFtn) {
    assert(instr);

    if (instrHasFlag(instr, INSTR_IS_DELETED) && instrHasFlag(instr, INSTR_USED_AS_CALL)) {
        instrRemoveFlag(instr, INSTR_IS_DELETED);
        return false;
    }
    if (instr->next == -1 || instr->prev == -1) {
        return false;
    }

    if (instrHasFlag(instr, INSTR_IS_DELETED)) {
        const std::string ftnName = persistentStorage.functionNameForIdx(instr->funcName);
        if (!ftnName.empty() && ftnName != "unknown" && !ignoreFtn) {
            instrRemoveFlag(instr, INSTR_IS_DELETED);
            instrSetFlag(instr, INSTR_UNSIMPLIFIABLE, __LINE__);
            return false;
        }

        Instruction *NextLive = fetchInstr(iList, instr->next);
        Instruction *PrevLive = fetchInstr(iList, instr->prev);
        if (PrevLive != nullptr && NextLive != nullptr) {
            PrevLive->next = NextLive->order;
            NextLive->prev = PrevLive->order;
        }
    }
    return true;
}

void carefulCopyUDins2InsStr(const std::shared_ptr<InstrList>& iList, Instruction *instr, ins_structure *uIns, ud_t *udIns, bool doNotChangeFlags, int line) {
    if (udIns == nullptr) {
        udIns = static_cast<ud_t *>(malloc(sizeof(ud_t)));
        return;
    }

    DEBUG(5, fmt::format("Modifying instruction on line {} - {:#x} @ {} | OLD {} | NEW {}", line, instr->addr, instr->order, *instr, UDCreate::stringifyUD(udIns)));

    glue::populateInsStructureFromUDisObject(uIns, udIns, utils::traceInfo.getTraceWidth());

    PSW_BITVECTOR tmpFlagsDef = 0, tmpFlagsUsed = 0;
    if (doNotChangeFlags) {
        tmpFlagsDef = instr->flagsDef;
        tmpFlagsUsed = instr->flagsUsed;
    }
    calculateFlagsAndRegistersForInstruction(iList, instr);
    if (doNotChangeFlags) {
        instr->flagsDef = tmpFlagsDef;
        instr->flagsUsed = tmpFlagsUsed;
    }
    instr->regFlagsKnown &= ~MemUsedKnown; // mem used stored in abbreviated form
    instr->regFlagsKnown &= ~MemDefKnown;

    instr->memUsedMin = 0;
    instr->memUsedSize = 0;
    instr->memDefMin = 0;
    instr->memDefSize = 0;

    auto nws = memoryDefined(iList, instr);
    instr->regFlagsKnown |= MemDefKnown;
    if (nws->empty()) {
        instrRemoveFlag(instr, INSTR_WRITES_MEM);
    } else {
        instrSetFlag(instr, INSTR_WRITES_MEM, __LINE__);
        if (nws->rangeCount() == 1) {
            instr->regFlagsKnown |= MemDefKnown;
            auto r = nws->getRange(0);
            instr->memDefMin = r->min;
            instr->memDefSize = r->max - r->min + 1;
        }
    }

    nws = memoryUsed(iList, instr);
    instr->regFlagsKnown |= MemUsedKnown;
    if (nws->empty()) {
        instrRemoveFlag(instr, INSTR_READS_MEM);
    } else {
        instrSetFlag(instr, INSTR_READS_MEM, __LINE__);
        if (nws->rangeCount() == 1) {
            instr->regFlagsKnown |= MemUsedKnown;
            auto r = nws->getRange(0);
            instr->memUsedMin = r->min;
            instr->memUsedSize = r->max - r->min + 1;
        }
    }
}

std::unique_ptr<deobf::library::writeset::WriteSet> memoryDefined(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    auto ws = std::make_unique<deobf::library::writeset::WriteSet>();
    // Use calculated version if available
    if (instr->regFlagsKnown & MemDefKnown) {
        if (instr->memDefMin != 0x0) {
            // if known not to be null
            ws->addRange(instr->memDefMin, instr->memDefMin + instr->memDefSize - 1);
        }
    } else {
        // Explicit targets
        ud_operand_t op0 = instr->uInstr.operand[0];
        ud_operand_t op1 = instr->uInstr.operand[1];

        if ((op0.access & UD_OP_ACCESS_WRITE) && op0.type == UD_OP_MEM) {
            // get explicit targets -- xchg is only instr I know of that can
            // have second op as mem dest.  xchg cannot have two mem operands.
            if (instr->uInstr.mnemonic == UD_Ixchg && op1.type == UD_OP_MEM) {
                ws->addRange(calculateTargetForInstruction(instr, op1));
            } else {
                ws->addRange(calculateTargetForInstruction(instr, op0));
            }
        }

        // Implicit targets
        ws->addRange(getImplicitTarget(iList, instr));

        /* Special Cases
         *
         * CMPXCHG
         * The reg-used depends on the ZF flag of next instruction in dynamic trace (OP2 must be a register)
         */
        if (instr->uInstr.mnemonic == UD_Icmpxchg) {
            DEOBF_REGISTER_VALUE eax1, eax2;
            eax1 = instr->eax;
            Instruction *temp_ins = fetchInstr(iList, (instr->order) + 1);
            eax2 = temp_ins->eax;
            // If they're equal, ZF is set in next flag, i.e. OP1 == AL/AX/EAX/RAX
            // Else, ZF is cleared in next flag, i.e. OP1 != AL/AX/EAX/RAX
            if (eax1 != eax2) {
                if (instr->uInstr.operand[0].type == UD_OP_MEM) {
                    ws->clear();
                }
            }
        }
    }
    return ws;
}


/**
 * Handle some special cases. Added when they are encountered.
 * @param iList
 * @param instr
 * @return
 */
std::unique_ptr<deobf::library::writeset::Range> getImplicitMemorySourceForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    int addrSize = 0;
    int srcVal = 0;
    int start = 1;
    int end = 0;
    ud_type srcReg;
    int operandSize;

    uint64_t min = 1, max = 0;

    switch (instr->uInstr.mnemonic) {
    case UD_Imovsd:
        // Imovsd can both be Move Data from String to String or Move or Merge Scalar Double-Precision Floating-Point Value
        if (!isMoveDataFromStringToString(instr)) {
            break;
        }
        [[fallthrough]];
    case UD_Ilodsb:
    case UD_Imovsb:
    case UD_Iscasb:
    case UD_Ilodsw:
    case UD_Imovsw:
    case UD_Iscasw:
    case UD_Ilodsd:
    case UD_Iscasd:
    case UD_Ilodsq:
    case UD_Imovsq:
    case UD_Iscasq:
        switch (instr->uInstr.mnemonic) {
        case UD_Ilodsb:
        case UD_Imovsb:
            addrSize = 1;
            srcReg = UD_R_ESI;
            break;
        case UD_Iscasb:
            addrSize = 1;
            srcReg = UD_R_EDI;
            break;
        case UD_Ilodsw:
        case UD_Imovsw:
            addrSize = 2;
            srcReg = UD_R_ESI;
            break;
        case UD_Iscasw:
            addrSize = 2;
            srcReg = UD_R_EDI;
            break;
        case UD_Ilodsd:
        case UD_Imovsd:
            addrSize = 4;
            srcReg = UD_R_ESI;
            break;
        case UD_Iscasd:
            addrSize = 4;
            srcReg = UD_R_EDI;
            break;
        case UD_Ilodsq:
        case UD_Imovsq:
            addrSize = 8;
            srcReg = UD_R_ESI;
            break;
        case UD_Iscasq:
            addrSize = 8;
            srcReg = UD_R_EDI;
            break;
        default:
            addrSize = 0;
            srcReg = UD_NONE;
            break;
        }
        {
            Instruction *next = fetchInstr(iList, instr->order + 1);
            srcVal = GetRegisterValue(instr, srcReg);

            // if instr has repeat prefix, need to calculate how many iterations
            if (hasREPPrefix(instr)) {
                start = GetRegisterValue(instr, UD_R_ECX);
                if (next) {
                    end = GetRegisterValue(next, UD_R_ECX);
                }
            }

            // if no repeat, then it was just one by definition.
            min = srcVal;
            max = srcVal + ((start - end) * addrSize) - 1;
        }

        break;
    case UD_Ipop:
        operandSize = utils::getRegisterByteWidth(glue::toDeobfRegister(instr->uInstr.operand[0].base));
        min = GetRegisterValue(instr, UD_R_ESP);
        max = min + operandSize - 1;
        break;
    case UD_Iret:
    case UD_Ipopfw:
    case UD_Ipopfd:
    case UD_Ipopfq:
        // return instruction is implicit pop, pops addr to jump to
        min = GetRegisterValue(instr, UD_R_ESP);
        max = min + getPtrSize() - 1;
        break;
    case UD_Ipopa:
    case UD_Ipopad:
        min = GetRegisterValue(instr, UD_R_ESP);
        max = min + 8 * getPtrSize() - 1;
        break;
    default:
        break;
    }

    if (min <= max) {
        return std::make_unique<deobf::library::writeset::Range>(min, max);
    }
    return nullptr;
}

std::unique_ptr<deobf::library::writeset::WriteSet> memoryUsed(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    auto ws = std::make_unique<deobf::library::writeset::WriteSet>();
    // Use calculated version if available
    if (instr->regFlagsKnown & MemUsedKnown) {
        if (instr->memUsedMin != 0x0) {
            // if known not to be null
            ws->addRange(instr->memUsedMin, instr->memUsedMin + instr->memUsedSize - 1);
        }
    } else {
        // first (0th) operand may be src, dest, or both. Handle as special case
        uint8_t start = deobf::library::instruction_utils::FirstOpIsSrc(instr) ? 0 : 1;

        // for the last two operands
        for (uint8_t i = start; i < 3; i++) {
            if (instr->uInstr.operand[i].type == UD_OP_MEM) {
                ws->addRange(calculateTargetForInstruction(instr, instr->uInstr.operand[i]));
            }
        }

        ws->addRange(getImplicitMemorySourceForInstruction(iList, instr));
    }
    return ws;
}

/* calculateTargetForInstruction
 *  Takes instr and operand, and returns range of memory addresses pointed
 *  to by that operand.
 *
 *  assumes that op has already been determined to be memory access operand
 */
std::unique_ptr<deobf::library::writeset::Range> calculateTargetForInstruction(Instruction *instr, ud_operand_t op) {
    uint64_t target = 0;
    uint64_t base = GetRegisterValue(instr, op.base);
    uint64_t index = GetRegisterValue(instr, op.index);
    uint8_t scale = op.scale;
    uint32_t displacement = op.lval.udword;

    if (op.base == UD_NONE && op.index == UD_NONE && op.lval.udword == 0) {
        // Triggered when 32 bit calls to fs[] are made. Added by Babak. Returning nullptr because the fs value is not
        // tracked in 32 bit traces.
        return nullptr;
    }

    uint64_t min = 1, max = 0;

    // HACK: for src operand of the instr: mov edx, [edi+eax]
    // udis86 will give base reg = edi, index reg = eax, scale = 0!!
    if ((index > 0) && (scale == 0)) {
        scale = 1;
    }

    if (op.base != UD_NONE) {
        /*
         * An interesting corner case occurs when we pop into the location on
         * top of the stack: "pop [esp]".  According to the Intel reference
         * manual, the destination location will be updated before ESP is
         * updated, which would mean that the location written is popped off ths
         * stack; however, dynamic traces indicate that ESP is updated before
         * the destination is written.  Possibly the reason is that the actual
         * hardware implementation is along the lines of:
         *
         *     _tmpReg := pop(esp); dest := _tmpReg
         *
         * This only affects instructions where we use esp as a base or index
         * register in the pop; such instructions have to be special-cased.
         *
         */
        if (instr->uInstr.mnemonic == UD_Ipop) {
            uint8_t registerByteWidth = utils::getRegisterByteWidth(glue::toDeobfRegister(op.base));
            if (op.base == UD_R_ESP) {
                base += registerByteWidth;
            }
            if (op.index == UD_R_ESP) {
                base += registerByteWidth;
            }
        }

        target = base + (index * scale);

        target += glue::getSizedLval(op);
    } else {
        target = displacement;
        if (op.index != UD_NONE) {
            // we have the form [index * scale + immediate_displacement]
            target += index * scale;
        }
    }

    if (instr->uInstr.pfx_seg == UD_R_FS && utils::traceInfo.is64bit()) {
        // Override current results so far...
        // We have (FS or GS).base + index + displacement
        DEOBF_REGISTER_VALUE fs = instr->fs;
        target = fs + base + displacement;
    }

    min = target;
    max = target + (op.size / 8) - 1;

    if (min <= max) {
        return std::make_unique<deobf::library::writeset::Range>(min, max);
    }
    return nullptr;
}

/**
 * Handle some special cases. Added when they are encountered.
 * @param iList
 * @param instr
 * @return
 */
std::unique_ptr<deobf::library::writeset::Range> getImplicitTarget(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    int addrSize = 0;
    int destVal = 0;
    int start = 1;
    int end = 0;
    uint8_t operandSize;

    uint64_t min = 1, max = 0;

    switch (instr->uInstr.mnemonic) {
    case UD_Imovsd:
        // Imovsd can both be Move Data from String to String or Move or Merge Scalar Double-Precision Floating-Point Value
        if (!isMoveDataFromStringToString(instr)) {
            break;
        }
        [[fallthrough]];
    case UD_Imovsb:
    case UD_Istosb:
    case UD_Imovsw:
    case UD_Istosw:
    case UD_Istosd:
    case UD_Imovsq:
    case UD_Istosq:
        switch (instr->uInstr.mnemonic) {
        case UD_Imovsb:
        case UD_Istosb:
            addrSize = 1;
            break;

        case UD_Imovsw:
        case UD_Istosw:
            addrSize = 2;
            break;

        case UD_Imovsd:
        case UD_Istosd:
            addrSize = 4;
            break;

        case UD_Imovsq:
        case UD_Istosq:
            addrSize = 8;
            break;
        default:
            addrSize = 0;
            break;
        }
        {
            Instruction *next = fetchInstr(iList, instr->order + 1);
            destVal = GetRegisterValue(instr, UD_R_EDI);

            // if instr has repeat prefix, need to calculate how many iterations
            if (hasREPPrefix(instr)) {
                start = GetRegisterValue(instr, UD_R_ECX);
                if (next) {
                    end = GetRegisterValue(next, UD_R_ECX);
                }
            }

            // if no repeat, then it was just one by definition.
            min = destVal;
            max = destVal + ((start - end) * addrSize) - 1;
        }
        break;
    case UD_Ipush: {
        ud_operand &op0 = instr->uInstr.operand[0];
        operandSize = op0.type == UD_OP_IMM ? getPtrSize() : utils::getRegisterByteWidth(glue::toDeobfRegister(op0.base));
    }
        min = GetRegisterValue(instr, UD_R_ESP) - operandSize;
        max = min + operandSize - 1;
        break;
    case UD_Icall:
    case UD_Ipushfw:
    case UD_Ipushfd:
    case UD_Ipushfq:
        // call is implicit push, pushes addr of next instr for ret
        min = GetRegisterValue(instr, utils::resizeBaseRegister(DeobfRegister::RSP, utils::traceInfo.getTraceWidth())) - getPtrSize();
        max = min + getPtrSize() - 1;
        break;
    case UD_Ipusha:
    case UD_Ipushad:
        // push all's push 8 user registers. Since it's not a valid instruction on 64 bit, we can hardcode the register number.
        min = GetRegisterValue(instr, UD_R_ESP) - 8 * getPtrSize();
        max = min + 8 * getPtrSize() - 1;
    default:
        break;
    }

    if (min <= max) {
        return std::make_unique<deobf::library::writeset::Range>(min, max);
    }

    return nullptr;
}

DEOBF_REGISTER_VALUE GetRegisterValue(Instruction *instr, DeobfRegister reg) {
    if (!instr || reg == DeobfRegister::NONE) {
        return 0;
    }
    Registers r(instr);
    return r.getRegisterValue(reg);
}

/*
 * UDOpIsRegister(op) checks whether its operand is a general-purpose
 * register.  If it is, it returns the register; otherwise it returns
 * the value UD_NONE.
 */
ud_type UDOpIsRegister(ud_operand_t *op) {
    if (op->type == UD_OP_REG) {
        return op->base;
    }

    return UD_NONE;
}

bool OperandsAreEqual(ud_operand_t *op0, ud_operand_t *op1) {
    if (op0->type != op1->type)
        return false;
    switch (op0->type) {
    case UD_OP_MEM:
        return op0->base == op1->base && op0->index == op1->index && op0->offset == op1->offset && op0->scale == op1->scale;
    case UD_OP_REG:
        return op0->base == op1->base;
    case UD_OP_IMM:
    case UD_OP_CONST:
        return op0->lval.sdword == op1->lval.sdword;
    default:
        return true;
    }
}

Instruction *ThreeXorsToXchg(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    ud_operand_t *op0, *op1;

    Instruction *second;

    op0 = &(instr->uInstr.operand[0]);
    op1 = &(instr->uInstr.operand[1]);
    int regsFirstInstr = UDOpIsRegister(op0) | UDOpIsRegister(op1);
    while ((second = fetchNextInstr(iList)) != nullptr) {
        if (second->uInstr.mnemonic == UD_Ixor && OperandsAreEqual(op0, &(second->uInstr.operand[1])) && OperandsAreEqual(op1, &(second->uInstr.operand[0]))) {
            Instruction *third;
            while ((third = fetchNextInstr(iList)) != nullptr) {
                if (third->uInstr.mnemonic == UD_Ixor && OperandsAreEqual(op0, &(third->uInstr.operand[0])) &&
                    OperandsAreEqual(op1, &(third->uInstr.operand[1]))) {
                    // FIXME: Not suited for 64 bit
                    if (instr->uInstr.bytes[0] != 0x66) {
                        if (instr->uInstr.bytes[0] == 0x31) {
                            instr->uInstr.bytes[0] = 0x87;
                        } else {
                            instr->uInstr.bytes[0] = 0x86;
                        }
                    } else {
                        instr->uInstr.bytes[1] = 0x87;
                    }
                    ud_t *udins = UDCreate::createDisassembledUD(instr->uInstr.bytes, MAX_X86_INSTR_LEN);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, false, __LINE__);
                    free(udins);
                    // instrSetFlag(second, INSTR_IS_DELETED);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    SaveInstrChange(iList, instr);

                    instrSetFlag(second, INSTR_IS_DELETED, __LINE__);
                    instrSetFlag(third, INSTR_IS_DELETED, __LINE__);

                    SaveInstrChange(iList, third);
                    SaveInstrChange(iList, second);

                    return instr;
                } else {
                    if (third->uInstr.operand[0].type == UD_OP_REG && (regsFirstInstr & third->uInstr.operand[0].base)) {
                        return nullptr;
                    }
                    if (third->uInstr.operand[1].type == UD_OP_REG && (regsFirstInstr & third->uInstr.operand[1].base)) {
                        return nullptr;
                    }
                    if (instrHasFlag(third, INSTR_READS_MEM)) {
                        if ((instr->memUsedMin >= third->memUsedMin && instr->memUsedMin <= third->memUsedMin + third->memUsedSize - 1) ||
                            (instr->memUsedMin + instr->memUsedSize - 1 <= third->memUsedMin + third->memUsedSize - 1 &&
                             instr->memUsedMin + instr->memUsedSize - 1 >= third->memUsedMin)) {
                            return nullptr;
                        }
                    } else if (instrHasFlag(third, INSTR_WRITES_MEM)) {
                        if ((instr->memUsedMin >= third->memDefMin && instr->memUsedMin <= third->memDefMin + third->memDefSize - 1) ||
                            (instr->memDefMin + instr->memDefSize - 1 <= third->memDefMin + third->memDefSize - 1 &&
                             instr->memDefMin + instr->memDefSize - 1 >= third->memDefMin)) {
                            return nullptr;
                        }
                    }
                }
            }

        } else {
            if (second->uInstr.operand[0].type == UD_OP_REG && (regsFirstInstr & second->uInstr.operand[0].base)) {
                return nullptr;
            }
            if (second->uInstr.operand[1].type == UD_OP_REG && (regsFirstInstr & second->uInstr.operand[1].base)) {
                return nullptr;
            }
            if (instrHasFlag(second, INSTR_READS_MEM)) {
                if ((instr->memUsedMin >= second->memUsedMin && instr->memUsedMin <= second->memUsedMin + second->memUsedSize - 1) ||
                    (instr->memUsedMin + instr->memUsedSize - 1 <= second->memUsedMin + second->memUsedSize - 1 &&
                     instr->memUsedMin + instr->memUsedSize - 1 >= second->memUsedMin)) {
                    return nullptr;
                }
            } else if (instrHasFlag(second, INSTR_WRITES_MEM)) {
                if ((instr->memUsedMin >= second->memDefMin && instr->memUsedMin <= second->memDefMin + second->memDefSize - 1) ||
                    (instr->memUsedMin + instr->memUsedSize - 1 <= second->memDefMin + second->memDefSize - 1 &&
                     instr->memUsedMin + instr->memUsedSize - 1 >= second->memDefMin)) {
                    return nullptr;
                }
            }
        }
    }
    return nullptr;
}

Instruction *TransformXchgNotXchgToNot(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    Instruction *second;

    ud_operand_t *op0, *op1;

    op0 = &(instr->uInstr.operand[0]);
    op1 = &(instr->uInstr.operand[1]);
    int regsFirstInstr = UDOpIsRegister(op0) | UDOpIsRegister(op1);
    while ((second = fetchNextInstr(iList)) != nullptr) {
        if (second->uInstr.mnemonic == UD_Inot && OperandsAreEqual(op1, &(second->uInstr.operand[0]))) {
            Instruction *third;
            while ((third = fetchNextInstr(iList)) != nullptr) {
                if (third->uInstr.mnemonic == UD_Ixchg && OperandsAreEqual(op0, &(third->uInstr.operand[0])) &&
                    OperandsAreEqual(op1, &(third->uInstr.operand[1]))) {
                    ud_t *udins;
                    if (op0->type == UD_OP_MEM) {
                        udins = UDCreate::notMem(instr->memDefMin, instr->memDefSize);
                    } else {
                        udins = UDCreate::notOnReg(op0->base);
                    }
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, false, __LINE__);
                    glue::freeUDStructure(udins, true);

                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    SaveInstrChange(iList, instr);
                    instrSetFlag(second, INSTR_IS_DELETED, __LINE__);
                    SaveInstrChange(iList, second);
                    instrSetFlag(third, INSTR_IS_DELETED, __LINE__);
                    SaveInstrChange(iList, third);

                    return instr;
                } else {
                    if (third->uInstr.operand[0].type == UD_OP_REG && (regsFirstInstr & third->uInstr.operand[0].base)) {
                        return nullptr;
                    }
                    if (third->uInstr.operand[1].type == UD_OP_REG && (regsFirstInstr & third->uInstr.operand[1].base)) {
                        return nullptr;
                    }
                    if (instrHasFlag(third, INSTR_READS_MEM)) {
                        if ((instr->memUsedMin >= third->memUsedMin && instr->memUsedMin <= third->memUsedMin + third->memUsedSize - 1) ||
                            (instr->memUsedMin + instr->memUsedSize - 1 <= third->memUsedMin + third->memUsedSize - 1 &&
                             instr->memUsedMin + instr->memUsedSize - 1 >= third->memUsedMin)) {
                            return nullptr;
                        }
                    } else if (instrHasFlag(third, INSTR_WRITES_MEM)) {
                        if ((instr->memUsedMin >= third->memDefMin && instr->memUsedMin <= third->memDefMin + third->memDefSize - 1) ||
                            (instr->memUsedMin + instr->memUsedSize - 1 <= third->memDefMin + third->memDefSize - 1 &&
                             instr->memUsedMin + instr->memUsedSize - 1 >= third->memDefMin)) {
                            return nullptr;
                        }
                    }
                }
            }

        } else {
            if (second->uInstr.operand[0].type == UD_OP_REG && (regsFirstInstr & second->uInstr.operand[0].base)) {
                return nullptr;
            }
            if (second->uInstr.operand[1].type == UD_OP_REG && (regsFirstInstr & second->uInstr.operand[1].base)) {
                return nullptr;
            }
            if (instrHasFlag(second, INSTR_READS_MEM)) {
                if ((instr->memUsedMin >= second->memUsedMin && instr->memUsedMin <= second->memUsedMin + second->memUsedSize - 1) ||
                    (instr->memUsedMin + instr->memUsedSize - 1 <= second->memUsedMin + second->memUsedSize - 1 &&
                     instr->memUsedMin + instr->memUsedSize - 1 >= second->memUsedMin)) {
                    return nullptr;
                }
            } else if (instrHasFlag(second, INSTR_WRITES_MEM)) {
                if ((instr->memUsedMin >= second->memDefMin && instr->memUsedMin <= second->memDefMin + second->memDefSize - 1) ||
                    (instr->memUsedMin + instr->memUsedSize - 1 <= second->memDefMin + second->memDefSize - 1 &&
                     instr->memUsedMin + instr->memUsedSize - 1 >= second->memDefMin)) {
                    return nullptr;
                }
            }
        }
    }
    return nullptr;
}


PSW_BITVECTOR FlagsDef(Instruction *instr) {
    if (!(instr->regFlagsKnown & FlagsDefKnown)) {
        // UDis86 sets no flags for call instructions, but a task switch might set all.
        if (ALLOW_TASK_SWITCH_CALLS && instr->uInstr.mnemonic == UD_Icall) {
            instr->flagsDef = PSW_ALL;
        } else {
            instr->flagsDef = instr->uInstr.psw;
        }
        instr->regFlagsKnown |= FlagsDefKnown;
    }
    return instr->flagsDef;
}

PSW_BITVECTOR FlagsUsed(Instruction *instr) {
    if (!(instr->regFlagsKnown & FlagsUsedKnown)) {
        instr->flagsUsed = instr->uInstr.pswUsed;
        instr->regFlagsKnown |= FlagsUsedKnown;
    }
    return instr->flagsUsed;
}


/*
 * OpcodeIsArith(mnemonic) -- returns true if the mnemonic given is one
 * of a set of recognized arithmetic operations.
 */
bool opcodeIsArith(ud_mnemonic_code opcode) {
    switch (opcode) {
    case UD_Iadc:
    case UD_Iadd:
    case UD_Ixadd:
    case UD_Iand:
    case UD_Idec:
    case UD_Iinc:
    case UD_Inot:
    case UD_Ior:
    case UD_Ishl:
    case UD_Ishr:
    case UD_Isub:
    case UD_Isbb:
    case UD_Ixor:
    case UD_Ineg:
    case UD_Irol:
    case UD_Iror:
    case UD_Iimul:
    case UD_Imul:
    case UD_Isar:
    case UD_Iidiv:
    case UD_Idiv:
    case UD_Ircr:
    case UD_Ircl:
    case UD_Ibswap:
    case UD_Ibtc:
    case UD_Ibtr:
    case UD_Ibts:
    case UD_Ibt:
    case UD_Icwde:
    case UD_Icbw:
    case UD_Ishrd:
    case UD_Ishld:
    case UD_Ibsf:
    case UD_Ibsr:
    case UD_Ipor:
    case UD_Ipsubb:
    case UD_Ivpor:
    case UD_Ivpandn:
    case UD_Ivpand:
    case UD_Ivpsubb:
    case UD_Iaddsd:
    case UD_Iandpd:
    case UD_Iorpd:
    case UD_Ivpxor:
    case UD_Ipxor:
    case UD_Ivpaddd:
        return true;
    default:
        return false;
    }
}

bool isCondJump(Instruction *instr) {
    switch (instr->uInstr.mnemonic) {
    case UD_Ijo:
    case UD_Ijno:
    case UD_Ijb:
    case UD_Ijae:
    case UD_Ijz:
    case UD_Ijnz:
    case UD_Ijbe:
    case UD_Ija:
    case UD_Ijs:
    case UD_Ijns:
    case UD_Ijp:
    case UD_Ijnp:
    case UD_Ijl:
    case UD_Ijge:
    case UD_Ijle:
    case UD_Ijg:
    case UD_Ijcxz:
    case UD_Ijecxz:
    case UD_Ijrcxz:
        return true;
    default:
        return false;
    }
}

/*
 * Return true if the opcode belongs to opcodes that set something on a condition.
 * @param opcode
 * @return
 */
bool instrIsSetOnCondition(ud_mnemonic_code opcode) {
    switch (opcode) {
    case UD_Iseta:
    case UD_Isetb:
    case UD_Isetbe:
    case UD_Isetg:
    case UD_Isetge:
    case UD_Isetl:
    case UD_Isetle:
    case UD_Isetae:
    case UD_Isetno:
    case UD_Isetnp:
    case UD_Isetns:
    case UD_Isetne:
    case UD_Iseto:
    case UD_Isetp:
    case UD_Isets:
    case UD_Isete:
        return true;
    default:
        return false;
    }
    return false;
}

bool isControlFlowInstr(Instruction *instr) {
    switch (instr->uInstr.mnemonic) {
    case UD_Ijmp:
        // only looking at indirect jumps for now
        return true;
    case UD_Icall:
        // looking at indirect calls
        return true;
    case UD_Iret:
        return true;
    case UD_Ijo:
    case UD_Ijno:
    case UD_Ijb:
    case UD_Ijae:
    case UD_Ijz:
    case UD_Ijnz:
    case UD_Ijbe:
    case UD_Ija:
    case UD_Ijs:
    case UD_Ijns:
    case UD_Ijp:
    case UD_Ijnp:
    case UD_Ijl:
    case UD_Ijge:
    case UD_Ijle:
    case UD_Ijg:
    case UD_Ijcxz:
    case UD_Ijecxz:
    case UD_Ijrcxz:
        // conditional jumps
        return true;

    default:
        return false;
    }
}

}