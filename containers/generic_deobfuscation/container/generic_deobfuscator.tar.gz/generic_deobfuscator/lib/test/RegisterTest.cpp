#include <gtest/gtest.h>

#include <register.h>

using namespace deobf::library;

TEST(RegisterTest, RelatedRegisters32bit) {
    auto result = relatedRegisters(DeobfRegister::RBX);
    ASSERT_TRUE(result.test(DeobfRegister::RBX));
    ASSERT_TRUE(result.test(DeobfRegister::EBX));
    ASSERT_TRUE(result.test(DeobfRegister::BX));
    ASSERT_TRUE(result.test(DeobfRegister::BH));
    ASSERT_TRUE(result.test(DeobfRegister::BL));
}

TEST(RegisterTest, RelatedRegisters64bit) {
    auto result = relatedRegisters(DeobfRegister::R13);
    ASSERT_TRUE(result.test(DeobfRegister::R13));
    ASSERT_TRUE(result.test(DeobfRegister::R13D));
    ASSERT_TRUE(result.test(DeobfRegister::R13W));
    ASSERT_TRUE(result.test(DeobfRegister::R13B));
}

TEST(RegisterTest, RelatedRegisters8bit) {
    auto result = relatedRegisters(DeobfRegister::BL);
    ASSERT_TRUE(result.test(DeobfRegister::RBX));
    ASSERT_TRUE(result.test(DeobfRegister::EBX));
    ASSERT_TRUE(result.test(DeobfRegister::BX));
    ASSERT_TRUE(!result.test(DeobfRegister::BH));
    ASSERT_TRUE(result.test(DeobfRegister::BL));

    result = relatedRegisters(DeobfRegister::BH);
    ASSERT_TRUE(result.test(DeobfRegister::RBX));
    ASSERT_TRUE(result.test(DeobfRegister::EBX));
    ASSERT_TRUE(result.test(DeobfRegister::BX));
    ASSERT_TRUE(result.test(DeobfRegister::BH));
    ASSERT_TRUE(!result.test(DeobfRegister::BL));
}

TEST(RegisterTest, RelatedRegisters16bit) {
    auto result = relatedRegisters(DeobfRegister::BX);
    ASSERT_TRUE(result.test(DeobfRegister::RBX));
    ASSERT_TRUE(result.test(DeobfRegister::EBX));
    ASSERT_TRUE(result.test(DeobfRegister::BX));
    ASSERT_TRUE(result.test(DeobfRegister::BH));
    ASSERT_TRUE(result.test(DeobfRegister::BL));

    result = relatedRegisters(DeobfRegister::R8W);
    ASSERT_TRUE(result.test(DeobfRegister::R8));
    ASSERT_TRUE(result.test(DeobfRegister::R8D));
    ASSERT_TRUE(result.test(DeobfRegister::R8W));
    ASSERT_TRUE(result.test(DeobfRegister::R8B));
}