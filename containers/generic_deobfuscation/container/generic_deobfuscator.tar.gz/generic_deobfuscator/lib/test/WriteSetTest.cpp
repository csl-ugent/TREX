#include <gtest/gtest.h>

#include <writeset.h>

using namespace deobf::library::writeset;

TEST(WriteSetTest, RangeIsEmpty) {
    auto r = Range(0, 5);
    EXPECT_FALSE(r.empty());
    r.min = 6;
    EXPECT_TRUE(r.empty());
}

TEST(WriteSetTest, RangeIsEqual) {
    auto r = Range(0, 5);
    auto r2 = Range(0, 5);
    auto r3 = Range(0, 10);
    auto r4 = Range(1, 5);
    EXPECT_EQ(r, r2);
    EXPECT_NE(r, r3);
    EXPECT_NE(r, r4);
}

TEST(WriteSetTest, WriteSetConstructor) {
    auto ws = WriteSet();
    EXPECT_EQ(ws.rangeCount(), 0);
    ws = WriteSet({{0, 1}, {1, 2}});
    EXPECT_EQ(ws.rangeCount(), 2);
}

TEST(WriteSetTest, WriteSetGetRange) {
    auto ws = WriteSet({{0, 1}, {5, 10}});
    auto r = ws.getRange(0);
    EXPECT_EQ(r->min, 0);
    r = ws.getRange(1);
    EXPECT_EQ(r->min, 5);
    EXPECT_THROW(ws.getRange(5), std::out_of_range);
}

TEST(WriteSetTest, WriteSetAddRangeInvalid) {
    auto ws = WriteSet();
    ws.addRange(7, 5);
    EXPECT_EQ(ws.rangeCount(), 0);
}

TEST(WriteSetTest, WriteSetAddRangeNonOverlapping) {
    auto ws = WriteSet();
    ws.addRange(0, 5);
    ws.addRange(7, 10);
    EXPECT_EQ(ws.rangeCount(), 2);
}

TEST(WriteSetTest, WriteSetAddRangeOverlapping) {
    auto ws = WriteSet();
    ws.addRange(0, 5);
    ws.addRange(50, 100);

    ws.addRange(6, 10);
    ws.addRange(49, 51);
    EXPECT_EQ(ws.rangeCount(), 2);
}

TEST(WriteSetTest, WriteSetAddRangePtr) {
    auto ws = WriteSet();
    auto r = std::make_unique<Range>(1, 5);
    ws.addRange(std::move(r));
    ws.addRange(nullptr);
    EXPECT_EQ(ws.rangeCount(), 1);
}

TEST(WriteSetTest, WriteSetClear) {
    auto ws = WriteSet({{0, 1}, { 5, 100}});
    ws.clear();
    EXPECT_EQ(ws.rangeCount(), 0);
}

TEST(WriteSetTest, WriteSetEmpty) {
    auto ws = WriteSet();
    EXPECT_TRUE(ws.empty());
    ws = WriteSet({{0, 5}});
    EXPECT_FALSE(ws.empty());
    ws = WriteSet({{6, 5}});
    EXPECT_TRUE(ws.empty());
    ws = WriteSet({{0, 1}, {6, 5}});
    EXPECT_FALSE(ws.empty());
}

TEST(WriteSetTest, WriteSetContains) {
    auto empty = WriteSet();
    auto r = Range(1, 5);
    EXPECT_FALSE(empty.contains(r));
    auto emptyR = Range(6, 5);
    auto super = WriteSet({{1, 5}, {30, 50}, {60, 100}});
    EXPECT_FALSE(super.contains(emptyR));
    EXPECT_TRUE(super.contains(r));
    auto other = Range(33, 60); // Range is partly in a range of super
    EXPECT_TRUE(super.contains(other));
}

TEST(WriteSetTest, WriteSetisSubsetOf) {
    auto super = std::make_unique<WriteSet>(std::list<Range>({{1, 5}, {30, 50}, {60, 100}}));
    auto small = std::make_unique<WriteSet>(std::list<Range>({{1, 5}}));
    auto other = std::make_unique<WriteSet>(std::list<Range>({{1, 5}, {33, 66}}));
    auto non = std::make_unique<WriteSet>(std::list<Range>({{1, 5}, {51, 59}}));
    auto empty = std::make_unique<WriteSet>();
    EXPECT_TRUE(empty->isSubsetOf(small));
    EXPECT_FALSE(small->isSubsetOf(empty));
    EXPECT_TRUE(small->isSubsetOf(super));
    EXPECT_TRUE(other->isSubsetOf(super)); // Partly in range of super, so true
    EXPECT_FALSE(non->isSubsetOf(super)); // One not in range of super, so false
}

TEST(WriteSetTest, WriteSetSort) {
    auto one = WriteSet({{1, 5}, {30, 50}, {60, 100}});
    one.addRange(20, 26);
    auto added = one.getRange(3);
    EXPECT_EQ(added->min, 20);
    one.sort();
    auto firstRange = one.getRange(1);
    EXPECT_EQ(firstRange->min, 20);
}

TEST(WriteSetTest, WriteSetMerge) {
    auto one = WriteSet({{1, 5}, {30, 50}, {60, 100}});
    auto two = std::make_unique<WriteSet>(std::list<Range>({{6, 10}, {55, 58}}));
    one.merge(two);
    EXPECT_EQ(one.rangeCount(), 4);
    one.sort();
    auto firstRange = one.getRange(0);
    EXPECT_EQ(firstRange->min, 1);
    EXPECT_EQ(firstRange->max, 10);
}

TEST(WriteSetTest, WriteSetMergePageRange) {
    auto one = WriteSet({{1, 5}, {30, 50}, {60, 100}});
    EXPECT_EQ(one.rangeCount(), 3);
    one.mergePageRange(100);
    EXPECT_EQ(one.rangeCount(), 1);
}

TEST(WriteSetTest, WriteSetBreakPageRange) {
    auto one = WriteSet({{1, 5}, {30, 49}, {60, 99}});
    EXPECT_EQ(one.rangeCount(), 3);
    one.breakPageRange(10);
    EXPECT_EQ(one.rangeCount(), 1 + 2 + 4);
    one = WriteSet({{0, 10}});
    one.breakPageRange(10);
    EXPECT_EQ(one.rangeCount(), 2);
}

TEST(WriteSetTest, WriteSetBreakPageRangeReal) {
    auto actual = WriteSet({
        {0x00000018,0x00020663},
        {0x0012edb4,0x00413e8f}, // Split me
        {0x77c110b8,0x77c627a7},
        {0x7814503c,0x781c594b},
        {0x7c801008,0x7c97d617}, // Split me
        {0x7f6f07cc,0x7f6f07cf},
        {0x7ffb0078,0x7ffe0303}
    });
    int page_size = 1048576;
    actual.breakPageRange(page_size);

    auto expected = WriteSet({
        {0x00000018, 0x00020663},
        {0x0012edb4, 0x0022edb3},
        {0x77c110b8, 0x77c627a7},
        {0x7814503c, 0x781c594b},
        {0x7c801008, 0x7c901007},
        {0x7f6f07cc, 0x7f6f07cf},
        {0x7ffb0078, 0x7ffe0303},
        {0x0022edb4, 0x0032edb3},
        {0x0032edb4, 0x0042edb3},
        //{0x0042edb4, 0x0052edb3}, // Missing compared to original Yagedari implementation, but this is a surplus range due to a bug in their code
        {0x7c901008, 0x7ca01007},
        //{0x7ca01008, 0x7cb01007} // Missing compared to original Yagedari implementation, but this is a surplus range due to a bug in their code
    });
    EXPECT_EQ(actual.rangeCount(), expected.rangeCount());
    EXPECT_EQ(actual, expected);
}

TEST(WriteSetTest, WriteSetEquals) {
    auto ws = WriteSet();
    auto ws1 = WriteSet();

    EXPECT_EQ(ws, ws1);

    ws.addRange(1, 10);
    ws.addRange(1, 5);
    EXPECT_NE(ws, ws1);

    ws1.addRange(1, 15);
    EXPECT_NE(ws, ws1);

    EXPECT_EQ(WriteSet({{1, 10}}), WriteSet({{1, 10}}));

    EXPECT_EQ(WriteSet({{1, 10}, {11, 15}}), WriteSet({{1, 15}}));
    EXPECT_EQ(WriteSet({{1, 15}}), WriteSet({{1, 10}, {11, 15}}));

    EXPECT_NE(WriteSet({{1, 16}}), WriteSet({{1, 10}, {11, 15}}));
    EXPECT_NE(WriteSet({{1, 10}, {11, 15}}), WriteSet({{1, 16}}));

    EXPECT_NE(WriteSet({{0, 10}, {20, 30}}), WriteSet({{0, 11}, {18, 25}, {25, 30}}));
    EXPECT_NE(WriteSet({{0, 11}, {18, 25}, {25, 30}}), WriteSet({{0, 10}, {20, 30}}));
}

TEST(WriteSetTest, WriteSetEqualsSpeed) {
    auto one = WriteSet({
        {0x00000018, 0x00020663},
        {0x0012edb4, 0x0022edb3},
        {0x77c110b8, 0x77c627a7},
        {0x7814503c, 0x781c594b},
        {0x7c801008, 0x7c901007},
        {0x7f6f07cc, 0x7f6f07cf},
        {0x7ffb0078, 0x7ffe0303},
        {0x0022edb4, 0x0032edb3},
        {0x0032edb4, 0x0042edb3},
        {0x7c901008, 0x7ca01007},
    });
    auto two = WriteSet({
        {0x00000018, 0x00020663},
        {0x0012edb4, 0x0022edb3},
        {0x77c110b8, 0x77c627a7},
        {0x7814503c, 0x781c594b},
        {0x7c801008, 0x7c901007},
        {0x7f6f07cc, 0x7f6f07cf},
        {0x7ffb0078, 0x7ffe0303},
        {0x0022edb4, 0x0032edb3},
        {0x0032edb4, 0x0042edb3},
        {0x7c901008, 0x7ca01007},
    });

    EXPECT_EQ(one, two);
}

TEST(WriteSetTest, WriteSetOverlapsWith) {
    auto ws = WriteSet();
    auto ws1 = WriteSet();

    EXPECT_FALSE(ws.overlapsWith(std::make_unique<WriteSet>(ws1)));

    ws.addRange(1, 10);
    EXPECT_FALSE(ws.overlapsWith(std::make_unique<WriteSet>(ws1)));

    ws1.addRange(5, 12);
    EXPECT_TRUE(ws.overlapsWith(std::make_unique<WriteSet>(ws1)));

    auto ws2 = WriteSet({{12, 20}});
    EXPECT_FALSE(ws.overlapsWith(std::make_unique<WriteSet>(ws2)));
}

TEST(WriteSetTest, WriteSetSubtract) {
    auto ws = WriteSet({{1244588, 1244595}});
    auto ws1 = WriteSet({{1244588, 1244591}});

    ws.subtract(std::make_unique<WriteSet>(ws1));
    EXPECT_EQ(ws.rangeCount(), 1);
    EXPECT_EQ(ws.getRange(0)->min, 1244592);
    EXPECT_EQ(ws.getRange(0)->max, 1244595);
}