#include <gtest/gtest.h>

#include <utils.h>

using namespace deobf::library::utils;

TEST(UtilsTest, UtilsGetBaseRegister) {
    ASSERT_EQ(getBaseRegister(DeobfRegister::AL), DeobfRegister::RAX);
    ASSERT_EQ(getBaseRegister(DeobfRegister::AH), DeobfRegister::RAX);
    ASSERT_EQ(getBaseRegister(DeobfRegister::RAX), DeobfRegister::RAX);
    ASSERT_EQ(getBaseRegister(DeobfRegister::ESP), DeobfRegister::RSP);
    ASSERT_EQ(getBaseRegister(DeobfRegister::R10B), DeobfRegister::R10);
    ASSERT_EQ(getBaseRegister(DeobfRegister::R15D), DeobfRegister::R15);
}

TEST(UtilsTest, UtilsGetRegisterWidthRegister) {
    ASSERT_EQ(getRegisterWidth(DeobfRegister::AL), DeobfRegisterWidth::lower8bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::DL), DeobfRegisterWidth::lower8bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::AH), DeobfRegisterWidth::higher8bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::DH), DeobfRegisterWidth::higher8bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::R15B), DeobfRegisterWidth::lower8bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::R15W), DeobfRegisterWidth::lower16bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::AX), DeobfRegisterWidth::lower16bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::EAX), DeobfRegisterWidth::lower32bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::R12D), DeobfRegisterWidth::lower32bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::R13), DeobfRegisterWidth::lower64bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::RAX), DeobfRegisterWidth::lower64bit);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::XMM1), DeobfRegisterWidth::lower128bit);
    traceInfo.setTraceWidthBits(64);
    ASSERT_EQ(getRegisterWidth(DeobfRegister::NONE), DeobfRegisterWidth::lower64bit);

}

TEST(UtilsTest, UtilsTraceInfo) {
    TraceInfo t {};

    ASSERT_EQ(t.getPlatform(), TracePlatform::Windows);
    ASSERT_EQ(t.getTraceWidthBits(), 32);
    ASSERT_EQ(t.getTraceWidthBytes(), 4);
    ASSERT_TRUE(t.is32bit());
    ASSERT_FALSE(t.isMeta());
    ASSERT_EQ(t.getTraceWidth(), DeobfRegisterWidth::lower32bit);

    t.setTraceWidthBits(64);
    t.setMeta(true);
    t.setPlatform(TracePlatform::Linux);

    ASSERT_EQ(t.getPlatform(), TracePlatform::Linux);
    ASSERT_EQ(t.getTraceWidthBits(), 64);
    ASSERT_EQ(t.getTraceWidthBytes(), 8);
    ASSERT_TRUE(t.is64bit());
    ASSERT_TRUE(t.isMeta());
    ASSERT_EQ(t.getTraceWidth(), DeobfRegisterWidth::lower64bit);
}

TEST(UtilsTest, UtilsStrToPlatform) {
    const char *platform = "LINUX";
    ASSERT_EQ(strToPlatform(platform), TracePlatform::Linux);
    const char *invalid = "FOO";
    ASSERT_EQ(strToPlatform(invalid), TracePlatform::Linux);
    const char *windows = "WINDOWS";
    ASSERT_EQ(strToPlatform(windows), TracePlatform::Windows);
}

TEST(UtilsTest, UtilsInsStructureEqual) {
    auto ins1 = ins_structure();
    ins1.bytes[0] = 0xDE;
    ins1.bytes[1] = 0xAD;
    ins1.length = 2;

    auto ins2 = ins_structure();
    ins2.bytes[0] = 0xBE;
    ins2.length = 1;
    ASSERT_FALSE(insStructureEqual(&ins1, &ins2));

    ins2.bytes[1] = 0xEF;
    ins2.length = 2;
    ASSERT_FALSE(insStructureEqual(&ins1, &ins2));

    auto ins3 = ins_structure();
    ins3.bytes[0] = 0xDE;
    ins3.bytes[1] = 0xAD;
    ins3.length = 2;
    ASSERT_TRUE(insStructureEqual(&ins1, &ins3));
}

TEST(UtilsTest, UtilsGetByteWidth) {
    ASSERT_EQ(getByteWidth(DeobfRegisterWidth::lower128bit), 16);
    ASSERT_EQ(getByteWidth(DeobfRegisterWidth::lower64bit), 8);
    ASSERT_EQ(getByteWidth(DeobfRegisterWidth::lower32bit), 4);
    ASSERT_EQ(getByteWidth(DeobfRegisterWidth::lower16bit), 2);
    ASSERT_EQ(getByteWidth(DeobfRegisterWidth::higher8bit), 1);
    ASSERT_EQ(getByteWidth(DeobfRegisterWidth::lower8bit), 1);
}

TEST(UtilsTest, UtilsGetRegisterWidthBytes) {
    ASSERT_EQ(getRegisterWidth(8), DeobfRegisterWidth::lower8bit);
    ASSERT_EQ(getRegisterWidth(16), DeobfRegisterWidth::lower16bit);
    ASSERT_EQ(getRegisterWidth(32), DeobfRegisterWidth::lower32bit);
    ASSERT_EQ(getRegisterWidth(64), DeobfRegisterWidth::lower64bit);
    ASSERT_EQ(getRegisterWidth(128), DeobfRegisterWidth::lower128bit);
    ASSERT_EQ(getRegisterWidth(12), DeobfRegisterWidth::lower64bit);
}