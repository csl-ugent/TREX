/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_TYPES_H
#define GENERIC_DEOBFUSCATOR_TYPES_H

#include <cstdint>
#include <vector>

extern "C" {
#include "udis86/libudis86/types.h"
}

using uint128_t = unsigned __int128;

constexpr uint8_t MAX_X86_INSTR_LEN = 15;  // max number of bytes for x86 instr
constexpr uint8_t MAX_X86_OPS = 4; // max number of supported operands for a x86 instr

constexpr char MEMORY_DEAD = 0;

extern uint64_t instructionCount; // global variable holding the total number of instructions

using PSW_BITVECTOR = uint32_t;
using ADDRESS = uint64_t;
using DEOBF_GENERIC_VALUE = uint64_t;
using DEOBF_REGISTER_VALUE = uint128_t;
using DEOBF_REGISTER = uint16_t;
using DEOBF_REGISTER_BITMASK = uint128_t;

#define FlagsUsedKnown (1 << 0)
#define FlagsDefKnown (1 << 1)
#define MemRegUsedKnown (1 << 2)    // mem regs used already stored
#define NonMemRegUsedKnown (1 << 3) // non mem regs used already stored
#define RegDefKnown (1 << 4)        // regs def already stored
#define MemUsedKnown (1 << 5)       // mem used stored in abbreviated form
#define MemDefKnown (1 << 6)        // mem def stored in abbreviated form

#define PSW_CF_INDEX 0
#define PSW_PF_INDEX 2
#define PSW_AF_INDEX 4
#define PSW_ZF_INDEX 6
#define PSW_SF_INDEX 7
#define PSW_TF_INDEX 8
#define PSW_IF_INDEX 9
#define PSW_DF_INDEX 10
#define PSW_OF_INDEX 11
#define PSW_NT_INDEX 14
#define PSW_RF_INDEX 16
#define PSW_AC_INDEX 18
#define PSW_MAX_INDEX 32

#define PSW_CF (1 << PSW_CF_INDEX)
#define PSW_PF (1 << PSW_PF_INDEX)
#define PSW_AF (1 << PSW_AF_INDEX)
#define PSW_ZF (1 << PSW_ZF_INDEX)
#define PSW_SF (1 << PSW_SF_INDEX)
#define PSW_TF (1 << PSW_TF_INDEX)
#define PSW_IF (1 << PSW_IF_INDEX)
#define PSW_DF (1 << PSW_DF_INDEX)
#define PSW_OF (1 << PSW_OF_INDEX)
#define PSW_NT (1 << PSW_NT_INDEX)
#define PSW_RF (1 << PSW_RF_INDEX)
#define PSW_AC (1 << PSW_AC_INDEX)
#define PSW_ALL (0x003fffff)

/*
 * ins_structure -- a struct that contains information about the structure
 * of the instruction, namely, its mnemonic, operands, etc.  This is an
 * excerpted version of the structure ud_t from udis86.
 */
using ins_structure = struct ins_structure {
    ud_mnemonic_code mnemonic;
    struct ud_operand operand[MAX_X86_OPS];
    unsigned char bytes[MAX_X86_INSTR_LEN];
    uint8_t length;
    uint8_t adr_mode;
    uint8_t opr_mode;
    ud_type pfx_seg;
    PSW_BITVECTOR psw;
    PSW_BITVECTOR pswUsed;
    ud_type impl_src1;
    ud_type impl_src2;
    ud_type impl_dst1;
    ud_type impl_dst2;
    bool has_rep;
};

/* Instruction struct
 *      IMPORTANT: Pointers are not allowed for fields in this struct
 *
 *      notes: name, module, and funcName lengths are hardcoded to
 *      standardize size of Instruction when stored in file
 */
using Instruction = struct Instruction {
    ADDRESS addr;
    ins_structure uInstr;
    uint16_t module;
    uint16_t funcName;
    uint64_t flags;
    DEOBF_REGISTER_VALUE eax;
    DEOBF_REGISTER_VALUE ecx;
    DEOBF_REGISTER_VALUE edx;
    DEOBF_REGISTER_VALUE ebx;
    DEOBF_REGISTER_VALUE esp;
    DEOBF_REGISTER_VALUE ebp;
    DEOBF_REGISTER_VALUE esi;
    DEOBF_REGISTER_VALUE edi;
    DEOBF_REGISTER_VALUE eip;
    DEOBF_REGISTER_VALUE r8;
    DEOBF_REGISTER_VALUE r9;
    DEOBF_REGISTER_VALUE r10;
    DEOBF_REGISTER_VALUE r11;
    DEOBF_REGISTER_VALUE r12;
    DEOBF_REGISTER_VALUE r13;
    DEOBF_REGISTER_VALUE r14;
    DEOBF_REGISTER_VALUE r15;
    DEOBF_REGISTER_VALUE fs;
    DEOBF_REGISTER_VALUE xmm0;
    DEOBF_REGISTER_VALUE xmm1;
    DEOBF_REGISTER_VALUE xmm2;
    DEOBF_REGISTER_VALUE xmm3;
    DEOBF_REGISTER_VALUE xmm4;
    DEOBF_REGISTER_VALUE xmm5;
    DEOBF_REGISTER_VALUE xmm6;
    DEOBF_REGISTER_VALUE xmm7;
    DEOBF_REGISTER_VALUE xmm8;
    DEOBF_REGISTER_VALUE xmm9;
    DEOBF_REGISTER_VALUE xmm10;
    DEOBF_REGISTER_VALUE xmm11;
    DEOBF_REGISTER_VALUE xmm12;
    DEOBF_REGISTER_VALUE xmm13;
    DEOBF_REGISTER_VALUE xmm14;
    DEOBF_REGISTER_VALUE xmm15;
    int order;
    int tid; // represents the threadID of an instruction in the trace
    uint8_t regFlagsKnown;
    DEOBF_REGISTER_BITMASK sourceMemoryRegisters;
    DEOBF_REGISTER_BITMASK sourceNonMemoryRegisters;
    DEOBF_REGISTER_BITMASK destinationRegisters;
    PSW_BITVECTOR flagsUsed;
    PSW_BITVECTOR flagsDef;
    uint64_t memUsedMin;
    uint8_t memUsedSize;
    DEOBF_GENERIC_VALUE memUsedVal;
    uint64_t memDefMin;
    uint8_t memDefSize;
    DEOBF_GENERIC_VALUE memDefVal;
    int next;               // pointing to next instruction(used for expanded instructions)!
    int prev;               // pointer to the previous instruction as well
    int ControlDependentOn; // keeps the instruction order that this instruction is control dependent on!
    int origNext;
    int origPrev;
};

constexpr uint8_t B2B_MAP_PAGESIZE = 8;

/*
 * we are keeping track of these structures in iList
 * structure. Every thread in the trace has a separate
 * iList so separate set of these structs.
 */
using BytetoByteMap = struct BytetoByteMap {
    uint64_t startAddrs[B2B_MAP_PAGESIZE];  // we can calculate the end address adding 8*page_size to the start addr!
    unsigned char *Constants;               // one page reserved to tag other 8 pages determining the bytes are constant or not!
    unsigned char *pages[B2B_MAP_PAGESIZE]; // the actual address space.
};

using InstrList = struct InstrList {
    uint32_t numInstrs;
    Instruction *newInstrCache;
    uint32_t newFirstInstr;
    uint32_t newLastInstr;
    Instruction *instrCache;
    int firstInstr;
    int lastInstr; // in a page, used for cache
    int currentInstr;
    int last;                // last instr's order in the trace
    int lastBaseModuleInstr; // keeps the order of last instr of base program
    int startMarker;
    int endMarker; // these two variables keep the start and end instruction of real main function
    int numBaseModuleInstrs;
    int stackBottom; // contains the highest esp value, setting by the first instruction in the trace
    int loop;
    int tid;                   // holds threadID of an instruction
    ADDRESS nextAvailableAddr; // keeps the biggest addr in base module instrs
    BytetoByteMap *constantPageDir;
    uint64_t constantNumPageEntries; // hold total number of pages a program access

    union {
        Instruction *iMMap; // pointer to mmap of instructions
        FILE *iListFile;
        //ArrayList *iListMem;
    };
};

enum class DeobfRegister : DEOBF_REGISTER {
    NONE = 0,
    AL,
    CL,
    DL,
    BL,
    AH,
    CH,
    DH,
    BH,
    SPL,
    BPL,
    SIL,
    DIL,
    R8B,
    R9B,
    R10B,
    R11B,
    R12B,
    R13B,
    R14B,
    R15B,

    /* 16 bit GPRs */
    AX,
    CX,
    DX,
    BX,
    SP,
    BP,
    SI,
    DI,
    R8W,
    R9W,
    R10W,
    R11W,
    R12W,
    R13W,
    R14W,
    R15W,

    /* 32 bit GPRs */
    EAX,
    ECX,
    EDX,
    EBX,
    ESP,
    EBP,
    ESI,
    EDI,
    R8D,
    R9D,
    R10D,
    R11D,
    R12D,
    R13D,
    R14D,
    R15D,

    /* 64 bit GPRs */
    RAX,
    RCX,
    RDX,
    RBX,
    RSP,
    RBP,
    RSI,
    RDI,
    R8,
    R9,
    R10,
    R11,
    R12,
    R13,
    R14,
    R15,

    /* segment registers */
    ES,
    CS,
    SS,
    DS,
    FS,
    GS,

    /* extended multimedia registers */
    XMM0,
    XMM1,
    XMM2,
    XMM3,
    XMM4,
    XMM5,
    XMM6,
    XMM7,
    XMM8,
    XMM9,
    XMM10,
    XMM11,
    XMM12,
    XMM13,
    XMM14,
    XMM15,

    /* Note: must be last register */
    RIP
};

constexpr DEOBF_REGISTER DEOBF_REGISTER_COUNT = 91; // Excludes NONE!
constexpr DEOBF_REGISTER DEOBF_REGISTER_LAST_UDIS =
    static_cast<DEOBF_REGISTER>(DeobfRegister::GS); // Last register that follows the numbering convention of udis

constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_8BITS_L = static_cast<DEOBF_REGISTER>(DeobfRegister::AL);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_8BITS_H = static_cast<DEOBF_REGISTER>(DeobfRegister::AH);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_16BITS = static_cast<DEOBF_REGISTER>(DeobfRegister::AX);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_32BITS = static_cast<DEOBF_REGISTER>(DeobfRegister::EAX);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_64BITS = static_cast<DEOBF_REGISTER>(DeobfRegister::RAX);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_SEGMENT = static_cast<DEOBF_REGISTER>(DeobfRegister::ES);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_XMM = static_cast<DEOBF_REGISTER>(DeobfRegister::XMM0);
constexpr DEOBF_REGISTER DEOBF_REGISTER_OFFSET_RIP = static_cast<DEOBF_REGISTER>(DeobfRegister::RIP);

const std::vector<DeobfRegister> registers32bitMode32bit{DeobfRegister::EAX, DeobfRegister::ECX, DeobfRegister::EDX, DeobfRegister::EBX,
                                                         DeobfRegister::ESP, DeobfRegister::EBP, DeobfRegister::ESI, DeobfRegister::EDI};

enum class DeobfRegisterWidth { lower128bit, lower64bit, lower32bit, lower16bit, higher8bit, lower8bit };

#endif // GENERIC_DEOBFUSCATOR_TYPES_H
