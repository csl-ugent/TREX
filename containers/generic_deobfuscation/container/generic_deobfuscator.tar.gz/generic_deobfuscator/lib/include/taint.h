#ifndef GENERIC_DEOBFUSCATOR_TAINT_H
#define GENERIC_DEOBFUSCATOR_TAINT_H

#include <cassert>
#include <functional>
#include <memory>
#include <set>
#include <sstream>
#include <fstream>
#include <string>
#include <utility>
#include <vector>

#include "register.h"
#include "types.h"

namespace deobf::library::taint {

using syscallTaintMapCall = std::map<uint8_t, DEOBF_REGISTER_VALUE>;
using syscallTaintMap = std::map<std::string, syscallTaintMapCall>;

class TaintAnalysis {
  public:
    explicit TaintAnalysis(std::shared_ptr<InstrList> iList, uint64_t start, bool enableImprovements) : iList(std::move(iList)), start(start), enableImprovements(enableImprovements) {}
    virtual ~TaintAnalysis() = default;
    virtual void annotate() = 0;
    virtual void propagate() = 0;

  protected:
    std::shared_ptr<InstrList> iList;
    uint64_t start;
    bool enableImprovements;
};

class ForwardTaintAnalysis : TaintAnalysis {
  public:
    explicit ForwardTaintAnalysis(const std::shared_ptr<InstrList> &iList, uint64_t start, bool enableImprovements) : TaintAnalysis(iList, start, enableImprovements) {}
    ~ForwardTaintAnalysis() override;
    void annotate() override;
    void propagate() override;
    void onlyTaintSpecific(std::shared_ptr<syscallTaintMap> inputs) {
        taintInputs = std::move(inputs);
    }
    void enableDOTDump(std::shared_ptr<std::ofstream> &dotFile) {
        dumpAsDot = true;
        dotOutput = dotFile;
        *dotOutput << "digraph G {" << std::endl;
    }
  private:
    bool dumpAsDot {};
    std::shared_ptr<std::ofstream> dotOutput;
    std::shared_ptr<syscallTaintMap> taintInputs {};
};

class BackwardTaintAnalysis : TaintAnalysis {
  public:
    explicit BackwardTaintAnalysis(const std::shared_ptr<InstrList> &iList, uint64_t start, bool checkSumDetection, bool enableImprovements) : TaintAnalysis(iList, start, enableImprovements), checkSumDetection(checkSumDetection) {}
    void annotate() override;
    void propagate() override;
  private:
    bool checkSumDetection;
};

class SyscallTaint {
  public:
    static constexpr uint8_t SYSCALL_INTERRUPT = 0x80;
    static constexpr DEOBF_REGISTER_VALUE NO_EXTRA_VALUE = -1;
    class SyscallTaintResult {
      public:
        DeobfRegisterUses registers;
        std::map<DEOBF_REGISTER_VALUE ,DEOBF_REGISTER_VALUE> memory;
    };
    using SyscallTaintHandler = std::function<SyscallTaintResult(Instruction*, bool)>;

    [[nodiscard]] bool isSupported(const std::string &syscallname) const {
        return syscalls.find(syscallname) != syscalls.end();
    }
    [[nodiscard]] std::pair<std::string, SyscallTaintHandler> findHandler(bool is64bit, uint8_t syscall_nr) const {
        auto syscall = std::find_if(syscalls.begin(), syscalls.end(), [&, is64bit, syscall_nr](const std::pair<std::string, SysCallHandling> &item) {
            if (is64bit) {
                return item.second.nr_64_bit == syscall_nr;
            }
            return item.second.nr_32_bit == syscall_nr;
        });
        if (syscall != syscalls.end()) {
            return {syscall->first, syscall->second.handler};
        }
        return {"", nullptr};
    }

    static bool isSyscall(bool is64bit, Instruction *iins) {
        return (is64bit && iins->uInstr.mnemonic == UD_Isyscall) || (iins->uInstr.mnemonic == UD_Iint &&  iins->uInstr.operand[0].lval.ubyte == SYSCALL_INTERRUPT);
    }

  private:
    class SysCallHandling {
      public:
        uint8_t nr_32_bit;
        uint8_t nr_64_bit;
        SyscallTaintHandler handler;
    };
    /*
     * Syscall numbers taken from:
     * - https://github.com/torvalds/linux/blob/master/arch/x86/entry/syscalls/syscall_64.tbl
     * - https://github.com/torvalds/linux/blob/master/arch/x86/entry/syscalls/syscall_32.tbl
     *
     * In general, rax/eax holds the syscall number, and the arguments are stored in:
     * - 64 bit: rdi, rsi, rdx, r10, r8, r9
     * - 32 bit: ebx, ecx, edx, esi, edi, stack (further args)
     */
    std::map<std::string, SysCallHandling> syscalls {
        {"read", {3, 0, [](Instruction *i, bool is64bit){ auto r = SyscallTaintResult(); r.memory.emplace(is64bit ? i->esi : i->ecx, i->edx); return r; }}} // This might over taint if the requested bytes are not all read.
    };
};

const SyscallTaint syscallTaint {};

#define DATAFLAG_CONST 0x0 // reserved (not used) in PSW_FLAGS!
#define DATAFLAG_UNKNOWN (unsigned)1 << 31

#define TAINT_GENERIC ((uint64_t)-1) // for marking taints from input values (use a reserved flag)
#define TAINT_NONE 0x0           // not tainted

class Taint {
  public:
    uint64_t tag; // the tag indicated the taint tag, generic tag used for non-flag
                  // taints, and (1 << flag_pos) for flag bits used in registers
                  // and memory locations
    uint32_t src_instr;
    uint8_t polarity; // for flags, original flag or negated!
    Taint(uint64_t t, uint32_t src) : tag(t), src_instr(src), polarity(0) {}

    [[nodiscard]] bool Tainted() const { return tag != DATAFLAG_CONST; }

    bool operator==(const Taint &o) const {
        return (tag == DATAFLAG_CONST && o.tag == DATAFLAG_CONST) || (tag == o.tag /*&& src_instr==o.src_instr*/ && polarity == o.polarity);
    }

    Taint operator!() const {
        Taint o = (*this);
        if (tag != DATAFLAG_CONST)
            o.polarity = !o.polarity; // flip the polarity
        return o;
    }

    Taint &Xor(const Taint &o, uint c0, uint c1) {
        if (tag != DATAFLAG_UNKNOWN && ((*this) == o || (*this == !o))) {
            tag = DATAFLAG_CONST;
        } else if (tag == DATAFLAG_CONST) { // o is tainted then
            if (c0)
                (*this) = !o;
            else
                (*this) = o;
        } else if (o.tag == DATAFLAG_CONST) {
            if (c1) {
                (*this) = !(*this);
            }
        } else {
            tag = DATAFLAG_UNKNOWN; // may need a new label here?
        }
        return *this;
    }

    Taint &operator&(const Taint &o) {
        if ((tag == DATAFLAG_CONST && o.tag == DATAFLAG_CONST) || *this == !o)
            tag = DATAFLAG_CONST;
        else
            tag = DATAFLAG_UNKNOWN;
        return *this;
    }

    Taint &operator|(const Taint &o) {
        if ((tag == DATAFLAG_CONST && o.tag == DATAFLAG_CONST) || *this == !o)
            tag = DATAFLAG_CONST;
        else
            tag = DATAFLAG_UNKNOWN;
        return *this;
    }

    /*
     * c0 is the concrete value of this and c1 is the concrete
     * value of o in case not tainted.
     */
    Taint &Add(const Taint &o, Taint &c, uint c0, uint c1) {
        // simple truth table

        if (this->Tainted() && o.Tainted() && c.Tainted()) {
            Taint tmp = o;
            tmp.Add(c, c.src_instr, c1);
            this->Add(c, c0, c1);
        } else {
            if (this->Tainted() && o.Tainted()) {
                Taint tmp = o; // since c is not tainted
                this->Add(tmp, 0, 0);
                c = tmp;
            } else if (this->Tainted() && c.Tainted()) {
                this->Add(c, c0, c1);
            } else if (c.Tainted() && o.Tainted()) {
                Taint tmp = o;
                tmp.Add(c, 0, c0);
                *this = tmp;
            } else if (o.Tainted()) {
                Taint tmp = o;
                tmp.Add(c, 0, c0);
                *this = tmp;
            } else { // none tainted or (c.Tainted() && !this->Tainted()) or (!c.Tainted() && this->Tainted())
                this->Add(c, c0, c1);
            }
        }
        return *this;
    }

    /*
     * Add(Taint &c, uint c0, uint cons)
     * adds a tainted bit with previous carry and a cons
     * cons is bit, 0 or 1. If there is a carry because
     * of this operation, it is saved in c. c0 is the constant
     * value of the tainted bit (this) in case it is not
     * tainted. If carry (produced or input) is not tainted,
     * then c.src_instr is significant, showing the concrete
     * vale of the carry (0 if src_instr = 0, 1 otherwise)
     */
    Taint &Add(Taint &c, uint c0, uint cons) {
        if (this->Tainted()) {
            if (!c.Tainted()) {
                if ((cons && c.src_instr == 0) || (!cons && c.src_instr == 1)) { // t+1
                    *this = !(*this);

                    c.src_instr = 0;
                } else if (cons && c.src_instr == 1) { // t+1+1
                    // a constant 1 will be carried over
                    c.src_instr = 1;
                }
            } else {
                if (c == *this && c.tag != TAINT_GENERIC) {
                    c = *this;
                    tag = DATAFLAG_CONST;
                    polarity = 0;
                } else if (*this == !c && c.tag != TAINT_GENERIC) {
                    c.tag = DATAFLAG_CONST;
                    c.polarity = 0;
                    tag = DATAFLAG_CONST;
                    polarity = 0;
                }
            }
        } else {
            if (!c.Tainted()) {
                if ((cons && c.src_instr == 1) || (cons && c0) || (c0 && c.src_instr == 1)) {
                    c.src_instr = 1;
                } else {
                    c.src_instr = 0;
                }
            } else {
                this->src_instr = 0;
                c.Add(*this, cons, c0);
                Taint tmp = c;
                c = *this;
                *this = tmp;
            }
        }
        return *this;
    }
};

class TByte {
    std::vector<Taint> t;

  public:
    TByte() : t(8, Taint(DATAFLAG_CONST, 0)) {}
    TByte(uint64_t tag, uint32_t src) : t(8, Taint(tag, src)) {}
    Taint &operator[](int index) {
        assert(index >= 0 && index < 8);
        return t[index];
    }
    bool Tainted() {
        for (int i = 0; i < 8; i++) {
            if (t[i].tag != DATAFLAG_CONST)
                return true;
        }
        return false;
    }
};

/*
 * one or more TaintByte objects. This object is just
 * a placeholder for TBytes, makes it easier to use
 * with operator[] as well as implementing operational
 * semantics for taint propagation purposes!
 */
class TaintBlock {
  private:
    std::vector<TByte *> bytes;
    uint size;

  public:
    TaintBlock() : bytes(0), size(0) {}
    TaintBlock(uint size, uint64_t tag, uint src = 0) : size(0) {
        for (uint i = 0; i < size; i++) {
            this->AddByte(new TByte(tag, src));
        }
    }

    Taint &operator[](uint index) const {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wtype-limits"
        assert(index >= 0 && index < size * 8);
#pragma GCC diagnostic pop
        return (*bytes[(index >> 3)])[index & 7];
    }

    void AddByte(TByte *t) {
        bytes.push_back(t);
        size++;
    }

    [[nodiscard]] uint Size() const { return size; }

    TaintBlock &operator=(TaintBlock &o) {
        if (this == &o)
            return *this;
        assert(size >= o.Size());
        for (uint i = 0; i < o.Size() * 8; i++) {
            (*this)[i] = o[i];
        }
        return *this;
    }

    [[nodiscard]] TByte *GetTByte(uint i) const {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wtype-limits"
        assert(i >= 0 && i < size);
#pragma GCC diagnostic pop
        return bytes[i];
    }

    [[nodiscard]] bool Tainted() const {
        for (uint i = 0; i < size; i++) {
            if (bytes[i]->Tainted())
                return true;
        }
        return false;
    }

    // operators: actually implement the operational semantics of instructions!

    TaintBlock &operator!() {
        for (uint i = 0; i < size * 8; i++) {
            (*this)[i] = !(*this)[i];
        }
        return *this;
    }

    TaintBlock &operator~() { return (!(*this)).Add(1, 0); }

    TaintBlock &operator|=(TaintBlock &o) {
        assert(o.Size() <= size);
        for (uint i = 0; i < size * 8; i++) {
            (*this)[i] = (*this)[i] | o[i];
        }
        return *this;
    }

    friend TaintBlock &operator|(TaintBlock &o1, TaintBlock &o2) { return o1 |= o2; }

    TaintBlock &operator|=(uint c) {
        for (uint i = 0; i < size * 8; i++) {
            uint mask = (1 << i) & c;
            if (mask)
                (*this)[i].tag = DATAFLAG_CONST;
        }
        return *this;
    }

    friend TaintBlock &operator|(TaintBlock &o1, uint c) { return o1 |= c; }

    TaintBlock &operator^(uint c) {
        for (uint i = 0; i < size * 8; i++) {
            uint mask = (1 << i) & c;
            if (mask && (*this)[i].Tainted()) {
                (*this)[i] = !(*this)[i];
            }
        }
        return *this;
    }

    TaintBlock &Xor(const TaintBlock &o, uint c0, uint c1) {
        assert(o.Size() <= size);
        uint mask = 1;
        for (uint i = 0; i < size * 8; i++) {
            (*this)[i].Xor(o[i], c0 & mask, c1 & mask);
            mask <<= 1;
        }
        return *this;
    }

    TaintBlock &operator&=(const TaintBlock &o) {
        assert(o.Size() <= size);
        for (uint i = 0; i < size * 8; i++) {
            (*this)[i] = (*this)[i] & o[i];
        }
        return *this;
    }

    friend TaintBlock &operator&(TaintBlock &o1, TaintBlock &o2) { return o1 &= o2; }

    bool operator==(const TaintBlock &other) {
        if (this->size != other.size) {
            return false;
        }
        for (uint i = 0; i < size * 8; i++) {
            if (!((*this)[i] == (*&other)[i])) {
                return false;
            }
        }
        return true;
    }

    TaintBlock &operator&=(uint c) {
        for (uint i = 0; i < size * 8; i++) {
            uint mask = (1 << i) & c;
            if (mask == 0)
                (*this)[i].tag = DATAFLAG_CONST;
        }
        return *this;
    }

    friend TaintBlock &operator&(TaintBlock &o1, uint c) { return o1 &= c; }

    TaintBlock &operator>>(uint shr) {
        if (!shr)
            return *this;
        uint i;
        for (i = shr % (size * 8); i < size * 8 - shr % (size * 8); i++) {
            (*this)[i - shr % (size * 8)] = (*this)[i];
        }
        for (; i < size * 8; i++) {
            (*this)[i].tag = DATAFLAG_CONST;
        }
        return *this;
    }

    TaintBlock &operator<<(uint shl) {
        if (!shl) {
            return *this;
        }
        int i;
        for (i = size * 8 - 1; i >= (int)(shl % (size * 8)); i--) {
            (*this)[i] = (*this)[i - shl % (size * 8)];
        }
        for (; i >= 0; i--) {
            (*this)[i].tag = DATAFLAG_CONST;
        }
        return *this;
    }

    TaintBlock &Add(const TaintBlock &o, uint c0, uint c1) {
        assert(o.Size() <= size);
        uint i, mask = 1;
        Taint carry(DATAFLAG_CONST, 0); // use carry.src_instr as the concrete value of carry

        for (i = 0; i < size * 8; i++) {
            (*this)[i].Add(o[i], carry, c0 & mask, c1 & mask);
            mask <<= 1;
        }
        return *this;
    }

    TaintBlock &Add(uint c0, uint c1) {
        uint i;
        uint mask = 1;
        Taint carry(DATAFLAG_CONST, 0);
        for (i = 0; i < size * 8; i++) {
            (*this)[i].Add(carry, c0 & mask, c1 & mask);
            mask <<= 1;
        }
        return *this;
    }

    TaintBlock &Adc(TaintBlock &o, uint c0, uint c1, const TaintBlock &flags) {
        uint i, mask = 1;
        Taint carry = flags[0];
        for (i = 0; i < size * 8; i++) {
            carry = (*this)[i].Add(o[i], carry, c0 & mask, c1 & mask);
            mask <<= 1;
        }
        return *this;
    }

    TaintBlock &Adc(uint c0, uint c1, const TaintBlock &flags) {
        uint i;
        Taint carry = flags[0];
        for (i = 0; i < size * 8; i++) {
            uint mask = (1 << i);
            carry = (*this)[i].Add(carry, c0 & mask, c1 & mask);
        }
        return *this;
    }

    // in fact, rotate right our array
    TaintBlock &Rol(uint c) {
        uint i;
        std::vector<Taint> tmpArr(size * 8, Taint(0, 0));
        for (i = 0; i < size * 8; i++) {
            tmpArr[(i + c) % (size * 8)] = (*this)[i];
        }
        for (i = 0; i < size * 8; i++) {
            (*this)[i] = tmpArr[i];
        }
        return *this;
    }

    // in fact, rotate left our array
    TaintBlock &Ror(uint c) {
        uint i;
        std::vector<Taint> tmpArr(size * 8, Taint(0, 0));
        for (i = 0; i < size * 8; i++) {
            tmpArr[i] = (*this)[(i + c) % (size * 8)];
        }
        for (i = 0; i < size * 8; i++) {
            (*this)[i] = tmpArr[i];
        }
        return *this;
    }

    std::string toString() {
        std::ostringstream ss;
        for (int i = size * 8 - 1; i >= 0; i--) {
            if ((*this)[i].polarity && (*this)[i].tag != DATAFLAG_CONST)
                ss << "!";
            ss << std::hex << (*this)[i].tag << std::dec << " ";
            if (i % 4 == 0) {
                ss << "  ";
            }
        }
        return ss.str();
    }
};

class BitDataDep {
  public:
    BitDataDep() : flags(new TaintBlock(4, DATAFLAG_CONST, 0)) {};
    TaintBlock *getRegBitVars(DeobfRegister reg);
    void applyRegTaintWithMask(uint64_t taint, const DeobfRegisterUses &regs, uint order);
    [[nodiscard]] bool isRegisterTainted(DeobfRegister reg) const {
        return taintedRegisters.test(reg);
    }
    void removeFlagTaint(PSW_BITVECTOR flag) { taintedFlags &= ~flag; };
    TaintBlock *getFlags() { return flags; };
    void setRegsTByteAtIndex(int index, TByte *tByte) { regsTaint[index] = *tByte; };
    void removeTaintForAllRegisters() { taintedRegisters.reset(); };
    void removeTaintForNonParameterRegisters() { taintedRegisters.resetNonParameterRegisters(); };
    void taintRegisterRelated(DeobfRegister r) { taintedRegisters.setRelated(r); };
    void taintRegisters(const DeobfRegisterUses& regs) { taintedRegisters.set(regs); }
    void taintRegister(DeobfRegister r) { taintedRegisters.set(r); }
    void removeTaintForRegisters(const DeobfRegisterUses & regs) { taintedRegisters.reset(regs); }
    std::unique_ptr<std::map<DeobfRegister, TaintBlock *>> getTaintForAffectedRegisters(const DeobfRegisterUses& regs);
    [[nodiscard]] DeobfRegisterUses taintedRegistersFor(const DeobfRegisterUses& usedRegisters) const { return usedRegisters & taintedRegisters; };
    /**
     * Calculates the index position in the regsTaint array that's held in a BitDataDep instance.
     *
     * @param reg
     * @return
     */
    static int getTaintIndex(DeobfRegister reg);
    [[nodiscard]] bool allUsedFlagsTainted(PSW_BITVECTOR usedFlags) const { return (usedFlags & taintedFlags) == usedFlags; }
    [[nodiscard]] bool anyUsedFlagTainted(PSW_BITVECTOR usedFlags) const { return (usedFlags & taintedFlags) != 0; };
    void resetTaintedFlags() { taintedFlags = 0; };
    void setFlagTaint(PSW_BITVECTOR flag) { taintedFlags |= flag; }
    void setFlags(TaintBlock newFlags) { *flags = newFlags; }
    bool isFlagTainted(PSW_BITVECTOR flag) const { return (taintedFlags & flag) != 0;}
    void setFlagsFor(uint64_t order, PSW_BITVECTOR usedFlags);

  private:
    DeobfRegisterUses taintedRegisters {};
    TByte regsTaint[17 * 8 + 15 * 16] {}; // 17 64-bit register + 15 128-bit register, an integer for every bit! Each TByte holds 8 bits.
    PSW_BITVECTOR taintedFlags {};
    TaintBlock *flags;
};

constexpr uint8_t NO_FORWARD_TAINT = (1 << 0);
constexpr uint8_t FORWARD_TAINT = (1 << 1);
constexpr uint8_t NO_BACKWARD_TAINT = (1 << 2);
constexpr uint8_t BACKWARD_TAINT = (1 << 3);

std::map<ADDRESS, uint8_t> createTaintOverview(const std::shared_ptr<InstrList>& iList);
void exportTaintOverview(const std::string &filename, const std::map<ADDRESS, uint8_t>& taints);

inline bool hasForwardTaint(uint8_t taint) {
    return (taint & FORWARD_TAINT) != 0;
}
inline bool hasNoForwardTaint(uint8_t taint) {
    return (taint & NO_FORWARD_TAINT) != 0;
}
inline bool hasBackwardTaint(uint8_t taint) {
    return (taint & BACKWARD_TAINT) != 0;
}
inline bool hasNoBackwardTaint(uint8_t taint) {
    return (taint & NO_BACKWARD_TAINT) != 0;
}
}
#endif // GENERIC_DEOBFUSCATOR_TAINT_H
