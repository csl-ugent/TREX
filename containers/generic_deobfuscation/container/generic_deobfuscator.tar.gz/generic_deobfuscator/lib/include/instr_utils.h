#ifndef GENERIC_DEOBFUSCATOR_INSTR_UTILS_H
#define GENERIC_DEOBFUSCATOR_INSTR_UTILS_H

#include <cstdint>

#include "types.h"
#include "register.h"
#include "writeset.h"

namespace deobf::library::instruction_utils {

constexpr bool ALLOW_TASK_SWITCH_CALLS = false;

using InstrFileHeader = struct InstrFileHeader {
    char baseModuleName[100];
    uint64_t NumInstrs;                // total number of instrs stored in the .InstrFile
    uint64_t LastInstrInOriginalTrace; // last instruction order of the original trace, NOTE: we add instrs to the end of file during simplification
    uint64_t lastBaseModule;
    int Loop; // last iteration of simplification

    int TraceIsMultiThreaded; // stuff to recover threads information for multi-threaded traces.
    int NumThreads;
    uint64_t RangeInfoOffset;
    size_t RangeInfoSize;
    int stackBottom; // save the stack bottom of a trace in its instrFile file header
    int nextAvailAddr;
    uint64_t startMarker;
    uint64_t endMarker;
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
    /*
     * Dummy padding as InstrFileHeader needs to be a multiple of 16 for efficient processing of instructions that are MMAP'ed.
     *
     * Previously the size of this Header was 184, which caused a crash when accessing data from an instruction using movdqa.
     * This padding should bring the size to 192.
     */
    [[maybe_unused]] uint64_t padding;
#pragma GCC diagnostic pop
};

static_assert(sizeof(InstrFileHeader) % 16 == 0);

constexpr uint8_t InstrFileHeaderSize = sizeof(InstrFileHeader);

inline bool hasREPPrefix(Instruction *instr) {
    // FIXME: Drop first condition. Will impact 66 F2/F3 xx instructions.
    return (instr->uInstr.bytes[0] == 0xf2 || instr->uInstr.bytes[0] == 0xf3) && instr->uInstr.has_rep;
}

inline bool isPush(Instruction *instr) {
    return instr->uInstr.mnemonic >= UD_Ipush && instr->uInstr.mnemonic <= UD_Ipushfw; // according to itab.h
}
inline bool isPop(Instruction *instr) {
    return instr->uInstr.mnemonic == UD_Ipop || instr->uInstr.mnemonic == UD_Ipopa || instr->uInstr.mnemonic == UD_Ipopad ||
           instr->uInstr.mnemonic == UD_Ipopfw || instr->uInstr.mnemonic == UD_Ipopfd || instr->uInstr.mnemonic == UD_Ipopfq;
}

/**
 * Checks if the given instruction is a mov string to string (opcode A5).
 *
 * @param instr
 * @return
 */
inline bool isMoveDataFromStringToString(Instruction *instr) {
    return instr->uInstr.bytes[0] == 0xA5 || (hasREPPrefix(instr) && instr->uInstr.bytes[1] == 0xA5);
}

bool isStringOperation(Instruction *instr);
bool FirstOpIsSrc(Instruction *instr);

inline void setCurrentInstr(const std::shared_ptr<InstrList>& iList, uint64_t order) {
    iList->currentInstr = order;
}
Instruction *fetchInstr(const std::shared_ptr<InstrList>& iList, uint64_t index);
Instruction *fetchPrevInstr(const std::shared_ptr<InstrList>& iList);
Instruction *fetchNextInstr(const std::shared_ptr<InstrList>& iList);

DeobfRegisterUses definedRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr);

DeobfRegisterUses getImplicitMemoryDestinationRegisters(Instruction *instr);

void calculateFlagsAndRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr);

DeobfRegisterUses definedMemoryRegistersForInstruction(Instruction *instr);
DeobfRegisterUses definedNonMemoryRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr);

inline DeobfRegisterUses usedRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    return definedMemoryRegistersForInstruction(instr) | definedNonMemoryRegistersForInstruction(iList, instr);
}

bool SaveInstrChange(const std::shared_ptr<InstrList>& iList, Instruction *instr, bool ignoreFtn = false);

/**
 * Checks if the given instruction is an xor reg, reg. If so, we can simplify to mov reg, 0.
 * @param instr
 * @return
 */
inline bool isXorOfSameReg(Instruction *instr) {
    return instr->uInstr.mnemonic == UD_Ixor && instr->uInstr.operand[0].type == UD_OP_REG && instr->uInstr.operand[1].type == UD_OP_REG &&
           instr->uInstr.operand[0].base == instr->uInstr.operand[1].base;
}

void carefulCopyUDins2InsStr(const std::shared_ptr<InstrList>& iList, Instruction *instr, ins_structure *uIns, ud_t *udIns, bool doNotChangeFlags, int line);

std::unique_ptr<writeset::WriteSet> memoryDefined(const std::shared_ptr<InstrList>& iList, Instruction *instr);
std::unique_ptr<writeset::WriteSet> memoryUsed(const std::shared_ptr<InstrList>& iList, Instruction *instr);

std::unique_ptr<deobf::library::writeset::Range> getImplicitTarget(const std::shared_ptr<InstrList>& iList, Instruction *instr);
std::unique_ptr<deobf::library::writeset::Range> calculateTargetForInstruction(Instruction *instr, ud_operand_t op);

DEOBF_REGISTER_VALUE GetRegisterValue(Instruction *instr, DeobfRegister reg);
inline DEOBF_REGISTER_VALUE GetRegisterValue(Instruction *instr, ud_type reg) {
    return GetRegisterValue(instr, glue::toDeobfRegister(reg));
}

Instruction *TransformXchgNotXchgToNot(const std::shared_ptr<InstrList>& iList, Instruction *instr);
Instruction *ThreeXorsToXchg(const std::shared_ptr<InstrList>& iList, Instruction *instr);

ud_type UDOpIsRegister(ud_operand_t *op);

PSW_BITVECTOR FlagsDef(Instruction *instr);
PSW_BITVECTOR FlagsUsed(Instruction *instr);

bool isCondJump(Instruction *instr);

bool opcodeIsArith(ud_mnemonic_code opcode);
bool instrIsSetOnCondition(ud_mnemonic_code opcode);
bool isControlFlowInstr(Instruction *instr);

} // deobf::library::instruction_utils

#endif // GENERIC_DEOBFUSCATOR_INSTR_UTILS_H
