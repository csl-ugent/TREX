#ifndef GENERIC_DEOBFUSCATOR_WRITESET_H
#define GENERIC_DEOBFUSCATOR_WRITESET_H

#include <cstdint>
#include <memory>
#include <utility>
#include <stdexcept>
#include <list>

namespace deobf::library::writeset {
class Range {
  public:
    Range(uint64_t min, uint64_t max) : min(min), max(max) {}

    /**
     * Returns true if the max is below the min value of this Range.
     * @return
     */
    [[nodiscard]] bool empty() const {
        return max < min;
    }
    [[nodiscard]] bool contains(uint64_t value) const { return value >= min && value <= max; }

    bool operator==(const Range &rhs) const { return min == rhs.min && max == rhs.max; }
    bool operator!=(const Range &rhs) const { return !(rhs == *this); }

    uint64_t min;
    uint64_t max;
};
class WriteSet {
  public:
    WriteSet() = default;
    explicit WriteSet(std::list<Range> ranges) : ranges(std::move(ranges)) {}

    bool operator==(const WriteSet &rhs) const;
    bool operator!=(const WriteSet &rhs) const;
    /**
     * Appends a new range to the set, merging overlapping ranges.
     * e.g. 1 to 5, and 6 to 10 are merged into one range from 1 to 10
     * @param min
     * @param max
     */
    void addRange(uint64_t min, uint64_t max);
    /**
     * Appends a new range to the set, merging overlapping ranges.
     * e.g. 1 to 5, and 6 to 10 are merged into one range from 1 to 10
     * @param range
     */
    void addRange(std::unique_ptr<Range> range);
    /**
     * Removes all ranges from the WriteSet.
     */
    void clear() {
        ranges.clear();
    }
    /**
     * Returns true if this WriteSet is contained in given superSet, false otherwise.
     * @param superSet
     * @return
     */
    [[nodiscard]] bool isSubsetOf(const std::unique_ptr<WriteSet>& superSet) const;
    /**
     * Returns true if the intersection of the ranges of this and other s1 and ws2 is nonempty; false otherwise.
     * @param other
     * @return
     */
    [[nodiscard]] bool overlapsWith(const std::unique_ptr<WriteSet>& other) const;
    /**
     * Merges the other WriteSet into this WriteSet.
     * @param otherSet
     */
    void merge(std::unique_ptr<WriteSet>& otherSet);
    /**
     * Returns true if no Range elements are present or if the only Range element is empty.
     * @return
     */
    [[nodiscard]] bool empty() const;
    /**
     * Checks if a given range is contained in this WriteSet. If the given range is partially contained
     * (i.e. a range from 5 -> 12 and a WriteSet from 1 -> 10) it will return true.
     * @param range
     * @return
     */
    [[nodiscard]] bool contains(const Range &range) const;
    /**
     * Exact matching rather than partial matching provided by contains.
     * @param range
     * @return
     */
    [[maybe_unused]] [[nodiscard]] bool hasExactRange(const Range &range) const;
    /**
     * Sorts the ranges based on the min values of the Range.
     */
    void sort();
    /**
     * Merges ranges that fall within the same given page size limit.
     * @param pageSize
     */
    void mergePageRange(uint64_t pageSize);
    /**
     * Breaks up ranges that span multiple pages, given the page size.
     * @param pageSize
     */
    void breakPageRange(uint64_t pageSize);
    /**
     * Returns the amount of Ranges in this WriteSet.
     * @return
     */
    [[nodiscard]] size_t rangeCount() const { return ranges.size(); }
    /**
     * Retrieve a Range based on it's index.
     * @param idx
     * @return
     * @throws std::out_of_range
     */
    std::shared_ptr<Range> getRange(uint64_t idx) {
        auto el = ranges.begin();
        std::advance(el, idx);
        if (el == ranges.end()) {
            throw std::out_of_range("idx not valid");
        }
        return std::make_shared<Range>(*el);
    }
    /**
     * Prints the ranges out to given file pointer.
     * @param fp
     */
    void fPrint(FILE *fp) const;
    /**
     * Subtract the other WriteSet from this WriteSet.
     * @param other
     */
    void subtract(const std::unique_ptr<WriteSet> &other);

  private:
    void pAddRange(Range range);
    [[nodiscard]] Range pRangeFor(uint64_t rangeValue) const;
    std::list<Range> ranges {};
};
};

#endif // GENERIC_DEOBFUSCATOR_WRITESET_H
