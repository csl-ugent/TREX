/*
* Author: Willem Van Iseghem
*
* Copyright 2022 University of Ghent
*/

#include <fstream>

#ifndef GENERIC_DEOBFUSCATOR_CSV_WRITER_H
#define GENERIC_DEOBFUSCATOR_CSV_WRITER_H

namespace deobf::library::csv_writer {

class CSVWriter {
  public:
    explicit CSVWriter(const std::string &fileName, const std::string &headerLine) : fs(std::ofstream(fileName, std::ios::out | std::ios::trunc)) {
        fs << headerLine << std::endl;
    }
    virtual ~CSVWriter() {
        fs.flush();
        fs.close();
    }
    void appendLine(const std::string &line) {
        fs << line << std::endl;
    }

  private:
    std::ofstream fs;
};

}

#endif // GENERIC_DEOBFUSCATOR_CSV_WRITER_H
