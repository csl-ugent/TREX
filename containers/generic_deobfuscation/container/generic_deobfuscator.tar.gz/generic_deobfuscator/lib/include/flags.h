/*
 * File: flags.h
 * Author: Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_FLAGS_H_
#define GENERIC_DEOBFUSCATOR_FLAGS_H_

#include <cstdint>

#include <utils.h>
#include <udis86_create.h>
#include "fmt/format.h"

/*
 * Instruction flags
 */
#define INSTR_MARKED (1 << 0)
#define INSTR_IN_USEDEF (1 << 1) // backward chains from uses to definitions
#define INSTR_IN_DEFUSE (1 << 2) // forward chains from definitions to uses
#define INSTR_IN_BASE_MODULE (1 << 3)
#define INSTR_BACKWARD_TAINTED (1 << 4)
#define INSTR_FN_ENTRY (1 << 5)
#define INSTR_HANDLER_ENTRY (1 << 6)
#define INSTR_BBL_START (1 << 7)
#define INSTR_BBL_END (1 << 8)
#define INSTR_FLAGS_KNOWN (1 << 9)
#define INSTR_IGNORED (1 << 10)
#define INSTR_READS_MEM (1 << 11) // instr is a relevant jump instruction
#define INSTR_USED_AS_CALL (1 << 12)
#define INSTR_MAYBE_DELETED (1 << 13)    // instr results from simplifying transformations
#define INSTR_READS_GLOBAL_MEM (1 << 14) // instr is ud chain target of control flow
#define INSTR_UD_BBL_START (1 << 15)
#define INSTR_UD_BBL_END (1 << 16)
#define INSTR_IN_SHARED_MEM (1 << 17)
#define INSTR_PUSHF (1 << 18) // instr is a pushfd instr
#define INSTR_FORWARD_TAINTED (1 << 19)
#define INSTR_COND_CF (1 << 20) // instr is conditional control flow
#define INSTR_TMP0 (1 << 30)    // use as temporary flag, should always be cleared when done!!
#define INSTR_TMP1 (1LLU << 31) // use as temporary flag, should always be cleared when done!!
/*
 *  additional temporary instruction flags defined by Gen Lu, for label important operands of xchg instruction
 *  labeling address save-use pairs
 *  09/20/2010
 */
#define INSTR_TMP2 (1 << 28)
#define INSTR_TMP3 (1 << 29)

/*
 * Instruction flags for UD simplification
 */
#define INSTR_OP0_CONSTANT (1 << 21)
#define INSTR_OP1_CONSTANT (1 << 22)
#define INSTR_DEST_CONSTANT (1 << 23)
#define INSTR_WRITES_MEM (1 << 24)
#define INSTR_IS_DELETED (1 << 25)
#define INSTR_MEM_SIMP (1 << 26)
#define INSTR_SIMPLIFIED_IGNORED (1 << 27)
#define INSTR_TEMP_CONDITIONAL (1LLU << 32)
#define INSTR_JMP_AS_CONDITIONAL (1LLU << 33)
#define INSTR_UNSIMPLIFIABLE (1LLU << 34)
#define INSTR_TRNASFORMED (1LLU << 35)
#define INSTR_BACKWARD_UD (1LLU << 36)
#define INSTR_READS_TAINTED_MEM (1LLU << 37)
#define INSTR_USES_FTAINT (1LLU << 38)
#define INSTR_READS_FLAGSTOREGS (1LLU << 39)
#define INSTR_DOES_UNPACKING (1LLU << 40)
#define INSTR_FLAG_FW_TAINED (1LLU << 41)
#define INSTR_REGDEF_KNOWN (1LLU << 42)
#define INSTR_TAINT_CLEARED (1LLU << 43)
#define INSTR_INPUT_SYMBOLIC (1LLU << 44)
#define INSTR_IS_SYMBOLIC (1LLU << 45)
#define INSTR_CONDJUMP_TAKEN (1LLU << 46)
#define INSTR_UNTOUCHABLE (1LLU << 47)

inline bool instrHasFlag(Instruction *instr, uint64_t flag) {
    return instr ? instr->flags & flag : false;
}

inline void instrRemoveFlag(Instruction *instr, uint64_t flag) {
    assert(instr);
    instr->flags &= ~flag;
}

inline void instrSetFlag(Instruction *instr, uint64_t flag, int line) {
    assert(instr);
    instr->flags |= flag;
    if (flag == INSTR_IS_DELETED) {
        DEBUG(4, fmt::format("{} - Deleted instruction at {}: {:#x}", line, instr->order, instr->addr));
    }
    if (flag == INSTR_UNSIMPLIFIABLE) {
        DEBUG(4, fmt::format("{} - Unsimplifiable instruction at {}: {:#x} {}", line, instr->order, instr->addr, *instr));
    }
    if (flag == INSTR_COND_CF) {
        DEBUG(4, fmt::format("{} - Cond CF instruction at {}: {:#x} {}", line, instr->order, instr->addr, *instr));
    }
}
#endif /* GENERIC_DEOBFUSCATOR_FLAGS_H */
