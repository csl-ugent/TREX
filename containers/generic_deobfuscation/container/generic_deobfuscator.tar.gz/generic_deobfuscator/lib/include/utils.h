/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_UTILS_H
#define GENERIC_DEOBFUSCATOR_UTILS_H

#include <unistd.h>
#include <algorithm>
#include <bitset>
#include <cstdint>
#include <iomanip>
#include <iterator>
#include <memory>
#include <queue>
#include <string>
#include <sstream>

#include <fmt/format.h>
#include <fmt/ostream.h>

#include "register.h"
#include "types.h"
#include "udis86_glue.h"
#include "udis86_create.h"

template <> struct fmt::formatter<Instruction> : formatter<string_view> {
    template <typename FormatContext>
    auto format(const Instruction& i, FormatContext& ctx) -> decltype(ctx.out()) {
        return format_to(ctx.out(), "{}", deobf::library::UDCreate::getStringRepresentationOfInstruction(i));
    }
};

template <> struct fmt::formatter<deobf::library::DeobfRegisterUses> : formatter<string_view> {
    template <typename FormatContext>
    auto format(const deobf::library::DeobfRegisterUses& i, FormatContext& ctx) -> decltype(ctx.out()) {
        return format_to(ctx.out(), "{}", i.toString());
    }
};

template <> struct fmt::formatter<DeobfRegister> : formatter<string_view> {
    template <typename FormatContext>
    auto format(const DeobfRegister& r, FormatContext& ctx) -> decltype(ctx.out()) {
        return format_to(ctx.out(), "{}", deobf::library::utils::stringifyRegister(r));
    }
};

namespace deobf::library::utils {
enum class TracePlatform { Windows, Linux };

TracePlatform strToPlatform(const char *platform);

class TraceInfo {
  public:
    inline void setTraceWidthBits(uint8_t bits) { trace_width_bits = bits; }

    [[nodiscard]] inline uint8_t getTraceWidthBits() const { return trace_width_bits; }

    [[nodiscard]] inline DeobfRegisterWidth getTraceWidth() const {
        if (trace_width_bits == 32) {
            return DeobfRegisterWidth::lower32bit;
        }
        return DeobfRegisterWidth::lower64bit;
    }

    [[nodiscard]] inline uint8_t getTraceWidthBytes() const { return trace_width_bits / 8; }

    inline void setMeta(bool isMeta) { meta = isMeta; }

    [[nodiscard]] inline bool isMeta() const { return meta; }

    [[nodiscard]] inline bool is64bit() const { return trace_width_bits == 64; }

    [[maybe_unused]] [[nodiscard]] inline bool is32bit() const { return trace_width_bits == 32; }

    inline void setPlatform(TracePlatform p) { platform = p; }

    [[nodiscard]] inline TracePlatform getPlatform() const { return platform; }

  private:
    uint8_t trace_width_bits = 32;                   // Default to 32 bits for the original Yadegari traces
    TracePlatform platform = TracePlatform::Windows; // Default to Windows for the original Yadegari traces
    bool meta{};
};

extern TraceInfo traceInfo;

class Logger {
  public:
    inline void log(const std::string &content) {
        *streamLog << indent(indentLevel) << content << std::endl;
    }
    inline void verbose(const std::string &content) {
        if (!isVerbose) {
            return;
        }
        log(content);
    }
    inline void debug(uint8_t level, const std::string &content) {
        if (level <= debugLevel) {
            *streamDebug << indent(indentLevel) << content << std::endl;
        }
    }
    inline void debugline(uint8_t level, const std::string &content, const std::string &ftn, int line) {
        if (level <= debugLevel) {
            *streamDebug << fmt::format("{}[{}:{}] {}", indent(indentLevel), ftn, line, content) << std::endl;
        }
    }
    inline void increaseIndent() { indentLevel++; }
    inline void decreaseIndent() { indentLevel--; }
    inline void setIndent(uint8_t newIndentLevel) { indentLevel = newIndentLevel; }
    inline void setDebugLevel(uint8_t newLevel) {
        debugLevel = newLevel;
        isVerbose = debugLevel > 0;
    }
    inline void setDebugPhases(const std::vector<std::string> &toDebug) { debugPhases = toDebug; }
    inline void checkForDebugAllPhases() {
        if (debugLevel > 0 && debugPhases.empty()) {
            debugPhase = true;
            log("Turning on debug for all phases!");
        }
    }
    inline void enableVerbose() { isVerbose = true; }

    inline void startPhase(const std::string &phase) {
        phases.push_back(phase);
        log(fmt::format("START {}", phase));
        increaseIndent();
        if (std::find(debugPhases.begin(), debugPhases.end(), phase) != debugPhases.end()) {
            debugPhase = true;
        }
    }

    inline void endPhase() {
        auto phase = phases.back();
        phases.pop_back();
        decreaseIndent();
        log(fmt::format("END {}", phase));
        if (std::find(debugPhases.begin(), debugPhases.end(), phase) != debugPhases.end()) {
            debugPhase = false;
        }
    }

    [[nodiscard]] inline bool isDebugEnabled() const { return debugPhase; }

  private:
    [[nodiscard]] static inline std::string indent(uint8_t level) { return std::string(level, '\t'); }
    bool isVerbose = false;
    bool debugPhase = false;
    uint8_t indentLevel = 0;
    uint8_t debugLevel = 0;
    std::ostream *streamLog = &std::cout;
    std::ostream *streamDebug = &std::cerr;
    std::vector<std::string> phases{};
    std::vector<std::string> debugPhases{};
};

extern Logger logger;

#ifdef DEBUG_ENABLED
#define DEBUG(level, msg) \
    do {                  \
        if(deobf::library::utils::logger.isDebugEnabled()) {            \
            deobf::library::utils::logger.debug(level, msg); \
        }                 \
    } while (false)
#define DEBUGLINE(level, msg) \
    do {                  \
        if(deobf::library::utils::logger.isDebugEnabled()) {            \
            deobf::library::utils::logger.debugline(level, msg, __FUNCTION__, __LINE__); \
        }                 \
    } while (false)
#else
#define DEBUG(level, msg) \
    do { } while (false)
#define DEBUGLINE(level, msg) \
    do { } while (false)
#endif

class ABITool {
    /**
     * Windows:
     * - 32-bit (https://docs.microsoft.com/en-us/cpp/cpp/argument-passing-and-naming-conventions?view=msvc-170)
     *      __stdcall 	Pushes parameters on the stack, in reverse order (right to left)
     *      __fastcall 	Stored in registers, then pushed on stack
     *
     *      Return values are also widened to 32 bits and returned in the EAX register, except for 8-byte structures, which are returned in the EDX:EAX register pair. Larger structures are returned in the EAX register as pointers to hidden return structures. Parameters are pushed onto the stack from right to left.
     *      The compiler generates prolog and epilog code to save and restore the ESI, EDI, EBX, and EBP registers, if they are used in the function.
     *  - 64-bit (https://docs.microsoft.com/en-us/cpp/build/x64-calling-convention?view=msvc-170)
     *  Register 	Status 	Use
     *  RAX 	Volatile 	Return value register
     *  RCX 	Volatile 	First integer argument
     *  RDX 	Volatile 	Second integer argument
     *  R8 	Volatile 	Third integer argument
     *  R9 	Volatile 	Fourth integer argument
     *  R10:R11 	Volatile 	Must be preserved as needed by caller; used in syscall/sysret instructions
     *  R12:R15 	Nonvolatile 	Must be preserved by callee
     *  RDI 	Nonvolatile 	Must be preserved by callee
     *  RSI 	Nonvolatile 	Must be preserved by callee
     *  RBX 	Nonvolatile 	Must be preserved by callee
     *  RBP 	Nonvolatile 	May be used as a frame pointer; must be preserved by callee
     *  RSP 	Nonvolatile 	Stack pointer
     *  XMM0, YMM0 	Volatile 	First FP argument; first vector-type argument when __vectorcall is used
     *  XMM1, YMM1 	Volatile 	Second FP argument; second vector-type argument when __vectorcall is used
     *  XMM2, YMM2 	Volatile 	Third FP argument; third vector-type argument when __vectorcall is used
     *  XMM3, YMM3 	Volatile 	Fourth FP argument; fourth vector-type argument when __vectorcall is used
     *  XMM4, YMM4 	Volatile 	Must be preserved as needed by caller; fifth vector-type argument when __vectorcall is used
     *  XMM5, YMM5 	Volatile 	Must be preserved as needed by caller; sixth vector-type argument when __vectorcall is used
     *  XMM6:XMM15, YMM6:YMM15 	Nonvolatile (XMM), Volatile (upper half of YMM) 	Must be preserved by callee. YMM registers must be preserved as needed by caller.
     *
     * Linux:
     * - 32 bit (https://wiki.osdev.org/System_V_ABI)
     * Parameters to functions are passed on the stack in reverse order...
     * Functions preserve the registers ebx, esi, edi, ebp, and esp; while eax, ecx, edx are scratch registers. The return value is stored in the eax register, or if it is a 64-bit value, then the higher 32-bits go in edx.
     *
     * - 64 bit (https://raw.githubusercontent.com/wiki/hjl-tools/x86-psABI/x86-64-psABI-1.0.pdf)
     * Register     Usage                                           Preserved
     * %rax         temporary register; 1st return register         No
     * %rbx         callee-saved register                           Yes
     * %rcx         4th integer argument to functions               No
     * %rdx         3rd argument to functions; 2nd return register  No
     * %rsp         stack pointer                                   Yes
     * %rbp         callee-saved register; optional frame pointer   Yes
     * %rsi         used to pass 2nd argument to functions          No
     * %rdi         used to pass 1st argument to functions          No
     * %r8          used to pass 5th argument to functions          No
     * %r9          used to pass 6th argument to functions          No
     * %r10         temporary, passing ftn’s static chain pointer   No
     * %r11         temporary register                              No
     * %r12-r14     callee-saved registers                          Yes
     * %r15         callee-saved register; optional GOT base ptr    Yes
     * %xmm0–%xmm1  pass and return floating point arguments        No
     * %xmm2–%xmm7  pass floating point arguments                   No
     * %xmm8–%xmm15 temporary registers                             No
     */
  public:
    static DeobfRegisterUses returnRegisters() {
        std::vector<DeobfRegister> regs {};
        if (traceInfo.is64bit()) {
            regs.push_back(DeobfRegister::RAX);
            if (traceInfo.getPlatform() == TracePlatform::Linux) {
                regs.insert(regs.end(), {DeobfRegister::XMM0, DeobfRegister::XMM1});
            }
        } else {
            // FIXME: do we need to include EDX in some cases? Ref specs above...
            regs.push_back(DeobfRegister::EAX);
        }
        return DeobfRegisterUses(regs);
    };
    static DeobfRegisterUses calleeSavedRegisters() {
        std::vector<DeobfRegister> regs {};
        if (traceInfo.is64bit()) {
            regs.insert(regs.end(), {DeobfRegister::RBX, DeobfRegister::RBP, DeobfRegister::R12, DeobfRegister::R13, DeobfRegister::R14, DeobfRegister::R15});
            if (traceInfo.getPlatform() == TracePlatform::Windows) {
                regs.insert(regs.end(), {
                                            DeobfRegister::RDI, DeobfRegister::RSI, DeobfRegister::XMM6, DeobfRegister::XMM7, DeobfRegister::XMM8, DeobfRegister::XMM9,
                                            DeobfRegister::XMM10, DeobfRegister::XMM11, DeobfRegister::XMM12, DeobfRegister::XMM13, DeobfRegister::XMM14, DeobfRegister::XMM15});
            }
        } else {
            regs.insert(regs.end(), {DeobfRegister::EBX, DeobfRegister::ESI, DeobfRegister::EDI, DeobfRegister::EBP});
        }
        return DeobfRegisterUses(regs);
    };
    static DeobfRegisterUses parameterRegisters() {
        std::vector<DeobfRegister> regs {};
        if (traceInfo.is64bit()) {
            regs.insert(regs.end(), {DeobfRegister::RCX, DeobfRegister::RDX, DeobfRegister::R8, DeobfRegister::R9, DeobfRegister::XMM0, DeobfRegister::XMM1, DeobfRegister::XMM2, DeobfRegister::XMM3});
            if (traceInfo.getPlatform() == TracePlatform::Linux) {
                regs.insert(regs.end(), {DeobfRegister::XMM4, DeobfRegister::XMM5, DeobfRegister::XMM6, DeobfRegister::XMM7, DeobfRegister::RSI, DeobfRegister::RDI});
            }
        }
        return DeobfRegisterUses(regs);
    };
};

// Solution for reversing arrays taken from https://stackoverflow.com/a/28139075
template <typename T> struct reversion_wrapper { T &iterable; };
template <typename T> auto begin(reversion_wrapper<T> w) {
    return std::rbegin(w.iterable);
}
template <typename T> auto end(reversion_wrapper<T> w) {
    return std::rend(w.iterable);
}
template <typename T> reversion_wrapper<T> reverse(T &&iterable) {
    return {iterable};
}

/**
 * Checks if the given register is a General Purpose Register (GPR) or not.
 *
 * @param r
 * @return
 */
bool isGPR(DeobfRegister r);

bool is8bitGPR(DeobfRegister r);
bool is16bitGPR(DeobfRegister r);
bool is32bitGPR(DeobfRegister r);
bool is64bitGPR(DeobfRegister r);

bool isXMM(DeobfRegister r);
/**
 * Checks if given register is one of SPL, BPL, SIL, DIL.
 *
 * @param r
 * @return
 */
bool is64bitLowExtension(DeobfRegister r);
/**
 * Checks if given register is specific to the x64 mode (i.e. R8-R15 and lower values, SPL, BPL, SIL, DIL).
 * @param r
 * @return
 */
bool is64bitSpecific(DeobfRegister r);
/**
 * Returns the base register for the given register. I.e. if AX is given, RAX is returned.
 *
 * @param r
 * @return
 */
DeobfRegister getBaseRegister(DeobfRegister r);
/**
 * Returns the appropriately sized register for the given base GPR register. Returns DeobfRegister::NONE in
 * unsupported cases (i.e. 8 bit high).
 *
 * @param base
 * @param size
 * @return
 */
DeobfRegister resizeBaseRegister(DeobfRegister base, DeobfRegisterWidth size);
/**
 * Returns the register width for the given register. Returns 64 bit in unsupported cases.
 *
 * @param r
 * @return
 */
DeobfRegisterWidth getRegisterWidth(DeobfRegister r);
/**
 * Returns the register width for the given bit size. Returns 64 bit in unsupported cases.
 *
 * @param bitsSize
 * @return
 */
DeobfRegisterWidth getRegisterWidth(uint8_t bitsSize);
/**
 * Checks if the given register is an 8 bit high register and returns 1 if so. Returns 0 in all other cases.
 *
 * @param r
 * @return
 */
inline int getRegisterLowOrHighOrder(DeobfRegister r) {
    return getRegisterWidth(r) == DeobfRegisterWidth::higher8bit ? 1 : 0;
}
/**
 * Returns the register width in bytes for a given register width, or 0 when unsupported.
 * @param registerWidth
 * @return
 */
uint8_t getByteWidth(DeobfRegisterWidth registerWidth);
/**
 * Returns the register width in bytes for the given register, or 0 when unsupported.
 *
 * @param r
 * @return
 */
inline uint8_t getRegisterByteWidth(DeobfRegister r) {
    return getByteWidth(getRegisterWidth(r));
}

/**
 * Retrieve the byte width for a given UDis register.
 *
 * @param reg
 * @return
 */
inline uint8_t UDRegSize(ud_type reg) {
    return utils::getRegisterByteWidth(glue::toDeobfRegister(reg));
}

/**
 * Creates a string-version of the given DeobfRegister.
 * @param r
 * @return
 */
std::string stringifyRegister(DeobfRegister r);

/**
 * Checks if two given instances of ins_structure are equal.
 * Returns true if they both have the same bytes.
 *
 * @param a
 * @param b
 * @return
 */
bool insStructureEqual(ins_structure *a, ins_structure *b);

/**
 * Calculates the page size for our instrFile uses based on the page size of the system.
 * Byte-sized.
 *
 * @return
 */
inline uint64_t pageSize() {
    return static_cast<uint64_t>(sysconf(_SC_PAGE_SIZE)) * 256; // 256 magic number comes from the original implementation
}

inline int lastStartMarkerOrder(const std::shared_ptr<InstrList>& iList) {
    return iList->startMarker + 2;
}
} // namespace deobf::library::utils

#endif // GENERIC_DEOBFUSCATOR_UTILS_H
