/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_UDIS86_CREATE_H
#define GENERIC_DEOBFUSCATOR_UDIS86_CREATE_H

extern "C" {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wregister"
#include "udis86/libudis86/extern.h"
#pragma GCC diagnostic pop
}

#include <string>

#include "types.h"

namespace deobf::library::UDCreate {
extern bool printCreateErrors;

/**
 * Calculate the offset from the base GPR (i.e. the offset of ECX from EAX is 1).
 * @param r
 * @return
 */
DEOBF_REGISTER registerOffset(DeobfRegister r);

ud_t *createDisassembledUD(const unsigned char *buf, uint8_t bufSize, ADDRESS address = 0);

inline std::string stringifyUD(ud_t *ud) {
    return ud_insn_asm(ud);
}

inline std::string getStringRepresentationOfInstruction(const Instruction &ins) {
    auto ud = createDisassembledUD(ins.uInstr.bytes, ins.uInstr.length, ins.addr);
    auto stringified = stringifyUD(ud);
    free(ud);
    return stringified;
}

inline std::string getStringRepresentationOfInstruction(Instruction *ins) {
    return ins ? getStringRepresentationOfInstruction(*ins) : "";
}

/*
 * movImmToReg -- create an instruction to move an
 * immediate value into a register.
 */
ud_t *movImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val, Instruction *ins, int line);
/**
 * arithmeticImmToReg -- create an instruction to arithmetically add the value to the register, and where the
 * type defines the type of arithmetic operation.
 */
ud_t *arithmeticImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val, uint8_t type);
/*
 * addImmToReg() -- create an instruction to add
 * an immediate value to a register.
 */
inline ud_t *addImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of valid returns:
     * 80 c0 ff                add    al,0xff
     * 41 80 c0 ff             add    r8b,0xff
     * 66 81 c0 ff ff          add    ax,0xffff
     * 81 c0 ff ff ff ff       add    eax,0xffffffff
     * 48 81 c0 ff ff ff ff    add    rax,0xffffffffffffffff (32 bit sign-extended)
     */
    return arithmeticImmToReg(reg, val, 0xc0);
}
/*
 * subImmFromReg() -- create an instruction to subtract
 * an immediate value from a register.
 */
inline ud_t *subImmFromReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of valid returns:
     * 80 e8 ff                sub    al,0xff
     * 41 80 e8 ff             sub    r8b,0xff
     * 66 81 e8 ff ff          sub    ax,0xffff
     * 81 e8 ff ff ff ff       sub    eax,0xffffffff
     * 48 81 e8 ff ff ff ff    sub    rax,0xffffffffffffffff (32 bit sign-extended)
     */
    return arithmeticImmToReg(reg, val, 0xe8);
}
/*
 * xorImmWithReg() -- create an instruction to xor
 * an immediate value with a register.
 */
inline ud_t *xorImmWithReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of valid returns:
     * 80 f0 ff                xor    al,0xff
     * 41 80 f0 ff             xor    r8b,0xff
     * 66 81 f0 ff ff          xor    ax,0xffff
     * 81 f0 ff ff ff ff       xor    eax,0xffffffff
     * 48 81 f0 ff ff ff ff    xor    rax,0xffffffffffffffff (32 bit sign-extended)
     */
    return arithmeticImmToReg(reg, val, 0xf0);
}
/*
 * andImmWithReg() -- create an instruction to and
 * an immediate value with a register.
 */
inline ud_t *andImmWithReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of valid returns:
     * 80 e0 ff                and    al,0xff
     * 41 80 e0 ff             and    r8b,0xff
     * 66 81 e0 ff ff          and    ax,0xffff
     * 81 e0 ff ff ff ff       and    eax,0xffffffff
     * 48 81 e0 ff ff ff ff    and    rax,0xffffffffffffffff (32 bit sign-extended)
     */
    return arithmeticImmToReg(reg, val, 0xe0);
}
/*
 * cmpImmWithReg() -- create an instruction to compare
 * an immediate value with a register.
 */
inline ud_t *cmpImmWithReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of valid returns:
     * 80 f8 ff                cmp    al,0xff
     * 41 80 f8 ff             cmp    r8b,0xff
     * 66 81 f8 ff ff          cmp    ax,0xffff
     * 81 f8 ff ff ff ff       cmp    eax,0xffffffff
     * 48 81 f8 ff ff ff ff    cmp    rax,0xffffffffffffffff (32 bit sign-extended)
     */
    return arithmeticImmToReg(reg, val, 0xf8);
}
/*
 * orImmWithReg() -- create an instruction to or
 * an immediate value with a register.
 */
inline ud_t *orImmWithReg(ud_type reg, DEOBF_GENERIC_VALUE val) {
    /**
     * Examples of valid returns:
     * 80 c8 ff                or    al,0xff
     * 41 80 c8 ff             or    r8b,0xff
     * 66 81 c8 ff ff          or    ax,0xffff
     * 81 c8 ff ff ff ff       or    eax,0xffffffff
     * 48 81 c8 ff ff ff ff    or    rax,0xffffffffffffffff (32 bit sign-extended)
     */
    return arithmeticImmToReg(reg, val, 0xc8);
}

ud_t *shiftRotateImmToReg(ud_type reg, uint8_t val, uint8_t type);

inline ud_t *shlImmToReg(ud_type reg, uint8_t val) {
    /**
     * Valid examples:
     * c0 e0 ff                shl    al,0xff
     * 41 c0 e0 ff             shl    r8b,0xff
     * 66 c1 e0 ff             shl    ax,0xff
     * c1 e0 ff                shl    eax,0xff
     * 48 c1 e0 ff             shl    rax,0xff
     */
    return shiftRotateImmToReg(reg, val, 0x4);
}
inline ud_t *shrImmToReg(ud_type reg, uint8_t val) {
    /**
     * Valid examples:
     * c0 f0 ff                shr    al,0xff
     * 41 c0 f0 ff             shr    r8b,0xff
     * 66 c1 f0 ff             shr    ax,0xff
     * c1 f0 ff                shr    eax,0xff
     * 48 c1 f0 ff             shr    rax,0xff
     */
    return shiftRotateImmToReg(reg, val, 0x5);
}
inline ud_t *rorImmToReg(ud_type reg, uint8_t val) {
    /**
     * Valid examples:
     * c0 c8 ff                ror    al,0xff
     * 41 c0 c8 ff             ror    r8b,0xff
     * 66 c1 c8 ff             ror    ax,0xff
     * c1 c8 ff                ror    eax,0xff
     * 48 c1 c8 ff             ror    rax,0xff
     */
    return shiftRotateImmToReg(reg, val, 0x1);
}
inline ud_t *rolImmToReg(ud_type reg, uint8_t val) {
    /**
     * Valid examples:
     * c0 c0 ff                rol    al,0xff
     * 41 c0 c0 ff             rol    r8b,0xff
     * 66 c1 c0 ff             rol    ax,0xff
     * c1 c0 ff                rol    eax,0xff
     * 48 c1 c0 ff             rol    rax,0xff
     */
    return shiftRotateImmToReg(reg, val, 0x0);
}

ud_t *imulImmToReg(ud_type reg, DEOBF_GENERIC_VALUE val);
ud_t *notOnReg(ud_type reg);
ud_t *notMem(DEOBF_GENERIC_VALUE offset, uint8_t size);
/* movImmToOffset
 * Creates an instruction in form of:
 * mov [offs.], const.
 *
 */
ud_t *movImmToOffset(DEOBF_GENERIC_VALUE absoluteOffset, DEOBF_GENERIC_VALUE value, uint8_t size, DEOBF_REGISTER_VALUE rip);
/* movOffsetToReg
 * Creates a mov instruction to copy a register to a memory offset or vice versa.
 * if regToOffset is true, it will be for reg to memory offset
 * if regToOffset is false, it will be for offset to reg
 */
ud_t *movOffsetToReg(ud_type dest, DEOBF_GENERIC_VALUE offset, bool regToOffset, DEOBF_REGISTER_VALUE rip);
/*
 * push val
 */
ud_t *pushImm(ud_type reg, DEOBF_GENERIC_VALUE val);
/*
 * jmp addr
 */
ud_t *jumpNear(DEOBF_GENERIC_VALUE jumpAddress, DEOBF_REGISTER_VALUE rip);
/*
 * nop() -- create a no operation, or "nop", instruction
 */
ud_t *nop();
/*
 * pushReg() -- create an instruction to push a register.
 */
ud_t *pushReg(DeobfRegister reg);
ud_t *callAddr(DEOBF_GENERIC_VALUE val);
/*
 * popReg() -- create an instruction to pop a register.
 */
ud_t *popReg(DeobfRegister r);
ud_t *movRegToReg(ud_type destination, ud_type source);
/*
 * Create cmp instruction with one offset operand
 * and a register operand.
 */
ud_t *cmpOffsetWithReg(DEOBF_GENERIC_VALUE offset, ud_type dest, uint8_t type);
/*
 * Create cmp instruction with one offset operand
 * and a register operand.
 */
ud_t *cmpOffsetWithImm(DEOBF_GENERIC_VALUE offset, DEOBF_GENERIC_VALUE value, uint8_t size, DEOBF_REGISTER_VALUE rip);
ud_t *popOffset(uint8_t size, DEOBF_GENERIC_VALUE offset, DEOBF_REGISTER_VALUE rip);
ud_t *pushOffset(uint8_t size, DEOBF_GENERIC_VALUE offset, DEOBF_REGISTER_VALUE rip);
/*
 * cmpMemWithImm() -- create an instruction to compare a
 * memory location with an immediate value.
 */
ud_t *cmpMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);
/*
 * xorMemWithImm() -- create an instruction to xor a
 * memory location with an immediate value.
 */
ud_t *xorMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);
/*
 * andMemWithImm() -- create an instruction to and a
 * memory location with an immediate value.
 */
ud_t *andMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);
/*
 * orMemWithImm() -- create an instruction to or a
 * memory location with an immediate value.
 */
ud_t *orMemWithImm(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);
/*
 * subImmFromMem() -- create an instruction to subtract an
 * immediate value from a memory address.
 */
ud_t *subImmFromMem(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);
/*
 * movImmToMem() -- create an instruction to move an
 * immediate value to a memory address.
 */
ud_t *movImmToMem(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);
/*
 * addImmToMem() -- create an instruction to Add an
 * immediate value to a memory address.
 */
ud_t *addImmToMem(unsigned char *bytes, ud_type dest, DEOBF_GENERIC_VALUE val);

ud_t *changeOperandToImm(unsigned char *instrBytes, uint8_t opIdx, DEOBF_GENERIC_VALUE immVal);

const std::string operandToString(ud_type type);

}; // namespace deobf::library::UDCreate

#endif // GENERIC_DEOBFUSCATOR_UDIS86_CREATE_H
