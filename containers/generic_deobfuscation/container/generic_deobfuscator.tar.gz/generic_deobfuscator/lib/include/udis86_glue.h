/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */
#ifndef GENERIC_DEOBFUSCATOR_UDIS86_GLUE_H
#define GENERIC_DEOBFUSCATOR_UDIS86_GLUE_H

#include <cassert>
#include <iostream>

extern "C" {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wregister"
#include "udis86/libudis86/extern.h"
#pragma GCC diagnostic pop
#include "udis86/libudis86/types.h"
}

#include "types.h"

namespace deobf::library::glue {
/**
 * Fills the provided ins_structure based on the information stored in the given UDis object.
 *
 * @param uIns
 * @param udIns
 * @param maxRegisterWidth
 */
void populateInsStructureFromUDisObject(ins_structure *uIns, ud_t *udIns, DeobfRegisterWidth maxRegisterWidth);

/**
 * Convert a UDis register to a DeobfRegister. Returns DeobfRegister::NONE if the UDis register is not supported.
 *
 * @param reg
 * @return
 */
DeobfRegister toDeobfRegister(ud_type reg);

/**
 * Convert a DeobfRegister to UDis register.
 *
 * @param reg
 * @return
 */
inline ud_type toUDRegister(DeobfRegister reg) {
    if (reg == DeobfRegister::RIP) {
        return UD_R_RIP;
    }
    auto numReg = static_cast<DEOBF_REGISTER>(reg);
    if (numReg >= DEOBF_REGISTER_OFFSET_XMM) {
        return static_cast<ud_type>(UD_R_XMM0 + numReg - DEOBF_REGISTER_OFFSET_XMM);
    }
    return static_cast<ud_type>(reg);
}

/**
 * Corrects the UDis register based on the given register width. Returns unmodified if it's not affected/unsupported.
 *
 * @param reg
 * @param maxRegisterWidth
 * @return
 */
ud_type correctRegisterWidth(ud_type reg, DeobfRegisterWidth maxRegisterWidth);

/**
 * Initializes the given UDis object in the given mode, with INTEL syntax.
 *
 * @param ud_obj
 * @param mode
 */
inline void initializeUDObject(ud_t *ud_obj, uint8_t mode) {
    ud_init(ud_obj);
    ud_set_mode(ud_obj, mode);
    ud_set_syntax(ud_obj, UD_SYN_INTEL);
    ud_set_vendor(ud_obj, UD_VENDOR_INTEL);
}

int64_t getSizedLval(const ud_operand_t &op);

ud_t *freeUDStructure(ud_t *toFree, bool freeBuffer);
} // namespace deobf::library::glue

#endif // GENERIC_DEOBFUSCATOR_UDIS86_GLUE_H
