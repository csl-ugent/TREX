/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_REGISTER_H
#define GENERIC_DEOBFUSCATOR_REGISTER_H

#include <bitset>
#include <cstdint>
#include <map>
#include <memory>

extern "C" {
#include "udis86/libudis86/types.h"
}

#include "types.h"
#include "udis86_glue.h"

namespace deobf::library::utils {
std::string stringifyRegister(DeobfRegister r);
DeobfRegister getBaseRegister(DeobfRegister r);
} // namespace deobf::library::utils

namespace deobf::library {
/**
 * Represents a register on the machine with the maximum size. It also holds the values of the lower parts of the
 * same register. E.g. RAX also holds the values for EAX, AX, AH, AL.
 */
class Register {
  public:
    /**
     * Retrieves the register value for the given width.
     *
     * @param registerWidth
     * @return
     */
    [[nodiscard]] DEOBF_REGISTER_VALUE getRegisterValue(DeobfRegisterWidth registerWidth) const;

    /**
     * Updates the value, taking the given width into account.
     *
     * @param registerWidth
     * @param newValue
     */
    void setRegisterValue(DeobfRegisterWidth registerWidth, DEOBF_REGISTER_VALUE newValue);

  private:
    DEOBF_REGISTER_VALUE value;
};

/**
 * A wrapper class around a std::bitset that keeps track of used/modified/... registers.
 */
class DeobfRegisterUses {
  public:
    DeobfRegisterUses() = default;
    DeobfRegisterUses(const DeobfRegisterUses &other) {
        items.reset();
        items |= other.items;
    }
    explicit DeobfRegisterUses(DEOBF_REGISTER_BITMASK bitmask);
    explicit DeobfRegisterUses(const std::vector<DeobfRegister>& regs) {
        for (auto r : regs) {
            items.set(static_cast<size_t>(r) - 1, true);
        }
    }

    DeobfRegisterUses &operator&=(const DeobfRegisterUses &other) noexcept {
        items &= other.items;
        return *this;
    }
    DeobfRegisterUses &operator|=(const DeobfRegisterUses &other) noexcept {
        items |= other.items;
        return *this;
    }
    DeobfRegisterUses &operator^=(const DeobfRegisterUses &other) noexcept {
        items ^= other.items;
        return *this;
    }
    DeobfRegisterUses operator~() const noexcept { return DeobfRegisterUses(*this).flip(); }
    bool operator==(const DeobfRegisterUses &rhs) const noexcept { return items == rhs.items; }
    DeobfRegisterUses &operator=(const DeobfRegisterUses &rhs) = default;

    friend std::ostream &operator<<(std::ostream &output, const DeobfRegisterUses &value) {
        for (int i = 0; i < DEOBF_REGISTER_COUNT; i++) {
            auto r = static_cast<DeobfRegister>(i);
            if (value.test(r)) {
                output << utils::stringifyRegister(r) << " ";
            }
        }
        return output;
    }

    [[nodiscard]] std::string toString() const;

    /**
     * Test if a DeobfRegister is set.
     * @param r
     * @return true if the bit for the DeobfRegister was set.
     */
    [[nodiscard]] bool test(DeobfRegister r) const {
        if (r == DeobfRegister::NONE) {
            return false;
        }
        return items.test(static_cast<size_t>(r) - 1);
    }
    /**
     * Test if a UDis register is set by converting it to a DeobfRegister and then testing that position.
     * @param reg
     * @return true if the bit for the DeobfRegister was set.
     */
    [[nodiscard]] bool test(ud_type reg) const { return test(glue::toDeobfRegister(reg)); }
    [[nodiscard]] bool all() const noexcept { return items.all(); }
    [[nodiscard]] bool any() const noexcept { return items.any(); }
    [[nodiscard]] bool none() const noexcept { return items.none(); }
    /**
     * Checks if this instance contains at least the same amount of set values as the other.
     *
     * Can be represented as follows: this & other == other
     *
     * @param other
     * @return True if all set values in the other are also set in this instance.
     */
    [[nodiscard]] bool hasAllOf(const DeobfRegisterUses &other) const noexcept {
        for (size_t i = 0; i < other.size(); i++) {
            if (other.items.test(i) && !items.test(i)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if this instance has no overlap with the other.
     *
     * Equivalent to (this & other).none()
     *
     * @param other
     * @return
     */
    [[nodiscard]] bool hasNoneOf(const DeobfRegisterUses& other) const noexcept {
        return (this->items & other.items).none();
    }
    /**
     * Checks if this instance has at least one overlapping register with the other.
     *
     * Equivalent to (this & other).any()
     *
     * @param other
     * @return
     */
    [[nodiscard]] bool hasAnyOf(const DeobfRegisterUses& other) const noexcept {
        return (this->items & other.items).any();
    }

    [[nodiscard]] std::size_t count() const noexcept { return items.count(); }
    [[nodiscard]] constexpr std::size_t size() const noexcept { return items.size(); }

    DeobfRegisterUses &set() noexcept {
        items.set();
        return *this;
    }
    DeobfRegisterUses &set(DeobfRegister r, bool value = true) {
        if (r != DeobfRegister::NONE) {
            items.set(static_cast<size_t>(r) - 1, value);
        }
        return *this;
    }
    DeobfRegisterUses &set(const std::vector<DeobfRegister> &regs, bool value = true) {
        for (auto r : regs) {
            set(r, value);
        }
        return *this;
    }
    DeobfRegisterUses &set(const DeobfRegisterUses &range) {
        items |= range.items;
        return *this;
    }
    /**
     * Sets the given register, as well as all related registers.
     *
     * @param r
     * @return
     */
    DeobfRegisterUses &setRelated(DeobfRegister r);
    DeobfRegisterUses &reset() noexcept {
        items.reset();
        return *this;
    }
    DeobfRegisterUses &reset(DeobfRegister r) {
        if (r != DeobfRegister::NONE) {
            items.reset(static_cast<size_t>(r) - 1);
        }
        return *this;
    }
    DeobfRegisterUses &reset(ud_type reg) {
        if (reg == UD_NONE) {
            return *this;
        }
        items.reset(static_cast<size_t>(reg) - 1);
        return *this;
    }
    DeobfRegisterUses &reset(const DeobfRegisterUses &other) {
        items &= ~other.items;
        return *this;
    }
    /**
     * Resets the given register, as well as all related registers.
     * @param r
     * @return
     */
    DeobfRegisterUses &resetRelated(DeobfRegister r);
    /**
     * Resets all registers that are not used for parameter transfer in function calls.
     *
     * @return
     */
    DeobfRegisterUses &resetNonParameterRegisters();
    DeobfRegisterUses &flip() noexcept {
        items.flip();
        return *this;
    }

    /**
     * Converts to a uint sized value for storage in the Instruction structure.
     * @return
     */
    [[nodiscard]] DEOBF_REGISTER_BITMASK toRegisterBitmask() const;

    /**
     * Returns the first DeobfRegister for which the value was set.
     * @return DeobfRegister::NONE if no values were set, a valid entry otherwise.
     */
    [[nodiscard]] DeobfRegister toDeobfRegister() const;
    /**
     * Returns the first UD register (converted from DeobfRegister) for which the value was set.
     * @return UD_NONE if no values were set, a UD_R_xxx otherwise.
     */
    [[nodiscard]] inline ud_type toUDRegister() const { return glue::toUDRegister(firstDeobfRegister()); }
    /**
     * Returns the first matching DeobfRegister (high to low bit size).
     * @return
     */
    [[nodiscard]] DeobfRegister firstDeobfRegister() const;
    /**
     * Returns the first matching ud register (high to low bit size).
     * @return
     */
    [[nodiscard]] inline ud_type firstUDRegister() const { return glue::toUDRegister(firstDeobfRegister()); }
    /**
     * Returns a list of all the registers that were set.
     * @return A vector of DeobfRegister entries that were set.
     */
    [[nodiscard]] std::vector<DeobfRegister> affectedRegisters() const;

  private:
    std::bitset<DEOBF_REGISTER_COUNT> items{};
};

inline DeobfRegisterUses operator&(const DeobfRegisterUses &lhs, const DeobfRegisterUses &rhs) noexcept {
    DeobfRegisterUses o(lhs);
    o &= rhs;
    return o;
}
inline DeobfRegisterUses operator|(const DeobfRegisterUses &lhs, const DeobfRegisterUses &rhs) noexcept {
    DeobfRegisterUses o(lhs);
    o |= rhs;
    return o;
}
inline DeobfRegisterUses operator^(const DeobfRegisterUses &lhs, const DeobfRegisterUses &rhs) noexcept {
    DeobfRegisterUses o(lhs);
    o ^= rhs;
    return o;
}

/**
 * Represents all registers on a machine.
 */
class Registers {
  public:
    /**
     * Initializes all registers.
     */
    explicit Registers();
    /**
     * Initialize all registers using the provided instruction.
     *
     * @param pInstruction
     */
    explicit Registers(Instruction *pInstruction) : Registers::Registers() { setRegisterValues(pInstruction); }

    /**
     * Retrieve the value for a given register.
     *
     * @param r
     * @return
     */
    DEOBF_REGISTER_VALUE getRegisterValue(DeobfRegister r);
    /**
     * Retrieve the value for a given UDis register.
     *
     * @param reg
     * @return
     */
    inline DEOBF_REGISTER_VALUE getRegisterValue(ud_type reg) { return getRegisterValue(glue::toDeobfRegister(reg)); }

    /**
     * Sets the value for a given register.
     *
     * @param r
     * @param value
     * @return
     */
    DeobfRegisterUses setRegisterValue(DeobfRegister r, DEOBF_REGISTER_VALUE value);
    /**
     * Sets the register value for a given UDis register.
     *
     * @param reg
     * @param value
     * @return
     */
    inline DeobfRegisterUses setRegisterValue(ud_type reg, DEOBF_REGISTER_VALUE value) { return setRegisterValue(glue::toDeobfRegister(reg), value); }
    /**
     * Set all register values based on the given instruction object.
     *
     * @param ins
     */
    void setRegisterValues(Instruction *ins);

  private:
    std::map<DeobfRegister, std::unique_ptr<Register>> registers{};
};

/**
 * Returns the related registers for the given register, optionally ignoring upper or lower registers.
 *
 * Example:
 * |--------------------------------------|
 * |                 RAX                  |
 * |                  |        EAX        |
 * |                            |     AX  |
 * |                                AH AL |
 * |--------------------------------------|
 *
 * When giving EAX, this method will return RAX, EAX, AX, AH, AL
 * When giving EAX and ignoring upper, it will return EAX, AX, AH, AL
 * When giving EAX and ignoring lower, it will return RAX, EAX
 * When giving AL, it will return AL, AX, EAX, RAX
 *
 * @param r
 * @param ignoreUpper
 * @param ignoreLower
 * @return
 */
DeobfRegisterUses relatedRegisters(DeobfRegister r, bool ignoreUpper = false, bool ignoreLower = false);
/**
 * Returns the lower related registers.
 * @related deobf::library::utils::relatedRegisters
 * @param r
 * @return
 */
inline DeobfRegisterUses relatedRegistersLower(DeobfRegister r) {
    return relatedRegisters(r, true, false);
};

inline DeobfRegisterUses relatedRegistersLower(ud_type r) {
    return relatedRegisters(glue::toDeobfRegister(r), true, false);
}
/**
 * Returns the lower related registers for every register that is set.
 *
 * @param uses
 * @return
 */
DeobfRegisterUses relatedRegistersLower(const DeobfRegisterUses &uses);
/**
 * Returns the higher related registers.
 * @related deobf::library::utils::relatedRegisters
 * @param r
 * @return
 */
inline DeobfRegisterUses relatedRegistersHigher(DeobfRegister r) {
    return relatedRegisters(r, false, true);
};
/**
 * Returns the higher related registers for every register that is set.
 *
 * @param uses
 * @return
 */
DeobfRegisterUses relatedRegistersHigher(const DeobfRegisterUses &uses);
/**
 * Returns all related registers (returns the related registers to the base register of given register).
 *
 * @related deobf::library::utils::relatedRegisters
 * @param r
 * @return
 */
inline DeobfRegisterUses allRelatedRegisters(const DeobfRegister &reg) {
    return relatedRegisters(utils::getBaseRegister(reg));
}
/**
 * Returns all related registers (returns the related registers to the base register of given register).
 *
 * @related deobf::library::utils::relatedRegisters
 * @param r
 * @return
 */
inline DeobfRegisterUses allRelatedRegisters(ud_type r) {
    return relatedRegisters(glue::toDeobfRegister(r));
}
/**
 * Returns all related registers for every register that is set.
 *
 * @param uses
 * @return
 */
DeobfRegisterUses allRelatedRegisters(const DeobfRegisterUses &uses);

DeobfRegisterUses baseRegisters(const DeobfRegisterUses &uses);

} // namespace deobf::library

#endif // GENERIC_DEOBFUSCATOR_REGISTER_H
