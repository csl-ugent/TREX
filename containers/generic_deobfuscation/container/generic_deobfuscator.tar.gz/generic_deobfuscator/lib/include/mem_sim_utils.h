#ifndef GENERIC_DEOBFUSCATOR_MEM_SIM_UTILS_H
#define GENERIC_DEOBFUSCATOR_MEM_SIM_UTILS_H

#include <cstdint>
#include <cstdlib>
#include <memory>

#include "types.h"

namespace deobf::library::memory_simulation {

void ClearConstantPages(const std::shared_ptr<InstrList>& iList);
bool MemLocIsConstant(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
void SetAddrAsConstWithValue(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, DEOBF_GENERIC_VALUE val, int line);
uint GetMemoryLocValue(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
void SetAddrAsConst(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
bool PartialMemLocIsConstant(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
size_t GetMemoryLocPointer(const std::shared_ptr<InstrList>& iList, ADDRESS addr);
void SetMemoryLocPointer(const std::shared_ptr<InstrList>& iList, ADDRESS addr, void *pointer);
void ClearMemoryPages(const std::shared_ptr<InstrList>& iList);

void removeConstAddr(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, bool resetMem, int line);
inline void UnsetConstAddr(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, int line) {
    removeConstAddr(iList, addr, numBytes, true, line);
}
inline void UnsetConstAddrWithoutMemReset(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, int line) {
    removeConstAddr(iList, addr, numBytes, false, line);
}

uint64_t DependencyMemGetConstLocSrc(const std::shared_ptr<InstrList>& iList, ADDRESS addr);
void DependencyMemSetConstWithSrc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, uint64_t src);

void TaintMemoryLoc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, uint8_t taint);
void UntaintMemoryLoc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
bool MemoryLocIsTainted(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);

bool MemoryLocationIsLive(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
void SetMemoryLocationLive(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);
void SetMemoryLocationDead(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);

void SetMemoryLocTainted(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes);

} // deobf::library::memory_simulation

#endif // GENERIC_DEOBFUSCATOR_MEM_SIM_UTILS_H
