/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2021 University of Ghent
 */

#include <string>
#include <vector>

#ifndef GENERIC_DEOBFUSCATOR_PERSISTENT_STORAGE_H
#define GENERIC_DEOBFUSCATOR_PERSISTENT_STORAGE_H

class PersistentStorage {
  public:
    uint16_t functionNameIdx(const std::string &functionName);
    uint16_t appendFunctionName(const std::string &functionName);
    std::string functionNameForIdx(uint16_t idx);
    void loadFunctionNamesFromFile();
    uint16_t moduleNameIdx(const std::string &moduleName);
    uint16_t appendModuleName(const std::string &moduleName);
    std::string moduleNameForIdx(uint16_t idx);
    void loadModuleNamesFromFile();

  private:
    std::vector<std::string> functionNames{};
    const std::string FUNCTION_NAME_FILE{"function_names"};
    std::vector<std::string> moduleNames{};
    const std::string MODULE_NAME_FILE{"module_names"};
};

extern PersistentStorage persistentStorage;

#endif // GENERIC_DEOBFUSCATOR_PERSISTENT_STORAGE_H
