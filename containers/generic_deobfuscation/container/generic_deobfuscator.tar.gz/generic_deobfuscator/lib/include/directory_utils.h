/*
* Author: Willem Van Iseghem
*
* Copyright 2022 University of Ghent
*/

#ifndef GENERIC_DEOBFUSCATOR_DIRECTORY_UTILS_H
#define GENERIC_DEOBFUSCATOR_DIRECTORY_UTILS_H

#include <filesystem>
#include <string>

class DirectoryUtils {
  public:
    void prepareOutputFolder();
    std::filesystem::path getOutputFile(std::string &fileName, std::string fileExtension, std::string &prefix, std::string &suffix);
    void parseBaseName(std::filesystem::path &inputPath);
    std::string getBaseName(const std::string& appendix = "");
    void setBaseName(char *base_name);
    static std::string dotExtension() {
        return ".dot";
    };
    static std::string csvExtension() {
        return ".csv";
    };

  private:
    std::filesystem::path outputPath {"./files"};
    std::string baseName;
};

extern DirectoryUtils directoryUtils;
#endif // GENERIC_DEOBFUSCATOR_DIRECTORY_UTILS_H
