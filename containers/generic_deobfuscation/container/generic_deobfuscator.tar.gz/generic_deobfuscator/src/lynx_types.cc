/*
 * File: lynx_types.cc
 * Author: Babak Yadegari, Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */
#include "lynx_types.h"

#include <flags.h>

#include "instr.h"

/*
 * InstrIsControlTransfer(iins) -- returns true if iins may
 * cause a control transfer.
 */
bool InstrIsControlTransfer(const std::shared_ptr<InstrList>& iList, Instruction *iins) {

    if (instrHasFlag(iins, INSTR_USED_AS_CALL)) {
        return true;
    }

    if (!instrHasFlag(iins, INSTR_IN_BASE_MODULE) && !instrHasFlag(iins, INSTR_USED_AS_CALL)) { // undisassembled
        Instruction *next = GetInstruction(iList, iins->next);
        if (next && !instrHasFlag(next, INSTR_IN_BASE_MODULE)) {
            return false;
        }
    }

    switch (iins->uInstr.mnemonic) {
    case UD_Icall:
    case UD_Ijo:
    case UD_Ijno:
    case UD_Ijb:
    case UD_Ijae:
    case UD_Ijz:
    case UD_Ijnz:
    case UD_Ijbe:
    case UD_Ija:
    case UD_Ijs:
    case UD_Ijns:
    case UD_Ijp:
    case UD_Ijnp:
    case UD_Ijl:
    case UD_Ijge:
    case UD_Ijle:
    case UD_Ijg:
    case UD_Ijcxz:
    case UD_Ijecxz:
    case UD_Ijrcxz:
    case UD_Ijmp:
    case UD_Iret:
    case UD_Iretf:
        return true;

    default:
        return false;
    }
    /* NOTREACHED */
}
