/*
 * File: flowgraph.cc
 * Author: Babak Yadegari, Saumya Debray
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */
#include "flowgraph.h"

#include <udis86_create.h>
#include <udis86_glue.h>
#include <flags.h>
#include <persistent_storage.h>
#include <directory_utils.h>
#include <taint.h>

#include <set>
#include <chrono>
#include <cinttypes>
#include <fmt/chrono.h>

#include "instr.h"
#include "mem_maps.h"

using namespace deobf::library;

namespace taint = deobf::library::taint;

iListNode *addressHashTable[HASH_TAB_SZ];
iListNode *ins_list{}; // instructions inserted in hash by order
iListNode *ins_list_by_addr{}, *ins_list_tl_by_addr{};
Bbl *bbl_list_hd{}, *bbl_list_tl{}; // basic blocks
BblEdge *bbl_edge_hd, *bbl_edge_tl;

int bbl_id = 0;

extern std::set<ADDRESS> modified_instructions;
extern std::string prefix;
extern std::string suffix;

void exitOOM(const std::string &ftn) {
    logger.log(fmt::format("{}: Out of memory!", ftn));
    exit(1);
}

void freeUpBListNode(bListNode *listNode) {
    while (listNode != nullptr) {
        bListNode *next = listNode->next;
        free(listNode);
        listNode = next;
    }
}

void freeUpIListNode(iListNode *listNode) {
    while (listNode != nullptr) {
        iListNode *next = listNode->next;
        free(listNode);
        listNode = next;
    }
}

static uint16_t hash(ADDRESS addr) {
    return addr & 0x7fff; /* low 15 bits */
}

static iListNode *hashLookupByAddress(iListNode **hashTbl, ADDRESS addr) {
    iListNode *node{};
    for (node = hashTbl[hash(addr)]; node != nullptr; node = node->hnext) {
        if (node->iptr->ins->addr == addr) {
            break;
        }
    }

    return node;
}

static iListNode *hashLookupByAddress(iListNode **hashTbl, Instruction *instr) {
    if (instr == nullptr) {
        logger.log(fmt::format("{}: nullptr for instruction!", __func__));
        exit(1);
    }

    return hashLookupByAddress(hashTbl, instr->addr);
}

static iListNode *hashInsertByAddress(iListNode **hashTbl, Instruction *instr) {
    if (instr == nullptr) {
        logger.log(fmt::format("{}: nullptr for instruction!", __func__));
        exit(1);
    }

    iListNode *node = hashLookupByAddress(hashTbl, instr);

    if (node == nullptr) {
        auto *insNode = static_cast<InsNode *>(calloc(1, sizeof(InsNode)));
        if (insNode == nullptr) {
            exitOOM(__func__);
        }

        insNode->ins = instr;
        insNode->numSuccs = insNode->numPreds = 0;
        insNode->succs = insNode->preds = nullptr;

        node = static_cast<iListNode *>(calloc(1, sizeof(iListNode)));
        uint16_t hashVal = hash(instr->addr);
        node->iptr = insNode;
        node->next = nullptr;
        node->prev = nullptr;
        node->hnext = hashTbl[hashVal];
        hashTbl[hashVal] = node;
    } else {
        if (!utils::insStructureEqual(&node->iptr->ins->uInstr, &instr->uInstr)) {
            DEBUG(3, fmt::format("Mark {:#x} ({} <-> {}) as untouchable!", instr->addr, *(node->iptr->ins), *instr));
            modified_instructions.insert(instr->addr);
        }
    }

    return node;
}

/*********************************************************************
 *                            PROCESSING                             *
 *********************************************************************/

static iListNode *CloneIListNode(iListNode *il) {
    auto *node = static_cast<iListNode *>(malloc(sizeof(iListNode)));
    if (node == nullptr) {
        exitOOM(__func__);
    }

    memcpy(node, il, sizeof(iListNode));
    node->next = nullptr;
    node->prev = nullptr;
    return node;
}

static void CollectDistinctInstructionsByAddress(const std::shared_ptr<InstrList>& iList) {
    Instruction *instr{};
    uint64_t listSize = iList->numInstrs;
    iListNode *node{};
    bool first = true;
    bool inCall = false;

    /* collect all distinct instructions */

    int index = iList->startMarker;

    if (iList->startMarker != 0) {
        index = index + 2;
    }
    while (!inCall && index != -1 && (index <= iList->endMarker || index > iList->last)) {
        instr = GetInstruction(iList, index);
        if (instr == nullptr) {
            logger.log(fmt::format("NULL instruction: order# = {} [total no. of instructions = {}]", index, listSize));
            return;
        }
        index = instr->next;

        if (!handle_rop && !instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            inCall = true;
        }
        node = hashInsertByAddress(addressHashTable, instr);

        auto *ins_list_entry_by_addr = static_cast<iListNode *>(calloc(1, sizeof(iListNode)));
        auto *insNode = static_cast<InsNode *>(malloc(sizeof(InsNode)));
        insNode->numPreds = insNode->numSuccs = 0;
        insNode->succs = insNode->preds = nullptr;
        insNode->flags = 0;
        insNode->ins = instr;

        if (ins_list_by_addr == nullptr) {
            ins_list_by_addr = ins_list_entry_by_addr;
        }
        ins_list_entry_by_addr->iptr = insNode; // add itmp to the global list of distinct addresses
        ins_list_entry_by_addr->prev = ins_list_tl_by_addr;
        ins_list_entry_by_addr->next = nullptr;
        if (ins_list_tl_by_addr != nullptr) {
            ins_list_tl_by_addr->next = ins_list_entry_by_addr;
        }
        ins_list_tl_by_addr = ins_list_entry_by_addr;

        if (first) { // first instruction
            NODE_SET_FLAG(node->iptr, BBL_ENTRY);
            first = false;
        }

        if (inCall) {
            SetCurrentInstr(iList, instr->next);
            Instruction *tmp{};
            while ((tmp = FetchNextInstr(iList)) != nullptr) {
                if (instrHasFlag(tmp, INSTR_IN_BASE_MODULE)) {
                    index = tmp->order;
                    inCall = false;
                    break;
                }
            }
        }
    }
}

/*
 * collect successors.
 */
void CollectInstrSuccessorsAndPredators(const std::shared_ptr<InstrList>& iList) {
    SetCurrentInstr(iList, iList->startMarker);
    Instruction *currIns = FetchNextInstr(iList);
    while ((currIns = FetchNextInstr(iList)) != nullptr) {
        if (currIns->order == iList->endMarker) {
            return;
        }

        Instruction *nextIns = GetInstruction(iList, currIns->next);

        if (nextIns == nullptr) {
            return;
        }
        /* check whether nextIns is already on currIns's successors list */
        iListNode *currHash = hashLookupByAddress(addressHashTable, currIns);
        if (currHash == nullptr) {
            continue;
        }
        InsNode *currInsNode = currHash->iptr;

        iListNode *nextHash = hashLookupByAddress(addressHashTable, nextIns);
        if (nextHash == nullptr) {
            continue; /* done */
        }
        InsNode *nextInsNode = nextHash->iptr;

        iListNode *tmpHash{};
        for (tmpHash = currInsNode->succs; tmpHash != nullptr; tmpHash = tmpHash->next) {
            if (tmpHash->iptr == nextInsNode) {
                break;
            }
        }
        if (tmpHash == nullptr) {
            tmpHash = static_cast<iListNode *>(calloc(1, sizeof(iListNode)));
            nextInsNode = nextHash->iptr;
            tmpHash->iptr = nextInsNode;
            tmpHash->next = currInsNode->succs;
            currInsNode->succs = tmpHash;
            currInsNode->numSuccs++;
        }

        for (tmpHash = nextInsNode->preds; tmpHash != nullptr; tmpHash = tmpHash->next) {
            if (tmpHash->iptr == currInsNode) {
                break;
            }
        }
        if (tmpHash == nullptr) {
            tmpHash = static_cast<iListNode *>(calloc(1, sizeof(iListNode)));
            tmpHash->iptr = currInsNode;
            tmpHash->next = nextInsNode->preds;
            nextInsNode->preds = tmpHash;
            nextInsNode->numPreds++;
        }
    }
}

static void MarkBblBoundariesByAddr(const std::shared_ptr<InstrList>& iList, bool jmpSingleBranch) {
    iListNode *il0Prev{};
    bool bblStart = true;
    iListNode *il0 = ins_list_by_addr;
    while (il0 != nullptr) {
        if (il0->iptr->ins->order == iList->endMarker) {
            NODE_SET_FLAG(il0->iptr, BBL_END);
            break; /* done */
        }

        iListNode *il0InHash = hashLookupByAddress(addressHashTable, il0->iptr->ins);
        if (il0InHash == nullptr) {
            return;
        }
        if (il0->iptr->ins->order == 0 || il0->iptr->ins->order == lastStartMarkerOrder(iList)) {
            NODE_SET_FLAG(il0->iptr, BBL_ENTRY);
            NODE_SET_FLAG(il0->iptr, BBL_START);
            il0 = il0->next;
            continue;
        }
        bool should_process = handle_rop || instrHasFlag(il0->iptr->ins, INSTR_IN_BASE_MODULE);
        bool processCondJump = IsCondJump(il0->iptr->ins) && instrHasFlag(il0->iptr->ins, INSTR_FORWARD_TAINTED) && should_process && jmpSingleBranch;
        if (bblStart || (il0InHash->iptr->numPreds > 1 && should_process) || processCondJump) {
            NODE_SET_FLAG(il0->iptr, BBL_START);
            if (il0Prev != nullptr) {
                NODE_SET_FLAG(il0Prev->iptr, BBL_END);
            }
            bblStart = false;
        }
        if ((InstrIsControlTransfer(iList, il0->iptr->ins)) || (il0InHash->iptr->numSuccs > 1 && should_process) ||
            (il0Prev != nullptr && !instrHasFlag(il0Prev->iptr->ins, INSTR_IN_BASE_MODULE))) {
            NODE_SET_FLAG(il0->iptr, BBL_END);
            bblStart = true;
        }
        il0Prev = il0;
        il0 = il0->next;
    }
}

static void FindBblSuccessorsAndPredatorsOldMethod() {
    for (auto *ibbl = bbl_list_hd; ibbl != nullptr && ibbl->ins_tl != nullptr; ibbl = ibbl->next) {
        for (auto *il0 = ibbl->ins_tl->iptr->succs; il0 != nullptr; il0 = il0->next) {
            /*
             * find the block whose first instruction is given by il0->iptr
             */
            Bbl *jbbl{};
            for (jbbl = bbl_list_hd; jbbl != nullptr; jbbl = jbbl->next) { // we are treating base module and
                                                                // non-base module bbls differently
                // printf("bbl %d: successor: %d: [0x%08x] %s vs %d: [0x%08x]
                // %s\n", jbbl->ins_hd->iptr->);
                if (jbbl->ins_hd->iptr->ins->addr == il0->iptr->ins->addr) {
                    break;
                }
            }

            if (jbbl == nullptr) {
                continue;
            }
            /*
             * create a bListNode node for this and add it as a successor to
             * ibbl
             */
            auto *bl0 = static_cast<bListNode *>(calloc(1, sizeof(bListNode)));
            if (bl0 == nullptr) {
                exitOOM(__func__);
            }

            bl0->bptr = jbbl;
            bl0->next = ibbl->succs;
            bl0->reserved = nullptr;
            ibbl->succs = bl0;
            ibbl->numSuccs++;
            for (bl0 = jbbl->preds; bl0 != nullptr; bl0 = bl0->next) { // add ibbl to jbbl's predecessors
                if (bl0->bptr->id == ibbl->id) {
                    break;
                }
            }
            if (bl0 == nullptr) {
                bl0 = static_cast<bListNode *>(malloc(sizeof(bListNode)));
                bl0->bptr = ibbl;
                bl0->reserved = nullptr;
                bl0->next = jbbl->preds;
                jbbl->preds = bl0;
                jbbl->numPreds++;
            }
        }
    }
}

void determineFlagsForBbl(Bbl *bbl, Instruction *ins, bool conditionalWhenIndirectJump) {
    if ((IsCondJump(ins) || (conditionalWhenIndirectJump && InstrIsIndirectJump(ins))) && instrHasFlag(ins, INSTR_FORWARD_TAINTED) &&
        (handle_rop || instrHasFlag(ins, INSTR_IN_BASE_MODULE))) {
        NODE_SET_FLAG(bbl, BBL_IS_CONDITIONAL);
    }
    if (instrHasFlag(ins, INSTR_FORWARD_TAINTED)) {
        NODE_SET_FLAG(bbl, BBL_FORWARD_TAINTED);
    }
    if (instrHasFlag(ins, INSTR_BACKWARD_TAINTED)) {
        NODE_SET_FLAG(bbl, BBL_BACKWARD_TAINTED);
    }
    if (instrHasFlag(ins, INSTR_DOES_UNPACKING)) {
        NODE_SET_FLAG(bbl, BBL_DOES_UNPACKING);
    }
}

int ConstructDistinctBblsOldMethod(__attribute__((unused)) const std::shared_ptr<InstrList>& iList) {
    iListNode *iltmp{};
    iListNode *ilnew{};
    iListNode *htmp{};
    iListNode *bblInstrPtr{};
    Bbl *ibbl{};
    InsNode *succtmp{};
    int ibblNumInstrs = 0;

    // MarkBblBoundaries(iList);

    auto *il0 = ins_list_by_addr;
    while (il0 != nullptr) {

        if (!NODE_HAS_FLAG(il0->iptr, BBL_START)) {
            DEBUG(3, fmt::format("Weird! il0 = {}: [{:#x}] {}", il0->iptr->ins->order, il0->iptr->ins->addr, *(il0->iptr->ins)));
        }

        for (ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next) {
            if (ibbl->ins_hd->iptr->ins->addr == il0->iptr->ins->addr) {
                DEBUG(3, fmt::format("bbl {} exists with starting {}: [{:#x}] {}", ibbl->id, il0->iptr->ins->order, il0->iptr->ins->addr, *(il0->iptr->ins)));
                al_add(ibbl->occurrences, &(il0->iptr->ins->order));
                bblInstrPtr = ibbl->ins_hd;
                ibblNumInstrs = ibbl->numInstrs;
                while (il0 != nullptr) {
                    auto *ins = il0->iptr->ins;
                    if (bblInstrPtr != nullptr && bblInstrPtr->iptr->ins->addr == ins->addr) {
                        if (instrHasFlag(bblInstrPtr->iptr->ins, INSTR_TMP0) && !instrHasFlag(ins, INSTR_TMP0)) {
                            bblInstrPtr->iptr->ins = ins;
                        }
                    }
                    determineFlagsForBbl(ibbl, ins, true);
                    if (!handle_rop && !instrHasFlag(ibbl->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)) {
                        if (NODE_HAS_FLAG(il0->iptr, BBL_END)) {
                            break;
                        }
                    } else {
                        ibblNumInstrs--;
                        if (ibblNumInstrs == 0) {
                            break;
                        }
                    }
                    il0 = il0->next;
                }
                if (il0 != nullptr) {
                    il0 = il0->next;
                }
                if (il0 != nullptr) {
                    succtmp = ibbl->ins_tl->iptr;
                    // now il0 points to the successor of ibbl!
                    for (htmp = succtmp->succs; htmp != nullptr; htmp = htmp->next) {
                        if (htmp->iptr->ins->addr == il0->iptr->ins->addr) {
                            break;
                        }
                    }

                    if (htmp == nullptr) { // jnstr not in instr's succs list
                        htmp = static_cast<iListNode *>(calloc(1, sizeof(iListNode)));
                        if (htmp == nullptr) {
                            exitOOM(__func__);
                        }

                        htmp->next = succtmp->succs;
                        htmp->iptr = il0->iptr; // add the end of next bbl to
                                                // the current bbl's successors
                        succtmp->numSuccs++;
                        succtmp->succs = htmp;
                    }
                }
                break;
            }
        }
        if (ibbl == nullptr) {
            ibbl = new Bbl();
            ibbl->id = bbl_id++;
            ibbl->mergedBBls = std::to_string(ibbl->id);
            ibbl->numInstrs = 0;

            if (bbl_list_tl != nullptr) {
                bbl_list_tl->next = ibbl;
            }
            ibbl->prev = bbl_list_tl;
            bbl_list_tl = ibbl;
            if (bbl_list_hd == nullptr) {
                bbl_list_hd = ibbl;
            }
            ibbl->occurrences = al_new();
            al_add(ibbl->occurrences, &(il0->iptr->ins->order));
            iListNode *prevIltmp{};
            for (iltmp = il0; iltmp != nullptr; iltmp = iltmp->next) {
                ilnew = CloneIListNode(iltmp);
                ilnew->prev = prevIltmp;
                auto *ins = ilnew->iptr->ins;
                if (prevIltmp != nullptr) {
                    prevIltmp->next = ilnew;
                }

                determineFlagsForBbl(ibbl, ins, false);

                if (ibbl->ins_tl != nullptr) {
                    ibbl->ins_tl->next = ilnew;
                }
                ibbl->ins_tl = ilnew;

                if (ibbl->ins_hd == nullptr) {
                    ibbl->ins_hd = ilnew;
                }
                ibbl->numInstrs++;

                prevIltmp = iltmp;

                /*
                 * we are adding next instruction of a block to a list
                 * this list is contained within the last instruction
                 * in each block. next instructions show the successor
                 * blocks. there is a post-process which looks at this
                 * list on the last instruction of each block, finds the
                 * corresponding block and attaches the block as successor
                 * (this is because we know the actual blocks ahead of time
                 * so after all blocks are constructed, we construct the
                 * successors list.)
                 */

                if (NODE_HAS_FLAG(iltmp->iptr, BBL_END)) { // attach bbl successors to the last instruction of bbl
                    ibbl->ins_tl->next = nullptr;          // so a successor is the last instruction of the next bbl
                    iListNode *tmp = iltmp->next;

                    if (tmp != nullptr) { // add first successor
                        auto *succ = static_cast<iListNode *>(malloc(sizeof(iListNode)));
                        succ->iptr = tmp->iptr;
                        succ->next = nullptr;
                        succ->prev = nullptr;
                        ilnew->iptr->succs = succ;
                        ilnew->iptr->numSuccs++;
                    }
                    break;
                }
            }
            DEBUG(3, fmt::format("bbl {} added with starting {}: [{:#x}] {}", ibbl->id, ibbl->ins_hd->iptr->ins->order, il0->iptr->ins->addr, *(il0->iptr->ins)));

            if (iltmp != nullptr) {
                il0 = iltmp->next;
            } else {
                il0 = nullptr;
            }
        }
    }
    NODE_SET_FLAG(bbl_list_hd, BBL_ENTRY);
    // Mark first bbl az entry node!
    NODE_SET_FLAG(bbl_list_tl, BBL_EXIT);
    // Mark last bbl az exit node!

#if 0 // print basic blocks and their instructions
    logger.log("bblsss");
    for(ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next){
        printf("Bbl %d:\n", ibbl->id);
        iListNode *tmp = ibbl->ins_hd;
        for(; tmp != nullptr; tmp = tmp->next){
            logger.log(fmt::format("\t{}: [{:#x}] {}", tmp->iptr->ins->order, tmp->iptr->ins->addr, *(tmp->iptr->ins)));
        }
    }
#endif

    FindBblSuccessorsAndPredatorsOldMethod();
#if 0
    {
        for (ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next) {
            logger.log(fmt::format("bbl {}: {}: [{:#x}] {}", ibbl->id, ibbl->ins_hd->iptr->ins->order, ibbl->ins_hd->iptr->ins->addr, *(ibbl->ins_hd->iptr->ins)));
        }
    }

#endif

#if 0 // print instr succs
    il0 = ins_list;
    while (il0 != nullptr) {
        logger.log(fmt::format("{}: [{}] {}", il0->iptr->ins->order, il0->iptr->ins->addr, UDCreate::getStringRepresentationOfInstruction(il0->iptr->ins)));
        iListNode *tmp = il0->iptr->succs;
        for(; tmp != nullptr; tmp = tmp->next){
            logger.log(fmt::format("{}: [{}] {}", tmp->iptr->ins->order, tmp->iptr->ins->addr, UDCreate::getStringRepresentationOfInstruction(tmp->iptr->ins)));
        }
        logger.log("");
        il0 = il0->next;
    }
#endif
    return bbl_id;
}

/*
 * given a basic block, returns
 * number of possible successors
 * the bbl can have!
 */
int NumberOfPossibleSuccessors(Bbl *ibbl) {
    Instruction *iins = ibbl->ins_tl->iptr->ins;
    if (IsCondJump(iins)) {
        return 2;
    }
    if (iins->uInstr.mnemonic == UD_Iret) {
        return 2;
    }
    if (iins->uInstr.mnemonic == UD_Ijmp) {
        if (iins->uInstr.operand[0].type == UD_OP_JIMM) {
            return 1;
        }
        return -1;
    }
    return 1;
}

static bListNode *Intersect(bListNode *dom1, bListNode *dom2) {
    if (dom1 == nullptr || dom2 == nullptr) {
        return nullptr;
    }
    bListNode *intersect {};
    for (auto *finger1 = dom1; finger1 != nullptr; finger1 = finger1->next) {
        for (auto *finger2 = dom2; finger2 != nullptr; finger2 = finger2->next) {
            if (finger1->bptr->id == finger2->bptr->id) {
                auto *tmp = static_cast<bListNode *>(malloc(sizeof(bListNode)));
                tmp->bptr = finger1->bptr;
                tmp->next = intersect;
                intersect = tmp;
                break;
            }
        }
    }
    return intersect;
}

static bool DomsAreEqual(bListNode *dom1, bListNode *dom2) {
    bool found = false;
    for (auto *finger1 = dom1; finger1 != nullptr; finger1 = finger1->next) {
        found = false;
        for (auto *finger2 = dom2; finger2 != nullptr; finger2 = finger2->next) {
            if (finger1->bptr->id == finger2->bptr->id) {
                found = true;
                break;
            }
        }
        if (!found) {
            return false;
        }
    }
    return true;
}
/*
 * PostDominatorTree
 * find all post-dominators of a node
 * and put it in a link-list in node
 * algorithm:
 * do until no change {
 * for each node n, post-dom{n} = {n} union intersect post-dom{s} for all s in
 * successors of n
 * }
 */
void PostDominatorTree() {
    // for the first node, set dominator the node itself
    Bbl *ibbl = bbl_list_tl;
    ibbl->pDoms = static_cast<bListNode *>(malloc(sizeof(bListNode)));
    ibbl->pDoms->bptr = ibbl;
    ibbl->pDoms->next = nullptr;

    // for every node in N - {n0}, set dominator to N (all nodes)
    for (ibbl = bbl_list_tl->prev; ibbl != nullptr; ibbl = ibbl->prev) {
        ibbl->pDoms = nullptr;
        for (auto *jbbl = bbl_list_tl; jbbl != nullptr; jbbl = jbbl->prev) {
            auto *domTmp = static_cast<bListNode *>(malloc(sizeof(bListNode)));
            domTmp->bptr = jbbl;
            domTmp->next = ibbl->pDoms;
            ibbl->pDoms = domTmp;
        }
    }
    bool change {};
    do {
        change = false;
        for (ibbl = bbl_list_tl->prev; ibbl != nullptr; ibbl = ibbl->prev) {
            auto *newPdoms = static_cast<bListNode *>(malloc(sizeof(bListNode)));
            newPdoms->bptr = ibbl; // add n itself to doms
            newPdoms->next = nullptr;

            auto *isuccs = ibbl->succs;
            if (ibbl->numSuccs == 1) { // dom(ibbl) = union(ibbl ,pdom(ibbl->succs))
                // add its successor's doms to node's doms!
                for (auto *isuccPdom = isuccs->bptr->pDoms; isuccPdom != nullptr; isuccPdom = isuccPdom->next) {
                    auto *tmp = static_cast<bListNode *>(malloc(sizeof(bListNode)));
                    tmp->bptr = isuccPdom->bptr;
                    tmp->next = newPdoms;
                    newPdoms = tmp;
                }
            } else if (ibbl->numSuccs > 1) { // > 1 successors
                auto *jsuccs = isuccs->next;
                bListNode *intersect = Intersect(isuccs->bptr->pDoms, jsuccs->bptr->pDoms);

                for (isuccs = jsuccs->next; isuccs != nullptr; isuccs = isuccs->next) {
                    intersect = Intersect(isuccs->bptr->pDoms, intersect);
                }
                newPdoms->next = intersect;
            }

            if (!DomsAreEqual(ibbl->pDoms, newPdoms)) {
                change = true;
                ibbl->pDoms = newPdoms;
            } else {
                freeUpBListNode(newPdoms);
            }
        }

    } while (change);
}

/*
 * returns true:
 * if node w is postdominated by
 * all post-dominators of v
 */
bool IsPostDomedByAllPostDominators(Bbl *v, Bbl *w) {
    bool vdomFoundinwdom{};
    for (auto *vpdoms = v->pDoms; vpdoms != nullptr; vpdoms = vpdoms->next) {
        if (vpdoms->bptr->id == v->id) {
            continue;
        }
        vdomFoundinwdom = false;
        for (auto *wpdoms = w->pDoms; wpdoms != nullptr; wpdoms = wpdoms->next) {
            if (wpdoms->bptr->id == vpdoms->bptr->id) {
                vdomFoundinwdom = true;
                break;
            }
        }
        if (!vdomFoundinwdom) {
            return false;
        }
    }
    return true;
}

/*
 * Finding immediate postdominators to construct
 * the (immediate) postdominator tree!
 * */
void ImmediateDominator() {
    Bbl *ibbl = bbl_list_tl;
    ibbl->ipDoms = nullptr;

    for (ibbl = bbl_list_tl->prev; ibbl != nullptr; ibbl = ibbl->prev) {
        for (auto *isuccPdom = ibbl->pDoms; isuccPdom != nullptr; isuccPdom = isuccPdom->next) { // pick one post dominator
            if (isuccPdom->bptr->id == ibbl->id) {
                continue;
            }
            if (IsPostDomedByAllPostDominators(ibbl, isuccPdom->bptr)) {
                auto *ipdom = static_cast<bListNode *>(malloc(sizeof(bListNode)));
                ipdom->bptr = isuccPdom->bptr;
                ipdom->next = ibbl->ipDoms;
                ibbl->ipDoms = ipdom;
                break;
            }
        }
    }
}

void MergeBblsNew() {
    logger.startPhase("Merging BBLs");
    bool change = true;
    while (change) {
        change = false;
        for (auto *ibbl = bbl_list_hd; ibbl != nullptr && ibbl->next != nullptr; ibbl = ibbl->next) {
            if (ibbl->numSuccs == 1 && instrHasFlag(ibbl->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)) {
                if (ibbl->succs->bptr->numPreds == 1 && ibbl->succs->bptr->id != ibbl->id) {
                    if (!instrHasFlag(ibbl->succs->bptr->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)) {
                        continue;
                    }
                    change = true;
                    ibbl->flags |= ibbl->succs->bptr->flags;
                    ibbl->ins_tl->next = ibbl->succs->bptr->ins_hd;
                    ibbl->ins_tl = ibbl->succs->bptr->ins_tl;
                    ibbl->numInstrs += ibbl->succs->bptr->numInstrs;
                    int removedBblID = ibbl->succs->bptr->id;
                    ibbl->mergedBBls.append(", " + std::to_string(removedBblID));

                    for (auto *jbbl = bbl_list_hd; jbbl != nullptr; jbbl = jbbl->next) {
                        if (jbbl->id == ibbl->succs->bptr->id) {
                            if (jbbl->next != nullptr) {
                                jbbl->next->prev = jbbl->prev;
                            } else {
                                jbbl->prev->next = nullptr;
                                bbl_list_tl = jbbl->prev;
                            }
                            if (jbbl != bbl_list_hd) {
                                jbbl->prev->next = jbbl->next;
                            } else {
                                bbl_list_hd = jbbl->next;
                            }
                            break;
                        }
                    }
                    ibbl->numSuccs = ibbl->succs->bptr->numSuccs;
                    ibbl->succs = ibbl->succs->bptr->succs;
                    for (auto *succs = ibbl->succs; succs != nullptr; succs = succs->next) {
                        for (auto *preds = succs->bptr->preds; preds != nullptr; preds = preds->next) {
                            if (preds->bptr->id == removedBblID) {
                                preds->bptr = ibbl;
                                if (preds->bptr->next == nullptr) {
                                    ibbl->next = nullptr;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    logger.endPhase();
}

BblEdge *createBBlEdge() {
    auto *tmp = static_cast<BblEdge *>(malloc(sizeof(BblEdge)));
    if (bbl_edge_tl != nullptr) {
        tmp->id = bbl_edge_tl->id + 1;
        bbl_edge_tl->next = tmp;
        tmp->prev = bbl_edge_tl;
        bbl_edge_tl = tmp;
        tmp->next = nullptr;
        return tmp;
    }
    tmp->id = 0;
    bbl_edge_hd = bbl_edge_tl = tmp;
    tmp->next = tmp->prev = nullptr;
    return tmp;
}
/*
 * returns true if b immediately
 * postdominates a, false otherwise
 */
static bool PostDominates(Bbl *a, Bbl *b) {
    auto *aipdoms = a->ipDoms;
    while (aipdoms != nullptr) {
        if (aipdoms->bptr->id == b->id) {
            return true;
        }
        aipdoms = aipdoms->bptr->ipDoms;
    }
    return false;
}

bListNode *createPathNode(bListNode *source) {
    auto *node = static_cast<bListNode *>(malloc(sizeof(bListNode)));
    node->bptr = source->bptr;
    node->next = nullptr;
    return node;
}

void markInstructionsAsCondCF(const std::shared_ptr<InstrList>& iList, int dependSource, int start, int numInstrs) {
    SetCurrentInstr(iList, start);
    while ((numInstrs--) != 0) {
        Instruction *next = FetchNextInstr(iList);
        instrSetFlag(next, INSTR_COND_CF, __LINE__);
        next->ControlDependentOn = dependSource;
        SaveInstrChange(iList, next);
    }
}

/*
 * FindExplicitControlDependencies:
 * walks in the post-dominator tree
 * collects the conditioned basic blocks,
 * and marks the corresponding instructions
 */
void FindExplicitControlDependencies(const std::shared_ptr<InstrList>& iList) {
    for (Bbl *ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next) {
        if (NODE_HAS_FLAG(ibbl, BBL_FORWARD_TAINTED) && NODE_HAS_FLAG(ibbl, BBL_IS_CONDITIONAL)) {
            // find (i, j) edges which are in CFG so that j does not immediately
            // post-dominate i (j is conditioned on j)
            for (bListNode *succs = ibbl->succs; succs != nullptr; succs = succs->next) {
                if (!PostDominates(ibbl, succs->bptr)) {
                    BblEdge *tmp = createBBlEdge();
                    tmp->from = ibbl;
                    tmp->to = succs->bptr;
                }
            }
        }
    }
    // !! from NODE IN EACH EDGE CONTAINS THE CONTROL BBL

    if (logger.isDebugEnabled()) {
        logger.startPhase("Discovered paths");
        for (BblEdge *edge = bbl_edge_hd; edge != nullptr; edge = edge->next) {
            DEBUG(1, fmt::format("{} ==> {}", edge->from->id, edge->to->id));
        }
        logger.endPhase();
    }

    // finding all dependent nodes in post-dominator tree
    for (BblEdge *edge = bbl_edge_hd; edge != nullptr; edge = edge->next) {
        auto *to = static_cast<bListNode *>(malloc(sizeof(bListNode)));
        to->bptr = edge->to;
        auto *from = static_cast<bListNode *>(malloc(sizeof(bListNode)));
        from->bptr = edge->from;

        logger.startPhase("Handle specific path");
        DEBUG(1, fmt::format("Handling path {} ==> {}", from->bptr->id, to->bptr->id));
        // find paths from two bbls to root, in domtree, then remove the intersection!
        bListNode *path1 = createPathNode(to);
        bListNode *lastPath1Node = path1;
        for (to = to->bptr->ipDoms; to != nullptr; to = to->bptr->ipDoms) {
            auto *newNode = createPathNode(to);
            lastPath1Node->next = newNode;
            lastPath1Node = newNode;
        }
        auto *path2 = createPathNode(from);
        bListNode *lastPath2Node = path2;
        for (from = from->bptr->ipDoms; from != nullptr; from = from->bptr->ipDoms) {
            auto *newNode = createPathNode(from);
            lastPath2Node->next = newNode;
            lastPath2Node = newNode;
        }
        if (logger.isDebugEnabled()) {
            auto out = fmt::memory_buffer();
            fmt::format_to(std::back_inserter(out), "Path 1: ");
            for (bListNode *pathNode = path1; pathNode != nullptr; pathNode = pathNode->next) {
                fmt::format_to(std::back_inserter(out), "{} -> ", pathNode->bptr->id);
            }
            DEBUG(1, fmt::to_string(out));
            out.clear();
            fmt::format_to(std::back_inserter(out), "Path 2: ");
            for (bListNode *pathNode = path2; pathNode != nullptr; pathNode = pathNode->next) {
                fmt::format_to(std::back_inserter(out), "{} -> ", pathNode->bptr->id);
            }
            DEBUG(1, fmt::to_string(out));
        }

        // find the lowest common ancestor, which is the first common Bbl in both paths!
        bListNode *lowestCommon{};
        bool found = false;
        for (lowestCommon = path1; lowestCommon != nullptr; lowestCommon = lowestCommon->next) {
            for (bListNode *tmp = path2; tmp != nullptr; tmp = tmp->next) {
                if (tmp->bptr != nullptr && tmp->bptr->id == lowestCommon->bptr->id) {
                    found = true;
                    break;
                }
            }
            if (found) {
                DEBUG(3, fmt::format("Lowest common ancestor: {}", lowestCommon->bptr->id));
                break;
            }
        }

        // add all control dependencies
        int maxToOcc = al_size(edge->to->occurrences);
        for (int currToOcc = 0; currToOcc < maxToOcc; currToOcc++) {
            // Get index of i'th execution of BBL
            int dependSource = *(int *)al_get(edge->to->occurrences, currToOcc);
            dependSource -= 1; // points to the last instruction in previous bbl, conditional jump

            Instruction *dependsOn = GetInstruction(iList, dependSource);
            DEBUG(3, fmt::format("{} - Ins: {}", dependSource, *dependsOn));
            if (!(instrHasFlag(dependsOn, INSTR_FORWARD_TAINTED))) {
                continue;
            }
            // Iterate over bbls between to and lowest bbl
            for (to = path1; to->bptr->id != lowestCommon->bptr->id; to = to->next) {
                DEBUG(3, fmt::format("Processing from BBL (path1) {}", to->bptr->id));
                if (!handle_rop && !instrHasFlag(to->bptr->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)) {
                    DEBUG(3, fmt::format("Skip {}", to->bptr->id));
                    continue;
                }
                if (currToOcc >= al_size(to->bptr->occurrences)) {
                    DEBUG(3, fmt::format("Skip {} - currToOcc > occ", to->bptr->id));
                    continue;
                }
                int start = *(int *)al_get(to->bptr->occurrences, currToOcc);
                DEBUG(3, fmt::format("Before setting COND_CF; start at {}", start));
                markInstructionsAsCondCF(iList, dependSource, start, to->bptr->numInstrs);
            }
            // Iterate over bbls between from and lowest bbl, skip the first node, the control node itself!
            for (from = path2->next; path2->bptr->id != lowestCommon->bptr->id && from->bptr->id != lowestCommon->bptr->id; from = from->next) {
                DEBUG(3, fmt::format("Processing from BBL (path2) {}", from->bptr->id));
                assert(false);
                if (!handle_rop && !instrHasFlag(from->bptr->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)) {
                    DEBUG(3, fmt::format("Skip {}", from->bptr->id));
                    continue;
                }
                if (currToOcc >= al_size(from->bptr->occurrences)) {
                    DEBUG(3, fmt::format("Skip {} - currToOcc > occ", from->bptr->id));
                    continue;
                }
                int start = *(int *)al_get(from->bptr->occurrences, currToOcc);
                DEBUG(3, fmt::format("Before setting COND_CF; start at {}", start));
                markInstructionsAsCondCF(iList, dependSource, start, from->bptr->numInstrs);
            }
        }
        logger.endPhase();
    }
}

ArrayList *newControlTransferInstrs;
void SetControlSourceforFlags(PSW_BITVECTOR flags, int order, int *FlagsDependency) {
    for (int i = 0; i < PSW_MAX_INDEX && flags != 0; i++) {
        int flag = 1 << i;
        if ((flag & flags) != 0) {
            FlagsDependency[i] = order;
        }
        flags &= ~flag;
    }
}

void setControlSourceForRegisters(DeobfRegisterUses &uses, int order, std::map<DeobfRegister, int> &map) {
    for (auto r : uses.affectedRegisters()) {
        map[r] = order;
        uses.reset(r);
    }
}

inline void resetRegisterDependencies(std::map<DeobfRegister, int> &registerDependencies) {
    for (auto &[_, v] : registerDependencies) {
        v = -1;
    }
}

bool MarkImplicitControlDependenciesNew(const std::shared_ptr<InstrList>& iList) {
    Instruction *iins{};
    ud_operand_t *op0{};
    enum ud_mnemonic_code opcode{};
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    DeobfRegisterUses regsTainted{};
    PSW_BITVECTOR flagsUsed{};
    PSW_BITVECTOR flagsDef{};
    PSW_BITVECTOR flagsTainted = 0;
    auto registerDependencies = std::map<DeobfRegister, int>{};
    int FlagDependency[PSW_MAX_INDEX]; // similar to the above, for flags
    bool Change = false;
    int PrevCondOrder = -1;

    ClearConstantPages(iList);

    newControlTransferInstrs = al_new();

    for (int regIdx = 1; regIdx <= DEOBF_REGISTER_OFFSET_RIP; regIdx++) {
        registerDependencies.emplace(static_cast<DeobfRegister>(regIdx), -1);
    }

    for (int & flagIdx : FlagDependency) {
        flagIdx = -1;
    }

    SetCurrentInstr(iList, 0);

    while ((iins = FetchNextInstr(iList)) != nullptr) {
        opcode = iins->uInstr.mnemonic;
        regsDefined = relatedRegistersLower(definedRegistersForInstruction(iList, iins));
        regsUsed = relatedRegistersLower(usedRegistersForInstruction(iList, iins));

        flagsUsed = FlagsUsed(iins);
        flagsDef = FlagsDef(iins);
        op0 = &(iins->uInstr.operand[0]);

        DEBUGLINE(3, fmt::format("Processing {} - {}", iins->order, *iins));

        if ((isPush(iins) || isPop(iins)) || opcode == UD_Icall || opcode == UD_Iret || opcode == UD_Ileave) {
            DEBUGLINE(3, "Is push, pop, call, ret or leave");
            if (UDOpIsRegister(op0) == UD_R_ESP) {
                if (iins->uInstr.mnemonic == UD_Ipop) {
                    regsUsed.resetRelated(DeobfRegister::RSP);
                } else if (iins->uInstr.mnemonic == UD_Ipush) {
                    regsDefined.resetRelated(DeobfRegister::RSP);
                }
            } else {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }

        if ((IsCondJump(iins) && instrHasFlag(iins, INSTR_FORWARD_TAINTED)) || !instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
            DEBUGLINE(3, "Is FT cond jump or not in base module");
            resetRegisterDependencies(registerDependencies);
            ClearConstantPages(iList);
            regsTainted.reset();
            PrevCondOrder = iins->order;
        }

        if (instrHasFlag(iins, INSTR_COND_CF)) {
            DEBUGLINE(3, "Has COND_CF");
            if (iins->ControlDependentOn != PrevCondOrder) {
                resetRegisterDependencies(registerDependencies);
                ClearConstantPages(iList);
                regsTainted.reset();
                PrevCondOrder = iins->ControlDependentOn;
            }

            if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                DependencyMemSetConstWithSrc(iList, iins->memDefMin, iins->memDefSize, iins->ControlDependentOn);
            }
            if (regsDefined.any()) {
                regsTainted |= regsDefined;
                setControlSourceForRegisters(regsDefined, iins->ControlDependentOn, registerDependencies);
            }
            if (flagsDef != 0) {
                flagsTainted |= flagsDef;
                SetControlSourceforFlags(flagsDef, iins->ControlDependentOn, FlagDependency);
            }
        } else {
            DEBUGLINE(3, "Doesn't have COND_CF");
            if (instrHasFlag(iins, INSTR_READS_MEM) && MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) {
                instrSetFlag(iins, INSTR_TEMP_CONDITIONAL, __LINE__);
            }
            DEBUGLINE(3, fmt::format("Regs used vs tainted: {} - {}", regsUsed, regsTainted));
            if (regsUsed.hasAnyOf(regsTainted)) {
                instrSetFlag(iins, INSTR_TEMP_CONDITIONAL, __LINE__);
            }
            DEBUGLINE(3, fmt::format("Flags used vs tainted: {} - {}", flagsUsed, flagsTainted));
            if ((flagsUsed & flagsTainted) != 0) {
                instrSetFlag(iins, INSTR_TEMP_CONDITIONAL, __LINE__);
            }
            if (instrHasFlag(iins, INSTR_TEMP_CONDITIONAL) && !(opcode == UD_Ixor && op0->base == iins->uInstr.operand[1].base)) {
                DEBUGLINE(3, "Is TMP Conditional");
                SaveInstrChange(iList, iins);
                if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                    if (opcode == UD_Ipushad) {
                        uint8_t offset = 0;
                        uint8_t registerWidth = getByteWidth(DeobfRegisterWidth::lower32bit);
                        for (auto reg : registers32bitMode32bit) {
                            if (regsTainted.test(reg)) {
                                DependencyMemSetConstWithSrc(iList, iins->esp - (offset + 1) * registerWidth, registerWidth, registerDependencies[reg]);
                            }
                            offset++;
                        }
                    } else if (opcode != UD_Ixchg && opcode != UD_Icmpxchg) {

                        uint64_t index = 0;
                        if (regsUsed.hasAnyOf(regsTainted)) { // filter out esp and memory registers
                            index = registerDependencies[(regsUsed & regsTainted).firstDeobfRegister()];
                        } else if (instrHasFlag(iins, INSTR_READS_MEM)) {
                            index = DependencyMemGetConstLocSrc(iList, iins->memUsedMin);
                        } else {
                            logger.verbose(fmt::format("Unhandled case: {}: {}", iins->order, *iins));
                        }
                        if (iins->uInstr.pfx_seg != UD_R_FS) {
                            DependencyMemSetConstWithSrc(iList, iins->memDefMin, iins->memDefSize, index);
                        }
                    }
                }
                if (regsDefined.any()) {
                    if (opcode == UD_Ipopad) {
                        uint8_t registerWidth = getByteWidth(DeobfRegisterWidth::lower32bit);
                        for (uint8_t k = 0; k < 8; k++) {
                            ADDRESS address = iins->esp + (k + 0) * registerWidth;
                            if (MemLocIsConstant(iList, address, registerWidth)) {
                                // Go from EDI to EAX
                                auto uses = relatedRegistersLower(static_cast<DeobfRegister>(DEOBF_REGISTER_OFFSET_32BITS + (7 - k)));
                                regsTainted |= uses;
                                int index = DependencyMemGetConstLocSrc(iList, address);

                                setControlSourceForRegisters(uses, index, registerDependencies);
                            }
                        }
                    } else if (opcode == UD_Ixchg || opcode == UD_Icmpxchg) {
                        bool regIsTainted = false;
                        if (op0->type == UD_OP_MEM) { // op0 is memory
                            if (MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) {
                                regIsTainted = true;
                            }
                            if (regsTainted.hasNoneOf(regsDefined)) {
                                UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                            } else if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                                DependencyMemSetConstWithSrc(iList, iins->memDefMin, iins->memDefSize,
                                                             registerDependencies[(regsDefined & regsTainted).firstDeobfRegister()]);
                                regsTainted.reset(allRelatedRegisters(regsDefined));
                            }
                            if (regIsTainted) {
                                regsTainted |= regsDefined;
                                int index = DependencyMemGetConstLocSrc(iList, iins->memUsedMin);

                                setControlSourceForRegisters(regsDefined, index, registerDependencies);
                            }
                        } else if (iins->uInstr.operand[1].type == UD_OP_MEM) { // op0 is reg
                            if (MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) { //(WriteSetsOverlap(memTainted, memUsed)) != 0)
                                regIsTainted = true;
                            }
                            if (regsTainted.hasNoneOf(regsDefined)) {
                                UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);

                            } else {
                                SetAddrAsConst(iList, iins->memDefMin, iins->memDefSize);
                                regsTainted.reset(allRelatedRegisters(regsDefined));
                            }
                            if (regIsTainted) {
                                regsTainted |= regsDefined;
                                setControlSourceForRegisters(regsDefined, iins->ControlDependentOn, registerDependencies);
                            }
                        } else { // op0 and op1 are regs
                            ud_operand *op1 = &iins->uInstr.operand[1];
                            const DeobfRegisterUses &testOp0 = regsTainted & relatedRegistersLower(op0->base);
                            const DeobfRegisterUses &testOp1 = regsTainted & relatedRegistersLower(op1->base);
                            auto relatedOp0 = allRelatedRegisters(op0->base);
                            auto relatedOp1 = allRelatedRegisters(op1->base);
                            if (testOp0.any() && testOp1.none()) {
                                regsTainted |= relatedOp1;
                                setControlSourceForRegisters(relatedOp1, registerDependencies[glue::toDeobfRegister(op0->base)], registerDependencies);
                                regsTainted.reset(relatedOp0);
                            } else if (testOp1.any() && testOp0.none()) {
                                regsTainted |= relatedOp0;
                                setControlSourceForRegisters(relatedOp0, registerDependencies[glue::toDeobfRegister(op1->base)], registerDependencies);
                                regsTainted.reset(relatedOp1);
                            }
                        }
                    } else {
                        int index = 0;
                        // filter out esp and memory registers
                        if (regsUsed.hasAnyOf(regsTainted)) {
                            DeobfRegister aRegister = (regsUsed & regsTainted).firstDeobfRegister();
                            index = registerDependencies[aRegister];
                        } else if (instrHasFlag(iins, INSTR_READS_MEM)) {
                            index = DependencyMemGetConstLocSrc(iList, iins->memUsedMin);
                        } else {
                            logger.verbose(fmt::format("Unhandled case: {}: {}", iins->order, *iins));
                        }
                        regsTainted |= regsDefined;
                        setControlSourceForRegisters(regsDefined, index, registerDependencies);
                    }
                }
                if (flagsDef != 0) {
                    flagsTainted |= flagsDef;
                    int index = 0;
                    if ((flagsUsed & flagsTainted) != 0) {
                        index = FlagDependency[floor_log2((flagsUsed & flagsTainted))];
                    } else if (regsUsed.hasAnyOf(regsTainted)) {
                        index = registerDependencies[(regsUsed & regsTainted).firstDeobfRegister()];
                    } else if (instrHasFlag(iins, INSTR_READS_MEM) && MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) {
                        index = DependencyMemGetConstLocSrc(iList, iins->memUsedMin);
                    }
                    SetControlSourceforFlags(flagsDef, index, FlagDependency);
                }
            } else {
                DEBUGLINE(3, "Not a TMP Conditional");
                if (instrHasFlag(iins, INSTR_WRITES_MEM) && MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize)) {
                    UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                }
                if (regsDefined.hasAnyOf(regsTainted)) {
                    DEBUGLINE(3, fmt::format("Reset {}", allRelatedRegisters(regsDefined)));
                    regsTainted.reset(allRelatedRegisters(regsDefined));
                }
                if ((flagsDef & flagsTainted) != 0) {
                    flagsTainted &= ~flagsDef;
                }
            }
        }

        if (InstrIsControlTransfer(iList, iins)) {
            DEBUGLINE(3, fmt::format("Control transfer, flags: {}", (flagsUsed & flagsTainted)));
        }
        if (!instrHasFlag(iins, INSTR_JMP_AS_CONDITIONAL) && (handle_rop || instrHasFlag(iins, INSTR_IN_BASE_MODULE)) && InstrIsControlTransfer(iList, iins) &&
            (regsUsed.hasAnyOf(regsTainted) || MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize) ||
             ((flagsUsed & flagsTainted) != 0))) {                                      // control instruction is implicit control transfer
            DEBUGLINE(3, "Is implicit transfer");
            if (instrHasFlag(iins, INSTR_FORWARD_TAINTED) && IsCondJump(iins)) { // don't add explicit conditionals here!
                DEBUGLINE(3, "Skip - FT and cond jump");
                continue;
            }

            if (regsUsed.hasAnyOf(regsTainted)) {
                DeobfRegister reg = (regsUsed & regsTainted).firstDeobfRegister();
                iins->ControlDependentOn = registerDependencies[reg];
                if (iins->ControlDependentOn == -1) {
                    // FIXME: check if we should replace the mechanism
                    regsUsed.reset(reg);
                    iins->ControlDependentOn = registerDependencies[(regsUsed & regsTainted).firstDeobfRegister()];
                }
            } else if (MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) { // WriteSetsOverlap(memTainted, memUsed)){
                iins->ControlDependentOn = DependencyMemGetConstLocSrc(iList, iins->memUsedMin);
            } else {
                iins->ControlDependentOn = FlagDependency[floor_log2((flagsUsed & flagsTainted))];
            }
            DEBUG(3, fmt::format("Mark {} ({}) as dependent on {}", iins->order, *iins, iins->ControlDependentOn));
            al_add(newControlTransferInstrs, iins);
            instrSetFlag(iins, INSTR_JMP_AS_CONDITIONAL, __LINE__);
            SaveInstrChange(iList, iins);
            Change = true;
        }
    }

    return Change;
}

void AddNewControlDependencies(const std::shared_ptr<InstrList>& iList) {
    Bbl *ibbl{};
    Bbl *jbbl{};

    for (int i = 0; i < al_size(newControlTransferInstrs); i++) { // iterate on all new found implicit control transfer instructions
        auto *iins = static_cast<Instruction *>(al_get(newControlTransferInstrs, i));
        DEBUGLINE(3, fmt::format("Processing {} (depends on {})", iins->order, iins->ControlDependentOn));
        auto *jins = GetInstruction(iList, iins->next); // and mark all BBl right after above instruction, until there is a bbl with more than 1 successor
        auto *ControlInstruction = GetInstruction(iList, iins->ControlDependentOn);
        // find the corresponding basic block
        for (ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next) {
            if (ibbl->ins_hd->iptr->ins->addr == jins->addr) {
                break;
            }
        }
        for (jbbl = bbl_list_hd; jbbl != nullptr; jbbl = jbbl->next) { // jins is the control transfer instr so it
                                                            // should be at the end of the bbl!
            if (ControlInstruction != nullptr && jbbl->ins_tl->iptr->ins->addr == ControlInstruction->addr) {
                break;
            }
        }

        if (ibbl == nullptr) {
            return;
        }

        if (jbbl == nullptr || ibbl->id == jbbl->succs->bptr->id) { // loop!
            continue;
        }

        while (ibbl->numSuccs <= 1) {
            while (jins != nullptr && jins->addr != ibbl->ins_tl->iptr->ins->addr) {
                DEBUGLINE(3, fmt::format("Mark {} as COND_CF", jins->order));
                instrSetFlag(jins, INSTR_COND_CF, __LINE__);
                jins->ControlDependentOn = ControlInstruction->order;
                SaveInstrChange(iList, jins);
                jins = GetInstruction(iList, jins->next);
            }
            if (ibbl->succs == nullptr) {
                break;
            }
            ibbl = ibbl->succs->bptr;
        }
    }
}

bool OperandsAreConstants(const std::shared_ptr<InstrList>& iList, Instruction *iins, ScopedConstants &scopedConstants) {
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    DeobfRegisterUses regsNonMemory{};
    std::unique_ptr<deobf::library::writeset::WriteSet> memUsed;
    std::unique_ptr<deobf::library::writeset::WriteSet> memDef;

    auto opcode = iins->uInstr.mnemonic;
    auto *op0 = &(iins->uInstr.operand[0]);
    auto *op1 = &(iins->uInstr.operand[1]);

    regsDefined = definedRegistersForInstruction(iList, iins);
    regsUsed = usedRegistersForInstruction(iList, iins);
    regsNonMemory = definedNonMemoryRegistersForInstruction(iList, iins);
    if (instrHasFlag(iins, INSTR_USES_FTAINT)) {
        if (regsDefined.any()) {
            scopedConstants.registers |= relatedRegistersLower(regsDefined);
        }
        if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
            memDef = memoryDefined(iList, iins);
            if (scopedConstants.memory->overlapsWith(memDef)) {
                scopedConstants.memory->subtract(memDef);
            }
        }
        return true;
    }

    if (!instrHasFlag(iins, INSTR_READS_MEM) && !instrHasFlag(iins, INSTR_WRITES_MEM)) { // register instruction
        if (opcode == UD_Ixchg) {
            if (op1->type == UD_OP_REG && op0->type == UD_OP_REG) {
                bool op0Const = scopedConstants.registers.test(op0->base);
                bool op1Const = scopedConstants.registers.test(op1->base);

                if (op0Const) {
                    scopedConstants.registers |= relatedRegistersLower(op1->base);
                } else {
                    scopedConstants.registers.reset(relatedRegistersLower(op1->base));
                }

                if (op1Const) {
                    scopedConstants.registers |= relatedRegistersLower(op0->base);
                } else {
                    scopedConstants.registers.reset(relatedRegistersLower(op0->base));
                }
            }
            return true;
        }
        if (regsDefined.any()) {
            bool usesKnown = scopedConstants.registers.hasAllOf(regsUsed);
            if (!OpcodeIsArith(opcode) && usesKnown) { // if instr only uses known registers or constants
                scopedConstants.registers |= allRelatedRegisters(regsDefined);
                return true;
            }
            if (OpcodeIsArith(opcode) && (scopedConstants.registers.hasAllOf(regsDefined) || usesKnown)) {
                scopedConstants.registers |= allRelatedRegisters(regsDefined);
                return true;
            }
            // for arithmetic operations, if defined register is constant, we
            // dont care about the other operands: consider the result as a
            // constant!
        }
    } else {
        if (!instrHasFlag(iins, INSTR_READS_MEM) && instrHasFlag(iins, INSTR_WRITES_MEM)) { // instr defines a memory location
            memDef = memoryDefined(iList, iins);
            if (opcode == UD_Ipushfd) {
                if (!instrHasFlag(iins, INSTR_FORWARD_TAINTED)) { // if flags are not affected by input, then the memory is constant!
                    scopedConstants.memory->merge(memDef);
                    return true;
                }
            } else if (regsNonMemory.none() || scopedConstants.registers.hasAllOf(regsNonMemory)) {
                // TODO: add support for popad, some regs maybe constant. question: can we easily separate regUsed and nonMemRegUsed?
                if (!memDef->empty()) {
                    scopedConstants.memory->merge(memDef);
                    return true;
                }
            } else if (regsNonMemory.any() &&
                       scopedConstants.registers.hasAllOf(relatedRegistersLower(regsNonMemory))) { // ex.: push eax while ax is only constant!
                auto es = memoryMask(iins->memDefMin, regsNonMemory.toDeobfRegister());
                scopedConstants.memory->merge(es);
                return true;
            }
        } else if (instrHasFlag(iins, INSTR_READS_MEM) && !instrHasFlag(iins, INSTR_WRITES_MEM)) {
            memUsed = memoryUsed(iList, iins);
            if (opcode == UD_Ipopfd) {
                // for flags TODO
            } else if (regsNonMemory.none() ||
                       scopedConstants.registers.hasAllOf(regsNonMemory)) { // consider instructions like mul [mem] which implicitly uses eax
                if (regsDefined.any() && (scopedConstants.memory->overlapsWith(memUsed) || instrHasFlag(iins, INSTR_READS_GLOBAL_MEM))) {
                    scopedConstants.registers |= relatedRegistersLower(regsDefined);
                    return true;
                }
            }
        } else if (instrHasFlag(iins, INSTR_READS_MEM) && instrHasFlag(iins, INSTR_WRITES_MEM)) {
            memUsed = memoryUsed(iList, iins);
            memDef = memoryDefined(iList, iins);
            if (opcode == UD_Ixchg || opcode == UD_Ixadd || opcode == UD_Icmpxchg) {
                // special case
                if (opcode == UD_Ixchg) {
                    bool op0Const{};
                    bool op1Const{};
                    if (op1->type == UD_OP_REG && op0->type == UD_OP_REG) {
                        op0Const = scopedConstants.registers.test(op0->base);
                        op1Const = scopedConstants.registers.test(op1->base);

                        if (op0Const) {
                            scopedConstants.registers |= relatedRegistersLower(op1->base);
                        } else {
                            scopedConstants.registers.reset(relatedRegistersLower(op1->base));
                        }

                        if (op1Const) {
                            scopedConstants.registers |= relatedRegistersLower(op0->base);
                        } else {
                            scopedConstants.registers.reset(relatedRegistersLower(op0->base));
                        }

                    } else if (op1->type == UD_OP_REG && op0->type == UD_OP_MEM) {
                        op0Const = scopedConstants.memory->overlapsWith(memDef);
                        op1Const = scopedConstants.registers.test(op1->base);

                        if (op1Const) {
                            if (!scopedConstants.memory->overlapsWith(memUsed)) {
                                scopedConstants.memory->merge(memDef);
                            }
                        } else {
                            if (scopedConstants.memory->overlapsWith(memUsed)) {
                                scopedConstants.memory->subtract(memDef);
                            }
                        }
                        if (op0Const) {
                            scopedConstants.registers |= relatedRegistersLower(op1->base);
                        } else {
                            scopedConstants.registers.reset(relatedRegistersLower(op1->base));
                        }
                    } else { // op1->type == ud_op_mem ...
                        op1Const = scopedConstants.memory->overlapsWith(memDef);
                        op0Const = scopedConstants.registers.test(op0->base);

                        if (op0Const) {
                            if (!scopedConstants.memory->overlapsWith(memUsed)) {
                                scopedConstants.memory->merge(memDef);
                            }
                        } else {
                            if (scopedConstants.memory->overlapsWith(memUsed)) {
                                scopedConstants.memory->subtract(memDef);
                            }
                        }
                        if (op1Const) {
                            scopedConstants.registers |= relatedRegistersLower(op0->base);
                        } else {
                            scopedConstants.registers.reset(relatedRegistersLower(op0->base));
                        }
                    }
                    return true;
                }
            } else if (regsNonMemory.none() || scopedConstants.registers.hasAllOf(regsNonMemory)) {
                if (!memDef->empty() && scopedConstants.memory->overlapsWith(memUsed)) {
                    scopedConstants.memory->merge(memDef);
                    return true;
                }
            }
        }
    }

    scopedConstants.registers.reset(regsDefined).setRelated(DeobfRegister::RSP);
    if (instrHasFlag(iins, INSTR_WRITES_MEM) && scopedConstants.memory->overlapsWith(memDef)) {
        scopedConstants.memory->subtract(memDef);
    }
    return false;
}

void MarkUnsimplifiableInstrs(const std::shared_ptr<InstrList>& iList) {
    Instruction *iins{};
    std::map<int, ScopedConstants> scopes {};

    SetCurrentInstr(iList, 0);
    while ((iins = FetchNextInstr(iList)) != nullptr) {
        if (iins->ControlDependentOn == -1 || (!handle_rop && !instrHasFlag(iins, INSTR_IN_BASE_MODULE))) {
            DEBUG(3, fmt::format("SKIP {} {}", iins->order, ((iins->ControlDependentOn == -1) ? "ControlF***" : "Not base")));
            continue;
        }
        if (scopes.find(iins->ControlDependentOn) == scopes.end()) {
            scopes[iins->ControlDependentOn] = ScopedConstants();
        }
        if (scopes.find(iins->ControlDependentOn) == scopes.end()) {
            logger.log(fmt::format("Error, Instr is not within any known scope! {}: {} depend on {}", iins->order, *iins, iins->ControlDependentOn));
            return;
        }
        if (instrHasFlag(iins, INSTR_IN_BASE_MODULE) && !OperandsAreConstants(iList, iins, scopes[iins->ControlDependentOn]) && OpcodeIsArith(iins->uInstr.mnemonic) &&
            instrHasFlag(iins, INSTR_BACKWARD_TAINTED)) {
            DEBUG(3, fmt::format("Marking {} as unsimplifiable!", iins->order));
            instrSetFlag(iins, INSTR_UNSIMPLIFIABLE, __LINE__);
            SaveInstrChange(iList, iins);
        } else if(instrHasFlag(iins, INSTR_IN_BASE_MODULE) && OpcodeIsArith(iins->uInstr.mnemonic) && instrHasFlag(iins, INSTR_BACKWARD_TAINTED)) {
            DEBUG(3, fmt::format("Not marking {} as unsimplifiable! Ops are const", iins->order));
        } else if(instrHasFlag(iins, INSTR_IN_BASE_MODULE) && OpcodeIsArith(iins->uInstr.mnemonic)) {
            DEBUG(3, fmt::format("Not marking {} as unsimplifiable! WTF?", iins->order));
        }
    }
}

ADDRESS getJmpAddress(const Instruction *ins) {
    ADDRESS dest = ins->eip + ins->uInstr.length;
    ud_operand op = ins->uInstr.operand[0];
    if (op.type == UD_OP_JIMM) {
        switch (op.size) {
        case 8:
            dest += op.lval.sbyte;
            break;
        case 16:
            dest += op.lval.sword;
            break;
        case 32:
            dest += op.lval.sdword;
            break;
        case 64:
            dest += op.lval.sqword;
            logger.log("WARNING: 64 bit offsets not implemented");
            break;
        default:
            logger.log(fmt::format("WARNING: Unhandled operand size {}", op.size));
            break;
        }
    } else {
        DEBUG(3, fmt::format("Unhandled type for jump {}", UDCreate::operandToString(op.type)));
    }
    return dest;
}

bListNode *createbListNodeAndSetPreviousSuccessor(Bbl *currBbl, Bbl *prevBbl) {
    auto *node = static_cast<bListNode *>(malloc(sizeof(bListNode)));
    node->bptr = currBbl;
    node->next = prevBbl->succs;
    prevBbl->succs = node;
    prevBbl->numSuccs++;
    return node;
}

Bbl *splitBblAt(iListNode *destNode, Bbl *targetBbl) {
    // Mark instructions with BBL start/end
    NODE_SET_FLAG(destNode->prev->iptr, BBL_END);
    NODE_SET_FLAG(destNode->iptr, BBL_START);
    // Create new BBl
    auto *newSplitBbl = new Bbl();
    newSplitBbl->id = bbl_id++;
    newSplitBbl->mergedBBls = std::to_string(newSplitBbl->id);
    newSplitBbl->numInstrs = 0;
    newSplitBbl->occurrences = al_new();
    al_add(newSplitBbl->occurrences, &(destNode->iptr->ins->order));
    // Assign instructions to BBl
    for (auto *cpyIns = destNode; cpyIns != nullptr; cpyIns = cpyIns->next) {
        if (newSplitBbl->ins_hd == nullptr) {
            newSplitBbl->ins_hd = cpyIns;
        }
        newSplitBbl->numInstrs++;

        if (NODE_HAS_FLAG(cpyIns->iptr, BBL_END)) {
            newSplitBbl->ins_tl = cpyIns;
            break;
        }
    }
    // Correct succs
    // New block goes to next bbl only
    auto *firstSucc = static_cast<bListNode *>(malloc(sizeof(bListNode)));
    firstSucc->bptr = targetBbl->next;
    newSplitBbl->succs = firstSucc;
    newSplitBbl->numSuccs++;
    // Old block goes to all old bbl's except the next BBL and to the new one
    for (auto *succ = targetBbl->succs; succ != nullptr; succ = succ->next) {
        if (succ->bptr->id == targetBbl->next->id) {
            succ->bptr = newSplitBbl;
            break;
        }
    }

    // Remove those instructions from old BBl
    targetBbl->ins_tl = destNode->prev;
    targetBbl->numInstrs -= newSplitBbl->numInstrs;
    // Correct chain
    auto *prev = targetBbl;
    auto *next = targetBbl->next;
    newSplitBbl->prev = targetBbl;
    newSplitBbl->next = next;
    prev->next = newSplitBbl;
    next->prev = newSplitBbl;

    // Redetermine flags
    for (auto *ins = newSplitBbl->ins_hd; ins != nullptr; ins = ins->next) {
        determineFlagsForBbl(newSplitBbl, ins->iptr->ins, true);
    }
    targetBbl->flags = 0;
    for (auto *ins = targetBbl->ins_hd; ins != nullptr; ins = ins->next) {
        determineFlagsForBbl(targetBbl, ins->iptr->ins, true);
    }

    DEBUG(3, fmt::format("Split BBL {0} into {0} and {1}", targetBbl->id, newSplitBbl->id));
    return newSplitBbl;
}

void ConstructOriginalCFG(const std::shared_ptr<InstrList>& iList) {
    logger.startPhase("Constructing CFG");

    CleanUpCFGData();
    CollectDistinctInstructionsByAddress(iList);
    CollectInstrSuccessorsAndPredators(iList);
    MarkBblBoundariesByAddr(iList, !uGhentImprovements);

    logger.startPhase("Constructing basic blocks");
    ConstructDistinctBblsOldMethod(iList);
    logger.endPhase(); // BBLs

    logger.endPhase(); // CFG
}

void AddBblPreds() {
    for (auto *ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next) {
        for (auto *succs = ibbl->succs; succs != nullptr; succs = succs->next) {
            auto *predNew = static_cast<bListNode *>(malloc(sizeof(bListNode)));
            predNew->bptr = succs->bptr;
            predNew->next = succs->bptr->preds;
            succs->bptr->preds = predNew;
            succs->bptr->numPreds++;
        }
    }
}

lastOp *createLastOperation(Bbl *from, Bbl *to, iListNode *backTo, bool removeEdge, Bbl *prevBbl, bListNode *otherSuccessors) {
    auto *operation = static_cast<lastOp *>(malloc(sizeof(lastOp)));
    operation->from = from;
    operation->to = to;
    operation->prevBbl = prevBbl;
    operation->backToInstr = backTo;
    operation->removeEdge = removeEdge;
    operation->otherSuccessors = nullptr;
    operation->bbls = al_new();

    if (otherSuccessors != nullptr) {
        for (; otherSuccessors != nullptr; otherSuccessors = otherSuccessors->next) {
            if (otherSuccessors->bptr->ins_hd->iptr->ins->addr == backTo->iptr->ins->addr) {
                operation->otherSuccessors = otherSuccessors;
                break;
            }
        }
    }

    al_add(operation->bbls, to);
    return operation;
}

void freeLastOperation(lastOp *lastOperation) {
    al_free(lastOperation->bbls);
    free(lastOperation);
}

bool bblIsPossiblyUnique(Bbl *bbl) {
    if (bbl == nullptr) {
        return true;
    }
    int numPossibleSuccs = NumberOfPossibleSuccessors(bbl);
    return !instrHasFlag(bbl->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE) || numPossibleSuccs == -1 || numPossibleSuccs > bbl->numSuccs;
}

void addOccurrenceToBbbl(Bbl *bbl, const iListNode *il) {
    al_add(bbl->occurrences, &il->iptr->ins->order);
    DEBUG(3, fmt::format("1 entry added to {}", bbl->id));
}

iListNode *advanceToNextBBl(iListNode *il, Bbl *bbl) {
    int instrCount = bbl->numInstrs;
    while (il != nullptr) {
        if (!instrHasFlag(bbl->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE) && NODE_HAS_FLAG(il->iptr, BBL_END)) {
            break;
        }
        instrCount--;
        if (instrCount == 0) {
            break;
        }

        il = il->next;
    }
    if (il != nullptr) {
        il = il->next;
    }
    return il;
}

bListNode *removeEdge(bListNode *successor, lastOp *lastOperation) {
    bListNode *toFree{};
    for (bListNode *tmp = successor = lastOperation->from->succs; successor != nullptr; successor = successor->next) {
        if (toFree != nullptr) {
            free(toFree);
            toFree = nullptr;
        }
        if (successor->bptr->id == lastOperation->to->id) {
            // remove from --> to edge
            if (successor == tmp) {
                toFree = lastOperation->from->succs;
                lastOperation->from->succs = lastOperation->from->succs->next;
            } else {
                tmp->next = successor->next;
            }
            lastOperation->from->numSuccs--;
        }
        tmp = successor;
    }
    if (toFree != nullptr) {
        free(toFree);
    }
    return successor;
}

void removeLastOccurrences(lastOp *lastOperation) {
    ArrayList *bbls = lastOperation->bbls;
    for (int l = 0; l < al_size(bbls); l++) {
        Bbl *tmp = static_cast<Bbl *>(al_get(bbls, l));
        al_removeLast(tmp->occurrences);
        DEBUG(2, fmt::format("last occurrences popped from {}", tmp->id));
    }
}

bool findMatchingBbl(Bbl *&ibbl, ADDRESS toMatch, Bbl *start) {
    bool found = false;
    for (ibbl = start; ibbl != nullptr; ibbl = ibbl->next) {
        if (ibbl == start) {
            continue;
        }
        if (ibbl->ins_hd->iptr->ins->addr == toMatch) {
            found = true;
            break;
        }
    }
    return found;
}

void FixBblBacktrack6(const std::shared_ptr<InstrList>& iList, std::map<ADDRESS, bool> jmpTakesBothBranches) {
    int id = 0;
    uint64_t currLoopCount = 0;
    Bbl *start{};
    Bbl *end{};
    Bbl *ibbl{};
    Bbl *prevBbl{};
    iListNode *iltmp{};
    bListNode *succs{};
    bListNode *remainingSuccs{};
    auto *il0 = ins_list_by_addr;

    bool resetToStartBBl{};
    bool notSteppingBack = true;
    bool flag = true;

    std::vector<lastOp *> steps{};

    while (il0 != nullptr) {
        currLoopCount++;
        DEBUG(3, fmt::format("Current loop is {}", currLoopCount));
        if (!NODE_HAS_FLAG(il0->iptr, BBL_START)) {
            DEBUG(3, fmt::format("Weird! il0 = {}: [{:#x}] {}", il0->iptr->ins->order, il0->iptr->ins->addr, *(il0->iptr->ins)));
        }
        if (prevBbl != nullptr) {
            if (remainingSuccs == nullptr) {
                succs = prevBbl->succs;
            } else {
                succs = remainingSuccs;
                remainingSuccs = nullptr;
            }
            bool found = false;
            if (notSteppingBack && flag) {
                for (; succs != nullptr; succs = succs->next) {
                    if (succs->bptr->ins_hd->iptr->ins->addr == il0->iptr->ins->addr) {
                        DEBUG(3, fmt::format("--bbl {} exists with starting: {}: [{:#x}] {}", succs->bptr->id, il0->iptr->ins->order, il0->iptr->ins->addr, *(il0->iptr->ins)));
                        found = true;
                        resetToStartBBl = true;

                        lastOp *lastOperation = createLastOperation(prevBbl, succs->bptr, il0, false, prevBbl, succs->next);
                        steps.push_back(lastOperation);

                        addOccurrenceToBbbl(succs->bptr, il0);
                        il0 = advanceToNextBBl(il0, succs->bptr);

                        prevBbl = succs->bptr;
                        break;
                    }
                }
                if (found) {
                    continue;
                }
            }
            // then we should add this coming bbl to prevBbl's successors!
            // can we go from prevBbl to ibbl?
            found = false;
            if (notSteppingBack) {
                if (resetToStartBBl) {
                    ibbl = start;
                }
                for (; ibbl != nullptr; ibbl = ibbl->next) {
                    if (il0->iptr->ins->addr == ibbl->ins_hd->iptr->ins->addr) {
                        found = true;
                        break;
                    }
                }
            }

            if (found) {
                DEBUG(3, fmt::format("bbl {} exists with starting: {}: [{:#x}] {}", ibbl->id, il0->iptr->ins->order, il0->iptr->ins->addr, *(il0->iptr->ins)));
                if (bblIsPossiblyUnique(prevBbl)) {
                    createbListNodeAndSetPreviousSuccessor(ibbl, prevBbl);
                    addOccurrenceToBbbl(ibbl, il0);

                    resetToStartBBl = true;
                    lastOp *lastOperation = createLastOperation(prevBbl, ibbl, il0, true, prevBbl, nullptr);
                    steps.push_back(lastOperation);

                    il0 = advanceToNextBBl(il0, ibbl);
                    prevBbl = ibbl;
                    continue;
                }
                // Handle non-unique BBL
                lastOp *lastOperation = steps.back();
                il0 = lastOperation->backToInstr;
                prevBbl = lastOperation->prevBbl;
                remainingSuccs = lastOperation->otherSuccessors;

                DEBUG(3, fmt::format("Going back to {}", il0->iptr->ins->order));

                removeLastOccurrences(lastOperation);

                flag = false;
                if (lastOperation->removeEdge) {
                    flag = true;
                    succs = removeEdge(succs, lastOperation);
                }

                bool matchingBbl = findMatchingBbl(ibbl, il0->iptr->ins->addr, lastOperation->to);
                notSteppingBack = matchingBbl;
                resetToStartBBl = !matchingBbl;

                if (!lastOperation->removeEdge && remainingSuccs == nullptr) {
                    notSteppingBack = false;
                }
                if (remainingSuccs != nullptr) {
                    notSteppingBack = true;
                    flag = true;
                }

                // Remove step
                steps.pop_back();
                freeLastOperation(lastOperation);
                continue;
            }
        }
        if (bblIsPossiblyUnique(prevBbl) && (ibbl == nullptr || !notSteppingBack)) {
            notSteppingBack = true;
            ibbl = new Bbl();
            ibbl->id = id++;
            ibbl->mergedBBls = std::to_string(ibbl->id);
            ibbl->numInstrs = 0;

            if (end != nullptr) {
                end->next = ibbl;
            }
            ibbl->prev = end;
            end = ibbl;
            if (start == nullptr) {
                start = ibbl;
            }
            ibbl->occurrences = al_new();
            al_add(ibbl->occurrences, &(il0->iptr->ins->order));

            for (iltmp = il0; iltmp != nullptr; iltmp = iltmp->next) {
                if (ibbl->ins_hd == nullptr) {
                    ibbl->ins_hd = iltmp;
                }
                ibbl->numInstrs++;

                if (NODE_HAS_FLAG(iltmp->iptr, BBL_END)) {
                    break;
                }
            }
            ibbl->ins_tl = iltmp;
            // add new bbl to previous' successors
            if (prevBbl != nullptr) {
                succs = createbListNodeAndSetPreviousSuccessor(ibbl, prevBbl);
            }

            prevBbl = ibbl;
            resetToStartBBl = true;
            DEBUG(3, fmt::format("bbl {} added with starting: {} [{:#x}] {}", ibbl->id, ibbl->ins_hd->iptr->ins->order, ibbl->ins_hd->iptr->ins->addr, *(ibbl->ins_hd->iptr->ins)));
            if (iltmp != nullptr) {
                il0 = iltmp->next;
            } else {
                il0 = nullptr;
            }
        } else {
            DEBUG(3, fmt::format("Currently at {} {}", il0->iptr->ins->order, *(il0->iptr->ins)));
            lastOp *lastOperation = steps.back();

            il0 = lastOperation->backToInstr;
            prevBbl = lastOperation->prevBbl;
            remainingSuccs = lastOperation->otherSuccessors;

            DEBUG(3, fmt::format("Going back (2) to {}", il0->iptr->ins->order));

            for (int o = il0->iptr->ins->order; o < il0->next->iptr->ins->order; o++) {
                Instruction *ins = GetInstruction(iList, o);
                if (IsCondJump(ins) && instrHasFlag(ins, INSTR_IS_DELETED) && jmpTakesBothBranches.find(ins->addr) != jmpTakesBothBranches.end() &&
                    jmpTakesBothBranches[ins->addr]) {
                    if (modified_instructions.find(ins->addr) == modified_instructions.end()) {
                        DEBUG(3, fmt::format("Deleted cond jump at {}: [{:#x}] {}", o, ins->addr, *ins));
                    }
                    modified_instructions.insert(ins->addr);
                }
            }

            removeLastOccurrences(lastOperation);

            flag = false;
            if (lastOperation->removeEdge) {
                flag = true;
                succs = removeEdge(succs, lastOperation);
            }

            bool matchingBbl = findMatchingBbl(ibbl, il0->iptr->ins->addr, lastOperation->to);
            notSteppingBack = matchingBbl;
            resetToStartBBl = !matchingBbl;

            if (!lastOperation->removeEdge && remainingSuccs == nullptr) {
                notSteppingBack = false;
            }
            if (remainingSuccs != nullptr) {
                notSteppingBack = true;
                flag = true;
            }
            // Remove step
            steps.pop_back();
            freeLastOperation(lastOperation);
        }
    }
    DEBUG(2, fmt::format("Loop count for FixBblBacktrack6: {}", currLoopCount));
    // Clean up steps
    for (lastOp *lastOp : reverse(steps)) {
        freeLastOperation(lastOp);
    }
    bbl_list_hd = start;
    bbl_list_tl = end;
}

/*
 * MergeSimilarBbls
 *
 * look at the basic blocks that start with the same
 * address, look at the instructions on the two bbls
 * if the only difference is dead codes, then two bbls
 * can be merged to one!
 */
bool MergeSimilarBbls(const std::shared_ptr<InstrList>& iList) {
    Instruction *iinsPrev{};
    Instruction *jinsPrev{};
    bool bblsEqual = true;
    bool retVal = false;

    for (auto *ibbl = bbl_list_hd; ibbl != nullptr; ibbl = ibbl->next) {
        for (auto *jbbl = ibbl->next; jbbl != nullptr; jbbl = jbbl->next) {
            if (ibbl->ins_hd->iptr->ins->addr == jbbl->ins_hd->iptr->ins->addr &&
                instrHasFlag(ibbl->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)) { // potentially ibbl and jbbl are the same
                int iBblTimes = al_size(ibbl->occurrences);
                int jBblTimes = al_size(jbbl->occurrences);
                while (iBblTimes != 0 && jBblTimes != 0) {

                    int iorder = *(int *)al_get(ibbl->occurrences, --iBblTimes);
                    int *jjorder = (int *)al_get(jbbl->occurrences, --jBblTimes);
                    int jorder = *jjorder;

                    auto *iins = GetInstruction(iList, iorder);
                    auto *jins = GetInstruction(iList, jorder);

                    while (iins->addr == jins->addr) {
                        iinsPrev = iins;
                        jinsPrev = jins;
                        iins = GetInstruction(iList, iins->next);
                        jins = GetInstruction(iList, jins->next);
                    }
                    // now
                    // CountInstructionsBetweenTwoInstrs()
                    uint64_t idiff = countInstructionsBetween(iList, iinsPrev, iins);
                    uint64_t jdiff = countInstructionsBetween(iList, jinsPrev, jins);
                    // whichever is greater, must have some dead instructions in between

                    if (idiff < jdiff) {
                        while (jinsPrev != jins) {

                            jinsPrev = GetInstruction(iList, jinsPrev->origNext);
                            iinsPrev = GetInstruction(iList, iinsPrev->origNext);

                            if (iinsPrev->addr != jinsPrev->addr) {
                                Instruction *iinsPrevTmp = GetInstruction(iList, iinsPrev->origNext);
                                Instruction *jinsPrevTmp = GetInstruction(iList, jinsPrev->origNext);
                                if (jinsPrevTmp->addr != iinsPrev->addr && iinsPrevTmp->addr != jinsPrev->addr) {
                                    bblsEqual = false;
                                    break;
                                }
                                if (jinsPrevTmp->addr == iinsPrev->addr) {
                                    jinsPrev = jinsPrevTmp;
                                } else {
                                    iinsPrev = iinsPrevTmp;
                                }
                            }

                            if (instrHasFlag(jinsPrev, INSTR_IS_DELETED) && !instrHasFlag(iinsPrev, INSTR_IS_DELETED)) {
                                bblsEqual = true;
                                MakeInstrAlive(iList, jinsPrev);
                                ud_t *udins_new = UDCreate::nop();
                                carefulCopyUDins2InsStr(iList, jinsPrev, &(jinsPrev->uInstr), udins_new, false, __LINE__);
                                glue::freeUDStructure(udins_new, true);
                            }
                        }
                    } else if (jdiff < idiff) {
                        while (iinsPrev != iins) {
                            jinsPrev = GetInstruction(iList, jinsPrev->origNext);
                            iinsPrev = GetInstruction(iList, iinsPrev->origNext);

                            if (iinsPrev == nullptr || jinsPrev == nullptr) {
                                break;
                            }

                            if (iinsPrev->addr != jinsPrev->addr) {
                                // skip 1 instruction
                                Instruction *iinsPrevTmp = GetInstruction(iList, iinsPrev->origNext);
                                Instruction *jinsPrevTmp = GetInstruction(iList, jinsPrev->origNext);
                                if (jinsPrevTmp->addr != iinsPrev->addr && iinsPrevTmp->addr != jinsPrev->addr) {
                                    bblsEqual = false;
                                    break;
                                }
                                if (jinsPrevTmp->addr == iinsPrev->addr) {
                                    jinsPrev = jinsPrevTmp;
                                } else {
                                    iinsPrev = iinsPrevTmp;
                                }
                            }
                            if (instrHasFlag(iinsPrev, INSTR_IS_DELETED) && !instrHasFlag(jinsPrev, INSTR_IS_DELETED)) {
                                bblsEqual = true;
                                MakeInstrAlive(iList, iinsPrev);
                                ud_t *udins_new = UDCreate::nop();
                                carefulCopyUDins2InsStr(iList, iinsPrev, &(iinsPrev->uInstr), udins_new, false, __LINE__);

                                glue::freeUDStructure(udins_new, true);
                            }
                        }
                    } else {
                        bblsEqual = false;
                        continue;
                    }
                    if (bblsEqual) {
                        retVal = true;
                    }
                }
            }
        }
    }
    return retVal;
}

std::map<ADDRESS, bool> collectBranchInformationForJumps(const std::shared_ptr<InstrList>& iList) {
    auto start = std::chrono::high_resolution_clock::now();
    std::map<ADDRESS, bool> jmps {};
    std::map<ADDRESS, std::set<ADDRESS>> takenJumps {};
    for (int o = iList->firstInstr; o < iList->lastInstr; o++) {
        Instruction *ins = GetInstruction(iList, o);
        if (!IsCondJump(ins)) {
            continue;
        }
        Instruction *next = GetInstruction(iList, ins->origNext);
        if (takenJumps.find(ins->addr) == takenJumps.end()) {
            takenJumps.insert({ins->addr, {}});
        }
        takenJumps[ins->addr].insert(next->addr);
    }
    for (const auto& takenJump : takenJumps) {
        DEBUG(5, fmt::format("Conditional jump {:#x} has {} destinations", takenJump.first, takenJump.second.size()));
        jmps.insert({takenJump.first, takenJump.second.size() > 1});
    }
    auto stop = std::chrono::high_resolution_clock::now();
    auto msTaken = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
    auto sTaken = std::chrono::duration_cast<std::chrono::seconds>(stop - start);
    DEBUG(3, fmt::format("collectBranchInformationForJumps: {} ({})", sTaken, msTaken));
    return jmps;
}

void ConstructCFG(const std::shared_ptr<InstrList>& iList, bool debugDot) {
    logger.startPhase("Constructing CFG");
    CollectDistinctInstructionsByAddress(iList);
    CollectInstrSuccessorsAndPredators(iList);
    MarkBblBoundariesByAddr(iList, true);

    logger.startPhase(PHASE_BTRk6);
    std::map<ADDRESS, bool> jmpBranches = collectBranchInformationForJumps(iList);
    FixBblBacktrack6(iList, jmpBranches);
    AddBblPreds();
    logger.endPhase();

    MergeBblsNew();

    if (debugDot) {
        std::string simplifiedDotFileName = directoryUtils.getBaseName("_simplified_0");

        FILE *simplifiedGraph = fopen(simplifiedDotFileName.c_str(), "w");
        assert(simplifiedGraph);
        PrintCFG(simplifiedGraph, true, true, std::map<ADDRESS, uint8_t>());
        fclose(simplifiedGraph);
    }

#if 1
    int iter = 0;
    while (MergeSimilarBbls(iList) && (iter < 100)) {
        logger.startPhase("Iterative fixing loop " + std::to_string(iter));

        CleanUpCFGData();

        CollectDistinctInstructionsByAddress(iList);
        CollectInstrSuccessorsAndPredators(iList);
        MarkBblBoundariesByAddr(iList, true);

        logger.startPhase(PHASE_BTRk6);
        jmpBranches = collectBranchInformationForJumps(iList);
        FixBblBacktrack6(iList, jmpBranches);
        AddBblPreds();
        logger.endPhase();

        MergeBblsNew();
        iter++;

        if (debugDot) {
            std::string baseName = directoryUtils.getBaseName("_simplified_" + std::to_string(iter));
            std::string simplifiedDotFileName = directoryUtils.getOutputFile(baseName, DirectoryUtils::dotExtension(), prefix, suffix);

            FILE *simplifiedGraph = fopen(simplifiedDotFileName.c_str(), "w");
            assert(simplifiedGraph);
            PrintCFG(simplifiedGraph, true, true, std::map<ADDRESS, uint8_t>());
            fclose(simplifiedGraph);
        }
        logger.endPhase();
    }
#endif
    logger.endPhase();
}

void DependencyAnalysis(const std::shared_ptr<InstrList>& iList) {
    logger.startPhase("Post-dominator tree");
    PostDominatorTree();
    logger.endPhase();
    logger.startPhase("Immediate post-dominators");
    ImmediateDominator();
    logger.endPhase();
    logger.startPhase("Explicit dependencies");
    FindExplicitControlDependencies(iList);
    logger.endPhase();
    logger.startPhase("Implicit dependencies");
    while (MarkImplicitControlDependenciesNew(iList)) {
        AddNewControlDependencies(iList);
    }
    MarkUnsimplifiableInstrs(iList);
    logger.endPhase();
}

void CleanUpCFGData() {
    logger.startPhase("Clean up CFG data");
    for (int i = 0; i < HASH_TAB_SZ; i++) {
        auto *il = addressHashTable[i];
        while (il != nullptr) {
            iListNode *tmp = il->hnext;
            freeUpIListNode(il->iptr->succs);
            freeUpIListNode(il->iptr->preds);
            free(il->iptr);
            free(il);
            il = tmp;
        }
        addressHashTable[i] = nullptr;
    }

    ins_list = nullptr; // just nulling the pointers, they should be freed!
    iListNode *currentIns = ins_list_by_addr;
    while (currentIns != nullptr) {
        iListNode *nextIns = currentIns->next;
        free(currentIns->iptr);
        free(currentIns);
        currentIns = nextIns;
    }
    ins_list_by_addr = ins_list_tl_by_addr = nullptr;
    Bbl *currentBbl = bbl_list_tl;
    while (currentBbl != nullptr) {
        Bbl *nextBbl = currentBbl->prev;
        freeUpBListNode(currentBbl->succs);
        freeUpBListNode(currentBbl->pDoms);
        freeUpBListNode(currentBbl->preds);
        freeUpBListNode(currentBbl->ipDoms);
        al_free(currentBbl->occurrences);
        free(currentBbl);
        currentBbl = nextBbl;
    }
    bbl_list_hd = bbl_list_tl = nullptr;

    bbl_id = 0;
    logger.endPhase();
}

/*
 * special CFG print routine, for doing
 * CFG similarity by Patrick!
 */
void PrintCFG(FILE *f, bool printInstructions, bool printTaint, const std::map<ADDRESS, uint8_t> &taintStatus) {
    std::map<ADDRESS, uint32_t> uniqueIns {};

    fprintf(f, "digraph G {\n");
#ifdef __APPLE__
    fprintf(f, "    graph [dpi = 1];\n");
#else
    fprintf(f, "	size=\"10,10\";\n");
#endif
    fprintf(f, "    fontname = Helvetica;\n");
    fprintf(f, "    fontsize =14;\n");
    fprintf(f, "    center = TRUE;\n");
    fprintf(f, "    ratio = auto;\n");
    //  printf("    page = \"7.5,10;\"\n");

    // fprintf(f, "    E_N_T_R_Y [shape=box];\n");
    // fprintf(f, "    E_X_I_T [shape=box];\n");

    for (auto *bbl = bbl_list_hd; bbl != nullptr; bbl = bbl->next) {
        fprintf(f, R"(    B%d [shape=box, label="BBL %s \l)", bbl->id, bbl->mergedBBls.c_str());
        iListNode *itmp = bbl->ins_hd;
        if (instrHasFlag(itmp->iptr->ins, INSTR_IN_BASE_MODULE) || handle_rop) {
            if (printInstructions) {
                for (itmp = bbl->ins_hd; itmp != nullptr; itmp = itmp->next) {
                    if (itmp != bbl->ins_tl && IsControlFlowInstr(itmp->iptr->ins)) {
                        continue;
                    }
                    ADDRESS addr = itmp->iptr->ins->addr;
                    if (uniqueIns.find(addr) != uniqueIns.end()) {
                        uniqueIns.insert({addr, 0});
                    }
                    uniqueIns[addr]++;
                    const std::string ftnName = persistentStorage.functionNameForIdx(itmp->iptr->ins->funcName);
                    if (!ftnName.empty()) {
                        fprintf(f, " %s:", ftnName.c_str());
                    }
                    if (printTaint) {
                        std::string taint;
                        if (taintStatus.find(itmp->iptr->ins->addr) != taintStatus.end()) {
                            uint8_t t = taintStatus.find(itmp->iptr->ins->addr)->second;
                            if (taint::hasForwardTaint(t)) {
                                if (taint::hasNoForwardTaint(t)) {
                                    taint += "(FT)";
                                } else {
                                    taint += "FT";
                                }
                            }
                            if (taint::hasBackwardTaint(t)) {
                                if (taint::hasNoBackwardTaint(t)) {
                                    taint += "(BT)";
                                } else {
                                    taint += "BT";
                                }
                            }
                        }
                        if (instrHasFlag(itmp->iptr->ins, INSTR_UNTOUCHABLE)) {
                            taint += "U";
                        }
                        fprintf(f, " %s [0x%08" PRIx64 "]", taint.c_str(), addr);
                    }
                    fprintf(f, " %s \\l", UDCreate::getStringRepresentationOfInstruction(itmp->iptr->ins).c_str());
                    if (itmp == bbl->ins_tl) {
                        break;
                    }
                }
                fprintf(f, "\"");

            } else {
                fprintf(f, "%d\"", bbl->id);
            }
        } else {
            fprintf(f, R"( %s", color="%s", style="filled",fontsize=18)", persistentStorage.functionNameForIdx(bbl->ins_hd->iptr->ins->funcName).c_str(),
                    SYSTEM_CALL_COLOR);
        }

#if 0
        if (NODE_HAS_FLAG(bbl, BBL_FORWARD_TAINTED) && NODE_HAS_FLAG(bbl, BBL_IS_CONDITIONAL)) {
            fprintf(f, ", color=\"%s\", style=\"filled\"", FORWARD_TAINTED_CONDITIONAL);
        } else if (NODE_HAS_FLAG(bbl, BBL_FORWARD_TAINTED)) {
            fprintf(f, ", color=\"%s\", style=\"filled\"", BACKWARD_TAINT_COLOR);
        }

        if(NODE_HAS_FLAG(bbl, BBL_BACKWARD_TAINTED)){
           fprintf(f, ", color=\"%s\", style=\"filled\"", FORWARD_TAINT_COLOR);
       }
#endif

        fprintf(f, "];\n"); // close the box definition!

        for (auto *bl0 = bbl->succs; bl0 != nullptr; bl0 = bl0->next) {
#if 0
            if(instrHasFlag(bbl->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE) && !instrHasFlag(bl0->bptr->ins_hd->iptr->ins, INSTR_IN_BASE_MODULE)){
                fprintf(f, "    B%d -> B%d[style=dashed, color=red]\n", bbl->id, bl0->bptr->id);
            } else
#endif
            { fprintf(f, "    B%d -> B%d\n", bbl->id, bl0->bptr->id); }
        }
    }
    fprintf(f, "}\n");
    if (logger.isDebugEnabled()) {
        std::vector<std::pair<ADDRESS, uint32_t>> elms {};
        for (auto elm : uniqueIns) {
            elms.emplace_back(elm);
        }
        std::sort(elms.begin(), elms.end(), [](const auto &a, const auto &b) {
            if (a.second == b.second) {
                return a.first > b.first;
            }
            return a.second > b.second;
        });
        logger.debug(2, "CFG contains these instructions:");
        for (auto uniq : elms) {
            logger.debug(2, fmt::format("{:#x}: {}", uniq.first, uniq.second));
        }
    }
}

///////////////////////////////End Graph/////////////////

