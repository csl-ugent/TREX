/*
 *
 * File: al_helper.c
 * helper functions for data structure code.
 * Author: Kevin Coogan
 */

/*
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#include "al_helper.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>

#include <utils.h>

#include "lynx_types.h"

using deobf::library::utils::logger;

void *alloc(size_t size) {
    void *obj = malloc(size);

    if (obj == nullptr) {
        logger.log("ALLOC: Out of memory");
    }

    return obj;
}

void *zalloc(size_t size) {
    auto obj = static_cast<char *>(alloc(size));

    if (obj == nullptr) {
        logger.log("ZALLOC: Out of memory");
    }

    memset(obj, 0, size);

    return obj;
}

void dealloc(void *ptr) {
    free(ptr);
}

void *resize(void *address, size_t newSize) {
    void *obj = realloc(address, newSize);
    if (obj == nullptr) {
        logger.log("RESIZE: Out of memory");
    }

    return obj;
}

/*
 *  refCompare(o1,o2) -- sorting comparison for ints and pointers.
 *
 *  Subtracts value of o1 from o2.
 *  #%#% Does not work in case of overflow?
 */
int refCompare(void *o1, void *o2) {
    return (long int)o1 - (long int)o2;
}

/*
 *  strCompare(o1,o2) -- compare strings for sorting.
 */
int strCompare(void *o1, void *o2) {
    return strcmp((char *)(o1), (char *)(o2));
}

/*
 * insCompareByOrder(i1, i2) -- compare instructions by order # for sorting
 */
int insCompareByOrder(void *i1, void *i2) {
    Instruction *ins1, *ins2;

    ins1 = (Instruction *)i1;
    ins2 = (Instruction *)i2;

    if (ins1->order < ins2->order) {
        return -1;
    }

    if (ins1->order > ins2->order) {
        return 1;
    }

    return 0;
}

/*
 *  intPrint(item) -- print an integer.
 */
void intPrint(void *item) {
    logger.log(fmt::format("{}", *static_cast<int *>(item)));
}

/*
 *  refPrint(item) -- print memory addresses.
 */
void refPrint(void *item) {
    logger.log(fmt::format("{:#x", *static_cast<int *>(item)));
}

/*
 *  strPrint(key) -- print a string.
 */
void strPrint(void *key) {
    logger.log(fmt::format("\"{}\"", static_cast<char *>(key)));
}
