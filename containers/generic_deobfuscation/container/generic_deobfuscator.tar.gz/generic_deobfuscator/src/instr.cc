/*
 * File: instr.cc
 * functions related to instructions, their manipulation or their characteristics
 *
 * Author: Babak Yadegari, Kevin Coogan, Saumya Debray, Willem Van Iseghem
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */
#include "instr.h"

#include <algorithm>
#include <cinttypes>

#include <udis86_create.h>
#include <udis86_glue.h>
#include <flags.h>
#include <persistent_storage.h>
#include <directory_utils.h>

#include "al_helper.h"
#include "mem_maps.h"

using namespace deobf::library;
using namespace deobf::library::glue;
using namespace deobf::library::utils;

namespace ins_utils = deobf::library::instruction_utils;

using deobf::library::utils::Logger;
using deobf::library::utils::traceInfo;

extern bool TraceIsMultiThreaded;
extern ArrayList *traceThreads;
uint64_t instructionCount; // global instructionCount for sharing between threads
pthread_mutex_t file_lock = PTHREAD_MUTEX_INITIALIZER;

inline uint64_t cacheSize() {
    return pageSize() * 2;
}

bool InstrIsIndirectJump(Instruction *instr) {
    assert(instr);
    if ((instr->uInstr.mnemonic == UD_Ijmp && instr->uInstr.operand[0].type != UD_OP_JIMM) || instr->uInstr.mnemonic == UD_Iret) {
        return true;
    }
    return false;
}

void WriteInstrFileHeader(const std::shared_ptr<InstrList>& iList, FILE *file, bool mmap) {
    ins_utils::InstrFileHeader fileHeader;
    Thread *currThread;
    ThreadRange *currRange;
    int i, j;
    size_t headerSize = 0;

    if (file == nullptr) {
        return;
    }

    // Write thread information first
    if (USE_MMAP && mmap && TraceIsMultiThreaded) {
        fileHeader.RangeInfoOffset = static_cast<uint64_t>(ins_utils::InstrFileHeaderSize) + static_cast<uint64_t>(iList->numInstrs) * sizeof(Instruction);

        for (i = 0; i < al_size(traceThreads); i++) {
            currThread = static_cast<Thread *>(al_get(traceThreads, i));
            memcpy((void *)((uint8_t *)iList->iMMap + fileHeader.RangeInfoOffset + headerSize), currThread, sizeof(Thread));
            headerSize += sizeof(Thread);
            for (j = 0; j < al_size(currThread->ranges); j++) {
                currRange = static_cast<ThreadRange *>(al_get(currThread->ranges, j));
                memcpy((void *)((uint8_t *)iList->iMMap + fileHeader.RangeInfoOffset + headerSize), currRange, sizeof(ThreadRange));
                headerSize += sizeof(ThreadRange);
            }
        }
    } else if (TraceIsMultiThreaded) {
        fseeko(file, 0, SEEK_END);
        fileHeader.RangeInfoOffset = ftello(file);
        for (i = 0; i < al_size(traceThreads); i++) {
            currThread = static_cast<Thread *>(al_get(traceThreads, i));
            fwrite(currThread, sizeof(Thread), 1, file);
            headerSize += sizeof(Thread);
            for (j = 0; j < al_size(currThread->ranges); j++) {
                currRange = static_cast<ThreadRange *>(al_get(currThread->ranges, j));
                fwrite(currRange, sizeof(ThreadRange), 1, file);
                headerSize += sizeof(ThreadRange);
            }
        }
    }
    directoryUtils.getBaseName().copy(fileHeader.baseModuleName, 100);
    fileHeader.TraceIsMultiThreaded = TraceIsMultiThreaded;
    fileHeader.LastInstrInOriginalTrace = iList->last;
    fileHeader.NumInstrs = instructionCount; // set to global numInstr variable since iList might be shared between threads!
    fileHeader.Loop = iList->loop;
    fileHeader.NumThreads = (TraceIsMultiThreaded ? al_size(traceThreads) : 0);
    fileHeader.RangeInfoSize = headerSize;
    fileHeader.lastBaseModule = iList->lastBaseModuleInstr;
    fileHeader.stackBottom = iList->stackBottom;
    fileHeader.nextAvailAddr = iList->nextAvailableAddr;
    fileHeader.startMarker = iList->startMarker;
    fileHeader.endMarker = iList->endMarker;

    if (USE_MMAP && mmap) {
        // write to the beginning of the mmap itself
        void *fileHdrAddr = (void *)iList->iMMap;
        memcpy(fileHdrAddr, &fileHeader, sizeof(ins_utils::InstrFileHeader));
    } else {
        // write it to the beginning of the file
        fseeko(file, 0, SEEK_SET);
        fwrite(&fileHeader, sizeof(ins_utils::InstrFileHeader), 1, file);
        logger.log(fmt::format("{} bytes written to the InstrFile", headerSize));
    }
}

/**
 * Add an instruction to the given file pointer.
 *
 * @param f
 * @param instr
 */
void AddInstrToFile(FILE *f, Instruction *instr) {
    if (!fwrite(instr, sizeof(Instruction), 1, f)) {
        logger.log("Could not write instr to file");
        exit(0);
    }
}

/**
 * Compare two instructions byte to byte, return false if they're not equal.
 * @param ins1
 * @param ins2
 * @return
 */
bool InstrCompare(Instruction *ins1, Instruction *ins2) {
    if (ins1->uInstr.length != ins2->uInstr.length) {
        return false;
    }

    for (uint8_t i = 0; i < ins1->uInstr.length; i++) {
        if (ins1->uInstr.bytes[i] != ins2->uInstr.bytes[i]) {
            return false;
        }
    }
    return true;
}

Instruction *InstrCreate() {
    auto *ins = static_cast<Instruction *>(calloc(1, sizeof(Instruction)));
    ins->flags = 0;

    ins->regFlagsKnown &= ~FlagsDefKnown;
    ins->regFlagsKnown &= ~FlagsUsedKnown;
    ins->regFlagsKnown &= ~RegDefKnown;
    ins->regFlagsKnown &= ~MemRegUsedKnown;
    ins->regFlagsKnown &= ~NonMemRegUsedKnown;
    ins->regFlagsKnown &= ~MemDefKnown;
    ins->regFlagsKnown &= ~MemUsedKnown;

    return ins;
}

Instruction *InstrClone(Instruction *instr) {
    auto clone = static_cast<Instruction *>(alloc(sizeof(Instruction)));
    memcpy(clone, instr, sizeof(Instruction));
    return clone;
}

std::shared_ptr<InstrList> InitInstructionCache(const std::shared_ptr<InstrList>& iList) {
    iList->instrCache = static_cast<Instruction *>(malloc(cacheSize()));
    memset(iList->instrCache, 0, cacheSize());
    iList->firstInstr = NO_INSTR;
    iList->lastInstr = NO_INSTR;

    iList->newInstrCache = static_cast<Instruction *>(malloc(cacheSize()));
    memset(iList->newInstrCache, 0, cacheSize());
    iList->newFirstInstr = NO_INSTR;
    iList->newLastInstr = NO_INSTR;

    return iList;
}

/**
 * FillCacheFromFile fills a cache of instructions loaded from a file.
 * By design the cache is 2 pages worth of instructions, excluding partial ones.
 * @param iList
 * @param index
 * @return
 */
std::shared_ptr<InstrList> FillCacheFromFile(const std::shared_ptr<InstrList>& iList, uint64_t index) {
    // let's blank out the old cache first
    if (index <= iList->last) {
        memset(iList->instrCache, 0, cacheSize());
        // calculate what page we need, we will retrieve this page and page + 1
        uint64_t instrSz = sizeof(Instruction);
        uint64_t offset = instrSz * index;
        uint64_t instrPg = offset / utils::pageSize();

        // get addr of first page to retrieve
        uint64_t pgAddr = instrPg * utils::pageSize(); // start addr of page

        // and calculate first full instruction on that page
        iList->firstInstr = pgAddr / instrSz;
        if (pgAddr % instrSz != 0) {
            iList->firstInstr++;
        }

        // Get addr of page after last page to retrieve
        uint64_t endAddr = (instrPg + 2) * utils::pageSize();

        // and calculate last full instruction on previous page
        iList->lastInstr = endAddr / instrSz - 1;
        if (iList->lastInstr > iList->last)
            iList->lastInstr = iList->last;
        pthread_mutex_lock(&file_lock);
        // read first to last instructions into cache
        int status = fseeko(iList->iListFile, (iList->firstInstr * instrSz) + ins_utils::InstrFileHeaderSize, SEEK_SET);
        if (status != 0) {
            perror("FillCacheFromFile");
        }

        if (fread(iList->instrCache, instrSz, iList->lastInstr - iList->firstInstr + 1, iList->iListFile) == 0) {
            perror("Failed to read instructions from file");
        }
        pthread_mutex_unlock(&file_lock);
    } else {
        memset((iList->newInstrCache), 0, cacheSize());
        // calculate what page we need, we will retrieve this page and page + 1
        uint64_t instrSz = sizeof(Instruction);
        uint64_t offset = instrSz * index;
        uint64_t instrPg = offset / utils::pageSize();

        // get addr of first page to retrieve
        uint64_t pgAddr = instrPg * utils::pageSize(); // start addr of page

        // and calculate first full instruction on that page
        iList->newFirstInstr = pgAddr / instrSz;
        if (pgAddr % instrSz != 0) {
            iList->newFirstInstr++;
        }
        if (iList->newFirstInstr <= (uint32_t)iList->last)
            iList->newFirstInstr = iList->last + 1;
        // Get addr of page after last page to retrieve
        uint64_t endAddr = (instrPg + 2) * utils::pageSize();

        // and calculate last full instruction on previous page
        iList->newLastInstr = endAddr / instrSz - 1;

        if (iList->newLastInstr >= instructionCount)
            iList->newLastInstr = instructionCount - 1;

        pthread_mutex_lock(&file_lock);
        // read first to last instructions into cache
        fseeko(iList->iListFile, (iList->newFirstInstr * instrSz) + ins_utils::InstrFileHeaderSize, SEEK_SET);
        if (fread(iList->newInstrCache, instrSz, iList->newLastInstr - iList->newFirstInstr + 1, iList->iListFile) == 0) {
            perror("Failed to read instructions from file");
        }
        pthread_mutex_unlock(&file_lock);
    }
    return (iList);
}

size_t WriteInstrToFile(FILE *f, Instruction *instr) {
    assert(instr);
    uint64_t offset = instr->order * sizeof(Instruction) + ins_utils::InstrFileHeaderSize;

    pthread_mutex_lock(&file_lock);
    fseeko(f, offset, SEEK_SET);
    size_t written = fwrite(instr, sizeof(Instruction), 1, f);
    pthread_mutex_unlock(&file_lock);

    return written;
}

void MakeInstrAlive(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    Instruction *prev, *next;

    prev = GetInstruction(iList, instr->origPrev);
    next = GetInstruction(iList, instr->origNext);
    while (instrHasFlag(prev, INSTR_IS_DELETED)) {
        prev = GetInstruction(iList, prev->origPrev);
    }
    while (instrHasFlag(next, INSTR_IS_DELETED)) {
        next = GetInstruction(iList, next->origNext);
    }

    instrRemoveFlag(instr, INSTR_IS_DELETED);
    if (prev) {
        instr->prev = prev->order;
        prev->next = instr->order;
        SaveInstrChange(iList, prev);
    }
    if (next) {
        instr->next = next->order;
        next->prev = instr->order;
        SaveInstrChange(iList, next);
    }

    SaveInstrChange(iList, instr);
}

uint64_t countInstructionsBetween(const std::shared_ptr<InstrList>& iList, Instruction *from, Instruction *to) {
    uint64_t count = 0;
    Instruction *current = from;
    do {
        count++;
        current = GetInstruction(iList, current->origNext);
    } while (current && current != to);
    return count;
}

Instruction *AddInstruction(const std::shared_ptr<InstrList>& iList, Instruction *newInstr, int after) {

    Instruction *prev = GetInstruction(iList, after);
    Instruction *next = GetInstruction(iList, prev->next);

    // update number of instructions carefully
    pthread_mutex_lock(&file_lock);

    newInstr->order = instructionCount;

    if (next) {
        newInstr->next = newInstr->origNext = next->order;
        if (iList->last > after) {
            // in a case an instr after 'after' is removed.
            newInstr->origNext = after + 1;
        }
        next->prev = next->origPrev = newInstr->order;

        SaveInstrChange(iList, next);
    }
    newInstr->prev = newInstr->origPrev = prev->order;
    prev->next = prev->origNext = newInstr->order;

    Instruction *i = GetInstruction(iList, instructionCount - 1);
    i++;
    memcpy(static_cast<void *>(i), newInstr, sizeof(Instruction));
    instructionCount++; // increment number of instruction only after it's written to file!
    pthread_mutex_unlock(&file_lock);

    SaveInstrChange(iList, prev);
    return i;
}

Instruction *GetInstructionFromFile(std::shared_ptr<InstrList>& iList, uint64_t index) {
    Instruction *instr = nullptr;
    if (index < static_cast<uint64_t>(iList->firstInstr) || (index > static_cast<uint64_t>(iList->lastInstr) && index < iList->newFirstInstr) ||
        index > iList->newLastInstr) {
        // need to fill cache with appropriate pages

        iList = FillCacheFromFile(iList, index);
    }

    if (index >= static_cast<uint64_t>(iList->firstInstr) && index <= static_cast<uint64_t>(iList->lastInstr)) {
        instr = (static_cast<Instruction *>(iList->instrCache) + (index - iList->firstInstr));
    } else if (index >= iList->newFirstInstr && index <= iList->newLastInstr) {
        instr = (static_cast<Instruction *>(iList->newInstrCache) + (index - iList->newFirstInstr));
    } else {
        logger.log(fmt::format("index: {} NOT FOUND in cache or file", index));
    }
    return instr;
}

DEOBF_REGISTER_VALUE SetRegisterValue(Instruction *instr, ud_type reg, DEOBF_REGISTER_VALUE val) {
    switch (reg) {
    case UD_R_EAX:
    case UD_R_AX:
    case UD_R_AH:
    case UD_R_AL:
        instr->eax = val;
        break;
    case UD_R_ECX:
    case UD_R_CX:
    case UD_R_CL:
    case UD_R_CH:
        instr->ecx = val;
        break;
    case UD_R_EDX:
    case UD_R_DX:
    case UD_R_DL:
    case UD_R_DH:
        instr->edx = val;
        break;
    case UD_R_EBX:
    case UD_R_BX:
    case UD_R_BL:
    case UD_R_BH:
        instr->ebx = val;
        break;
    case UD_R_ESP:
    case UD_R_SP:
        instr->esp = val;
        break;
    case UD_R_EBP:
    case UD_R_BP:
        instr->ebp = val;
        break;
    case UD_R_ESI:
    case UD_R_SI:
        instr->esi = val;
        break;
    case UD_R_EDI:
    case UD_R_DI:
        instr->edi = val;
        break;
    case UD_R_RIP:
        instr->eip = val;
        break;
    case UD_NONE:
        break;
    default:
        logger.log(fmt::format("[{}]: Invalid or unhandled register:  {}", __func__, reg));
        break;
    }
    return val;
}

bool IsMxcsrInstr(Instruction *instr) {
    switch (instr->uInstr.mnemonic) {
    case UD_Istmxcsr:
    case UD_Ildmxcsr:
        return true;
    default:
        return false;
    }
}

bool IsStringCompare(Instruction *instr) {
    switch (instr->uInstr.mnemonic) {
    case UD_Iscasb:
    case UD_Iscasw:
    case UD_Iscasd:
    case UD_Iscasq:
        return true;
    default:
        return false;
    }
}

/*
 * RegUsedInclSP() returns the registers used by an instruction, including
 * esp (for push/pop instructions).
 */
DeobfRegisterUses usedRegistersForInstructionAndSP(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    DeobfRegisterUses used = usedRegistersForInstruction(iList, instr);
    if (isPush(instr) || isPop(instr)) {
        // FIXME: should include RSP?
        used.set(DeobfRegister::ESP);
        used.set(DeobfRegister::SP);
    }
    return used;
}

/*
 * RegDefInclSP() returns the registers defined by an instruction, including
 * esp (for push/pop instructions).
 */
DeobfRegisterUses definedRegistersForInstructionAndSP(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    auto def = definedRegistersForInstruction(iList, instr);
    auto used = usedRegistersForInstruction(iList, instr);
    if (isPush(instr) || isPop(instr)) {
        def |= used;
        def.set(DeobfRegister::ESP);
        // FIXME: should include RSP?
    }
    return def;
}

/*
 * This function should be called once when a new instrFile is being
 * created.  It makes a single pass to pre-calculate mem, reg, and flag uses
 * and defs so that these values need not be calculated over and over
 * for later use.
 *
 * Note that we do not include this calculation when reading in the std
 * trace file, because some mem def and use calculation depend on the
 * instr *after* the current instr (which would not have been read yet).
 */
void CalcKnownDefsAndUses(const std::shared_ptr<InstrList>& iList) {
    Instruction *prev = nullptr;
    Instruction *next;

    for (uint64_t i = 0; i < instructionCount; i++) {
        next = GetInstruction(iList, i);

        next->ControlDependentOn = -1; // not dependent yet!
        calculateFlagsAndRegistersForInstruction(iList, next);

        auto nws = memoryDefined(iList, next);
        if (nws->empty()) {
            next->regFlagsKnown |= MemDefKnown;
            next->memDefMin = 0;
            next->memDefSize = 0;
        } else {
            size_t rangeCount = nws->rangeCount();
            if (rangeCount == 1) {
                next->regFlagsKnown |= MemDefKnown;
                auto r = nws->getRange(0);
                next->memDefMin = r->min;
                next->memDefSize = r->max - r->min + 1;
            }
            if (next->memDefMin != 0) {
                instrSetFlag(next, INSTR_WRITES_MEM, __LINE__);
            }
        }

        nws = memoryUsed(iList, next);
        if (nws->empty()) {
            next->regFlagsKnown |= MemUsedKnown;
            next->memUsedMin = 0;
            next->memUsedSize = 0;
        } else {
            size_t rangeCount = nws->rangeCount();
            if (rangeCount == 1) {
                next->regFlagsKnown |= MemUsedKnown;
                auto r = nws->getRange(0);
                next->memUsedMin = r->min;
                next->memUsedSize = r->max - r->min + 1;
            }
            if (next->memUsedMin) {
                instrSetFlag(next, INSTR_READS_MEM, __LINE__);
            }
        }

        if (prev && IsCondJump(prev)) {
            ADDRESS target = prev->uInstr.operand[0].lval.sdword + prev->uInstr.length + prev->addr;
            if (target == next->addr) {
                instrSetFlag(prev, INSTR_CONDJUMP_TAKEN, __LINE__);
            }
        }

        SaveInstrChange(iList, next);
        prev = next;
    }
}

std::unique_ptr<deobf::library::writeset::WriteSet> memoryMask(uint64_t offset, DeobfRegister reg) {
    auto ws = std::make_unique<deobf::library::writeset::WriteSet>();
    if (isGPR(reg)) {
        uint64_t min, max;
        switch (getRegisterWidth(reg)) {
        case DeobfRegisterWidth::lower128bit:
            min = offset;
            max = offset + 15;
            break;
        case DeobfRegisterWidth::lower64bit:
            min = offset;
            max = offset + 7;
            break;
        case DeobfRegisterWidth::lower32bit:
            min = offset;
            max = offset + 3;
            break;
        case DeobfRegisterWidth::lower16bit:
            min = offset;
            max = offset + 1;
            break;
        case DeobfRegisterWidth::higher8bit:
            min = offset + 1;
            max = offset + 1;
            break;
        case DeobfRegisterWidth::lower8bit:
            min = offset;
            max = offset;
            break;
        }
        ws->addRange(std::make_unique<deobf::library::writeset::Range>(min, max));
    } else {
        logger.log(fmt::format("[{}] Warning {} is not a valid GPR!", __func__, reg));
    }
    return ws;
}

/*
 * OpcodeIsArithWithArithmetic(mnemonic) -- returns true if the mnemonic given
 * is one of a set of recognized arithmetic operations and if the second operand
 *  is 0, the result would be the same.
 */
bool OpcodeIsArithWithNoEffect(ud_mnemonic_code opcode) {
    switch (opcode) {
    case UD_Iadd:
    case UD_Ior:
    case UD_Ishl:
    case UD_Ishr:
    case UD_Isub:
    case UD_Isbb:
    case UD_Irol:
    case UD_Iror:
    case UD_Isar:
    case UD_Ircr:
    case UD_Ircl:
        return true;
    default:
        return false;
    }
}

#define ROT_LEFT 0x0
#define ROT_RIGHT !ROT_LEFT

int rotate(unsigned int in_value, int places, int direction, int size) {
    int outvalue;

    /*  Rotating left or right?   */
    if (direction == ROT_LEFT) {
        /*  First a normal shift  */
        outvalue = in_value << (places % (8 * size));
        outvalue |= in_value >> ((8 * size) - places % (8 * size));
    } else {
        /*  First a normal shift  */
        outvalue = in_value >> (places % (8 * size));
        /*  Then place the part that's shifted off the screen at the end  */
        outvalue |= in_value << ((8 * size) - places % (8 * size));
    }
    return outvalue;
}

/*
 * implements bswap instruction
 * bits 0 through 7 are swapped with bits 24 through 31,
 * and bits 8 through 15 are swapped with bits 16 through 23
 * Flags are not
 */
int bSwap(int val) {
    int byte0 = val & 0xff;
    int byte1 = val & 0xff00;
    int byte2 = val & 0xff0000;
    int byte3 = val & 0xff000000;
    return (byte0 << 24) | (byte1 << 8) | (byte2 >> 8) | (byte3 >> 24);
}

/*
 * ArithOp(op, val1, val2) -- return the result of performing the arithmetic
 * operation op on the values val1 and val2 (for binary op) or on val1
 * (for unary op).
 */
unsigned int ArithOp(ud_mnemonic_code op, unsigned int val1, int val2, int size, PSW_BITVECTOR *flags) {
    int tmp;
    int res = 0, i = 0;
    switch (op) {
    case UD_Iadd:
    case UD_Ixadd:
    case UD_Iadc: // TODO: we are treating adc like add! Should be fixed by considering the carry flag.
        return val1 + val2;

    case UD_Iand:
        return val1 & val2;

    case UD_Idec:
        return val1 - 1;

    case UD_Iinc:
        return val1 + 1;

    case UD_Inot:
        return ~val1;

    case UD_Ior:
        return val1 | val2;

    case UD_Ishl:
    case UD_Ishld: // TODO
        return val1 << val2;

    case UD_Ishr:
    case UD_Isar:
    case UD_Ishrd: // TODO: this is not really shr!
        return val1 >> val2;

    case UD_Isub:
    case UD_Isbb:
        return val1 - val2;

    case UD_Ixor:
        return val1 ^ val2;

    case UD_Ineg:
        return ~val1 + 1;

    case UD_Iimul:
    case UD_Imul:
        return val1 * val2;

    case UD_Iidiv:
    case UD_Idiv:
        if (val2)
            return val1 / val2;
        else
            return 0;

    case UD_Iror:
        return rotate(val1, val2, ROT_RIGHT, size);
    case UD_Irol:
        return rotate(val1, val2, ROT_LEFT, size);

    case UD_Ibswap:
        return bSwap(val1);

    case UD_Ircr:
        return rotate(val1, val2, ROT_RIGHT, size);
    case UD_Ircl:
        logger.log("[ArithOp] Warning: operation cannot be competed inside the function!");
        return rotate(val1, val2, ROT_LEFT, size); // TODO: implement rcr and rcl arithmetics1

    case UD_Ibt:
        *flags |= PSW_CF;
        break;

    case UD_Ibts:
        *flags |= PSW_CF;
        tmp = (1 << val2);
        return (val1 | tmp);
    case UD_Ibtr:
        *flags |= PSW_CF;
        tmp = ~(1 << val2);
        return (val1 & tmp);
    case UD_Ibtc:
        *flags |= PSW_CF;
        tmp = (1 << val2);
        if (val1 & tmp) {
            return (val1 & ~(1 << val2));
        } else {
            return (val1 | (1 << val2));
        }
    case UD_Icbw:
    case UD_Icwde:
        return SignExtend(val1);

    case UD_Iaaa:
        return val1;

    case UD_Ibsf:
        while (!(val2 & (1 << i++)))
            ;
        res = i - 1;
        break;

    case UD_Ibsr:
        i = size * 8;
        while (!(val2 & (1 << i--)))
            ;
        res = i - 1;
        break;

    default:
        logger.log(fmt::format("ERROR [ArithOp]: unrecognized operation {}", op));
        return -1;
    }
    return res;
}

/*
 * return [lg(v)]
 */
int floor_log2(PSW_BITVECTOR v) {
    for (uint8_t i = 0; i < 32; i++) {
        if ((v >> i) & 1) {
            return i;
        }
    }
    return -1;
}

int SignExtend(int value) {
    if (value & (1 << 15))
        return (value | 0xffff0000);
    else if (value & (1 << 7))
        return (value | 0xffffff00);
    return value;
}

bool isPotentialStartMarker(Instruction *ins) {
    return ins->uInstr.mnemonic == UD_Ior
           && ins->uInstr.operand[0].type == UD_OP_REG && ins->uInstr.operand[1].type == UD_OP_REG
           && ins->uInstr.operand[0].base == UD_R_EAX && ins->uInstr.operand[1].base == UD_R_EAX;
}

bool isPotentialEndMarker(Instruction *ins) {
    return ins->uInstr.mnemonic == UD_Ior
           && ins->uInstr.operand[0].type == UD_OP_REG && ins->uInstr.operand[1].type == UD_OP_REG
           && ins->uInstr.operand[0].base == UD_R_EBX && ins->uInstr.operand[1].base == UD_R_EBX;
}

/*
 * map memory used in the program to a
 * global (duplicate) memory for using
 * in liveliness and simplification process.
 */
void ConstantMemoryMap(const std::shared_ptr<InstrList>& iList) {
    BytetoByteMap *PageDir = nullptr;

    Instruction *instr = nullptr;
    std::unique_ptr<deobf::library::writeset::WriteSet> memUsed, memDef;
    bool startMarker = false, endMarker = false;

    auto globalMem = std::make_unique<deobf::library::writeset::WriteSet>();

    iList->currentInstr = iList->firstInstr;
    while ((instr = FetchNextInstr(iList)) != nullptr) {
        if (instr->uInstr.mnemonic == UD_Imovsd && isMoveDataFromStringToString(instr)) {
            // Imovsd can both be Move Data from String to String or Move or Merge Scalar Double-Precision Floating-Point Value
            Instruction *tmp = GetInstruction(iList, instr->next);
            while (tmp && tmp->addr == instr->addr) {
                instrSetFlag(tmp, INSTR_IS_DELETED, __LINE__);
                SaveInstrChange(iList, tmp);
                tmp = GetInstruction(iList, tmp->next);
            }
        }

#if MAIN_MARKER
        if (!startMarker && isPotentialStartMarker(instr)) {
            Instruction *second = GetInstruction(iList, instr->next);
            if (isPotentialStartMarker(second)) {
                Instruction *third = GetInstruction(iList, second->next);
                if (isPotentialStartMarker(third)) {
                    startMarker = true;
                    instrSetFlag(third, INSTR_UNSIMPLIFIABLE, __LINE__);
                    instrSetFlag(third, INSTR_UNTOUCHABLE, __LINE__);
                    SaveInstrChange(iList, third);
                    iList->startMarker = instr->order;
                }
            }
        }

        if (!endMarker && isPotentialEndMarker(instr)) {
            Instruction *second = GetInstruction(iList, instr->next);
            if (isPotentialEndMarker(second)) {
                Instruction *third = GetInstruction(iList, second->next);
                if (isPotentialEndMarker(third)) {
                    endMarker = true;
                    iList->endMarker = instr->order;
                    instrSetFlag(instr, INSTR_UNSIMPLIFIABLE, __LINE__);
                    instrSetFlag(third, INSTR_UNTOUCHABLE, __LINE__);
                    SaveInstrChange(iList, instr);
                }
            }
        }
        if (iList->endMarker == 0) {
            iList->endMarker = iList->numInstrs;
        }
#endif

        if (instruction_utils::isXorOfSameReg(instr)) {
            ud_t *udins_new = UDCreate::movImmToReg(instr->uInstr.operand[0].base, 0, instr, __LINE__);
            carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, true, __LINE__);
            glue::freeUDStructure(udins_new, true);
            SaveInstrChange(iList, instr);
        }

        if (!instrHasFlag(instr, INSTR_WRITES_MEM) && !instrHasFlag(instr, INSTR_READS_MEM)) {
            continue;
        }
        memUsed = memoryUsed(iList, instr);
        memDef = memoryDefined(iList, instr);

        if (instrHasFlag(instr, INSTR_READS_MEM)) {
            if (!memUsed->isSubsetOf(globalMem)) {
                globalMem->merge(memUsed);
            }
        }
        if (instrHasFlag(instr, INSTR_WRITES_MEM)) {
            if (!memDef->isSubsetOf(globalMem)) {
                globalMem->merge(memDef);
            }
        }
#if CHECKSUM_DETECT
        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            globalMem->addRange(instr->addr, instr->addr + instr->uInstr.length);
        }
#endif
    }

    globalMem->sort();
    globalMem->mergePageRange(utils::pageSize());
    globalMem->breakPageRange(utils::pageSize());

    uint64_t totalPageDirEntries = globalMem->rangeCount();
    iList->constantNumPageEntries = totalPageDirEntries / B2B_MAP_PAGESIZE + 1;
    size_t pageDirSize = iList->constantNumPageEntries * sizeof(BytetoByteMap);
    PageDir = static_cast<BytetoByteMap *>(malloc(pageDirSize));
    bzero(PageDir, pageDirSize);
    uint64_t constSize = utils::pageSize();
    /*
     * multiplication by sizeof(uint64_t) is for dependency analysis which we need 64 bit (instruction's order number)
     * for each entry (does not matter how big is the instruction's read or write memory)
     */
    uint64_t pageSize = constSize * sizeof(uint64_t);
    for (uint64_t pageDirIdx = 0; pageDirIdx < iList->constantNumPageEntries; pageDirIdx++) {
        PageDir[pageDirIdx].Constants = static_cast<unsigned char *>(malloc(constSize));
        for (uint8_t pageIdx = 0; pageIdx < B2B_MAP_PAGESIZE && pageDirIdx * B2B_MAP_PAGESIZE + pageIdx < totalPageDirEntries; pageIdx++) {
            auto r = globalMem->getRange(pageDirIdx * B2B_MAP_PAGESIZE + pageIdx);
            PageDir[pageDirIdx].startAddrs[pageIdx] = r->min;
            PageDir[pageDirIdx].pages[pageIdx] = static_cast<unsigned char *>(malloc(pageSize));
            memset(PageDir[pageDirIdx].pages[pageIdx], 0, pageSize);
        }
    }

    iList->constantPageDir = PageDir;
}

void FreeConstantMemoryMap(const std::shared_ptr<InstrList>& iList) {
    for (uint64_t r = 0; r < iList->constantNumPageEntries; r++) {
        free(iList->constantPageDir[r].Constants);

        for (auto &page : iList->constantPageDir[r].pages) {
            free(page);
        }
    }
}
