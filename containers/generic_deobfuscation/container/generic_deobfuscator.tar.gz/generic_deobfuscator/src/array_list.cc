/*
 *
 * File: ./src/array_list.c
 * A fully functional, sortable ArrayList with set operations.
 * Also supports iteration.
 * Author: Kevin Coogan, Saumya Debray
 */

/*
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#include "array_list.h"

#include <cassert>
#include <cstdio>
#include <cstring>

#include "al_helper.h"

#define AL_LOCK()
#define AL_UNLOCK()

/* STATIC HELPER FUNCTIONS */

/*
 *  al_itrHasNext(itr) --
 */
static int al_itrHasNext(Iterator *itr) {
    ArrayList *list;
    int index;

    assert(itr);

    list = (ArrayList *)itr->it_dataStructure;
    assert(list);

    index = (long int)itr->it_opaque1;
    return index < list->al_size;
}

/*
 *  al_itrNext(itr) --
 */
static void *al_itrNext(Iterator *itr) {
    ArrayList *list;

    assert(itr);

    list = (ArrayList *)itr->it_dataStructure;
    assert(list);

    itr->it_opaque1 = (void *)((long int)itr->it_opaque1 + 1);
    return itr->it_current = al_get(list, (long int)itr->it_opaque1 - 1);
}

/*
 *  al_itrRemove(itr) --
 */
static void *al_itrRemove(Iterator *itr) {
    ArrayList *list;
    long int index;
    void *result;

    assert(itr);

    list = (ArrayList *)itr->it_dataStructure;
    assert(list);
    index = (long int)itr->it_opaque1 - 1;

    result = al_get(list, index);

    al_removeAt(list, index);        // remove node
    itr->it_opaque1 = (void *)index; // correct index in iterator

    return result;
}

/* CONSTRUCTORS / DESTRUCTORS */

/*
 *  al_new(void) --
 *
 *  Initializes a new empty unsorted linked list of addresses.
 */
ArrayList *al_new() {
    return al_newPtr(AL_LIST_UNSORTED);
}

/*
 *  al_newPtr(type) -- initializes a new empty linked list of addresses.
 */
ArrayList *al_newPtr(ATYPE type) {
    return al_newGeneric(type, refCompare, refPrint, dealloc);
}

/*
 *  al_newGeneric(type,compareFunc)printFunc)freeFunc) --
 *
 *  Initializes a new empty linked list of given type and
 *  with the given function to pairwise compare/sort its elements.
 *
 *  The function is expected to return:
 *  -1 if the first argument is 'less than' the second argument,
 *  0 if they are equal,
 *  1 if the first argument is 'greater than' the second argument.
 */
ArrayList *al_newGeneric(ATYPE type, int (*compareFunc)(void *, void *), void (*printFunc)(void *), void (*freeFunc)(void *)) {

    auto *list = static_cast<ArrayList *>(alloc(sizeof(ArrayList)));
    list->al_size = 0;
    list->al_capacity = 10;
    list->al_elements = static_cast<void **>(zalloc(list->al_capacity * sizeof(void *)));
    list->al_type = type;
    list->al_lock = 1;
    list->al_compare = compareFunc ? compareFunc : refCompare;
    list->al_print = printFunc ? printFunc : refPrint;
    list->al_free = freeFunc ? freeFunc : nullptr;

    return list;
}

/*
 *  al_free(list) --
 *
 *  Frees the given list (doesn't free the elements themselves).
 */
void al_free(ArrayList *list) {
    AL_LOCK();
    dealloc(list->al_elements);
    dealloc(list);
    AL_UNLOCK();
}

/*
 *  al_freeWithElements(list) --
 *
 *  Frees the given list, and calls its free function to free every element
 *  contained inside it.
 */
void al_freeWithElements(ArrayList *list) {
    al_clearAndFreeElements(list);
    al_free(list);
}

/*
 *  al_add(list,val) -- add an element to the end of the list.
 */
void *al_add(ArrayList *list, void *val) {
    assert(list);
    return (list->al_type == AL_LIST_SORTED) ? al_insertSorted(list, val) : al_insertAt(list, val, list->al_size);
}

/*
 *  al_clear(list) -- remove all elements from the given list.
 */
void al_clear(ArrayList *list) {
    AL_LOCK();
    assert(list);
    memset(list->al_elements, 0, list->al_size * sizeof(void *));
    list->al_size = 0;
    AL_UNLOCK();
}

/*
 *  al_clearAndFreeElements(list) --
 *
 *  Calls given list's free function to free every element
 *  contained inside it.  Also clears list to have 0 elements.
 */
void al_clearAndFreeElements(ArrayList *list) {
    int ii;

    if (!list) {
        assert(list);
    }

    // free each node
    AL_LOCK();
    for (ii = 0; ii < list->al_size; ii++) {
        if (list->al_free) {
            list->al_free(list->al_elements[ii]);
        }
    }
    AL_UNLOCK();

    al_clear(list);
}

/*
 *  al_contains(list,val) --
 *
 *  Returns whether the list contains the given value.
 *  Compares by the list's given comparison function.
 */
int al_contains(ArrayList *list, void *val) {
    assert(list);
    return al_indexOf(list, val) >= 0;
}

/*
 *  al_get(list,index) --
 *
 *  Return the element at index index
 *  Must check that index < numElements head
 */
void *al_get(ArrayList *list, int index) {
    if (!(list && 0 <= index && (index < list->al_size))) {
        assert(0);
    }
    // assert((list && 0 <= index && (index < list->al_size)));
    return list->al_elements[index];
}

/*
 *  al_indexOf(list,val) --
 *
 *  Lookup val in list using list's compare function for equality test
 *  Return index if present, otherwise -1
 */
int al_indexOf(ArrayList *list, void *val) {
    int ii, size;
    assert(list);

    // check for invalid arguments
    if (!list) {
        return -1;
    }

    // iterate through list to find val, if present
    size = al_size(list);
    for (ii = 0; ii < size; ii++) {
        if (!list->al_compare(al_get(list, ii), val)) {
            return ii;
        }
    }

    return -1;
}

/*
 *  al_insertAt(list,val,index) -- add an element at the given list index.
 */
void *al_insertAt(ArrayList *list, void *val, int index) {
    int ii;

    assert(list && (0 <= index) && (index <= list->al_size));

    // check for invalid parameters
    // (includes duplicate check if list is a set)
    if (!(0 <= index && index <= al_size(list)) || (list->al_type == AL_LIST_SET && al_contains(list, val)))
        return val;

    AL_LOCK();

    // may have to reallocate elements to make room
    if (list->al_size >= list->al_capacity) {
        list->al_capacity *= 2;
        list->al_elements = static_cast<void **>(resize(list->al_elements, list->al_capacity * sizeof(void *)));
    }
    // slide elements right by one to make room for new value
    for (ii = list->al_size; ii > index; ii--) {
        list->al_elements[ii] = list->al_elements[ii - 1];
    }

    // insert new value
    list->al_elements[index] = val;
    list->al_size++;

    AL_UNLOCK();
    return val;
}

/*
 *  al_insertSorted(list,val) -- add an element at the given index of the list.
 */
void *al_insertSorted(ArrayList *list, void *val) {
    int ii, size;

    assert(list);

    // duplicate check if list is a set
    if (list->al_type == AL_LIST_SET && al_contains(list, val)) {
        return val;
    }

    AL_LOCK();

    // iterate through to find place to insert this new link
    // (insert it after all nodes that are <= it
    size = al_size(list);
    for (ii = 0; ii < size && list->al_compare(al_get(list, ii), val) <= 0; ii++) {
    }

    AL_UNLOCK();

    // put the new node here
    al_insertAt(list, val, ii);
    return val;
}

/*
 *  al_iterator(list) --
 */
Iterator *al_iterator(ArrayList *list) {
    Iterator *itr;
    assert(list);

    itr = static_cast<Iterator *>(alloc(sizeof(Iterator)));
    itr->it_dataStructure = list;
    itr->it_next = al_itrNext;
    itr->it_hasNext = al_itrHasNext;
    itr->it_remove = al_itrRemove;
    itr->it_current = nullptr;
    itr->it_opaque1 = nullptr;
    itr->it_opaque2 = nullptr;

    return itr;
}

/*
 *  al_removeAt(list,index) --
 *
 *
 *  Remove an element at the specified index
 *  Must check that index < numElements head
 */
void *al_removeAt(ArrayList *list, int index) {
    int ii, size;
    void *result;

    size = al_size(list);
    assert(list && 0 <= index && index < size);

    // set return val
    result = list->al_elements[index];

    // slide remaining elements left by one
    AL_LOCK();
    for (ii = index; ii < size - 1; ii++) {
        list->al_elements[ii] = list->al_elements[ii + 1];
    }
    list->al_elements[size - 1] = nullptr;
    list->al_size--;
    AL_UNLOCK();
    return result;
}

/*
 *  al_removeLast(list) -- removes and returns last element of list.
 */
void *al_removeLast(ArrayList *list) {
    return al_removeAt(list, al_size(list) - 1);
}

/*
 *  al_size(list) -- returns the number of elements in the list.
 */
int al_size(ArrayList *list) {
    if (list == nullptr) {
        assert(list);
    }
    return list->al_size;
}

/*
 *  al_sort(list) --
 *
 *
 *  Sorts the linked list using its compare function for equality test.
 *  Uses a crappy selection sort because I do not wish to implement
 *  anything tougher!
 */
void al_sort(ArrayList *list) {
    int ii, jj, size, smallestIndex;
    void *el_ii;
    void *el_jj;
    void *el_smallest;

    assert(list && list->al_compare);

    AL_LOCK();
    size = al_size(list);
    for (ii = 0; ii < size; ii++) {
        // find smallest element
        el_ii = al_get(list, ii);
        el_smallest = el_ii;
        smallestIndex = ii;

        for (jj = ii + 1; jj < size; jj++) {
            el_jj = al_get(list, jj);

            if (list->al_compare(el_jj, el_smallest) < 0) {
                el_smallest = el_jj;
                smallestIndex = jj;
            }
        }

        // swap
        if (smallestIndex != ii) {
            list->al_elements[ii] = el_smallest;
            list->al_elements[smallestIndex] = el_ii;
        }
    }

    AL_UNLOCK();
}
