/*
 * File: read.cc
 * Author: Babak Yadegari, Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */
#include "read.h"

#include <fcntl.h>
#include <sys/mman.h>
#include <types.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cinttypes>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <stack>
#include <iterator>

extern "C" {
#include "udis86/udis86.h"
}


#include <udis86_create.h>
#include <flags.h>
#include <persistent_storage.h>
#include <directory_utils.h>

#include "al_helper.h"
#include "array_list.h"
#include "instr.h"
#include "trace_mapping.h"

using namespace deobf::library::glue;

using deobf::library::utils::traceInfo;

namespace ins_utils = deobf::library::instruction_utils;

bool TraceIsMultiThreaded;
ArrayList *traceThreads;

/*
 * error codes indicating where something went wrong
 * while reading an input trace
 */
enum class ErrorCodes { ERR_AT_ADDR = 0, ERR_AT_FNAME, ERR_AT_INSTRBYTES, ERR_AT_MNEMONIC, ERR_AT_REGVALS };

extern bool InstrFileExists;

bool ignoreModule(const std::string &name) {
    // list of modules/DLLs whose instructions should NOT be included in the code output by lynx.
    std::vector<std::string> ignore_module_names{"kernel32", "ntdll",   "MSVCP80", "MSVCP90", "MSVCR80", "MSVCR90", "msvcrt", "ADVAPI32", "RPCRT4", "comctl32",
                                                 "SHELL32",  "SHLWAPI", "USER32",  "GDI32",   "MPR",     "WS2HELP", "WS2_32", "",         "dll"};
    return std::any_of(ignore_module_names.cbegin(), ignore_module_names.cend(), [name](const std::string &ignore) { return ignore == name; });
}

unsigned int lineno = 0;

bool found_first_base_instr = false;

/*
 * errGetInstrFromText() -- give error messages for GetInstrFromText()
 */
void errGetInstrFromText(ErrorCodes err_code, Instruction *instr) {
    std::stringstream line {};
    line << "ERROR [line " << lineno << "]: malformed trace ";

    switch (err_code) {
    case ErrorCodes::ERR_AT_ADDR:
        line << "[at address]";
        break;
    case ErrorCodes::ERR_AT_FNAME:
        line << "[at function name]";
        break;
    case ErrorCodes::ERR_AT_INSTRBYTES:
        line << "[at instr bytes]";
        break;
    case ErrorCodes::ERR_AT_MNEMONIC:
        line << "[at instruction mnemonic]";
        break;
    case ErrorCodes::ERR_AT_REGVALS:
        line << "[at register values]";
        break;
    default:
        line << " [unrecognized error code " << static_cast<int>(err_code) << "]";
        break;
    }
    logger.log(line.str());
    logger.increaseIndent();

    if (err_code >= ErrorCodes::ERR_AT_ADDR) {
        line << "[DUMP] module: " << persistentStorage.moduleNameForIdx(instr->module);
    }

    if (err_code >= ErrorCodes::ERR_AT_FNAME) {
        line << "[DUMP] addr: " << fmt::format("{:#x}", instr->addr);
    }

    if (err_code >= ErrorCodes::ERR_AT_INSTRBYTES) {
        line << "[DUMP] function name: " << persistentStorage.functionNameForIdx(instr->funcName);
    }

    if (err_code >= ErrorCodes::ERR_AT_MNEMONIC) {
        line << "[DUMP] instr bytes: ";
        for (uint8_t i = 0; i < instr->uInstr.length; i++) {
            line << std::hex << static_cast<int>(instr->uInstr.bytes[i]);
        }
    }

    if (err_code >= ErrorCodes::ERR_AT_REGVALS) {
        line << "[DUMP] mnemonic: " << instr;
    }
    line.flush();
    logger.decreaseIndent();
    abort();
}

int ignores = 0;
char moduleName[100];

/* GetInstrFromText
 *  Parse instruction struct from line of text
 */
Instruction *GetInstrFromText(char *s, const std::shared_ptr<TraceMapping>& traceMapping) {
    char *tok, *tokSave, *p;

    lineno++;

    // a '#' appearing as the first character of a line indicates a comment.
    if (*s == '#') {
        if (lineno == 1) {
            // Parse META line if present
            int arch = -1;
            char platformName[10];
            if (sscanf(s, "# META: ARCH: %d PLATFORM: %s NAME: %s", &arch, platformName, moduleName) > 0) {
                logger.log("META data identified:");
                logger.increaseIndent();
                logger.log(fmt::format("arch: {} bit", arch));
                logger.log(fmt::format("platform: {}", platformName));
                logger.log(fmt::format("name: {}", moduleName));
                logger.decreaseIndent();
                traceInfo.setTraceWidthBits(arch);
                traceInfo.setPlatform(strToPlatform(platformName));
                traceInfo.setMeta(true);
                traceMapping->initializeRegisterValues();
            }
        }

        return nullptr;
    }

    // create instr object, and initialize its udis object
    auto ins = InstrCreate();

    // get first token, depending on version, may be module name, or may be pid
    tok = strtok_r(s, "\t", &tokSave);

    if (tok == nullptr) {
        logger.log(fmt::format("ERROR [line {}]: malformed trace [at entry]", lineno));
        abort();
    }

    // check for pid and tid.  if there, first tok will be number other than 0
    if (strtol(tok, nullptr, 10) != 0) {
        // we are ignoring pid completely for now
        tok = strtok_r(nullptr, "\t", &tokSave);

        // check for multi-threaded program, in future may want to do more w/tid
        int currTID = std::stoi(tok, nullptr, 10);
        ins->tid = currTID;

        tok = strtok_r(nullptr, "\t", &tokSave);
    }

    // parse module name
    // eliminate extraneous whitespace

    for (p = tok; p && *p != '\0'; p++) {
        if (isspace(*p)) {
            *p = '\0';
        }
    }

    /*
     * If the module is one that we don't care about (e.g., kernel32, ntdll),
     * we want to just ignore the instruction and bail out.  But we can't
     * ignore _all_ such instructions, since we determine the identity of DLL
     * calls by looking at the callee instruction's function name; a similar
     * issue arises with exceptions as well.  To deal with this, we keep track
     * of whether the previous instruction was ignored, and ignore an
     * instruction only if it is from an "ignored" module AND the previous
     * instruction was ignored.
     *
     * At some point in the future we might want to have a command-line
     * switch to control this behavior.
     */
    if (ignoreModule(tok)) {
        if (found_first_base_instr) {
            instrSetFlag(ins, INSTR_IGNORED, __LINE__);
        } else { /* ignore */
            ignores++;
            free(ins);
            return nullptr;
        }
    }

    // one-way door, to initialize when we've started including instructions
    // we need this to ignore the large group of instructions at front of file
    if (!found_first_base_instr) {
        found_first_base_instr = true;
    }

    uint16_t index;

    char moduleNameExe[104];
    sprintf(moduleNameExe, "%s.exe", moduleName);

    if (strcmp(tok, moduleName) == 0 || strcmp(tok, "unknown") == 0 || strcmp(tok, moduleNameExe) == 0) {
        ins->module = 0;
    } else {
        if ((index = persistentStorage.moduleNameIdx(tok)) != 0) {
            ins->module = index;
        } else {
            ins->module = persistentStorage.appendModuleName(tok);
        }
    }

    // parse address
    tok = strtok_r(nullptr, "\t", &tokSave);

    if (tok == nullptr) {
        errGetInstrFromText(ErrorCodes::ERR_AT_ADDR, ins);
    }
    ins->addr = std::strtoul(tok, nullptr, 16);

    // parse function name
    tok = strtok_r(nullptr, "\t", &tokSave);

    if (tok == nullptr) {
        errGetInstrFromText(ErrorCodes::ERR_AT_FNAME, ins);
    }

    // eliminate extraneous whitespace
    for (p = tok; p && *p != '\0'; p++) {
        if (isspace(*p)) {
            *p = '\0';
        }
    }

    if (strcmp(tok, "") == 0) {
        ins->funcName = 0;
    } else {
        if ((index = persistentStorage.functionNameIdx(tok)) != 0) {
            ins->funcName = index;
        } else {
            ins->funcName = persistentStorage.appendFunctionName(tok);
        }
    }

    // parse instruction bytes
    int byte = 1;
    char *tok2 = nullptr;
    tok = strtok_r(nullptr, "\t", &tokSave);
    if (tok == nullptr) {
        errGetInstrFromText(ErrorCodes::ERR_AT_INSTRBYTES, ins);
    }

    tok2 = strtok(tok, " ");
    if (tok2 != nullptr) {
        ins->uInstr.bytes[0] = strtol(tok2, nullptr, 16);
        while ((tok2 = strtok(nullptr, " ")) != nullptr) {
            ins->uInstr.bytes[byte] = strtol(tok2, nullptr, 16);
            byte++;
        }
        ins->uInstr.length = byte;
    }

    // parse instruction mnemonic
    tok = strtok_r(nullptr, "\t", &tokSave);

    if (tok == nullptr) {
        errGetInstrFromText(ErrorCodes::ERR_AT_MNEMONIC, ins);
    }

    // parse values for each register
    tok = strtok_r(nullptr, "\t", &tokSave);

    if (tok == nullptr) {
        errGetInstrFromText(ErrorCodes::ERR_AT_REGVALS, ins);
    }

    if (traceInfo.isMeta()) {
        std::istringstream tokSS(tok);
        std::vector<std::string> changedRegs{std::istream_iterator<std::string>{tokSS}, std::istream_iterator<std::string>{}};

        uint8_t lastFound = 0;
        for (auto changedReg : changedRegs) {
            if (changedReg.rfind("EIP=", 0) == 0) {
                changedReg.erase(0, 4);
                ins->eip = std::strtoul(changedReg.c_str(), nullptr, 16);
                continue;
            }
            traceMapping->parseSparseRegisters(changedReg, &lastFound);
        }

        traceMapping->setRegistersInInstruction(ins);
    } else {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat"
        int read_regs = sscanf(tok, "EAX=%lx, ECX=%lx, EDX=%lx, EBX=%lx, ESP=%lx, EBP=%lx, ESI=%lx, EDI=%lx", &(ins->eax), &(ins->ecx), &(ins->edx),
                               &(ins->ebx), &(ins->esp), &(ins->ebp), &(ins->esi), &(ins->edi));
#pragma GCC diagnostic pop
        uint8_t expected_nr = 8;
        if (read_regs != expected_nr) { // not all the register values were read
            logger.log(fmt::format("Read out {} register values, expected {}!", read_regs, expected_nr));
            errGetInstrFromText(ErrorCodes::ERR_AT_REGVALS, ins);
        }
    }

    // parse values for memory read/writes
    tok = strtok_r(nullptr, "\t", &tokSave);
    if (tok != nullptr) {
        int memRead = sscanf(tok, "MR:%" PRIx64 ":%" PRIx64, &(ins->memUsedMin), &(ins->memUsedVal));
        if (memRead == 0) {
            sscanf(tok, "MW:%" PRIx64 ":%" PRIx64, &(ins->memDefMin), &(ins->memDefVal));
        }
    }
    tok = strtok_r(nullptr, "\t", &tokSave);
    if (tok != nullptr) {
        sscanf(tok, "MW:%" PRIx64 ":%" PRIx64, &(ins->memDefMin), &(ins->memDefVal));
    }

    if (ins->module == 0) {
        instrSetFlag(ins, INSTR_IN_BASE_MODULE, __LINE__);
        ud_t *ud_ins = deobf::library::UDCreate::createDisassembledUD(ins->uInstr.bytes, MAX_X86_INSTR_LEN, ins->addr);
        populateInsStructureFromUDisObject(&(ins->uInstr), ud_ins, traceInfo.getTraceWidth());
        free(ud_ins);
    } else {
        ud_t *ud_ins = deobf::library::UDCreate::createDisassembledUD(ins->uInstr.bytes, MAX_X86_INSTR_LEN, ins->addr);
        populateInsStructureFromUDisObject(&(ins->uInstr), ud_ins, traceInfo.getTraceWidth());
        free(ud_ins);
    }
    return (ins);
}

uint64_t LargestThreadNumInstructions = 0;
int LargestThreadTID = 0;
void MarkThreadBoundaries(const std::shared_ptr<InstrList>& i_list) {
    ArrayList *threads = traceThreads;
    uint64_t totalInstrs = 0;

    for (int j = 0; j < al_size(threads); j++) {
        auto *th = static_cast<Thread *>(al_get(threads, j));
        uint64_t threadTotal = 0;
        int k;
        for (k = 0; k < al_size(th->ranges); k++) {
            auto *threadRange = static_cast<ThreadRange *>(al_get(th->ranges, k));
            threadTotal += threadRange->last - threadRange->first + 1;
        }
        th->numRanges = al_size(th->ranges);
        totalInstrs += th->numInstrs;
        if (LargestThreadNumInstructions < th->numBaseModuleInstrs) {
            LargestThreadNumInstructions = th->numBaseModuleInstrs;
            LargestThreadTID = th->tid;
        }
        if (threadTotal != th->numInstrs) {
            logger.log(fmt::format("Error in number of instructions: {}, {}", threadTotal, th->numInstrs));
        }

        for (k = 0; k < al_size(th->ranges) - 1; k++) {
            auto *thrange1 = static_cast<ThreadRange *>(al_get(th->ranges, k));
            auto *thrange2 = static_cast<ThreadRange *>(al_get(th->ranges, k + 1));
            Instruction *iins = GetInstruction(i_list, thrange1->last);
            Instruction *iins2 = GetInstruction(i_list, thrange2->first);
            iins->next = iins->origNext = thrange2->first;
            SaveInstrChange(i_list, iins);
            if (iins->addr ==
                iins2->addr) { // ether's bug, in base module's thread switch, last instruction is being replicated with the effect of executing it once!
                thrange1->last = iins->prev;
                instrSetFlag(iins, INSTR_IS_DELETED, __LINE__);
                SaveInstrChange(i_list, iins);
                iins = GetInstruction(i_list, thrange1->last);
            }
            iins->next = iins->origNext = thrange2->first;
            SaveInstrChange(i_list, iins);

            iins2 = GetInstruction(i_list, thrange2->first);
            if (iins->tid != iins2->tid) {
                logger.log("Error");
            }
            iins2->prev = iins2->origPrev = thrange1->last;
            SaveInstrChange(i_list, iins2);
            if (k == 0) {
                iins = GetInstruction(i_list, thrange1->first);
                iins->prev = iins->origPrev = -1;
                SaveInstrChange(i_list, iins);
            }
            if (k == al_size(th->ranges) - 2) {
                iins = GetInstruction(i_list, thrange2->last);
                iins->next = iins->origNext = -1;
                SaveInstrChange(i_list, iins);
            }
        }
    }
    if (totalInstrs != instructionCount) {
        logger.log(fmt::format("Error in number of Instrs: {}, {}", totalInstrs, instructionCount));
    }
}

void reserveMMapSpace(const std::shared_ptr<InstrList>& i_list, uint64_t allocationCount) {
    auto *temp = static_cast<Instruction *>(calloc(sizeof(Instruction), allocationCount));
    fseeko(i_list->iListFile, 0, SEEK_END);
    if (fwrite(temp, sizeof(Instruction), allocationCount, i_list->iListFile) != allocationCount) {
        logger.log("ERROR: padding file for mmap");
    }
    free(temp);
}

std::shared_ptr<InstrList> BuildIListFromFile(std::fstream &file, const fs::path &instrFile) {
    int lastTID = 0, currTID = 0;
    ArrayList *threads = nullptr;
    auto *currThread = static_cast<Thread *>(malloc(sizeof(struct Thread)));
    ThreadRange *currRange = nullptr;
    auto i_list = std::make_shared<InstrList>();
    i_list->numInstrs = 0;
    i_list->numBaseModuleInstrs = 0;
    bool isMultiThread = false;
    currThread->numBaseModuleInstrs = 0;

    lineno = 0;
    found_first_base_instr = false;

    int order = 0; // dyn trace, so add instructions in order of 1st exec.

    currThread->numBaseModuleInstrs = 0;

    // we will be storing ilist either in a file or in mem
    if (STORE_INSTRS_IN_FILE) {
        i_list->iListFile = fopen(instrFile.c_str(), "w+");
        i_list = InitInstructionCache(i_list);
        i_list->nextAvailableAddr = 0;

        fseeko(i_list->iListFile, deobf::library::instruction_utils::InstrFileHeaderSize, SEEK_SET); // make room to write iList at the beginning
    } else {
        assert(false);
        //i_list->iListMem = al_new();
    }

    std::string line;
    directoryUtils.getBaseName().copy(moduleName, 100); // Always start with original basename, can be overwritten by meta information

    auto tm = std::make_shared<TraceMapping>();

    while (std::getline(file, line)) {
        Instruction *nw = GetInstrFromText(line.data(), tm);
        if (nw) {
            currTID = nw->tid;
            nw->order = order++;
            i_list->numInstrs++;
            nw->next = nw->origNext = order;
            nw->prev = nw->origPrev = nw->order - 1;
            if (instrHasFlag(nw, INSTR_IN_BASE_MODULE)) {
                currThread->numBaseModuleInstrs++;
                i_list->numBaseModuleInstrs++;
            }
            if (instrHasFlag(nw, INSTR_IN_BASE_MODULE)) {
                i_list->lastBaseModuleInstr = nw->order;
                if (i_list->nextAvailableAddr < nw->addr + MAX_X86_INSTR_LEN) {
                    i_list->nextAvailableAddr = nw->addr;
                }
            }
            if (nw->esp > (uint)i_list->stackBottom) {
                i_list->stackBottom = nw->esp;
            }

            if (STORE_INSTRS_IN_FILE) {
                AddInstrToFile(i_list->iListFile, nw);
                if (lastTID != 0 && lastTID != currTID) { // a thread switch!
                    if (!isMultiThread) {
                        threads = al_new();
                        currThread->tid = lastTID;
                        currThread->numInstrs = 0;
                        currThread->numRanges = 0;
                        currThread->ranges = al_new();
                        currRange = static_cast<ThreadRange *>(malloc(sizeof(struct ThreadRange)));
                        currRange->first = 0;
                        al_add(currThread->ranges, currRange);
                        al_add(threads, currThread);
                        isMultiThread = true;
                        TraceIsMultiThreaded = true;
                    }
                    currRange->last = nw->order - 1;
                    currThread->numInstrs += currRange->last - currRange->first + 1; // +1: inclusive!
                    currRange = static_cast<ThreadRange *>(malloc(sizeof(struct ThreadRange)));
                    currThread->numRanges++;
                    currRange->first = nw->order;

                    /* search in previous threads to see if
                     the thread already exists, otherwise
                     create a new one			*/
                    currThread = nullptr;
                    int numThreads = al_size(threads);
                    int i = 0;
                    for (; i < numThreads; i++) {
                        auto *th = static_cast<Thread *>(al_get(threads, i));
                        if (th->tid == currTID) {
                            currThread = th;
                            break;
                        }
                    }
                    if (currThread == nullptr) {
                        currThread = static_cast<Thread *>(malloc(sizeof(struct Thread)));
                        currThread->tid = currTID;
                        currThread->numInstrs = 0;
                        currThread->numBaseModuleInstrs = 0;
                        currThread->numRanges = 0;
                        currThread->ranges = al_new();
                        al_add(threads, currThread);
                    }
                    al_add(currThread->ranges, currRange);
                }
                lastTID = currTID;
                free(nw);
            } else {
                assert(false);
                //al_add(i_list->iListMem, nw);
            }
        }
    }

    instructionCount = i_list->numInstrs;
    i_list->last = i_list->numInstrs - 1;

    // pad the file to handle adding instructions
    // for now, arbitrarily double size of file, though this may be excessive
    if (USE_MMAP) {
        // Allocate in blocks of max. 4GB a time, so that we can still process traces that are larger than the available
        // amount of memory.
        uint64_t allocationsLeft = instructionCount;
        constexpr uint64_t blockSize4GB = static_cast<uint64_t>(4) * 1073741824;
        uint64_t instructionsIn4GB = (blockSize4GB / sizeof(Instruction)) + 1;
        while (allocationsLeft >= instructionsIn4GB) {
            reserveMMapSpace(i_list, instructionsIn4GB);
            allocationsLeft -= instructionsIn4GB;
        }
        reserveMMapSpace(i_list, allocationsLeft);
    }
    Instruction *newInstr = GetInstructionFromFile(i_list, i_list->numInstrs - 1);

    newInstr->next = newInstr->origNext = -1;

    if (WriteInstrToFile(i_list->iListFile, newInstr) == 0) {
        logger.log("Unable to save instr changes to file");
        exit(0);
    }

    i_list->loop = 0;
    i_list->firstInstr = 0;

    traceThreads = threads;
    if (TraceIsMultiThreaded) {
        currRange->last = i_list->numInstrs - 1;
        currThread->numInstrs += currRange->last - currRange->first + 1;
    }
    return i_list;
}

void InitMMAP(const fs::path &instrFile, const std::shared_ptr<InstrList>& iList) {
    // get file size
    fseeko(iList->iListFile, 0, SEEK_END);
    uint64_t size = ftello(iList->iListFile);

    // close the file, and reopen to get file descriptor needed by mmap
    fclose(iList->iListFile);
    free(iList->instrCache);
    iList->instrCache = nullptr;

    // get page size
    uint64_t pageSize = sysconf(_SC_PAGE_SIZE);

    // calculate size of mmap
    uint64_t numPages = size / pageSize;
    uint64_t remainder = size % pageSize;

    if (remainder != 0) {
        numPages++;
    }

    uint64_t len = numPages * pageSize;

    // get a file descriptor that mmap can use
    int fd = open(instrFile.c_str(), O_RDWR);

    // do the mmap
    // mmap(
    //      don't care where addr starts,
    //      size of the map,
    //      allow read and write to pages,
    //      mmap maps a file, may have semaphores, and shares memory,
    //      the file descriptor of the file
    //      offset into file (I think, though not 0 doesn't work)
    //  );
    void *pVoid = mmap(nullptr, static_cast<size_t>(len), PROT_READ | PROT_WRITE, MAP_NORESERVE | MAP_FILE | MAP_SHARED, fd, static_cast<off_t>(0));
    if (pVoid == MAP_FAILED) {
        perror("Error mapping file");
        exit(0);
    }
    iList->iMMap = static_cast<Instruction *>(pVoid);
    // don't need fd anymore. File is mapped.
    close(fd);
}

/*
 * InitInstrList
 * first looks for previously created instrList for same module, and tries
 * to use that, otherwise, reads trace file and generates new instr file.
 * Once instr file is created, creates instrList
 */
std::shared_ptr<InstrList> InitInstrList(const fs::path &inPath, std::vector<ADDRESS> *dont_simplify, bool delete_existing_file) {
    std::shared_ptr<InstrList> iList;

    fs::path instructionsFilename = "./" + directoryUtils.getBaseName() + ".instrFile";

    if (delete_existing_file) {
        logger.startPhase("Deleting .instrFile");
        try {
            fs::remove(instructionsFilename);
        } catch (fs::filesystem_error &e) {
            logger.verbose("Unable to delete .instrFile");
            logger.verbose(fmt::format("Error message: {}", e.what()));
        }
        logger.endPhase();
    }

    fs::path baseFilename(instructionsFilename);
    baseFilename += ".base";

    FILE *instrFile;
    FILE *baseInstrFile;
    ins_utils::InstrFileHeader *fileHeader;
    bool setInstrFileExist = true;

    Thread *currThread;
    ThreadRange *currRange;

    instrFile = fopen(instructionsFilename.c_str(), "r+");
    baseInstrFile = fopen(baseFilename.c_str(), "r+");

    if (STORE_INSTRS_IN_FILE && baseInstrFile != nullptr && instrFile == nullptr) {
        logger.startPhase("Copying baseInstrFile");
        try {
            fs::copy(baseFilename, instructionsFilename);
        } catch (fs::filesystem_error &e) {
            logger.verbose("Failed to copy base file to working copy!");
            logger.verbose(fmt::format("Error message: {}", e.what()));
            exit(-1);
        }
        setInstrFileExist = false;
        instrFile = fopen(instructionsFilename.c_str(), "r+");
        logger.endPhase();
    }

    // NOTE: using previous instrFile won't work if STORE_INSTRS_IN_FILE false!!
    if (STORE_INSTRS_IN_FILE && instrFile != nullptr) {
        logger.startPhase("Reading existing .instrFile");
        /* reading file header */
        fileHeader = static_cast<ins_utils::InstrFileHeader *>(malloc(sizeof(ins_utils::InstrFileHeader)));
        fseeko(instrFile, 0, SEEK_SET);
        if (fread(fileHeader, sizeof(ins_utils::InstrFileHeader), 1, instrFile) <= 0) {
            logger.verbose("Could not read the instrFile!");
            exit(-1);
        }

        if (setInstrFileExist) {
            InstrFileExists = true;
        }

        iList = std::make_shared<InstrList>();
        iList->iListFile = instrFile;
        iList->numInstrs = fileHeader->NumInstrs;
        iList->lastBaseModuleInstr = fileHeader->lastBaseModule;
        iList->nextAvailableAddr = fileHeader->nextAvailAddr;
        iList->startMarker = fileHeader->startMarker;
        iList->endMarker = fileHeader->endMarker;
        directoryUtils.setBaseName(&fileHeader->baseModuleName[0]);

        instructionCount = fileHeader->NumInstrs; // setting global instructionCount

        iList->last = fileHeader->LastInstrInOriginalTrace;
        iList->loop = fileHeader->Loop;
        iList->stackBottom = fileHeader->stackBottom;
        TraceIsMultiThreaded = fileHeader->TraceIsMultiThreaded;

        /* Recover thread information if any! */
        if (fileHeader->TraceIsMultiThreaded) {
            off_t rangesOffset = fileHeader->RangeInfoOffset;
            fseeko(instrFile, rangesOffset, SEEK_SET);
            traceThreads = al_new();
            int i, j;
            for (i = 0; i < fileHeader->NumThreads; i++) {
                currThread = static_cast<Thread *>(malloc(sizeof(Thread)));
                if (fread(currThread, sizeof(Thread), 1, instrFile) <= 0) {
                    logger.verbose("Could not read the trace file!");
                    exit(-1);
                }
                if (currThread->numBaseModuleInstrs > LargestThreadNumInstructions) {
                    LargestThreadNumInstructions = currThread->numBaseModuleInstrs;
                    LargestThreadTID = currThread->tid;
                }
                currThread->ranges = al_new();
                for (j = 0; j < currThread->numRanges; j++) {
                    currRange = static_cast<ThreadRange *>(malloc(sizeof(ThreadRange)));
                    if (fread(currRange, sizeof(ThreadRange), 1, instrFile) < 1) {
                        logger.verbose("Could not read the trace file!");
                        exit(-1);
                    }
                    al_add(currThread->ranges, currRange);
                }
                al_add(traceThreads, currThread);
            }
        }

        if (USE_MMAP) {
            // NOTE This closes the open file, and replaces the file pointer with mmap pointer in the iList
            InitMMAP(instructionsFilename, iList);
        } else {
            off_t size = ftello(instrFile);
            if (!ftruncate(fileno(instrFile), size - fileHeader->RangeInfoSize)) {
                logger.verbose("Error resizing instrFile!");
                exit(-1);
            }
        }
        logger.endPhase();
    } else {
        std::fstream traceFile;
        traceFile.open(inPath, std::ios::in);

        if (!traceFile.is_open()) {
            logger.log(fmt::format("ERROR: unable to open ", inPath.string()));
            exit(0);
        }
        iList = BuildIListFromFile(traceFile, instructionsFilename);
        traceFile.close();

        if (USE_MMAP) {
            // NOTE This closes the open file, and replaces the file pointer with mmap pointer in the iList
            InitMMAP(instructionsFilename, iList);
        }
        if (TraceIsMultiThreaded) {
#if MARK_THREAD_BOUNDARIES
            MarkThreadBoundaries(iList);
#endif
        }

        logger.log("Calculate known defs and uses...");
        CalcKnownDefsAndUses(iList);
        logger.log("done.");
    }

    Instruction *ins;

    if (!dont_simplify->empty()) {
        SetCurrentInstr(iList, iList->firstInstr);
        while ((ins = FetchNextInstr(iList)) != nullptr) {
            if (std::find(dont_simplify->begin(), dont_simplify->end(), ins->addr) != dont_simplify->end()) {
                instrSetFlag(ins, INSTR_UNTOUCHABLE, __LINE__);
                SaveInstrChange(iList, ins);
                DEBUG(5, fmt::format("Can't touch this! [{:#x}] @ {}", ins->addr, ins->order));
            }
        }
    }

    return iList;
}
