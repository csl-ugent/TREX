/*
 * File: simplify.cc
 * Purpose: Semantics-preserving simplifications to the code.
 * Author: Babak Yadegari, Willem Van Iseghem
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */
#include "simplify.h"

#include <cstdlib>

#include <register.h>
#include <udis86_create.h>
#include <udis86_glue.h>
#include <utils.h>
#include <flags.h>

#include "array_list.h"
#include "instr.h"
#include "mem_maps.h"
#include "persistent_storage.h"

using namespace deobf::library;
using namespace deobf::library::glue;
using namespace deobf::library::utils;

extern bool TraceIsMultiThreaded;
extern ArrayList *traceThreads;
extern int SimplifyLoopMax;

bool partialKnown(Instruction *ins, const DeobfRegisterUses &knownRegisters) {
    ud_operand_t *op0 = &(ins->uInstr.operand[0]);
    ud_operand_t *op1 = &(ins->uInstr.operand[1]);

    if (!(OpcodeIsArith(ins->uInstr.mnemonic) && (op0->type == UD_OP_REG && op1->type == UD_OP_IMM))) {
        return false;
    }

    DeobfRegister reg0 = toDeobfRegister(op0->base);
    DeobfRegisterUses related = relatedRegistersLower(reg0).reset(reg0);

    return knownRegisters.hasAnyOf(related);
}

ud_type UDSubRegister(ud_type reg, uint8_t size) {
    if (reg >= UD_R_EAX && reg <= UD_R_EDI) { // 32-bit
        if (size == 2) {
            return static_cast<ud_type>((reg - UD_R_EAX) + UD_R_AX);
        } else if (size == 1) {
            return static_cast<ud_type>((reg - UD_R_EAX) + UD_R_AL);
        }
    } else if (reg >= UD_R_AX && reg <= UD_R_DI) { // 16-bit
        if (size == 1) {
            return static_cast<ud_type>((reg - UD_R_AX) + UD_R_AL);
        }
    }
    return UD_NONE;
}

#define SIMPLIFY_INDIRECT_MEM_ACCESS 1

/*
 * PropagateConstants() -- carry out constant propagation on registers
 */
unsigned int PropagateConstants(const std::shared_ptr<InstrList>& iList, int first, int last) {
    auto constsRegisters = std::make_unique<Registers>();
    DEOBF_REGISTER_VALUE val = 0;

    ud_t *udins_new = nullptr;
    ud_mnemonic_code opcode;
    ud_type reg1 = UD_NONE, reg2, reg3;
    ud_operand_t *op0, *op1, *op2;
    unsigned int changeCount = 0;
    DEOBF_REGISTER_VALUE previousESP;

    DeobfRegisterUses regsKnown{};
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    DeobfRegisterUses regsUsedNonMemory{};
    DeobfRegisterUses regsDisallowed{};

    bool memIsConst;
    std::unique_ptr<deobf::library::writeset::WriteSet> memUsed, memDef;

    // Assume all flags are known at start of trace.
    PSW_BITVECTOR flagsKnown = 0xffffffff;

    PSW_BITVECTOR flagsDef = 0;
    int push = 0, flags = 0;

    Instruction *instr = GetInstruction(iList, 0);
    previousESP = instr->esp;

    // Assume all registers known at start of trace except ESP
    regsKnown.set().resetRelated(DeobfRegister::RSP);

    constsRegisters->setRegisterValues(instr);

    ClearConstantPages(iList);

    // stuff for removing useless 'add' and 'sub' esp instructions. Start with an unbiased stack.
    int countESPAddSubInstr = 0;
    uint64_t lastESPAddSubInstr = 0;

    SetCurrentInstr(iList, first);

    while ((instr = FetchNextInstr(iList)) != nullptr) {
        opcode = instr->uInstr.mnemonic;
        op0 = &(instr->uInstr.operand[0]);
        op1 = &(instr->uInstr.operand[1]);
        op2 = &(instr->uInstr.operand[2]);

        regsDefined = definedRegistersForInstruction(iList, instr);
        regsUsed = usedRegistersForInstruction(iList, instr);
        regsUsedNonMemory = definedNonMemoryRegistersForInstruction(iList, instr);

        bool canFreeUDBuffer = true;
        udins_new = nullptr;

        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            Instruction *prev = GetInstruction(iList, instr->prev);
            if (!instrHasFlag(prev, INSTR_IN_BASE_MODULE)) {
                regsKnown.resetRelated(DeobfRegister::RAX);
            }
        }

        if (instrHasFlag(instr, INSTR_UNTOUCHABLE)) {
            DEBUG(3, fmt::format("Skipping {}", *instr));
            continue;
        }

        if (instr->uInstr.mnemonic == UD_Ijmp && instr->uInstr.operand[0].type == UD_OP_JIMM && persistentStorage.functionNameForIdx(instr->funcName).empty()) {
            Instruction *next = GetInstruction(iList, instr->next);
            if (instrHasFlag(next, INSTR_IN_BASE_MODULE)) {
                instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                SaveInstrChange(iList, instr);
                continue;
            }
        }

        if (opcode == UD_Ipushad) {
            int order = instr->order;
            for (auto reg : registers32bitMode32bit) {
                ud_t *pushes = UDCreate::pushReg(reg);
                Instruction *nw = InstrClone(instr);
                nw->esp = instr->esp - 4 * UDCreate::registerOffset(reg);
                carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), pushes, false, __LINE__);
                nw->regFlagsKnown |= MemDefKnown;
                nw->memDefMin = nw->esp - 4;
                nw->memDefSize = 4;
                nw->addr = (instr->addr + UDCreate::registerOffset(reg)) | 0x0f000000;

                Instruction *added = AddInstruction(iList, nw, order);
                free(nw);
                glue::freeUDStructure(pushes, true);
                order = added->order;
            }
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            SaveInstrChange(iList, instr);
            SetCurrentInstr(iList, instr->next);
            continue;
        }
        if (opcode == UD_Ipopad) {
            // break popad into series of pop
            int order = instr->order;

            uint8_t regCount = 0;
            for (auto reg : reverse(registers32bitMode32bit)) {
                ud_t *pops = reg == DeobfRegister::ESP ? UDCreate::addImmToReg(UD_R_ESP, 4) : UDCreate::popReg(reg);
                Instruction *nw = InstrClone(instr);
                nw->esp = instr->esp + 4 * regCount;
                carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), pops, false, __LINE__);
                glue::freeUDStructure(pops, true);
                nw->regFlagsKnown |= MemUsedKnown;
                nw->memUsedMin = nw->esp;
                nw->memUsedSize = 4;
                nw->addr = (instr->addr + regCount) | 0x0f000000;

                AddInstruction(iList, nw, order);
                order = nw->order;
                free(nw);
                regCount++;
            }
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            SaveInstrChange(iList, instr);
            SetCurrentInstr(iList, instr->next);
            continue;
        }

        if (IsCondJump(instr)) {
            Instruction *next;
            while ((next = FetchNextInstr(iList)) != nullptr && IsCondJump(next) && !instrHasFlag(next, INSTR_UNTOUCHABLE)) {
                instrSetFlag(next, INSTR_IS_DELETED, __LINE__);
                instrSetFlag(next, INSTR_TMP0, __LINE__);
                SaveInstrChange(iList, next);
            }
            SetCurrentInstr(iList, instr->next);
        }

        if (opcode == UD_Imov && op0->type == UD_OP_REG && op1->type == UD_OP_REG && op0->base == op1->base) {
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            instrSetFlag(instr, INSTR_TMP0, __LINE__);
            SaveInstrChange(iList, instr);
            continue;
        }

        if (opcode == UD_Imov && op0->type == UD_OP_REG && op1->type == UD_OP_REG && op1->base == UD_R_ESP) {
            ud_t *tmp = UDCreate::movImmToReg(op0->base, GetRegisterValue(instr, UD_R_ESP), instr, __LINE__);
            carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmp, true, __LINE__);
            SaveInstrChange(iList, instr);
            glue::freeUDStructure(tmp, true);
        }

        if (instr->uInstr.mnemonic == UD_Irdtsc || (regsDefined.none() && regsUsed.none() && !instrHasFlag(instr, INSTR_READS_MEM) &&
                                                    !instrHasFlag(instr, INSTR_WRITES_MEM) && !FlagsDef(instr) && !FlagsUsed(instr))) {
            continue;
        }

        /////// esp add sub verification!

        if ((opcode == UD_Iadd || opcode == UD_Isub || opcode == UD_Imov) && op0->type == UD_OP_REG && op0->base == UD_R_ESP &&
            (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST)) {
            if (!instrHasFlag(instr, INSTR_MAYBE_DELETED)) {
                if (opcode == UD_Iadd) {
                    countESPAddSubInstr += op1->lval.sdword;
                    lastESPAddSubInstr = instr->order;
                    instrSetFlag(instr, INSTR_MAYBE_DELETED, __LINE__);
                    SaveInstrChange(iList, instr);
                } else if (opcode == UD_Isub) {
                    countESPAddSubInstr -= op1->lval.sdword;
                    lastESPAddSubInstr = instr->order;
                    instrSetFlag(instr, INSTR_MAYBE_DELETED, __LINE__);
                    SaveInstrChange(iList, instr);
                } else {
                    countESPAddSubInstr = 0;
                    instrSetFlag(instr, INSTR_MAYBE_DELETED, __LINE__);
                    SaveInstrChange(iList, instr);
                }
            }
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            SaveInstrChange(iList, instr);
            continue;
        } else if (regsUsed.test(DeobfRegister::ESP) || regsDefined.test(DeobfRegister::ESP)) { // stop removing adds and subs
            Instruction *tmp = GetInstruction(iList, lastESPAddSubInstr);
            if (instrHasFlag(tmp, INSTR_MAYBE_DELETED)) {
                instrRemoveFlag(tmp, INSTR_MAYBE_DELETED);
                // changeCount--;
            }
            if (countESPAddSubInstr) {
                ud_t *tmp_ud = nullptr;
                if (countESPAddSubInstr > 0) {
                    tmp_ud = UDCreate::addImmToReg(UD_R_ESP, countESPAddSubInstr);
                } else {
                    tmp_ud = UDCreate::subImmFromReg(UD_R_ESP, -countESPAddSubInstr);
                }
                countESPAddSubInstr = 0;
                carefulCopyUDins2InsStr(iList, tmp, &(tmp->uInstr), tmp_ud, true, __LINE__);

                glue::freeUDStructure(tmp_ud, true);
                instrSetFlag(tmp, INSTR_TMP0, __LINE__);

                SaveInstrChange(iList, tmp);
                if (instrHasFlag(tmp, INSTR_IN_BASE_MODULE)) {
                    // changeCount++;
                }
            }
        }
        if (isPush(instr) || isPop(instr) || opcode == UD_Iret || opcode == UD_Icall || opcode == UD_Ileave) {
            if (UDOpIsRegister(op0) != UD_R_ESP) {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }

        memIsConst = true;

        if (opcode == UD_Ior && op0->type == UD_OP_REG && regsKnown.test(op0->base) &&
            constsRegisters->getRegisterValue(op0->base) == 0) { // or [0], reg --> mov [0], reg. [0] is the reg which is known to be 0!
            if (op1->type == UD_OP_REG) {
                udins_new = UDCreate::movRegToReg(op0->base, op1->base);
            }
        }

        if (opcode == UD_Ilea && regsKnown.hasAllOf(DeobfRegisterUses(regsUsed).reset(DeobfRegister::ESP))) {
            Instruction *next = GetInstruction(iList, instr->next);
            ud_t *tmp = nullptr;
            if (regsDefined.test(DeobfRegister::ESP) && regsUsed.test(DeobfRegister::ESP)) { // lea esp, [esp + val]
                val = GetRegisterValue(next, UD_R_ESP);
                if (val > instr->esp) {
                    tmp = UDCreate::addImmToReg(UD_R_ESP, val - instr->esp);
                } else {
                    tmp = UDCreate::subImmFromReg(UD_R_ESP, instr->esp - val);
                }
            } else {

                val = GetRegisterValue(next, op0->base);
                tmp = UDCreate::movImmToReg(op0->base, val, instr, __LINE__);
            }
            carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmp, true, __LINE__);
            instr->regFlagsKnown |= (FlagsUsedKnown | FlagsDefKnown);
            instr->flagsDef = instr->flagsUsed = 0;
            glue::freeUDStructure(tmp, true);
            opcode = instr->uInstr.mnemonic;
            op0 = &(instr->uInstr.operand[0]);
            op1 = &(instr->uInstr.operand[1]);
        }
        // arithmetic instructions without taint can be simplified
        if (OpcodeIsArith(opcode) && instrHasFlag(instr, INSTR_TAINT_CLEARED)) {
            if (op0->type == UD_OP_REG) {
                if (!instrHasFlag(instr, INSTR_IN_USEDEF)) {
                    val = GetRegisterValue(instr, op0->base);
                    ud_t *tmp = UDCreate::movImmToReg(op0->base, val, instr, __LINE__);
                    instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmp, true, __LINE__);
                    SaveInstrChange(iList, instr);
                    glue::freeUDStructure(tmp, true);

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);
                    op2 = &(instr->uInstr.operand[2]);

                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                    regsUsedNonMemory = definedNonMemoryRegistersForInstruction(iList, instr);
                } else {
                    instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                    SaveInstrChange(iList, instr);
                }
            }
        }

        // simplify non-mem instructions which the operands are known!
        if (!instrHasFlag(instr, INSTR_READS_MEM) && !instrHasFlag(instr, INSTR_WRITES_MEM)) {
            ud_t *tmpUD = nullptr;
            DEBUGLINE(3, "Non-mem instruction");
            if (regsKnown.hasAllOf(DeobfRegisterUses(regsUsed).reset(DeobfRegister::SP)) ||
                partialKnown(instr, regsKnown)) { // exclude sub and add esp instructions!
                if (OpcodeIsArith(opcode) && (!regsUsed.test(DeobfRegister::ESP) || opcode == UD_Isbb)) {
                    DEBUGLINE(3, "Arith opcode that doesn't use ESP");
                    reg1 = UDOpIsRegister(op0);
                    if (reg1 == UD_NONE) {
                        reg1 = regsDefined.toUDRegister();
                    }
                    Instruction *tmp;
                    if (op2->type == UD_NONE) {
                        DEBUGLINE(3, "1 or 2 op instr");
                        if ((reg2 = UDOpIsRegister(op1)) != UD_NONE) { // second op is a known reg
                            DEBUGLINE(3, "2 op instr (known)");
                            instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                            instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                            DEOBF_REGISTER_VALUE val1 = constsRegisters->getRegisterValue(reg2);
                            if (instr->uInstr.bytes[0] == 0x83 || instr->uInstr.bytes[1] == 0x83) { // arithmetics with 83 opcode, do the sign extension!
                                val1 = SignExtend(val1);
                            }
                            tmp = GetInstruction(iList, instr->next);
                            constsRegisters->setRegisterValue(reg1, GetRegisterValue(tmp, reg1));
                            val = constsRegisters->getRegisterValue(reg1);
                            tmpUD = UDCreate::movImmToReg(reg1, val, instr, __LINE__);
                        } else if (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST) { // second op is constant
                            DEBUGLINE(3, "2 op instr (const)");
                            instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                            int val1 = op1->lval.sdword;
                            if (instr->uInstr.bytes[0] == 0x83 || instr->uInstr.bytes[1] == 0x83) { // arithmetics with 83 opcode, do the sign extension!
                                val1 = SignExtend(val1);
                            }
                            tmp = GetInstruction(iList, instr->next);
                            constsRegisters->setRegisterValue(reg1, GetRegisterValue(tmp, reg1));
                            val = constsRegisters->getRegisterValue(reg1);
                            tmpUD = UDCreate::movImmToReg(reg1, val, instr, __LINE__);
                        } else { // one operand
                            DEBUGLINE(3, "1 op instr");
                            constsRegisters->setRegisterValue(reg1, ArithOp(opcode, constsRegisters->getRegisterValue(reg1), 1, op0->size, &flagsKnown));
                            val = constsRegisters->getRegisterValue(reg1);
                            instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                            tmpUD = UDCreate::movImmToReg(reg1, val, instr, __LINE__);
                        }
                        if (!instrHasFlag(instr, INSTR_IN_USEDEF)) {
                            glue::freeUDStructure(tmpUD, true);
                            tmpUD = UDCreate::movImmToReg(reg1, val, instr, __LINE__);
                        } else {
                            instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                            SaveInstrChange(iList, instr);
                        }
                    } else { // 3 operand instr
                        DEBUGLINE(3, "3 operand instr");
                        reg2 = UDOpIsRegister(op1);
                        // handling imul now! TODO: generalize for all 3 operand instructions!
                        if (opcode == UD_Imul || opcode == UD_Iimul || opcode == UD_Ishrd || opcode == UD_Ishld) {
                            if ((reg3 = UDOpIsRegister(op2)) != UD_NONE) {
                                constsRegisters->setRegisterValue(reg1, ArithOp(opcode, constsRegisters->getRegisterValue(reg2),
                                                                                constsRegisters->getRegisterValue(reg3), op2->size, &flagsKnown));
                                val = constsRegisters->getRegisterValue(reg1);
                            } else { // op2 constant
                                constsRegisters->setRegisterValue(
                                    reg1, ArithOp(opcode, constsRegisters->getRegisterValue(reg2), op2->lval.sdword, op2->size, &flagsKnown));
                                val = constsRegisters->getRegisterValue(reg1);
                            }
                            if (!instrHasFlag(instr, INSTR_IN_USEDEF)) {
                                tmpUD = UDCreate::movImmToReg(reg1, val, instr, __LINE__);
                            } else {
                                instrSetFlag(instr, INSTR_REGDEF_KNOWN, __LINE__);
                                instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                                SaveInstrChange(iList, instr);
                            }
                        }
                    }
                    if (regsKnown.hasAllOf(regsUsed)) {
                        if (opcode == UD_Icmp || opcode == UD_Itest) {
                            if ((reg1 = UDOpIsRegister(op0)) && regsKnown.test(reg1)) {
                                instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                                SaveInstrChange(iList, instr);
                            }
                            if ((reg1 = UDOpIsRegister(op1)) && regsKnown.test(reg1)) {
                                instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                                SaveInstrChange(iList, instr);
                            }
                        }
                    }
                } else if (opcode == UD_Iaaa &&
                           (regsKnown.test(DeobfRegister::AL) || regsKnown.test(DeobfRegister::AX) || regsKnown.test(DeobfRegister::EAX))) {
                    Instruction *tmp = GetInstruction(iList, instr->origNext);
                    tmpUD = UDCreate::movImmToReg(UD_R_AL, GetRegisterValue(tmp, UD_R_AL), instr, __LINE__);

                } else if (op0->type == UD_NONE && !FlagsDef(instr)) { // instructions without operands! cdq
                    if (opcode == UD_Icdq) {
                        unsigned int imm = SignExtend(constsRegisters->getRegisterValue(DeobfRegister::EAX)) & 0xffffffff;
                        tmpUD = UDCreate::movImmToReg(UD_R_EDX, imm, instr, __LINE__); // mov sign extend eax to edx
                    } else if (opcode == UD_Ileave) {
                        tmpUD = UDCreate::movImmToReg(UD_R_EBP, GetRegisterValue(instr, UD_R_EBP), instr, __LINE__);
                    }
                }
            } else if (op0->type == UD_OP_REG && op1->type == UD_OP_IMM) {
            }
            if (tmpUD != nullptr && !instrHasFlag(instr, INSTR_UNSIMPLIFIABLE)) { // we recognized opcode2
                if (instrHasFlag(instr, INSTR_IN_USEDEF)) {
                    flagsKnown = FlagsDef(instr);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmpUD, true, __LINE__);
                } else {
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmpUD, false, __LINE__);
                }
                instrSetFlag(instr, INSTR_TMP0, __LINE__);
                SaveInstrChange(iList, instr);
                if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                    changeCount++;
                }
                regsDefined = definedRegistersForInstruction(iList, instr);
                regsUsed = usedRegistersForInstruction(iList, instr);
                opcode = instr->uInstr.mnemonic;
                op0 = &(instr->uInstr.operand[0]);
                op1 = &(instr->uInstr.operand[1]);
                op2 = &(instr->uInstr.operand[2]);
            }
            glue::freeUDStructure(tmpUD, true);
        }
        if (instrHasFlag(instr, INSTR_WRITES_MEM) && !instrHasFlag(instr, INSTR_READS_MEM)) {
            if (opcode == UD_Ipushfd && !instrHasFlag(instr, INSTR_FORWARD_TAINTED)) {
                instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                SaveInstrChange(iList, instr);
                val = -1;
            } else if (!IsStringOperation(instr) && opcode != UD_Ipushfd &&
                       ((regsUsedNonMemory.any() && regsKnown.hasAllOf(DeobfRegisterUses(regsUsedNonMemory).reset(DeobfRegister::ESP))) ||
                        regsUsedNonMemory.none() // TODO: this or can possibly be simplified to just regsKnown.contains(...)
                        )) {
                if (op2->type == UD_NONE) {
                    if (op1->type == UD_OP_REG) {
                        val = constsRegisters->getRegisterValue(regsUsedNonMemory.toDeobfRegister());

                        instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                        instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                        SaveInstrChange(iList, instr);
                    } else if (op1->type == UD_OP_CONST || op1->type == UD_OP_IMM) {
                        instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                        SaveInstrChange(iList, instr);
                        val = op1->lval.sdword;
                    } else if (opcode == UD_Icall) {
                        val = instr->addr + instr->uInstr.length;
                    } else if (op1->type == UD_NONE) {
                        if (op0->type == UD_OP_REG) {
                            val = constsRegisters->getRegisterValue(regsUsedNonMemory.toDeobfRegister());
                            if (op0->base == UD_R_ESP) {
                                val = GetRegisterValue(instr, UD_R_ESP);
                            }
                        } else {
                            val = op0->lval.sdword;
                        }
                    }
                } else {
                    // is there any? an instr with mem dest and 3 operands
                }
            } else if (opcode == UD_Icall && op0->type == UD_OP_IMM) {
                val = instr->addr + instr->uInstr.length;
            } else if (regsUsedNonMemory.count() == 1 &&
                       (regsKnown & relatedRegistersLower(regsUsedNonMemory.toDeobfRegister())).reset(DeobfRegister::ESP).any()) {
                // if a only a part of a register is known, like cl in ecx!
                // FIXME: above statement probably should be simplified...
                /*
                 * select the write range which corresponds to the known part,
                 * lower memory addresses should go to the least significant
                 * bits!(?) Does this depend on big/little-endian?
                 */
                DeobfRegisterUses affected = relatedRegistersLower(regsUsedNonMemory.toDeobfRegister()) & regsKnown;
                auto affectedRegs = affected.affectedRegisters();

                for (const DeobfRegister r : affectedRegs) {
                    val = constsRegisters->getRegisterValue(r);
                    uint64_t memMin, memMax;
                    memMin = instr->memDefMin + getRegisterLowOrHighOrder(r);
                    memMax = memMin + getRegisterByteWidth(r) - 1;
                    DEBUG(3, fmt::format("{} - {}", *instr, r));
                    SetAddrAsConstWithValue(iList, memMin, memMax - memMin + 1, val, __LINE__);
                }

            } else if (opcode == UD_Istosb || opcode == UD_Istosd || opcode == UD_Istosw) {
                if (regsKnown.test(DeobfRegister::EDI)) {
                    regsDefined.reset();
                }
                if (opcode == UD_Istosb && regsKnown.test(DeobfRegister::AL)) {
                    SetAddrAsConstWithValue(iList, instr->memDefMin, getByteWidth(DeobfRegisterWidth::lower8bit),
                                            constsRegisters->getRegisterValue(DeobfRegister::AL) & 0xff, __LINE__);
                    val = constsRegisters->getRegisterValue(DeobfRegister::AL) & 0xff;
                } else if (opcode == UD_Istosw && regsKnown.test(DeobfRegister::AX)) {
                    SetAddrAsConstWithValue(iList, instr->memDefMin, getByteWidth(DeobfRegisterWidth::lower16bit),
                                            constsRegisters->getRegisterValue(DeobfRegister::AX) & 0xffff, __LINE__);
                    val = constsRegisters->getRegisterValue(DeobfRegister::AX) & 0xffff;
                } else if (opcode == UD_Istosd && regsKnown.test(DeobfRegister::EAX)) {
                    SetAddrAsConstWithValue(iList, instr->memDefMin, getByteWidth(DeobfRegisterWidth::lower32bit),
                                            constsRegisters->getRegisterValue(DeobfRegister::EAX), __LINE__);
                    val = constsRegisters->getRegisterValue(DeobfRegister::EAX);
                }

                ud_t *udnew = UDCreate::movImmToOffset(instr->memDefMin, val, instr->memDefSize, instr->eip);
                carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udnew, false, __LINE__);
                SaveInstrChange(iList, instr);
                udnew = glue::freeUDStructure(udnew, true);

                Instruction *tmp = InstrClone(instr);
                tmp->addr += 1;
                udnew = UDCreate::addImmToReg(UD_R_EDI, 1);
                carefulCopyUDins2InsStr(iList, tmp, &(tmp->uInstr), udnew, false, __LINE__);
                AddInstruction(iList, tmp, instr->order);
                SaveInstrChange(iList, tmp);
                glue::freeUDStructure(udnew, true);
            } else {
                // remove previous entries

                memIsConst = false;
                UnsetConstAddr(iList, instr->memDefMin, instr->memDefSize, __LINE__);

                if (opcode == UD_Ipushfd) { // means it is forward tainted!
                    val = FlagsUsed(instr);
                    SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, val, __LINE__);
                    UnsetConstAddrWithoutMemReset(iList, instr->memDefMin, instr->memDefSize, __LINE__);
                }
            }

            DEBUG(3, fmt::format("{} - {}", instr->order, *instr));
            if (memIsConst) {
                SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, val, __LINE__);
            } else {
                UnsetConstAddr(iList, instr->memDefMin, instr->memDefSize, __LINE__);
            }
        } else if (instrHasFlag(instr, INSTR_WRITES_MEM) && instrHasFlag(instr, INSTR_READS_MEM)) {
            if (MemLocIsConstant(iList, instr->memUsedMin, instr->memUsedSize)) {
                val = GetMemoryLocValue(iList, instr->memUsedMin, instr->memUsedSize);
                if (instrHasFlag(instr, INSTR_UNSIMPLIFIABLE)) {
                    if (MemLocIsConstant(iList, instr->memDefMin, instr->memDefSize)) {
                        // simplify the instruction itself but do not propagate!
                        UnsetConstAddr(iList, instr->memUsedMin, instr->memUsedSize, __LINE__);
                    }
                }

                if (OpcodeIsArith(opcode)) {
                    if (op2->type == UD_NONE) {
                        if (op1->type == UD_OP_REG) {
                            if (regsKnown.hasAllOf(regsUsedNonMemory)) {
                                instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                                instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                                SaveInstrChange(iList, instr);
                                val = GetMemoryLocValue(iList, instr->memUsedMin, instr->memUsedSize);
                                DeobfRegister r = regsUsedNonMemory.toDeobfRegister();
                                DEBUG(3, fmt::format("{}", *instr));
                                SetAddrAsConstWithValue(iList, instr->memUsedMin, instr->memUsedSize,
                                                        ArithOp(opcode, val, constsRegisters->getRegisterValue(r), 4, &flagsKnown), __LINE__);
                            } else {
                                UnsetConstAddr(iList, instr->memDefMin, instr->memDefSize, __LINE__);
                            }
                        } else if (op1->type == UD_OP_CONST || op1->type == UD_OP_IMM) {
                            instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                            SaveInstrChange(iList, instr);
                            val = GetMemoryLocValue(iList, instr->memUsedMin, instr->memUsedSize);
                            DEBUG(3, fmt::format("{}", *instr));
                            SetAddrAsConstWithValue(iList, instr->memUsedMin, instr->memUsedSize, ArithOp(opcode, val, op1->lval.sdword, 4, &flagsKnown),
                                                    __LINE__);
                        } else if (op1->type == UD_NONE) { // one operand instruction
                            if (opcode == UD_Iimul || opcode == UD_Iidiv || opcode == UD_Imul || opcode == UD_Idiv) {
                                if (regsKnown.test(DeobfRegister::EAX)) {
                                    val = GetMemoryLocValue(iList, instr->memUsedMin, instr->memUsedSize);
                                    DeobfRegister r = regsUsedNonMemory.toDeobfRegister();
                                    SetAddrAsConstWithValue(iList, instr->memUsedMin, instr->memUsedSize,
                                                            ArithOp(opcode, val, constsRegisters->getRegisterValue(r), 4, &flagsKnown), __LINE__);
                                    udins_new = UDCreate::movImmToReg(UD_R_EAX, ArithOp(opcode, val, constsRegisters->getRegisterValue(r), 4, &flagsKnown),
                                                                      instr, __LINE__);
                                    instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                                }
                            } else {
                                instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                                SaveInstrChange(iList, instr);
                                DEBUG(3, fmt::format("{}", *instr));
                                SetAddrAsConstWithValue(iList, instr->memUsedMin, instr->memUsedSize, ArithOp(opcode, val, 0, 4, &flagsKnown), __LINE__);
                            }
                        }
                    } else {
                        // is there any? an instr with mem dest and 3 operands
                    }
                } else if (regsUsedNonMemory.any()) { // xchg, xadd, ...
                    if (opcode == UD_Ixchg) {
                        if (regsKnown.hasAllOf(regsUsedNonMemory)) {
                            DeobfRegister r = regsUsedNonMemory.toDeobfRegister();
                            DEOBF_REGISTER_VALUE old = constsRegisters->getRegisterValue(r);
                            udins_new = UDCreate::movImmToOffset(instr->memDefMin, old, instr->memDefSize, instr->eip);

                            ud_t *udins = UDCreate::movImmToReg(regsUsedNonMemory.toUDRegister(), val, instr, __LINE__);
                            Instruction *nw = InstrClone(instr);
                            nw->order = instr->order;
                            nw->addr = instr->addr + 1;
                            carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, true, __LINE__);
                            glue::freeUDStructure(udins, true);

                            AddInstruction(iList, nw, instr->order);
                            free(nw);

                            constsRegisters->setRegisterValue(r, val);
                            DEBUG(3, fmt::format("{}", *instr));
                            SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, old, __LINE__);
                        } else {
                            UnsetConstAddr(iList, instr->memDefMin, instr->memDefSize, __LINE__);

                            // first op is mem and const, second is reg and
                            // not const OR first op is reg and not const,
                            // second is mem and const in either case: mov
                            // [mem], reg and mov reg, const

                            ud_t *udins = UDCreate::movImmToReg(regsUsedNonMemory.toUDRegister(), val, instr, __LINE__);
                            Instruction *nw = InstrClone(instr);
                            nw->addr = instr->addr + 1;
                            carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, true, __LINE__);
                            glue::freeUDStructure(udins, true);
                            AddInstruction(iList, nw, instr->order);
                            free(nw);
                        }
                    } else if ((opcode == UD_Icmpxchg || opcode == UD_Icmpxchg8b) &&
                               regsKnown.test(resizeBaseRegister(DeobfRegister::RAX, traceInfo.getTraceWidth()))) {
                        // compares eax with op2
                        bool compare = false;
                        DEOBF_REGISTER_VALUE eax = constsRegisters->getRegisterValue(resizeBaseRegister(DeobfRegister::RAX, traceInfo.getTraceWidth()));
                        DEOBF_REGISTER_VALUE dest;
                        if (op0->type == UD_OP_REG && regsUsedNonMemory.hasAnyOf(regsKnown)) {
                            dest = op0->lval.sdword;
                            compare = true;
                        } else if (op0->type == UD_OP_MEM) {
                            dest = val;
                            compare = true;
                        }

                        if (compare) {
                            if (dest == eax) { // dest <== src
                                if (op0->type == UD_OP_MEM) {
                                    if (regsUsedNonMemory.hasAnyOf(regsKnown)) {
                                        udins_new = UDCreate::movImmToOffset(instr->memDefMin, constsRegisters->getRegisterValue(op1->base), instr->memDefSize,
                                                                             instr->eip);
                                    } else {
                                        udins_new = UDCreate::movOffsetToReg(op1->base, instr->memDefMin, REG_TO_OFFSET, instr->eip);
                                    }
                                } else { // op0 = reg
                                    udins_new = UDCreate::movImmToReg(op0->base, val, instr, __LINE__);
                                }

                            } else { // eax <== dest
                                if (op0->type == UD_OP_MEM) {
                                    udins_new = UDCreate::movImmToReg(UD_R_EAX, val, instr, __LINE__);
                                } else {
                                    if (regsUsedNonMemory.hasAnyOf(regsKnown)) {
                                        udins_new = UDCreate::movImmToReg(UD_R_EAX, constsRegisters->getRegisterValue(op0->base), instr, __LINE__);
                                    } else {
                                        udins_new = UDCreate::movRegToReg(UD_R_EAX, op0->base);
                                    }
                                }
                            }
                        }
                    } else if (opcode == UD_Imovsb || (opcode == UD_Imovsd && isMoveDataFromStringToString(instr)) || opcode == UD_Imovsw ||
                               opcode == UD_Imovsq) {
                        SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, val, __LINE__);
                        regsDefined.reset();
                    } else if (opcode == UD_Istosb || opcode == UD_Istosd || opcode == UD_Istosw || opcode == UD_Istosq) {
                        SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, val, __LINE__);
                        regsDefined.reset();
                    }
                } else { // mem copy: push [mem], pop [mem], cmpxchg [mem], ...
                    val = GetMemoryLocValue(iList, instr->memUsedMin, instr->memUsedSize);
                    SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, val, __LINE__);

                    // change instr to move [target], const
                    if (opcode == UD_Ipop) {
                        ud_t *udins = UDCreate::addImmToReg(UD_R_ESP, instr->memUsedSize);
                        Instruction *nw = InstrClone(instr);
                        nw->order = instr->order;
                        nw->addr = instr->addr;
                        nw->flags = 0;
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, true, __LINE__);
                        nw->regFlagsKnown |= FlagsDefKnown;
                        nw->regFlagsKnown |= FlagsUsedKnown;
                        nw->flagsUsed = 0;
                        nw->flagsDef = 0;
                        glue::freeUDStructure(udins, true);
                        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                            instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                        }
                        AddInstruction(iList, nw, instr->order);
                        free(nw);
                    }
                    if (opcode == UD_Ipush) {
                        ud_t *udins = UDCreate::subImmFromReg(UD_R_ESP, instr->memDefSize);
                        Instruction *nw = InstrClone(instr);
                        nw->order = instr->order;
                        nw->addr = instr->addr;
                        nw->flags = 0;
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, true, __LINE__);
                        nw->regFlagsKnown |= FlagsDefKnown;
                        nw->regFlagsKnown |= FlagsUsedKnown;
                        nw->flagsUsed = 0;
                        nw->flagsDef = 0;
                        glue::freeUDStructure(udins, true);
                        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                            instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                        }
                        AddInstruction(iList, nw, instr->order);
                        free(nw);
                    }
                }
            } else if (opcode == UD_Ixchg) {
                if (regsUsedNonMemory.hasAnyOf(regsKnown)) {
                    udins_new = UDCreate::movOffsetToReg(regsUsedNonMemory.toUDRegister(), instr->memUsedMin, OFFSET_TO_REG, instr->eip);

                    Instruction *tmp = InstrClone(instr);
                    DeobfRegister r = regsUsedNonMemory.toDeobfRegister();
                    ud_t *udins = UDCreate::movImmToOffset(instr->memDefMin, constsRegisters->getRegisterValue(r), instr->memDefSize, instr->eip);
                    tmp->addr = instr->addr + 1;
                    carefulCopyUDins2InsStr(iList, tmp, &(tmp->uInstr), udins, true, __LINE__);
                    AddInstruction(iList, tmp, instr->order);
                    free(tmp);
                    glue::freeUDStructure(udins, true);
                }
            } else {
                DeobfRegister resized = resizeBaseRegister(DeobfRegister::RAX, traceInfo.getTraceWidth());
                if (op0->type == UD_OP_MEM && op1->type == UD_NONE && instrHasFlag(instr, INSTR_OP0_CONSTANT) &&
                    (opcode == UD_Icmpxchg || opcode == UD_Icmpxchg8b) && regsKnown.test(resized)) {
                    // compares eax with op2
                    Instruction *tmp = GetInstruction(iList, instr->next);
                    DEOBF_REGISTER_VALUE val2 = GetRegisterValue(tmp, resized);
                    udins_new = UDCreate::movImmToReg(toUDRegister(resized), val2, instr, __LINE__);
                } else if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && opcode == UD_Icall && instrHasFlag(instr, INSTR_OP0_CONSTANT)) {
                    SetAddrAsConstWithValue(iList, instr->memDefMin, instr->memDefSize, instr->addr + instr->uInstr.length, __LINE__);
                } else {
                    UnsetConstAddr(iList, instr->memDefMin, instr->memDefSize, __LINE__);
                }
            }
        } else if (instrHasFlag(instr, INSTR_READS_MEM) && !instrHasFlag(instr, INSTR_WRITES_MEM)) {
            DEBUG(3, fmt::format("mem loc check at {} - {:#x} - {}", instr->order, instr->addr, *instr));
            if (MemLocIsConstant(iList, instr->memUsedMin, instr->memUsedSize) || instrHasFlag(instr, INSTR_READS_GLOBAL_MEM)) {
                val = GetMemoryLocValue(iList, instr->memUsedMin, instr->memUsedSize);
                if (opcode == UD_Ipop && op0->type != UD_OP_MEM) {
                    if (op0->base != UD_R_ESP) {
                        udins_new = UDCreate::movImmToReg(op0->base, val, instr, __LINE__);

                        ud_t *udins = UDCreate::addImmToReg(UD_R_ESP, UDRegSize(op0->base));
                        Instruction *nw = InstrClone(instr);
                        nw->order = instr->order;
                        nw->addr = instr->addr;
                        nw->flags = 0;
                        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                            instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                        }
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, true, __LINE__);
                        nw->regFlagsKnown |= FlagsDefKnown;
                        nw->regFlagsKnown |= FlagsUsedKnown;
                        nw->flagsUsed = 0;
                        nw->flagsDef = 0;
                        glue::freeUDStructure(udins, true);
                        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                            instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                        }
                        AddInstruction(iList, nw, instr->order);
                        free(nw);
                    } else {
                        DEOBF_REGISTER_VALUE currentESP = GetRegisterValue(instr, UD_R_ESP);
                        Instruction *next = GetInstruction(iList, instr->order + 1);
                        DEOBF_REGISTER_VALUE nextESP = GetRegisterValue(next, UD_R_ESP);
                        if (currentESP < nextESP) {
                            udins_new = UDCreate::addImmToReg(UD_R_ESP, nextESP - currentESP);
                        } else if (currentESP > nextESP) {
                            udins_new = UDCreate::subImmFromReg(UD_R_ESP, currentESP - nextESP);
                        } else {
                            udins_new = nullptr;
                            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                            SaveInstrChange(iList, instr);
                        }
                    }

                } else if (opcode == UD_Ipopfd) {
                    // this changes a popf to nop IF the stack location is a constant. This is to get rid of the corresponding stack location!
                    instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                    ud_t *tmp = UDCreate::nop();
                    instr->flagsDef = flagsDef;
                    instr->regFlagsKnown |= FlagsDefKnown;
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmp, true, __LINE__);
                    glue::freeUDStructure(tmp, true);
                    SaveInstrChange(iList, instr);
                } else if (opcode == UD_Icmp || opcode == UD_Itest) { // Instructions of type "cmp mem/reg, mem/imm"
                    if ((op0->type == UD_OP_MEM || op0->type == UD_OP_IMM || op0->type == UD_OP_CONST)) {
                        instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                        instrSetFlag(instr, INSTR_MEM_SIMP, __LINE__);
                        if (op0->type == UD_OP_MEM) {
                            udins_new = UDCreate::changeOperandToImm(instr->uInstr.bytes, 0, val);
                            canFreeUDBuffer = false;
                        }
                        // N++;
                    }
                    if ((op1->type == UD_OP_MEM || op1->type == UD_OP_IMM || op1->type == UD_OP_CONST)) {
                        instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                        instrSetFlag(instr, INSTR_MEM_SIMP, __LINE__);
                        if (op1->type == UD_OP_MEM) {
                            udins_new = UDCreate::changeOperandToImm(instr->uInstr.bytes, 1, val);
                            canFreeUDBuffer = false;
                        }
                        // N++;
                    }
                    if (op0->type == UD_OP_REG && regsUsedNonMemory.hasAnyOf(regsKnown)) {
                        instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                    }
                    if (op1->type == UD_OP_REG && regsUsedNonMemory.hasAnyOf(regsKnown)) {
                        instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                    }
                    SaveInstrChange(iList, instr);
                } else if (instr->uInstr.bytes[0] == 0xf7) {
                    if (regsKnown.test(DeobfRegister::AX)) { // FIXME: check if this behaviour is correct! Should be EAX
                        val = ArithOp(opcode, val, constsRegisters->getRegisterValue(DeobfRegister::EAX), 1, &flagsKnown);
                        // store results in edx:eax
                        constsRegisters->setRegisterValue(DeobfRegister::EAX, val & 0xffffffff);
                        constsRegisters->setRegisterValue(DeobfRegister::EDX, (val & 0xffffffff00000000) >> 32);
                        regsKnown.set(DeobfRegister::EDX);
                    }
                } else if (instr->uInstr.bytes[0] == 0x66 && instr->uInstr.bytes[1] == 0xf7) {
                    if (regsKnown.test(DeobfRegister::AX)) { // FIXME: check if this behaviour is correct!
                        val = ArithOp(opcode, val, constsRegisters->getRegisterValue(DeobfRegister::AX), 1, &flagsKnown);
                        // store results in dx:ax
                        constsRegisters->setRegisterValue(DeobfRegister::AX, val & 0xffff);
                        constsRegisters->setRegisterValue(DeobfRegister::DX, val & 0xffff0000);
                        regsKnown.set(DeobfRegister::DX);
                    }
                } else if (OpcodeIsArith(opcode)) { // it is: arith reg, [mem]
                    if (regsKnown.hasAllOf(regsUsed)) {
                        val = ArithOp(opcode, constsRegisters->getRegisterValue(op0->base), val, op1->size, &flagsKnown);
                        udins_new = UDCreate::movImmToReg(regsDefined.toUDRegister(), val, instr, __LINE__);
                        instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                    } else {
                        udins_new = UDCreate::changeOperandToImm(instr->uInstr.bytes, 1, val);
                        canFreeUDBuffer = false;
                    }
                } else if (opcode == UD_Iret && instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                    int size = 4;
                    if (op0->type != UD_NONE) { // number of bytes being popped off the stack
                        size += op0->lval.sdword;
                    }
                    ud_t *tmp = UDCreate::jumpNear(val - 5, instr->eip);
                    instrSetFlag(instr, INSTR_MEM_SIMP, __LINE__);

                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmp, false, __LINE__);
                    SaveInstrChange(iList, instr);
                    glue::freeUDStructure(tmp, true);

                    ud_t *udins = UDCreate::addImmToReg(UD_R_ESP, size);
                    Instruction *nw = InstrClone(instr);
                    nw->order = instr->order;
                    nw->addr = instr->addr;
                    nw->flags = 0;
                    carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, true, __LINE__);
                    nw->regFlagsKnown |= FlagsDefKnown;
                    nw->regFlagsKnown |= FlagsUsedKnown;
                    nw->flagsUsed = 0;
                    nw->flagsDef = 0;
                    glue::freeUDStructure(udins, true);

                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                        instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                    }

                    AddInstruction(iList, nw, instr->prev);
                    free(nw);
                } else if (opcode == UD_Iscasb && regsKnown.test(DeobfRegister::EAX)) { // scasb // FIXME: verify this - Should be compared to AL
                    udins_new =
                        UDCreate::cmpOffsetWithImm(instr->memUsedMin, constsRegisters->getRegisterValue(DeobfRegister::AL), instr->memUsedSize, instr->eip);
                    instrSetFlag(instr, INSTR_READS_GLOBAL_MEM, __LINE__);
                    SaveInstrChange(iList, instr);
                } else if (regsDefined.any() && !IsStringOperation(instr) && !IsMxcsrInstr(instr)) {
                    udins_new = UDCreate::movImmToReg(regsDefined.toUDRegister(), val, instr, __LINE__);
                    instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                }
            } else if (regsDefined.any() && instrHasFlag(instr, INSTR_READS_GLOBAL_MEM) && regsKnown.hasAllOf(regsUsed)) { // arithmetic with data section
                if (IsStringCompare(instr)) {
                    instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
                } else if (opcode != UD_Ixchg) {
                    Instruction *nextInstr = GetInstruction(iList, instr->next);
                    DEOBF_REGISTER_VALUE tmp = GetRegisterValue(nextInstr, op0->base);
                    udins_new = UDCreate::movImmToReg(op0->base, tmp, instr, __LINE__);
                    instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                }
            }
        }
        if (udins_new != nullptr) {                                                                             // we recognized opcode2
            if ((instrHasFlag(instr, INSTR_SIMPLIFIED_IGNORED) && instrHasFlag(instr, INSTR_UNSIMPLIFIABLE))) { // stop simplifying
                instrRemoveFlag(instr, INSTR_SIMPLIFIED_IGNORED);
                SaveInstrChange(iList, instr);
                udins_new = glue::freeUDStructure(udins_new, canFreeUDBuffer);
            } else {
                carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);

                udins_new = glue::freeUDStructure(udins_new, canFreeUDBuffer);
                instrSetFlag(instr, INSTR_TMP0, __LINE__);
                instrRemoveFlag(instr, INSTR_SIMPLIFIED_IGNORED);
                SaveInstrChange(iList, instr);
                regsDefined = definedRegistersForInstruction(iList, instr);
                regsUsed = usedRegistersForInstruction(iList, instr);
                opcode = instr->uInstr.mnemonic;
                op0 = &(instr->uInstr.operand[0]);
                op1 = &(instr->uInstr.operand[1]);
                op2 = &(instr->uInstr.operand[2]);
                udins_new = nullptr;
            }
        }

        bool canPropagate = false;
        if (regsUsed.hasAnyOf(regsKnown)) {
            if (regsUsed.hasAnyOf(regsDefined)) {
                canPropagate =
                    (OpcodeIsArith(opcode) ||
                     (opcode == UD_Ilea || opcode == UD_Ixadd || opcode == UD_Ixchg || opcode == UD_Ileave || op1->type == UD_OP_MEM) // TODO: looks fishy
                     || (opcode == UD_Ipush && op0->type == UD_OP_REG && regsKnown.test(op0->base)));
            } else {
                canPropagate = true;
            }
        } else {
        }
        if (canPropagate) {
            reg2 = UDOpIsRegister(op0);
            if (opcode == UD_Ixchg && ((op0->type == UD_OP_REG && op1->type == UD_OP_MEM) || (op0->type == UD_OP_MEM && op1->type == UD_OP_REG))) {
                if (op0->type == UD_OP_MEM) {
                    instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                } else {
                    instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                }
                SaveInstrChange(iList, instr);
            } else if (opcode == UD_Ixchg && op0->type == UD_OP_REG && op1->type == UD_OP_REG) {
                if (regsKnown.hasAllOf(regsUsed)) { // op0 and op1 are known!
                    regsDefined.reset(regsUsed);

                    ud_t *instrForReg0 = UDCreate::movImmToReg(op0->base, constsRegisters->getRegisterValue(op0->base), instr, __LINE__);
                    ud_t *instrForReg2 = UDCreate::movImmToReg(op1->base, constsRegisters->getRegisterValue(op1->base), instr, __LINE__);

                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), instrForReg0, true, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && instrForReg0 != nullptr) {
                        changeCount++;
                    }

                    Instruction *nw = InstrClone(instr);
                    Instruction *next = GetInstruction(iList, instr->next);
                    SetRegisterValue(nw, op0->base, GetRegisterValue(next, op0->base));
                    carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), instrForReg2, true, __LINE__);

                    AddInstruction(iList, nw, instr->order);
                    free(nw);
                    glue::freeUDStructure(instrForReg0, true);
                    glue::freeUDStructure(instrForReg2, true);
                } else if (regsKnown.test(op0->base)) { // op0 is known
                    regsDefined.reset(op1->base);

                    ud_t *instrForReg0 = UDCreate::movRegToReg(op0->base, op1->base); // mov op0, op1
                    ud_t *instrForReg2 = UDCreate::movImmToReg(op1->base, constsRegisters->getRegisterValue(op0->base), instr, __LINE__);

                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), instrForReg0, true, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && instrForReg0 != nullptr) {
                        changeCount++;
                    }

                    Instruction *nw = InstrClone(instr);
                    Instruction *next = GetInstruction(iList, instr->next);
                    SetRegisterValue(nw, op0->base, GetRegisterValue(next, op0->base));
                    carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), instrForReg2, true, __LINE__);

                    AddInstruction(iList, nw, instr->order);
                    free(nw);
                    glue::freeUDStructure(instrForReg0, true);
                    glue::freeUDStructure(instrForReg2, true);
                } else { // op1 is known
                    regsDefined.reset(op0->base);

                    ud_t *instrForReg0 = UDCreate::movRegToReg(op1->base, op0->base); // mov op1, op0
                    ud_t *instrForReg2 = UDCreate::movImmToReg(op0->base, constsRegisters->getRegisterValue(op1->base), instr, __LINE__);

                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), instrForReg0, true, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && instrForReg0 != nullptr) {
                        changeCount++;
                    }

                    Instruction *nw = InstrClone(instr);
                    Instruction *next = GetInstruction(iList, instr->next);
                    SetRegisterValue(nw, op1->base, GetRegisterValue(next, op1->base));
                    carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), instrForReg2, true, __LINE__);

                    AddInstruction(iList, nw, instr->order);
                    free(nw);
                    glue::freeUDStructure(instrForReg0, true);
                    glue::freeUDStructure(instrForReg2, true);
                }
            }
            if (op0->type == UD_OP_REG && op1->type == UD_OP_REG && (regsKnown.test(op1->base) || (opcode == UD_Icmp && regsKnown.test(op0->base)))) {
                val = constsRegisters->getRegisterValue(op1->base);
                if (opcode == UD_Imov) {
                    udins_new = UDCreate::movImmToReg(reg2, val, instr, __LINE__);
                } else if (opcode == UD_Iadd) {
                    udins_new = UDCreate::addImmToReg(reg2, val);
                } else if (opcode == UD_Isub) {
                    udins_new = UDCreate::subImmFromReg(reg2, val);
                } else if (opcode == UD_Ixor) {
                    udins_new = UDCreate::xorImmWithReg(reg2, val);
                } else if (opcode == UD_Iand) {
                    udins_new = UDCreate::andImmWithReg(reg2, val);
                } else if (opcode == UD_Ior) {
                    udins_new = UDCreate::orImmWithReg(reg2, val);
                } else if (opcode == UD_Icmp) {
                    instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                    if (regsKnown.test(op0->base) && !instrHasFlag(instr, INSTR_FORWARD_TAINTED)) {
                        udins_new = UDCreate::cmpImmWithReg(op1->base, val);
                        instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                    }
                    if (regsKnown.test(op1->base) && op1->type == UD_OP_REG) {
                        if (!instrHasFlag(instr, INSTR_OP0_CONSTANT)) {
                            udins_new = UDCreate::cmpImmWithReg(op0->base, constsRegisters->getRegisterValue(op1->base));
                        }
                        instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                    }
                    if (udins_new) {
                        if (udins_new->operand[0].type == UD_OP_REG && !regsKnown.test(udins_new->operand[0].base)) {
                            instrRemoveFlag(instr, INSTR_OP0_CONSTANT);
                        }
                        if (udins_new->operand[1].type == UD_OP_REG && !regsKnown.test(udins_new->operand[1].base)) {
                            instrRemoveFlag(instr, INSTR_OP1_CONSTANT);
                        }
                    }
                    SaveInstrChange(iList, instr);
                } else if (opcode == UD_Itest) {
                    instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                    if (regsKnown.test(op0->base) && !instrHasFlag(instr, INSTR_FORWARD_TAINTED)) {
                        instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                    }
                    SaveInstrChange(iList, instr);
                } else if (opcode == UD_Imovzx) {
                    udins_new = UDCreate::movImmToReg(reg2, val, instr, __LINE__);
                } else if (opcode == UD_Imovsx) {
                    int sign = (val >> (UDRegSize(reg2) * 8 - 1));
                    if (sign) {
                        val |= (0xffffffff << (UDRegSize(reg2) * 8));
                    }
                    udins_new = UDCreate::movImmToReg(reg2, val, instr, __LINE__);
                } else if (opcode == UD_Ishl && op1->base != UD_R_CL) {
                    udins_new = UDCreate::shlImmToReg(reg2, val);
                } else if (opcode == UD_Ishr && op1->base != UD_R_CL) {
                    udins_new = UDCreate::shrImmToReg(reg2, val);
                } else if (opcode == UD_Iror) {
                    udins_new = UDCreate::rorImmToReg(reg2, val);
                } else if (opcode == UD_Irol) {
                    udins_new = UDCreate::rolImmToReg(reg2, val);
                } else if (opcode == UD_Ixadd) {
                    if (instrHasFlag(instr, INSTR_IN_USEDEF)) {
                        instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                        SaveInstrChange(iList, instr);
                    } else { // needs action!
                    }
                } else if (opcode == UD_Iimul) {
                    if (instr->uInstr.operand[2].type == UD_NONE) {
                        udins_new = UDCreate::imulImmToReg(reg2, val);
                        instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                        SaveInstrChange(iList, instr);
                    } else if ((instr->uInstr.operand[2].type == UD_OP_IMM || instr->uInstr.operand[2].type == UD_OP_CONST) &&
                               !instrHasFlag(instr, INSTR_COND_CF) && !instrHasFlag(instr, INSTR_BACKWARD_TAINTED)) {
                        udins_new = UDCreate::movImmToReg(reg2,
                                                          ArithOp(opcode, constsRegisters->getRegisterValue(op1->base), instr->uInstr.operand[2].lval.sdword,
                                                                  instr->uInstr.operand[2].size, &flagsKnown),
                                                          instr, __LINE__);
                        instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                        SaveInstrChange(iList, instr);
                    }
                } else if (opcode == UD_Iidiv) {
                    if (instr->uInstr.operand[2].type == UD_NONE) {
                        udins_new = UDCreate::imulImmToReg(reg2, val);
                        instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                        SaveInstrChange(iList, instr);
                    } else if ((instr->uInstr.operand[2].type == UD_OP_IMM || instr->uInstr.operand[2].type == UD_OP_CONST) &&
                               !instrHasFlag(instr, INSTR_COND_CF) && !instrHasFlag(instr, INSTR_BACKWARD_TAINTED)) {
                        udins_new = UDCreate::movImmToReg(reg2,
                                                          ArithOp(opcode, constsRegisters->getRegisterValue(op1->base), instr->uInstr.operand[2].lval.sdword,
                                                                  instr->uInstr.operand[2].size, &flagsKnown),
                                                          instr, __LINE__);
                        instrSetFlag(instr, INSTR_SIMPLIFIED_IGNORED, __LINE__);
                        SaveInstrChange(iList, instr);
                    }
                }

                /* introduce code for additional operations here */
            } else if (op0->type == UD_OP_REG && op1->type == UD_NONE && regsKnown.test(op0->base)) {
                val = constsRegisters->getRegisterValue(op0->base);
                if (opcode == UD_Ipush) {
                    udins_new = UDCreate::pushImm(op0->base, val);
                } else if (opcode == UD_Icall) {
                    udins_new = UDCreate::callAddr(val - 5);
                } else if (opcode == UD_Ijmp) {
                    udins_new = UDCreate::jumpNear(val, instr->eip);
                }
            } else if (op0->type == UD_OP_REG && (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST) && !instrHasFlag(instr, INSTR_FORWARD_TAINTED)) {
                if (opcode == UD_Itest || opcode == UD_Icmp) {
                    instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                    SaveInstrChange(iList, instr);
                }
            } else if (op1->type == UD_OP_REG && (op0->type == UD_OP_IMM || op0->type == UD_OP_CONST)) {
                if (opcode == UD_Itest || opcode == UD_Icmp) {
                    instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                    SaveInstrChange(iList, instr);
                }
            } else if (op0->type == UD_OP_MEM && op1->type == UD_OP_REG && regsKnown.test(op1->base)) {
                if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                    reg2 = UDOpIsRegister(op1);
                    val = constsRegisters->getRegisterValue(op1->base);
                    if (opcode == UD_Isub) {
                        udins_new = UDCreate::subImmFromMem(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Imov && instr->uInstr.bytes[0] != 0x64) { // prefix 0x64 is for fs register, not available in trace!
                        udins_new = UDCreate::movImmToMem(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Iadd) {
                        udins_new = UDCreate::addImmToMem(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Icmp) {
                        udins_new = UDCreate::cmpMemWithImm(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Ixor) {
                        udins_new = UDCreate::xorMemWithImm(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Iand) {
                        udins_new = UDCreate::andMemWithImm(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Ior) {
                        udins_new = UDCreate::orMemWithImm(instr->uInstr.bytes, reg2, val);
                    } else if (opcode == UD_Ixchg) {
                        if (!instrHasFlag(instr, INSTR_OP1_CONSTANT)) {
                            instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                        }
                    } else if (opcode == UD_Ixadd) {
                        if (instrHasFlag(instr, INSTR_IN_USEDEF) && !instrHasFlag(instr, INSTR_OP1_CONSTANT)) {
                            instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                        } else if (!instrHasFlag(instr, INSTR_IN_USEDEF) && instrHasFlag(instr, INSTR_READS_GLOBAL_MEM)) {
                            Instruction *next = FetchNextInstr(iList);
                            int newVal = GetRegisterValue(next, reg2);
                            ud_t *udins = UDCreate::movImmToReg(op1->base, newVal, instr, __LINE__);

                            auto *bytes = static_cast<unsigned char *>(malloc(instr->uInstr.length - 1));

                            bytes[0] = instr->uInstr.bytes[0];
                            for (uint8_t uLength = 1; uLength < instr->uInstr.length - 1; uLength++) {
                                bytes[uLength] = instr->uInstr.bytes[uLength + 1];
                            }
                            udins_new = UDCreate::movImmToMem(bytes, reg2, newVal + val);
                            free(bytes);
                            carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);

                            instrSetFlag(instr, INSTR_TMP0, __LINE__);
                            SaveInstrChange(iList, instr);
                            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr) {
                                changeCount++;
                            }
                            udins_new = glue::freeUDStructure(udins_new, true);

                            Instruction *nw = InstrClone(next);
                            nw->order = instr->order;
                            nw->addr = instr->addr;
                            nw->flags = 0;
                            carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins, false, __LINE__);
                            glue::freeUDStructure(udins, true);

                            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                                instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                            }

                            AddInstruction(iList, nw, instr->order);
                            free(nw);

                            SetCurrentInstr(iList, instr->next);
                        }
                    } else if (opcode == UD_Icmpxchg) {
                        if (instrHasFlag(instr, INSTR_IN_USEDEF) && !instrHasFlag(instr, INSTR_OP1_CONSTANT)) {
                            instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                                changeCount++;
                            }
                        } else if (instrHasFlag(instr, INSTR_READS_GLOBAL_MEM)) {
                            Instruction *next = FetchNextInstr(iList);
                            uint newVal = GetRegisterValue(next, reg2);
                            if (val == newVal) { // if reg is not changed, memory is loaded with reg
                                auto *bytes = static_cast<unsigned char *>(malloc(instr->uInstr.length));
                                bytes[0] = instr->uInstr.bytes[0];
                                for (uint8_t uLength = 1; uLength < instr->uInstr.length - 1; uLength++) {
                                    bytes[uLength] = instr->uInstr.bytes[uLength + 1];
                                }
                                udins_new = UDCreate::movImmToMem(bytes, reg2, val);
                            } else { // otherwise the reg is loaded with memory
                                udins_new = UDCreate::movImmToReg(reg2, newVal, instr, __LINE__);
                            }
                        }
                    }
                    /* introduce code for additional operations here */
                }
                /*
                 * Transforming instructions that use registers as memory pointers, replacing it with
                 * the same instr directly accessing the memory address.
                 */
            } else if (SIMPLIFY_INDIRECT_MEM_ACCESS && op0->type == UD_OP_REG && op1->type == UD_OP_MEM) {
                auto uses = definedMemoryRegistersForInstruction(instr);
                if (uses.any() && regsKnown.hasAllOf(DeobfRegisterUses(uses).reset(DeobfRegister::ESP))) {
                    if (opcode == UD_Imov && instrHasFlag(instr, INSTR_READS_MEM)) {
                        udins_new = UDCreate::movOffsetToReg(op0->base, instr->memUsedMin, OFFSET_TO_REG, instr->eip);
                    } else if (opcode == UD_Icmp) {
                        uint8_t type = instr->uInstr.bytes[0];
                        if (type == 0x66) {
                            type = instr->uInstr.bytes[1];
                        }
                        udins_new = UDCreate::cmpOffsetWithReg(instr->memUsedMin, op0->base, type);
                    }
                }
                if (regsKnown.test(op0->base)) {
                    if (opcode == UD_Icmp) {
                        if (op0->type == UD_OP_REG && !instrHasFlag(instr, INSTR_OP0_CONSTANT)) {
                            instrSetFlag(instr, INSTR_OP0_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                        }
                        if (op1->type == UD_OP_REG && !instrHasFlag(instr, INSTR_OP1_CONSTANT)) {
                            instrSetFlag(instr, INSTR_OP1_CONSTANT, __LINE__);
                            SaveInstrChange(iList, instr);
                        }
                    }
                }
            } else if (op1->type == UD_OP_REG && op0->type == UD_OP_MEM) {
                auto uses = definedMemoryRegistersForInstruction(instr);
                if (uses.any() && regsKnown.hasAllOf(DeobfRegisterUses(uses).reset(DeobfRegister::ESP))) {
                    if (opcode == UD_Icmp) {
                        uint8_t type = instr->uInstr.bytes[0];
                        if (type == 0x66) {
                            type = instr->uInstr.bytes[1];
                        }
                        udins_new = UDCreate::cmpOffsetWithReg(instr->memUsedMin, op0->base, type);
                    }
                }
            } else if (SIMPLIFY_INDIRECT_MEM_ACCESS && op1->type == UD_OP_IMM && op0->type == UD_OP_MEM) {
                auto uses = definedMemoryRegistersForInstruction(instr);
                if (uses.any() && regsKnown.hasAllOf(DeobfRegisterUses(uses).reset(DeobfRegister::ESP))) {
                    if (opcode == UD_Icmp) {
                        udins_new = UDCreate::cmpOffsetWithImm(instr->memUsedMin, op1->lval.sdword, instr->memUsedSize, instr->eip);
                    } else if (opcode == UD_Imov) {
                        udins_new = UDCreate::movImmToOffset(instr->memDefMin, op1->lval.sdword, instr->memDefSize, instr->eip);
                    }
                }
            } else if (op0->type == UD_OP_IMM && op1->type == UD_OP_MEM) {
                auto uses = definedMemoryRegistersForInstruction(instr);
                if (uses.any() && regsKnown.hasAllOf(DeobfRegisterUses(uses).reset(DeobfRegister::ESP))) {
                    if (opcode == UD_Icmp) {
                        udins_new = UDCreate::cmpOffsetWithImm(instr->memUsedMin, op0->lval.sdword, instr->memUsedSize, instr->eip);
                    }
                }
            } else if (opcode == UD_Ijmp && (
                                                (regsKnown.hasAllOf(regsUsed))
                                            )) {
                Instruction *next = FetchNextInstr(iList);
                udins_new = UDCreate::jumpNear(next->addr - 0x5, instr->eip);

                instrSetFlag(instr, INSTR_IS_DELETED, __LINE__); // a test, to simplify the control flow graph.
                SaveInstrChange(iList, instr);

                SetCurrentInstr(iList, instr->next);
            } else if (opcode == UD_Ijmp) {
                logger.log("Hit unknown jump! WARNING");
            } else if (opcode == UD_Ilea && regsKnown.hasAllOf(regsUsed)) {
                Instruction *next = FetchNextInstr(iList);
                udins_new = UDCreate::movImmToReg(op0->base, GetRegisterValue(next, op0->base), instr, __LINE__);
                SetCurrentInstr(iList, instr->next);
            }

            if (udins_new != nullptr) { // we have a possible simplification
                if (instrHasFlag(instr, INSTR_UNSIMPLIFIABLE) && instrHasFlag(instr, INSTR_SIMPLIFIED_IGNORED)) {
                    udins_new = glue::freeUDStructure(udins_new, true);
                } else {
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                    instrSetFlag(instr, INSTR_TMP0, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr) {
                        changeCount++;
                    }
                    udins_new = glue::freeUDStructure(udins_new, true);
                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);
                    op2 = &(instr->uInstr.operand[2]);

                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                }
                instrRemoveFlag(instr, INSTR_SIMPLIFIED_IGNORED);
            }
        }
        if (SIMPLIFY_INDIRECT_MEM_ACCESS && op0->type == UD_OP_MEM && op1->type == UD_OP_REG && definedMemoryRegistersForInstruction(instr).any()) {
            if (opcode == UD_Imov) {
                if (instrHasFlag(instr, INSTR_WRITES_MEM)) {
                    udins_new = UDCreate::movOffsetToReg(op1->base, instr->memDefMin, REG_TO_OFFSET, instr->eip);

                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                    instrSetFlag(instr, INSTR_TMP0, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr)
                        changeCount++;
                    udins_new = glue::freeUDStructure(udins_new, true);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                }
            }
        } else if (SIMPLIFY_INDIRECT_MEM_ACCESS && op1->type == UD_OP_MEM && op0->type == UD_OP_REG && definedMemoryRegistersForInstruction(instr).any()) {
            if (opcode == UD_Imov) {
                if (instrHasFlag(instr, INSTR_READS_MEM)) {
                    udins_new = UDCreate::movOffsetToReg(op0->base, instr->memUsedMin, OFFSET_TO_REG, instr->eip);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                    instrSetFlag(instr, INSTR_TMP0, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr)
                        changeCount++;
                    udins_new = glue::freeUDStructure(udins_new, true);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                }
            }
        } else if (SIMPLIFY_INDIRECT_MEM_ACCESS && op0->type == UD_OP_MEM && op1->type == UD_NONE &&
                   definedMemoryRegistersForInstruction(instr).reset(DeobfRegister::ESP).any()) { // push [ebx], pop [ebx]
            if (opcode == UD_Ipush) {
                udins_new = UDCreate::pushOffset(instr->uInstr.adr_mode / 8, instr->memUsedMin, instr->eip);
                carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                instrSetFlag(instr, INSTR_TMP0, __LINE__);
                SaveInstrChange(iList, instr);
                if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr) {
                    changeCount++;
                }
                udins_new = glue::freeUDStructure(udins_new, true);
                regsUsed = usedRegistersForInstruction(iList, instr);
            } else if (SIMPLIFY_INDIRECT_MEM_ACCESS && opcode == UD_Ipop) {
                udins_new = UDCreate::popOffset(instr->uInstr.adr_mode / 8, instr->memDefMin, instr->eip);
                carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                instrSetFlag(instr, INSTR_TMP0, __LINE__);
                SaveInstrChange(iList, instr);
                if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr) {
                    changeCount++;
                }
                udins_new = glue::freeUDStructure(udins_new, true);
                regsUsed = usedRegistersForInstruction(iList, instr);
            }
        }

        if (opcode == UD_Ixor && (reg1 = UDOpIsRegister(op0)) != UD_NONE && reg1 == UDOpIsRegister(op1)) {
            ud_t *udins = UDCreate::movImmToReg(reg1, 0, instr, __LINE__);
            carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, false, __LINE__);
            SaveInstrChange(iList, instr);
            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins != nullptr) {
                changeCount++;
            }
            glue::freeUDStructure(udins, true);
            opcode = instr->uInstr.mnemonic;
            op0 = &(instr->uInstr.operand[0]);
            op1 = &(instr->uInstr.operand[1]);
        }

        // The MOV should have a valid op0 and the first operand should be either IMM or CONST.
        bool isQualifiedMOV = opcode == UD_Imov && (reg1 = UDOpIsRegister(op0)) != UD_NONE && (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST);
        if (opcode == UD_Imov) {
            DEBUGLINE(10, fmt::format("Qualified mov? {:#x} - isQualifiedMOV: {} - {} && {} && ({} || {})", instr->addr, isQualifiedMOV, opcode == UD_Imov,
                                      ((reg1 = UDOpIsRegister(op0)) != UD_NONE), op1->type == UD_OP_IMM, op1->type == UD_OP_CONST));
        }
        if (instrHasFlag(instr, INSTR_REGDEF_KNOWN) || (opcode == UD_Icpuid) || isQualifiedMOV) { // second part is for instructions not being simplified but operands are known!
            if (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST) {
                val = op1->lval.sdword;
            } else {
                val = GetRegisterValue(instr, UD_R_ESP);
            }
            const DeobfRegisterUses &uses = constsRegisters->setRegisterValue(reg1, val);
            for (auto &u : uses.affectedRegisters()) {
                DEBUG(3, fmt::format("Setting {} at {} - {}", u, instr->order, *instr));
            }
            regsKnown |= uses;
        } else if (relatedRegistersLower(regsDefined).hasAnyOf(regsKnown)) {
            const DeobfRegisterUses &toReset = relatedRegistersHigher(regsDefined) | relatedRegistersLower(regsDefined);
	    for (auto &u : toReset.affectedRegisters()) {
                DEBUG(3, fmt::format("Resetting {} at {} - {}", u, instr->order, *instr));
            }
            regsKnown.reset(toReset);
        }

        if (instr->order < iList->last && ((instr->esp > previousESP) /*|| opcode == UD_Icall || retChange*/)) {
        }
        previousESP = instr->esp;

        ///////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////
        /*SIMPLIFYCONDITIONALJUMPA*/
        flagsDef = FlagsDef(instr);
        PSW_BITVECTOR flagsUsed = FlagsUsed(instr);
        Instruction *iins1;

        if (flagsDef && !(instrHasFlag(instr, INSTR_READS_MEM) || regsUsed.any() || flagsUsed)) {
            // instructions like cld which just change flag status, not depending on anything
            instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
            SaveInstrChange(iList, instr);
        }
        if (flagsDef && !instrHasFlag(instr, INSTR_FORWARD_TAINTED)) {
            flagsKnown |= flagsDef;
            if (regsDefined.none() && !instrHasFlag(instr, INSTR_WRITES_MEM)) {
                instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                SaveInstrChange(iList, instr);
            }
        } else if (!(instrHasFlag(instr, INSTR_TMP3) && (instr->uInstr.mnemonic == UD_Iadd || instr->uInstr.mnemonic == UD_Isub) &&
                     instr->uInstr.operand[1].type == UD_OP_IMM)) {
            flagsKnown &= ~flagsDef;
        }
        if (flagsUsed && (flagsUsed & flagsKnown) == flagsUsed) {
            instrSetFlag(instr, INSTR_FLAGS_KNOWN, __LINE__);
            SaveInstrChange(iList, instr);
        }
        if (instrHasFlag(instr, INSTR_FLAGS_KNOWN) && opcode == UD_Ipushfd) {
            SetAddrAsConstWithValue(iList, instr->memDefMin, getByteWidth(DeobfRegisterWidth::lower32bit), 0x202,
                                    __LINE__); // TODO: don't know the value that is being pushed!
        }
        if (instr->uInstr.mnemonic == UD_Iclc) {
            flagsKnown |= flagsDef;
        }
        if (instr->uInstr.mnemonic == UD_Icmc && (flagsKnown & flagsUsed) == flagsUsed) {
            flagsKnown |= flagsDef;
        }
        if (opcode == UD_Ixor || opcode == UD_Iand || opcode == UD_Itest || opcode == UD_Ior) { // these instructions set CF and OF flags to 0!
            flagsKnown |= (PSW_CF | PSW_OF);
        }
        if (IsCondJump(instr)) {
            if ((flagsUsed & flagsKnown) == flagsUsed && !instrHasFlag(instr, INSTR_UNSIMPLIFIABLE)) {
                op0 = &(instr->uInstr.operand[0]);
                Instruction *nextInstr = FetchNextInstr(iList);
                if (nextInstr && op0->lval.sdword + instr->uInstr.length + instr->addr == nextInstr->addr) { // jumpNear has been taken
                    udins_new = UDCreate::jumpNear(nextInstr->addr - 5, instr->eip);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                    if (instr->uInstr.mnemonic != UD_Ijmp) {
                        logger.log(fmt::format("[SimplifyConditionalJumps] Error: in creating jmp instr. {}: {}", nextInstr->order, *nextInstr));
                    }
                    instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins_new != nullptr) {
                        changeCount++;
                    }
                    glue::freeUDStructure(udins_new, true);
                } else {
                    instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                    SaveInstrChange(iList, instr);
                }
                SetCurrentInstr(iList, instr->next);
            }
            /*
             * check http://css.csail.mit.edu/6.858/2011/readings/i386/SETcc.htm
             * there are lots of them!
             */
        } else if (InstrIsSetOnCondition(instr->uInstr.mnemonic) && (flagsUsed & flagsKnown) == flagsUsed) {
            if (instr->uInstr.operand[0].type == UD_OP_REG) {
                enum ud_type reg;
                reg = instr->uInstr.operand[0].base;
                Instruction *next = FetchNextInstr(iList);
                int imm = GetRegisterValue(next, reg);
                SetCurrentInstr(iList, instr->next);

                ud_t *udins = UDCreate::movImmToReg(reg, imm, instr, __LINE__);
                carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, false, __LINE__);
                SaveInstrChange(iList, instr);
                glue::freeUDStructure(udins, true);
            }
        } else if (instr->uInstr.mnemonic == UD_Isetg && (flagsUsed & flagsKnown) == flagsUsed) {
            if (instr->uInstr.operand[0].type == UD_OP_REG) { // could be memory!
                enum ud_type reg;
                reg = instr->uInstr.operand[0].base;
                Instruction *next = FetchNextInstr(iList);
                int imm = GetRegisterValue(next, reg);
                SetCurrentInstr(iList, instr->next);

                ud_t *udins = UDCreate::movImmToReg(reg, imm, instr, __LINE__);
                carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, false, __LINE__);
                SaveInstrChange(iList, instr);
                glue::freeUDStructure(udins, true);
            }

        } else {
            // fprintf(stderr, "SimplifyConditionalJumps: setnz m8
            // unhandled: %d\n", iins->order);
        }
        /*SIMPLIFYCONDITIONALJUMPA*/
        ///////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////

        /*REMOVEUNNECESSARYPUSHESANDPOPS*/
        ///////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////
        push = flags = 0;
        bool pushpopChange = false;

        if (opcode == UD_Ipush || opcode == UD_Ipushfd) {
            if (opcode == UD_Ipush) {
                push = 1;
            } else {
                flags = 1;
            }

            reg1 = UDOpIsRegister(op0);
            regsDisallowed = relatedRegistersLower(toDeobfRegister(reg1));

            memDef = memoryDefined(iList, instr);
            int j = first + 1;
            bool shouldContinue = true;
            while (j < last && shouldContinue) {
                Instruction *nextInstr = FetchNextInstr(iList);
                if (nextInstr->order <= iList->last) {
                    j = nextInstr->order;
                }
                enum ud_mnemonic_code opcode2 = nextInstr->uInstr.mnemonic;
                op1 = &(nextInstr->uInstr.operand[0]);
                memUsed = memoryUsed(iList, nextInstr);
                flagsDef = FlagsDef(nextInstr);
                auto ws = memoryDefined(iList, nextInstr);
                if (push && opcode2 == UD_Inot && shouldContinue && memUsed->isSubsetOf(memDef)) {
                    Instruction *tmp = FetchNextInstr(iList);
                    reg2 = UDOpIsRegister(&tmp->uInstr.operand[0]);
                    if (tmp->uInstr.mnemonic == UD_Ipop && reg1 == reg2 && reg1 != UD_NONE) {
                        instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                        instrSetFlag(tmp, INSTR_IS_DELETED, __LINE__);
                        instrSetFlag(instr, INSTR_TMP1, __LINE__);
                        instrSetFlag(tmp, INSTR_TMP1, __LINE__);
                        SaveInstrChange(iList, instr);
                        SaveInstrChange(iList, tmp);

                        ud_t *new_ins = nullptr;
                        if (memDef == memUsed) {
                            new_ins = UDCreate::notOnReg(reg1);
                        } else if (nextInstr->memUsedSize == 2 || nextInstr->memUsedSize == 1) {
                            new_ins = UDCreate::notOnReg(UDSubRegister(reg1, nextInstr->memUsedSize));
                        }

                        carefulCopyUDins2InsStr(iList, nextInstr, &(nextInstr->uInstr), new_ins, false, __LINE__);
                        SaveInstrChange(iList, nextInstr);
                        if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && new_ins != nullptr)
                            changeCount++;
                        glue::freeUDStructure(new_ins, true);
                    }
                    SetCurrentInstr(iList, nextInstr->next);
                }
                if (push && opcode2 == UD_Ipop && shouldContinue && memDef == memUsed) {
                    reg2 = UDOpIsRegister(op1);
                    if (!(reg1 == UD_NONE || reg2 == UD_NONE)) {

                        if (reg2 != reg1) {
                            shouldContinue = false;

                            ud_t *udins = UDCreate::movRegToReg(reg2, reg1);
                            carefulCopyUDins2InsStr(iList, nextInstr, &(nextInstr->uInstr), udins, true, __LINE__);
                            instrSetFlag(nextInstr, INSTR_TMP1, __LINE__);
                            SaveInstrChange(iList, nextInstr);
                            glue::freeUDStructure(udins, true);

                            SetCurrentInstr(iList, instr->next);
                            instrSetFlag(instr, INSTR_TMP1, __LINE__);
                            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                            SaveInstrChange(iList, instr);

                            break;
                        } else if (instr->esp == nextInstr->esp + UDRegSize(reg1)) {
                            ud_t *udins = UDCreate::subImmFromReg(UD_R_ESP, UDRegSize(reg1));
                            carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, true, __LINE__);
                            instrSetFlag(instr, INSTR_TMP1, __LINE__);
                            SaveInstrChange(iList, instr);
                            glue::freeUDStructure(udins, true);
                            udins = UDCreate::addImmToReg(UD_R_ESP, UDRegSize(reg1));
                            carefulCopyUDins2InsStr(iList, nextInstr, &(nextInstr->uInstr), udins, true, __LINE__);
                            instrSetFlag(nextInstr, INSTR_TMP1, __LINE__);
                            SaveInstrChange(iList, nextInstr);
                            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && udins != nullptr) {
                                changeCount++;
                            }
                            glue::freeUDStructure(udins, true);
                        }
                    } else if (instr->uInstr.operand[0].type == UD_OP_MEM && nextInstr->uInstr.operand[0].type == UD_OP_MEM) {
                        Instruction *nw;
                        ud_t *tmpUD;
                        enum ud_type reg;
                        int size = instr->memUsedSize;
                        if (size == 4) {
                            reg = UD_R_EAX;
                        } else if (size == 2) {
                            reg = UD_R_AX;
                        } else {
                            reg = UD_R_AL;
                        }

                        nw = InstrClone(instr);
                        tmpUD = UDCreate::pushReg(DeobfRegister::EAX); // save eax first!
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), tmpUD, true, __LINE__);
                        nw->addr = instr->addr - 1;
                        AddInstruction(iList, nw, instr->prev); // insert it before the arithmetic instr!
                        glue::freeUDStructure(tmpUD, true);
                        free(nw);
                        instr->esp -= 4; // allocate stack!

                        // copy mem1 to eax first!
                        tmpUD = UDCreate::movOffsetToReg(reg, instr->memUsedMin, OFFSET_TO_REG, instr->eip);
                        carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), tmpUD, true, __LINE__);
                        SaveInstrChange(iList, instr);
                        glue::freeUDStructure(tmpUD, true);

                        // copy eax to mem2!
                        nw = InstrClone(instr);
                        tmpUD = UDCreate::movOffsetToReg(reg, nextInstr->memDefMin, REG_TO_OFFSET, nextInstr->eip);
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), tmpUD, true, __LINE__);
                        nw->addr = instr->addr + 1;
                        AddInstruction(iList, nw, instr->order);
                        glue::freeUDStructure(tmpUD, true);
                        free(nw);

                        // pop saved eax!
                        nw = InstrClone(instr);
                        tmpUD = UDCreate::popReg(DeobfRegister::EAX);
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), tmpUD, true, __LINE__);
                        nw->addr = instr->addr + 2;
                        AddInstruction(iList, nw, instr->next); // insert it before the arithmetic instr!
                        glue::freeUDStructure(tmpUD, true);
                        free(nw);
                        SetCurrentInstr(iList, instr->prev);

                        instrSetFlag(nextInstr, INSTR_IS_DELETED, __LINE__);
                        SaveInstrChange(iList, nextInstr);
                        pushpopChange = true;
                    }
                } else if (flags && opcode2 == UD_Ipopfd && shouldContinue && instr->memDefMin == nextInstr->memUsedMin) {
                    instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                    instrSetFlag(nextInstr, INSTR_IS_DELETED, __LINE__);
                    instrSetFlag(instr, INSTR_TMP1, __LINE__);
                    instrSetFlag(nextInstr, INSTR_TMP1, __LINE__);
                    SaveInstrChange(iList, instr);
                    SaveInstrChange(iList, nextInstr);
                    changeCount += 2;
                }
                if ((!ws->empty() && memDef->overlapsWith(ws)) || nextInstr->esp >= instr->esp) {
                    shouldContinue = false;
                    break;
                }
                regsUsed = relatedRegistersLower(usedRegistersForInstructionAndSP(iList, nextInstr));
                regsDefined = relatedRegistersLower(definedRegistersForInstructionAndSP(iList, nextInstr));
                if (!flags && regsDefined.hasAnyOf(regsDisallowed) && !((opcode2 == UD_Iadd || opcode2 == UD_Isub) && op1->base == UD_R_ESP)) {
                    shouldContinue = false;
                    break;
                }
                if (flags && (flagsDef)) {
                    shouldContinue = false;
                    break;
                }
                /*
                 * For now, we [conservatively] consider _any_ write to memory
                 * as possibly writing to the stack.	This can and should be
                 * made more discriminating.
                 */
            }
        }

        if (!pushpopChange) {
            SetCurrentInstr(iList, instr->next);
        }
        /*REMOVEUNNECESSARYPUSHESANDPOPS*/
        ///////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////
    }
    logger.log(fmt::format("[PropagateConstants]: propagated to {} instructions", changeCount));
    return changeCount;
}

bool DefinitionIsGuaranteed(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    Instruction *prev;
    int i, window = 0;
    enum ud_mnemonic_code opcode;
    std::unique_ptr<deobf::library::writeset::WriteSet> nMemUsed, nMemDef, nMemTarget, nMemTmp;

    opcode = instr->uInstr.mnemonic;

    if (opcode == UD_Ileave || opcode == UD_Ipopad || opcode == UD_Ipopa || IsStringOperation(instr)) {
        return false;
    }

    if (opcode == UD_Ipopfd) { // handle popfd differently, if it reaches all the way up to a pushfd!
        nMemTarget = memoryUsed(iList, instr);
        for (i = instr->order - 1; i >= 0 && (window++ < 50) && (prev = FetchPrevInstr(iList)) != nullptr; i--) {
            nMemDef = memoryDefined(iList, prev);
            if (instrHasFlag(prev, INSTR_WRITES_MEM) && nMemTarget->overlapsWith(nMemDef)) {
                if (instrHasFlag(prev, INSTR_READS_MEM)) {
                    nMemUsed = memoryUsed(iList, prev);

                    nMemTarget->subtract(nMemDef);
                    nMemTarget->merge(nMemUsed);
                } else {
                    if (prev->uInstr.mnemonic == UD_Ipushfd) {
                        instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                        instrSetFlag(prev, INSTR_IS_DELETED, __LINE__);
                        SaveInstrChange(iList, instr);
                        SaveInstrChange(iList, prev);
                        return true;
                    }
                }
            } else {
                PSW_BITVECTOR flagsDef = FlagsDef(prev);
                if (flagsDef) {
                    return false;
                }
            }
        }
    }
    return false;
}

uint8_t GetStackSize(Instruction *instr) {
    if (instr->uInstr.bytes[0] == 0x66) {
        return 2;
    }
    if (instr->uInstr.mnemonic == UD_Ipush && instr->uInstr.operand[0].type == UD_OP_IMM) {
        return instr->memDefSize;
    }
    return getRegisterByteWidth(toDeobfRegister(instr->uInstr.operand[0].base));
}

int RemoveDeadCode(const std::shared_ptr<InstrList>& iList, int first, int last, uint64_t *numInstructions) {
    Instruction *instr, *next, *prev = nullptr;
    ud_mnemonic_code opcode;
    ud_operand_t *op0, *op1;
    PSW_BITVECTOR flagsDef, flagsUsed, flagsAlive;
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    DeobfRegisterUses regsAlive{};

    int removed = 0;
    int changeCount = 0;

    regsAlive.reset();
    flagsAlive = 0;
    ClearConstantPages(iList);

    instr = GetInstruction(iList, first);

    SetCurrentInstr(iList, last);
    while ((instr = FetchPrevInstr(iList)) != nullptr) {
        if (!instrHasFlag(prev, INSTR_IN_BASE_MODULE) && instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            flagsAlive = 0;
            regsAlive.resetNonParameterRegisters();
        }

        if (prev && prev->addr == instr->addr && InstrCompare(prev, instr)) {
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            SaveInstrChange(iList, instr);
            continue;
        }
        removed = 0;
        flagsDef = FlagsDef(instr);
        flagsUsed = FlagsUsed(instr);
        regsDefined = definedRegistersForInstruction(iList, instr);
        regsUsed = usedRegistersForInstruction(iList, instr);
        if (instr->uInstr.mnemonic == UD_Ipushfd) {
            flagsUsed = 0x8d5;
        }
        if (!(flagsDef | flagsUsed) && regsDefined.none() && regsUsed.none() && instr->memUsedMin == 0 && instr->memDefMin == 0) {
            if (instr->uInstr.mnemonic == UD_Inop ||
                (instr->uInstr.mnemonic == UD_Ijmp && !instrHasFlag(instr, INSTR_UNSIMPLIFIABLE) && !instrHasFlag(instr, INSTR_USED_AS_CALL))) {
                instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                if (SaveInstrChange(iList, instr) && instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                    changeCount++;
                }
            } else if (handle_rop || instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                (*numInstructions)++;
            }
            continue;
        }
        opcode = instr->uInstr.mnemonic;
        op0 = &(instr->uInstr.operand[0]);
        op1 = &(instr->uInstr.operand[1]);

        if ((isPush(instr) || isPop(instr) || opcode == UD_Icall || opcode == UD_Iret)) {
            if (UDOpIsRegister(op0) == UD_R_ESP) {
                if (opcode == UD_Ipop) {
                    regsUsed.resetRelated(DeobfRegister::RSP);
                } else if (opcode == UD_Ipush) {
                    regsDefined.resetRelated(DeobfRegister::RSP);
                }
            } else {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }

        if ((!instrHasFlag(instr, INSTR_IN_USEDEF)) && !instrHasFlag(instr, INSTR_UNSIMPLIFIABLE) &&
            !instrHasFlag(instr, INSTR_UNTOUCHABLE)) { // just keep the first instruction of a function, need it when constructing cfg!
            bool producesData = (instrHasFlag(instr, INSTR_WRITES_MEM) && MemoryLocationIsLive(iList, instr->memDefMin, instr->memDefSize)) ||
                                (flagsDef & flagsAlive) != 0 || relatedRegistersLower(regsDefined).hasAnyOf(regsAlive);
            bool arithNoEffect = OpcodeIsArithWithNoEffect(opcode) && op1 != nullptr && (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST) &&
                                 op1->lval.sdword == 0 && !instrHasFlag(instr, INSTR_BACKWARD_TAINTED);
            if (!producesData || arithNoEffect || opcode == UD_Inop || opcode == UD_Ijmp) {
                if (opcode == UD_Icall && (next = FetchNextInstr(iList)) && !instrHasFlag(instr, INSTR_USED_AS_CALL)) {
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    ud_t *udins_new = UDCreate::subImmFromReg(UD_R_ESP, 4);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, true, __LINE__);
                    instrRemoveFlag(instr, INSTR_FORWARD_TAINTED);
                    SaveInstrChange(iList, instr);
                    udins_new = glue::freeUDStructure(udins_new, true);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                        changeCount++;
                    }
                } else if ((opcode == UD_Ipush || opcode == UD_Ipushfd)) {
                    if (opcode == UD_Ipushfd) {
                        instr->flagsUsed = 0;
                        instr->flagsDef = 0;
                    }

                    uint8_t stackSize = 0;
                    if (opcode == UD_Icall || opcode == UD_Ipushfd) {
                        stackSize = 4;
                    } else {
                        stackSize = GetStackSize(instr);
                    }
                    ud_t *udins = UDCreate::subImmFromReg(UD_R_ESP, stackSize);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, true, __LINE__);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    instrRemoveFlag(instr, INSTR_FORWARD_TAINTED);
                    SaveInstrChange(iList, instr);
                    glue::freeUDStructure(udins, true);

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                } else if ((opcode == UD_Ipop || opcode == UD_Ipopfd || opcode == UD_Iret) && !instrHasFlag(instr, INSTR_FORWARD_TAINTED)) {
                    if (opcode == UD_Ipopfd) {
                        instr->flagsUsed = 0;
                        instr->flagsDef = 0;
                    }

                    uint8_t stackSize = 0;
                    if (opcode == UD_Ipopfd || opcode == UD_Iret) {
                        stackSize = 4;
                    } else {
                        stackSize = GetStackSize(instr);
                    }
                    ud_t *udins = UDCreate::addImmToReg(UD_R_ESP, stackSize);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, true, __LINE__);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    instrRemoveFlag(instr, INSTR_FORWARD_TAINTED);
                    SaveInstrChange(iList, instr);
                    glue::freeUDStructure(udins, true);

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                } else if (!IsControlFlowInstr(instr) && !instrHasFlag(instr, INSTR_USED_AS_CALL) &&
                           !((opcode == UD_Iadd || opcode == UD_Isub) && op0->type == UD_OP_REG && op0->base == UD_R_ESP)) {
                    instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && SaveInstrChange(iList, instr)) {
                        changeCount++;
                    }
                    removed = 1;
                }
            } else if (opcode == UD_Ixchg) { // this instruction has two dests and one of them maybe dead!
                ud_t *udins_new = nullptr;
                if (op0->type == UD_OP_MEM || op1->type == UD_OP_MEM) { // one of the operands is memory, the other is got to be reg
                    auto r = definedNonMemoryRegistersForInstruction(iList, instr);
                    if (!MemLocIsConstant(iList, instr->memDefMin, instr->memDefSize)) {
                        udins_new = UDCreate::movOffsetToReg(op1->base, instr->memDefMin, OFFSET_TO_REG, instr->eip);
                    } else if (r.hasNoneOf(regsAlive)) { // so mem loc is alive
                        udins_new = UDCreate::movOffsetToReg(r.toUDRegister(), instr->memDefMin, REG_TO_OFFSET, instr->eip);
                    }
                } else {                              // both are reg
                    if (!regsAlive.test(op0->base)) { // first op is dead
                        udins_new = UDCreate::movRegToReg(op1->base, op0->base);
                    } else if (!regsAlive.test(op1->base)) {
                        udins_new = UDCreate::movRegToReg(op0->base, op1->base);
                    }
                }
                if (udins_new != nullptr) {
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, false, __LINE__);
                    glue::freeUDStructure(udins_new, true);
                    SaveInstrChange(iList, instr);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);
                }
            }
        }
        if (instrHasFlag(instr, INSTR_MAYBE_DELETED)) {
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            instrSetFlag(instr, INSTR_TMP3, __LINE__);
            SaveInstrChange(iList, instr);
            removed = 1;
        }

        if (!removed) {
            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && !InstrIsControlTransfer(iList, instr) &&
                (regsDefined.any() || (opcode == UD_Imov && instrHasFlag(instr, INSTR_WRITES_MEM)) || opcode == UD_Ipopfd ||
                 (opcode == UD_Ipush && instrHasFlag(instr, INSTR_READS_MEM)) || (opcode == UD_Ipop && instrHasFlag(instr, INSTR_WRITES_MEM))) &&
                opcode != UD_Ixchg && opcode != UD_Irdtsc) {
                if (op1->type != UD_OP_IMM && DefinitionIsGuaranteed(iList, instr)) {
                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                    SetCurrentInstr(iList, instr->prev);
                }
            }
        }

        if (handle_rop || instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            if (!instrHasFlag(instr, INSTR_IS_DELETED))
                (*numInstructions)++; // add whenever want to fetch an instr!
        }
#if IGNORE_API_CALLS
        else {
            prev = instr;
            continue;
        }
#endif

        if ((instr->uInstr.mnemonic == UD_Ishr || instr->uInstr.mnemonic == UD_Ishl) && instr->uInstr.operand[1].type == UD_OP_IMM &&
            instr->uInstr.operand[1].lval.sdword > 1) {
            flagsDef &= ~PSW_OF;
        }

        if ((flagsDef & flagsAlive)) {
            if (!instrHasFlag(instr, INSTR_IN_USEDEF)) {
                instrSetFlag(instr, INSTR_IN_USEDEF, __LINE__);
                SaveInstrChange(iList, instr);
            }
        } else {
            if (instrHasFlag(instr, INSTR_IN_USEDEF)) {
                instrRemoveFlag(instr, INSTR_IN_USEDEF);
                SaveInstrChange(iList, instr);
            }
        }
        if (!removed) {
            flagsAlive = (flagsAlive & ~flagsDef) | flagsUsed;
            regsAlive.reset(relatedRegistersLower(regsDefined)).set(relatedRegistersLower(regsUsed));

            if (instrHasFlag(instr, INSTR_WRITES_MEM) && instr->memDefMin > 0x100) {
                SetMemoryLocationDead(iList, instr->memDefMin, instr->memDefSize);
            }
            if (instrHasFlag(instr, INSTR_READS_MEM)) {
                SetMemoryLocationLive(iList, instr->memUsedMin, instr->memUsedSize);
            }

        } else {
            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                iList->numBaseModuleInstrs--;
            }
        }
        prev = instr;
    }
    logger.log(fmt::format("[RemoveDeadCodeIntraBbl]: removed {} instructions", changeCount));
    return changeCount;
}

int RemoveOnlyDeadCode(const std::shared_ptr<InstrList>& iList, int first, int last, uint64_t *numInstructions) {
    Instruction *instr, *next, *prev = nullptr;
    ud_mnemonic_code opcode;
    ud_operand_t *op0, *op1;
    PSW_BITVECTOR flagsDef, flagsUsed, flagsAlive;
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    DeobfRegisterUses regsAlive{};
    int removed = 0;
    int changeCount = 0;

    regsAlive.reset();
    flagsAlive = 0;
    ClearConstantPages(iList);

    instr = GetInstruction(iList, first);

    SetCurrentInstr(iList, last);
    while ((instr = FetchPrevInstr(iList)) != nullptr) {
        if (!instrHasFlag(prev, INSTR_IN_BASE_MODULE) && instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            flagsAlive = 0;
            regsAlive.resetNonParameterRegisters();
        }
        if (prev && prev->addr == instr->addr && InstrCompare(prev, instr)) {
            instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
            SaveInstrChange(iList, instr);
            continue;
        }

        removed = 0;
        flagsDef = FlagsDef(instr);
        flagsUsed = FlagsUsed(instr);
        regsDefined = definedRegistersForInstruction(iList, instr);
        regsUsed = usedRegistersForInstruction(iList, instr);

        if (!(flagsDef | flagsUsed) && regsDefined.none() && regsUsed.none() && instr->memUsedMin == 0 && instr->memDefMin == 0) {
            if (instr->uInstr.mnemonic == UD_Inop ||
                (instr->uInstr.mnemonic == UD_Ijmp && !instrHasFlag(instr, INSTR_UNSIMPLIFIABLE) && !instrHasFlag(instr, INSTR_USED_AS_CALL))) {
                instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                if (SaveInstrChange(iList, instr)) {
                    changeCount++;
                }
            } else if (handle_rop || instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                (*numInstructions)++;
            }
            continue;
        }
        opcode = instr->uInstr.mnemonic;
        op0 = &(instr->uInstr.operand[0]);
        op1 = &(instr->uInstr.operand[1]);

        if ((isPush(instr) || isPop(instr) || opcode == UD_Icall || opcode == UD_Iret)) {
            if (UDOpIsRegister(op0) == UD_R_ESP) {
                if (opcode == UD_Ipop) {
                    regsUsed.resetRelated(DeobfRegister::RSP);
                } else if (opcode == UD_Ipush) {
                    regsDefined.resetRelated(DeobfRegister::RSP);
                }
            } else {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }

        if (!instrHasFlag(instr, INSTR_IN_USEDEF) && !instrHasFlag(instr, INSTR_UNSIMPLIFIABLE) &&
            !instrHasFlag(instr, INSTR_UNTOUCHABLE)) { // just keep the producesData instruction of a function, need it when constructing cfg!
            bool producesData = (instrHasFlag(instr, INSTR_WRITES_MEM) && MemoryLocationIsLive(iList, instr->memDefMin, instr->memDefSize)) ||
                                (flagsDef & flagsAlive) != 0 || relatedRegistersLower(regsDefined).hasAnyOf(regsAlive);
            bool arithNoEffect = OpcodeIsArithWithNoEffect(opcode) && op1 != nullptr && (op1->type == UD_OP_IMM || op1->type == UD_OP_CONST) &&
                                 op1->lval.sdword == 0 && !instrHasFlag(instr, INSTR_BACKWARD_TAINTED);

            if (!producesData || arithNoEffect || opcode == UD_Inop || opcode == UD_Ijmp) {
                if (opcode == UD_Icall && (next = FetchNextInstr(iList)) && !instrHasFlag(instr, INSTR_USED_AS_CALL)) {

                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    ud_t *udins_new = UDCreate::subImmFromReg(UD_R_ESP, 4);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins_new, true, __LINE__);
                    SaveInstrChange(iList, instr);
                    udins_new = glue::freeUDStructure(udins_new, true);
                    changeCount++;

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                } else if ((opcode == UD_Ipush || opcode == UD_Ipushfd)) {
                    if (opcode == UD_Ipushfd) {
                        instr->flagsUsed = 0;
                        instr->flagsDef = 0;
                    }

                    uint8_t stackSize = 0;
                    if (opcode == UD_Icall || opcode == UD_Ipushfd) {
                        stackSize = 4;
                    } else {
                        stackSize = GetStackSize(instr);
                    }
                    ud_t *udins = UDCreate::subImmFromReg(UD_R_ESP, stackSize);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, true, __LINE__);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    SaveInstrChange(iList, instr);
                    glue::freeUDStructure(udins, true);

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                } else if ((opcode == UD_Ipop || opcode == UD_Ipopfd)) {
                    if (opcode == UD_Ipopfd) {
                        instr->flagsUsed = 0;
                        instr->flagsDef = 0;
                    }

                    uint8_t stackSize = 0;
                    if (opcode == UD_Ipopfd) {
                        stackSize = 4;
                    } else {
                        stackSize = GetStackSize(instr);
                    }
                    ud_t *udins = UDCreate::addImmToReg(UD_R_ESP, stackSize);
                    carefulCopyUDins2InsStr(iList, instr, &(instr->uInstr), udins, true, __LINE__);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    SaveInstrChange(iList, instr);
                    glue::freeUDStructure(udins, true);

                    opcode = instr->uInstr.mnemonic;
                    op0 = &(instr->uInstr.operand[0]);
                    op1 = &(instr->uInstr.operand[1]);

                    flagsDef = FlagsDef(instr);
                    flagsUsed = FlagsUsed(instr);
                    regsDefined = definedRegistersForInstruction(iList, instr);
                    regsUsed = usedRegistersForInstruction(iList, instr);
                } else if (!IsControlFlowInstr(instr) && !instrHasFlag(instr, INSTR_USED_AS_CALL) &&
                           !((opcode == UD_Iadd || opcode == UD_Isub) && op0->type == UD_OP_REG && op0->base == UD_R_ESP)) {

                    instrSetFlag(instr, INSTR_IS_DELETED, __LINE__);
                    instrSetFlag(instr, INSTR_TMP3, __LINE__);
                    SaveInstrChange(iList, instr);
                    if (instrHasFlag(instr, INSTR_IN_BASE_MODULE) && SaveInstrChange(iList, instr)) {
                        changeCount++;
                    }
                    removed = 1;
                }
            }
        }

        ////////////////////////////////////////////////////////////
        if (handle_rop || instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
            if (!instrHasFlag(instr, INSTR_IS_DELETED))
                (*numInstructions)++; // add whenever want to fetch an instr!
        }
#if IGNORE_API_CALLS
        else {
            prev = instr;
            continue;
        }
#endif

        if ((instr->uInstr.mnemonic == UD_Ishr || instr->uInstr.mnemonic == UD_Ishl) && instr->uInstr.operand[1].type == UD_OP_IMM &&
            instr->uInstr.operand[1].lval.sdword > 1) {
            flagsDef &= ~PSW_OF;
        }

        if ((flagsDef & flagsAlive)) {
            if (!instrHasFlag(instr, INSTR_IN_USEDEF)) {
                instrSetFlag(instr, INSTR_IN_USEDEF, __LINE__);
                SaveInstrChange(iList, instr);
            }
        } else {
            if (instrHasFlag(instr, INSTR_IN_USEDEF)) {
                instrRemoveFlag(instr, INSTR_IN_USEDEF);
                SaveInstrChange(iList, instr);
            }
        }
        if (!removed) {
            flagsAlive = (flagsAlive & ~flagsDef) | flagsUsed;
            regsAlive.reset(relatedRegistersLower(regsDefined)).set(relatedRegistersLower(regsUsed));

            if (instrHasFlag(instr, INSTR_WRITES_MEM) && instr->memDefMin > 0x100) {
                SetMemoryLocationDead(iList, instr->memDefMin, instr->memDefSize);
            }
            if (instrHasFlag(instr, INSTR_READS_MEM)) {
                SetMemoryLocationLive(iList, instr->memUsedMin, instr->memUsedSize);
            }

        } else {
            if (instrHasFlag(instr, INSTR_IN_BASE_MODULE)) {
                iList->numBaseModuleInstrs--;
            }
        }
        prev = instr;
    }
    return changeCount;
}

int SimplifyGlobalMems(const std::shared_ptr<InstrList>& iList) {
    Instruction *iins, *iins1;
    int N = 0;
    DeobfRegisterUses regsDefined{};
    DeobfRegisterUses regsUsed{};
    ud_t *udins_new = nullptr;

    ClearConstantPages(iList);

    iList->currentInstr = 0;
    while ((iins = FetchNextInstr(iList)) != nullptr) {
#if IGNORE_API_CALLS
        if (!handle_rop && !instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
            continue;
        }
#endif

        if (!instrHasFlag(iins, INSTR_READS_MEM) && !instrHasFlag(iins, INSTR_WRITES_MEM)) {
            continue;
        }

        regsUsed = definedNonMemoryRegistersForInstruction(iList, iins);
        regsDefined = definedRegistersForInstruction(iList, iins);

        if ((isPush(iins) || isPop(iins))) {
            if (iins->uInstr.operand[0].base == UD_R_ESP) {
                if (iins->uInstr.mnemonic == UD_Ipop) {
                    regsUsed.resetRelated(DeobfRegister::RSP);
                } else if (iins->uInstr.mnemonic == UD_Ipush) {
                    regsDefined.resetRelated(DeobfRegister::RSP);
                }
            } else {
                regsDefined.resetRelated(DeobfRegister::RSP);
                regsUsed.resetRelated(DeobfRegister::RSP);
            }
        }
        if (iins->uInstr.operand[0].base == UD_R_RIP && iins->uInstr.operand->type == UD_OP_MEM) {
            regsDefined.reset(DeobfRegister::RIP);
        }
        if (instrHasFlag(iins, INSTR_READS_MEM) && !MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize) &&
            !instrHasFlag(iins, INSTR_READS_TAINTED_MEM)) {
            if (!instrHasFlag(iins, INSTR_WRITES_MEM) && regsDefined.any() && iins->uInstr.mnemonic != UD_Icall && iins->uInstr.mnemonic != UD_Ipopad &&
                iins->uInstr.mnemonic != UD_Ipopa) {
                if (DeobfRegisterUses(regsDefined & ~regsUsed).reset(DeobfRegister::ESP).any()) {
                    auto memDest = deobf::library::instruction_utils::getImplicitMemoryDestinationRegisters(iins);
                    auto nonMemDest = regsDefined & ~memDest;
                    iins1 = GetInstruction(iList, iins->next);
                    int val = 0;
                    if ((iins->uInstr.mnemonic == UD_Imul || iins->uInstr.mnemonic == UD_Iimul) && iins->uInstr.operand[1].type == UD_NONE) {
                        val = GetRegisterValue(iins1, UD_R_EAX);
                        udins_new = UDCreate::movImmToReg(UD_R_EAX, val, iins, __LINE__); // change EAX reg

                        Instruction *edxInstr = InstrClone(iins);
                        edxInstr->eax = iins1->eax;
                        ud_t *edx_udis = UDCreate::movImmToReg(UD_R_EDX, iins1->edx, iins, __LINE__); // change EDX reg
                        carefulCopyUDins2InsStr(iList, edxInstr, &(edxInstr->uInstr), edx_udis, false, __LINE__);
                        edxInstr->flags = 0;
                        if (instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
                            instrSetFlag(edxInstr, INSTR_IN_BASE_MODULE, __LINE__);
                        }
                        AddInstruction(iList, edxInstr, iins->order);
                        free(edxInstr);
                        glue::freeUDStructure(edx_udis, true);
                    } else if (nonMemDest.any()) {
                        ud_type reg = nonMemDest.toUDRegister();
                        val = GetRegisterValue(iins1, reg);
                        udins_new = UDCreate::movImmToReg(reg, val, iins, __LINE__);
                    }
                    if (udins_new) {
                        carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udins_new, false, __LINE__);
                        SaveInstrChange(iList, iins);
                        udins_new = glue::freeUDStructure(udins_new, false);
                    }
                    if (memDest.any()) {
                        ud_type reg = memDest.toUDRegister();
                        udins_new = UDCreate::addImmToReg(reg, GetRegisterValue(iins1, reg) - GetRegisterValue(iins, reg));
                        Instruction *nw = InstrClone(iins1);
                        SetRegisterValue(nw, nonMemDest.toUDRegister(), val);
                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins_new, false, __LINE__);
                        nw->flags = 0;
                        if (instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
                            instrSetFlag(nw, INSTR_IN_BASE_MODULE, __LINE__);
                        }
                        AddInstruction(iList, nw, iins->order);
                        free(nw);
                        udins_new = glue::freeUDStructure(udins_new, true);
                    }

                    N++;
                } else if ((DeobfRegisterUses(regsDefined).reset(DeobfRegister::ESP)).any()) {
                    instrSetFlag(iins, INSTR_READS_GLOBAL_MEM, __LINE__);
                }
            } else if (instrHasFlag(iins, INSTR_WRITES_MEM)) {
                if (definedNonMemoryRegistersForInstruction(iList, iins).none()) { // like push [global_mem]
                    if (iins->uInstr.mnemonic == UD_Ipush) {
                        udins_new = UDCreate::pushImm(UD_R_EAX, 0);
                    } else {
                        udins_new = UDCreate::movImmToOffset(iins->memDefMin, 0, iins->memDefSize, iins->eip);
                    }
                    carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udins_new, true, __LINE__);
                    SaveInstrChange(iList, iins);

                    udins_new = glue::freeUDStructure(udins_new, true);
                } else { // like xadd, cmpxchg, add [global_mem], reg, inc [global_mem] etc.
                    if (iins->uInstr.mnemonic == UD_Ixadd || iins->uInstr.mnemonic == UD_Icmpxchg || iins->uInstr.mnemonic == UD_Icmpxchg8b) {
                        instrSetFlag(iins, INSTR_READS_GLOBAL_MEM, __LINE__);
                        instrSetFlag(iins, INSTR_OP0_CONSTANT, __LINE__);
                        SaveInstrChange(iList, iins);
                    } else if (iins->uInstr.mnemonic == UD_Ixchg) {
                        ud_type dest = (iins->uInstr.operand[0].type == UD_OP_REG ? iins->uInstr.operand[0].base : iins->uInstr.operand[1].base);
                        udins_new = UDCreate::movOffsetToReg(dest, iins->memDefMin, REG_TO_OFFSET, iins->eip);
                        carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udins_new, true, __LINE__);
                        SaveInstrChange(iList, iins);
                        glue::freeUDStructure(udins_new, true);

                        Instruction *nw = InstrClone(iins);
                        Instruction *next = GetInstruction(iList, iins->next);
                        udins_new = UDCreate::movImmToReg(dest, GetRegisterValue(next, dest), iins, __LINE__);

                        carefulCopyUDins2InsStr(iList, nw, &(nw->uInstr), udins_new, true, __LINE__);
                        AddInstruction(iList, nw, iins->order);
                        free(nw);
                        udins_new = glue::freeUDStructure(udins_new, true);
                        UnsetConstAddr(iList, iins->memDefMin, iins->memDefSize, __LINE__);
                        N++;
                        continue;
                    } else {
                        if (iins->uInstr.operand[0].type == UD_OP_MEM) {
                            instrSetFlag(iins, INSTR_OP0_CONSTANT, __LINE__);
                        } else if (iins->uInstr.operand[1].type == UD_OP_MEM) {
                            instrSetFlag(iins, INSTR_OP1_CONSTANT, __LINE__);
                        }
                        SaveInstrChange(iList, iins);
                    }
                }
            } else if (instrHasFlag(iins, INSTR_IN_BASE_MODULE) && (iins->uInstr.mnemonic == UD_Iret || iins->uInstr.mnemonic == UD_Icall) &&
                       !instrHasFlag(iins, INSTR_FORWARD_TAINTED)) {

                Instruction *next = GetInstruction(iList, iins->next);
                udins_new = UDCreate::jumpNear(next->addr - 5, iins->eip);

                carefulCopyUDins2InsStr(iList, iins, &(iins->uInstr), udins_new, true, __LINE__);
                SaveInstrChange(iList, iins);
                udins_new = glue::freeUDStructure(udins_new, true);
            } else {
                if (iins->uInstr.operand[0].type == UD_OP_MEM) {
                    instrSetFlag(iins, INSTR_OP0_CONSTANT, __LINE__);
                } else if (iins->uInstr.operand[1].type == UD_OP_MEM) {
                    instrSetFlag(iins, INSTR_OP1_CONSTANT, __LINE__);
                }
                SaveInstrChange(iList, iins);
            }
        }
        if (instrHasFlag(iins, INSTR_WRITES_MEM) && !MemLocIsConstant(iList, iins->memDefMin, iins->memDefSize)) {
            if (!instrHasFlag(iins, INSTR_READS_MEM)) {
                SetAddrAsConst(iList, iins->memDefMin, iins->memDefSize);
            } else {
                if (MemLocIsConstant(iList, iins->memUsedMin, iins->memUsedSize)) {
                    SetAddrAsConst(iList, iins->memDefMin, iins->memDefSize);
                }
            }
        }
    }
    return N;
}

void applySimplifications(const std::shared_ptr<InstrList>& iList) {
    logger.startPhase(PHASE_SIMPL);
    bool chg, codeRemoved;
    uint64_t numProcessed = 0, prevNumProcessed = 0;
    int last = iList->lastInstr;
    int first = iList->firstInstr;
    int loop = iList->loop + 1;
    uint sameCount = 0, lastPropagations = 0;

    RemoveOnlyDeadCode(iList, first, last, &numProcessed);

    do {
        chg = false;
        codeRemoved = false;

        if (loop > 1) { // Skip first iteration as we already removed dead code before the loop
            if (RemoveDeadCode(iList, first, last, &numProcessed) > 0) {
                chg = true;
                codeRemoved = true;
            }
        }

        uint propagations = PropagateConstants(iList, first, last);
        if (propagations > 0) {
            chg = true;
        }
        numProcessed += propagations;

        iList->loop = loop;
        loop++;

        // Break if no changes were made
        if (numProcessed == prevNumProcessed) {
            break;
        }
        // Break if hard limit (set by user) was reached
        if (SimplifyLoopMax > 0 && loop > SimplifyLoopMax) {
            logger.log(fmt::format("Quitting loop because threshold of {} loops is reached", SimplifyLoopMax));
            break;
        }
        // Break if less than 2 instructions were changed in total
        if (numProcessed < 2) {
            break;
        }

        if (propagations == lastPropagations) {
            sameCount++;
        } else {
            sameCount = 0;
        }

        if (sameCount >= 10 && !codeRemoved) {
            logger.log("Exceeded 10 loops with same propagation count and no code removal!");
            break;
        }

        prevNumProcessed = numProcessed;
        lastPropagations = propagations;
    } while (chg);

    logger.endPhase();
}

