/*
 * File: main.cc
 * Author: Babak Yadegari, Willem Van Iseghem
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#include <getopt.h>
#include <sys/mman.h>

#include <cassert>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <set>
#include <utility>

#include <fmt/chrono.h>

#include <flags.h>
#include <persistent_storage.h>
#include <directory_utils.h>
#include <taint.h>

#include "array_list.h"
#include "flowgraph.h"
#include "instr.h"
#include "lynx_types.h"
#include "print.h"
#include "read.h"
#include "simplify.h"

namespace taint = deobf::library::taint;

bool handle_rop;

bool InstrFileExists = false; // true if using existing instrFile

extern bool TraceIsMultiThreaded;
extern ArrayList *traceThreads;

int SimplifyLoopMax = -1;
bool DebugCounterUse = false;
int DebugCounter = 0;
bool uGhentImprovements = false;
int minInstruction = -1;
int maxInstruction = -1;

bool OnlyPrintTrace;
extern int LargestThreadTID;
bool print_instrs_in_cfg = false;
bool print_taint_in_cfg = false;
bool DropInternalFtn;
std::vector<ADDRESS> dont_simplify{};
std::set<ADDRESS> modified_instructions{};
std::string prefix {};
std::string suffix {};
bool onlyApplyTaintForGivenInput {};


void filterCalls(const std::shared_ptr<InstrList>& iList) {
    logger.startPhase("Drop internal functions");
    Instruction *iins;
    Instruction *prev = nullptr;
    iList->currentInstr = 0;
    while ((iins = FetchNextInstr(iList)) != nullptr) {
        if (iins->uInstr.mnemonic == UD_Icall && instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
            prev = iins;
            continue;
        }
        if (prev != nullptr) {
            if (iins->uInstr.mnemonic != UD_Ijmp && instrHasFlag(iins, INSTR_IN_BASE_MODULE)) {
                instrSetFlag(prev, INSTR_IS_DELETED, __LINE__);
                SaveInstrChange(iList, prev, true);
                instrSetFlag(iins, INSTR_IS_DELETED, __LINE__);
                SaveInstrChange(iList, iins, true);
                uint8_t innerCount = 0;
                Instruction *find;
                while ((find = FetchNextInstr(iList)) != nullptr) {
                    DEBUG(1, fmt::format("Marking instruction {} ({})", find->order, *find));
                    instrSetFlag(find, INSTR_IS_DELETED, __LINE__);
                    SaveInstrChange(iList, find, true);
                    if (find->uInstr.mnemonic == UD_Icall) {
                        innerCount++;
                    }
                    if (find->uInstr.mnemonic == UD_Iret) {
                        if (innerCount == 0) {
                            break;
                        }
                        innerCount--;
                    }
                }
            }
            prev = nullptr;
        }
    }
    logger.endPhase();
}

void TaintAnalysis(const std::shared_ptr<InstrList> &iList, bool includeBackward, bool taintSpecificInputs, std::shared_ptr<taint::syscallTaintMap> taintInputs) {
    logger.startPhase(PHASE_TAINT);
    uint64_t forwardStart = 0;
    uint64_t backwardStart = iList->lastBaseModuleInstr;

    bool checkSum {};
#if CHECKSUM_DETECT
    checkSum = true;
#endif
    auto forward = std::make_shared<taint::ForwardTaintAnalysis>(iList, forwardStart, uGhentImprovements);
    auto backward = std::make_shared<taint::BackwardTaintAnalysis>(iList, backwardStart, checkSum, uGhentImprovements);

    if (taintSpecificInputs) {
        includeBackward = false;
        forward->onlyTaintSpecific(std::move(taintInputs));
    }
    std::string baseName = directoryUtils.getBaseName("_taint_tracking");
    std::string simplifiedDotFileName = directoryUtils.getOutputFile(baseName, DirectoryUtils::dotExtension(), prefix, suffix);
    auto dotFile = std::make_shared<std::ofstream>(simplifiedDotFileName);

    forward->enableDOTDump(dotFile);

    forward->annotate();

    if (includeBackward) {
        backward->annotate(); // initialize starting point of taint analysis
    }

    forward->propagate();

    if (includeBackward) {
        backward->propagate();
    }

    logger.endPhase();
}

int main(int argc, char *argv[]) {
    logger.startPhase("Command parsing");
    handle_rop = false;
    bool debugDots = false;
    bool GlobalMem = true;
    int verbose_flag = 0;
    std::string specialTaintInput {};

    std::map<int, std::string> phases{{1, PHASE_TAINT}, {2, PHASE_SIMPL}, {4, PHASE_BTRk6}, {8, PHASE_DOTS}};

    struct option long_options[] = {/* Debug parameters */
                                    {"verbose", no_argument, &verbose_flag, 1},
                                    {"brief", no_argument, &verbose_flag, 0},
                                    {"debug", required_argument, nullptr, 'd'},
                                    {"min-ins", required_argument, nullptr, 'j'},
                                    {"max-ins", required_argument, nullptr, 'k'},
                                    {"debugphase", required_argument, nullptr, 'e'},
                                    {"no-simplification", required_argument, nullptr, 'n'},
                                    {"debug-counter", required_argument, nullptr, 'c'},
                                    {"simplify-rounds", required_argument, nullptr, 's'},
                                    {"prefix-filename", required_argument, nullptr, 'b'},
                                    {"suffix-filename", required_argument, nullptr, 'a'},
                                    {"taint_specific_input_only", required_argument, nullptr, 'T'},
                                    /* Feature toggles */
                                    {"global_mem", no_argument, nullptr, 'g'},
                                    {"print_trace", no_argument, nullptr, 'p'},
                                    {"print-instrs-in-cfg", no_argument, nullptr, 'i'},
                                    {"print-taint-in-cfg", no_argument, nullptr, 't'},
                                    {"rop", no_argument, nullptr, 'o'},
                                    {"drop-internal-ftn-calls", no_argument, nullptr, 'z'},
                                    {"intermediate-dot-files", no_argument, nullptr, 'y'},
                                    {"disable-improvements", no_argument, nullptr, 'u'},
                                    {nullptr, 0, nullptr, 0}};
    const char *shortopts = "T:j:k:d:e:n:c:s:b:a:gpitozyu";
    /* getopt_long stores the option index here. */
    int option_index = 0;

    while (true) {
        int c = getopt_long(argc, argv, shortopts, long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }
        switch (c) {
        case 0:
            // Handle flag setting by doing nothing
            break;
        case 'd':
            logger.setDebugLevel(std::stoi(optarg));
            break;
        case 'j':
            minInstruction = std::stoi(optarg);
            break;
        case 'k':
            maxInstruction = std::stoi(optarg);
            break;
        case 'e': {
            std::vector<std::string> debugPhases{};
            int argPhase = std::stoi(optarg);
            for (auto &phase : phases) {
                if ((argPhase & phase.first) == phase.first) {
                    logger.log(fmt::format("Enable debug for phase {}", phase.second));
                    debugPhases.push_back(phase.second);
                }
            }
            logger.setDebugPhases(debugPhases);
        } break;
        case 'g':
            GlobalMem = false;
            break;
        case 'p':
            OnlyPrintTrace = true; // if on, just prints the trace in "baseName.trace" and exits
            break;
        case 'i':
            print_instrs_in_cfg = true;
            break;
        case 't':
            print_taint_in_cfg = true;
            break;
        case 'o':
            handle_rop = true;
            break;
        case 'u':
            uGhentImprovements = false;
            break;
        case 's':
            SimplifyLoopMax = std::stoi(optarg);
            logger.log(fmt::format("Setting to quit simplifying after {} loops", SimplifyLoopMax));
            break;
        case 'c':
            DebugCounterUse = true;
            DebugCounter = std::stoi(optarg);
            logger.log(fmt::format("Setting debug counter to {} loops", DebugCounter));
            break;
        case 'z':
            DropInternalFtn = true;
            logger.log("Will be dropping internal calls");
            break;
        case 'y':
            debugDots = true;
            break;
        case 'n': {
            std::stringstream ss(optarg);
            std::string item;

            while (std::getline(ss, item, ',')) {
                ADDRESS addr = std::strtoul(item.c_str(), nullptr, 0);
                dont_simplify.push_back(addr);
                modified_instructions.insert(addr);
            }
        }
            logger.log("Ignoring these addresses: ");
            logger.log(fmt::format("{}", fmt::join(dont_simplify, " ")));
            break;
        case 'b': {
            std::stringstream ss(optarg);
            prefix = ss.str() + "_";
            logger.log(fmt::format("Setting prefix for output filenames to {}", prefix));
            break;
        }
        case 'a': {
            std::stringstream ss(optarg);
            suffix = "_" + ss.str();
            logger.log(fmt::format("Setting suffix for output filenames to {}", suffix));
            break;
        }
        case 'T': {
            specialTaintInput = std::string(optarg);
            onlyApplyTaintForGivenInput = true;
            break;
        }
        case '?':
            if (isprint(optopt) != 0) {
                logger.log(fmt::format("Unknown option `-{}`.", optopt));
            } else {
                logger.log(fmt::format("Unknown option character `{}`.", optopt));
            }
            return 1;
        default:
            abort();
        }
    }

    std::stringstream args{};
    for (int i = 1; i < argc; i++) {
        args << " " << argv[i];
    }
    logger.log(fmt::format("Executed command: deobf {}", args.str()));
    if (verbose_flag == 1) {
        logger.enableVerbose();
    }
    logger.verbose("Verbose logging enabled");
    logger.checkForDebugAllPhases();

    if (optind >= argc) {
        logger.log(fmt::format("Usage: {} your_trace_std_trace.txt", argv[0]));
        exit(0);
    }
    logger.endPhase();

    persistentStorage.loadModuleNamesFromFile();
    persistentStorage.loadFunctionNamesFromFile();

    try {
        directoryUtils.prepareOutputFolder();
    } catch (std::filesystem::filesystem_error const &e) {
        std::cerr << e.what() << std::endl;
        exit(1);
    }

    while (optind < argc) {
        auto start = std::chrono::high_resolution_clock::now();
        auto inPath = std::filesystem::path(argv[optind++]);
        logger.startPhase("File " + inPath.filename().string());
        directoryUtils.parseBaseName(inPath);

        logger.startPhase("Parsing of trace");
        auto iList = InitInstrList(inPath, &dont_simplify, true);
        std::string baseName = directoryUtils.getBaseName();

        // write the header file in case of a crash in the middle!
        WriteInstrFileHeader(iList, reinterpret_cast<FILE *>(iList->iMMap), true);
        logger.endPhase();

        auto taintForGivenInput = std::make_shared<taint::syscallTaintMap>();
        if (onlyApplyTaintForGivenInput) {
            logger.startPhase("Parsing input taint file");
            auto taintFile = std::filesystem::path(specialTaintInput);
            auto taintFileStream = std::ifstream(taintFile);
            if (taintFileStream.is_open()) {
                for (std::string line; std::getline(taintFileStream, line); ) {
                    if (line.find('#') == 0) {
                        continue;
                    }
                    auto commaPos = line.find(',');
                    auto syscallName = line.substr(0, commaPos);
                    line.erase(0, commaPos + 1);
                    commaPos = line.find(',');
                    int count = 0;
                    DEOBF_REGISTER_VALUE extra = deobf::library::taint::SyscallTaint::NO_EXTRA_VALUE;
                    if (commaPos == std::string::npos) {
                        count = std::atoi(line.c_str());
                    } else {
                        auto countPart = line.substr(0, commaPos);
                        count = std::atoi(countPart.c_str());
                        line.erase(0, commaPos + 1);
                        extra = std::atoi(line.c_str());
                    }

                    DEBUG(5, fmt::format("Parsed data: name: {}, index {}, extra data: {}", syscallName, count, extra));
                    if (!deobf::library::taint::syscallTaint.isSupported(syscallName)) {
                        logger.log(fmt::format("Error: syscall to {} is not (yet) supported! Exiting"));
                        exit(2);
                    }
                    if (taintForGivenInput->find(syscallName) == taintForGivenInput->end()) {
                        taintForGivenInput->emplace(syscallName, deobf::library::taint::syscallTaintMapCall());
                    }
                    (*taintForGivenInput)[syscallName].emplace(count, extra);
                }
                taintFileStream.close();
            }
            logger.endPhase();
        }

        logger.startPhase("Memory map");
        ConstantMemoryMap(iList);
        logger.endPhase();

        auto traceName = directoryUtils.getOutputFile(baseName, ".trace", prefix, suffix);

        if (OnlyPrintTrace) {
            logger.log("Write trace only");
            FILE *traceFile = fopen(traceName.c_str(), "w");
            assert(traceFile);
            PrintSimplifiedFullInstrList(traceFile, iList, false, true, 0, iList->lastBaseModuleInstr);
            fclose(traceFile);
            exit(0);
        }

        if (TraceIsMultiThreaded) {
            logger.log("Set correct instructions for threaded trace");
            for (int i = 0; i < al_size(traceThreads); i++) {
                auto currThread = static_cast<Thread *>(al_get(traceThreads, i));
                auto currRange = static_cast<ThreadRange *>(al_get(currThread->ranges, 0));
                if (currThread->tid == LargestThreadTID) {
                    iList->currentInstr = currRange->first;
                    currRange = static_cast<ThreadRange *>(al_get(currThread->ranges, currThread->numRanges - 1));
                    iList->lastInstr = currRange->last;
                    iList->lastBaseModuleInstr = iList->lastInstr;

                    currRange = static_cast<ThreadRange *>(al_get(currThread->ranges, 0));
                    iList->firstInstr = currRange->first;
                    iList->tid = currThread->tid;

                    break;
                }
            }
        }

#if !MAIN_MARKER
        iList->endMarker = iList->last;
#endif

        if (!InstrFileExists) {
            TaintAnalysis(iList, true, onlyApplyTaintForGivenInput, taintForGivenInput);
        }

        auto taintOverview = taint::createTaintOverview(iList);

        std::string taintBaseName = directoryUtils.getBaseName("_taintStatus");
        taint::exportTaintOverview(directoryUtils.getOutputFile(taintBaseName, DirectoryUtils::csvExtension(), prefix, suffix), taintOverview);

        if (DropInternalFtn) {
            filterCalls(iList);
        }

        // print annotated trace to a file
        logger.startPhase("Write annotated trace");
        FILE *traceFile = fopen(traceName.c_str(), "w");
        assert(traceFile);
        if (TraceIsMultiThreaded) {
            PrintEntireMultiThreadInstrListInternal(traceFile, iList, true, false, iList->tid);
        } else {
            PrintSimplifiedTrace(traceFile, iList, true, false, true, 0, iList->numInstrs);
        }
        fclose(traceFile);
        logger.endPhase();

        if (onlyApplyTaintForGivenInput) {
            logger.log("Exiting for only taint input");
            exit(1);
        }

        if (iList->endMarker == 0) {
            iList->endMarker = -1;
        }

        // build initial CFG and figure out control dependencies
        logger.startPhase("Original CFG");
        ConstructOriginalCFG(iList);

        logger.startPhase(PHASE_DOTS);
        std::string dotFileName = directoryUtils.getOutputFile(baseName, DirectoryUtils::dotExtension(), prefix, suffix);
        FILE *graph = fopen(dotFileName.c_str(), "w");
        assert(graph);
        PrintCFG(graph, print_instrs_in_cfg, print_taint_in_cfg, taintOverview);
        fclose(graph);
        logger.endPhase();

        MergeBblsNew();

        logger.startPhase("Dependency analysis");
        DependencyAnalysis(iList);
        logger.endPhase();

        // this should be done before dependency analysis!
        if (GlobalMem && !InstrFileExists) {
            logger.startPhase("Simplify global memory");
            SimplifyGlobalMems(iList);
            logger.endPhase();
        }

        CleanUpCFGData();

        logger.endPhase(); // Original CFG

        applySimplifications(iList);

        auto updatedTaintOverview = taint::createTaintOverview(iList);

        std::string taintBaseNameUpdated = directoryUtils.getBaseName("_simplifiedTaintStatus");
        taint::exportTaintOverview(directoryUtils.getOutputFile(taintBaseNameUpdated, DirectoryUtils::csvExtension(), prefix, suffix), updatedTaintOverview);

        logger.startPhase("Write simplified trace");
        // write the simplified trace to file
        std::string simplifiedTraceFileName = directoryUtils.getOutputFile(baseName, ".simplified", prefix, suffix);

        // print simplified trace to a file
        FILE *simplifiedFile = fopen(simplifiedTraceFileName.c_str(), "w");
        assert(simplifiedFile);
        if (TraceIsMultiThreaded) {
            PrintEntireMultiThreadInstrListInternal(simplifiedFile, iList, false, false, iList->tid);
        } else {
            PrintSimplifiedTrace(simplifiedFile, iList, false, false, true, 0, iList->numInstrs);
        }
        fclose(simplifiedFile);
        logger.endPhase(); // Write simplified trace

        // update binary trace format
        WriteInstrFileHeader(iList, reinterpret_cast<FILE *>(iList->iMMap), true);

        // build and write the
        logger.startPhase("Simplified CFG");
        CleanUpCFGData();
        ConstructCFG(iList, debugDots);
        MergeBblsNew();

        logger.startPhase(PHASE_DOTS);
        std::string simplifiedDot = directoryUtils.getBaseName() + "_simplified";
        std::string simplifiedDotFileName = directoryUtils.getOutputFile(simplifiedDot, DirectoryUtils::dotExtension(), prefix, suffix);

        FILE *simplifiedGraph = fopen(simplifiedDotFileName.c_str(), "w");
        assert(simplifiedGraph);
        PrintCFG(simplifiedGraph, print_instrs_in_cfg, print_taint_in_cfg, updatedTaintOverview);
        fclose(simplifiedGraph);
        logger.endPhase(); // Creating dot file

        logger.endPhase(); // Simplified CFG

        // finishing up
        logger.startPhase("Cleanup");
        if (USE_MMAP) {
            // munmap so that dirty pages know to be written out to file
            munmap(iList->iMMap, 0);
        }
        if (!USE_MMAP && STORE_INSTRS_IN_FILE) {
            fclose(iList->iListFile);
            free(iList->instrCache);
        }

        free(iList->newInstrCache);
        FreeConstantMemoryMap(iList);
        free(iList->constantPageDir);
        logger.endPhase();

        logger.log(fmt::format("Untouchable instructions: {}", modified_instructions.size()));
        if (!modified_instructions.empty()) {
            logger.log(fmt::format("Instructions to mark untouchable: {:#x}", fmt::join(modified_instructions, ",")));
            std::vector<ADDRESS> newEntries {};
            std::set_difference(modified_instructions.begin(), modified_instructions.end(), dont_simplify.begin(), dont_simplify.end(), std::back_inserter(newEntries));
            logger.log(fmt::format("Newly added untouchables: {:#x}", fmt::join(newEntries, ",")));
        }

        logger.endPhase(); // File ...
        auto stop = std::chrono::high_resolution_clock::now();
        auto msTaken = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
        auto sTaken = std::chrono::duration_cast<std::chrono::seconds>(stop - start);
        logger.log(fmt::format("Execution time was {} ({})", sTaken, msTaken));
    }

    return 0;
}
