/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2022 University of Ghent
 */

#include "trace_mapping.h"
#include "utils.h"

void TraceMapping::initializeRegisterValues() {
    for (uint8_t r = 0; r <= static_cast<uint8_t>(lastRegister); r++) {
        registerValues[static_cast<Registers>(r)] = 0;
    }
}
void TraceMapping::setRegistersInInstruction(Instruction *ins) {
    for (uint8_t r = 0; r <= static_cast<uint8_t>(lastRegister); r++) {
        auto reg = static_cast<Registers>(r);
        if (r >= static_cast<uint8_t>(Registers::XMM0_0)) {
            mapToXMMInstruction[reg](ins, registerValues[reg], registerValues[static_cast<Registers>(r + 1)]);
            r++; // skip R_XMMx_1
            continue;
        }
        mapToInstruction[reg](ins, registerValues[reg]);
    }
}

void TraceMapping::parseSparseRegisters(std::string changedReg, uint8_t *lastFound) {
    for (uint8_t r = *lastFound; r <= static_cast<uint8_t>(lastRegister); r++) {
        auto reg = static_cast<Registers>(r);
        if (changedReg.rfind(mapToRegex[reg], 0) == 0) {
            changedReg.erase(0, mapToRegex[reg].size());
            unsigned long newValue = std::strtoul(changedReg.c_str(), nullptr, 16);
            registerValues[reg] = newValue;
            if (reg == Registers::FS) {
                if (fs_first) {
                    fs_first = false;
                    if (newValue == 0) {
                        registerValues[reg] = 0xDEADBEEF; // Hardcoded value
                        fs_change_count++;
                    }
                } else if (fs_change_count > 1) {
                    deobf::library::utils::logger.log("FS changed twice in the trace! Unsupported case, exiting");
                    exit(1);
                }
            }
            // We assume they are always in the same order, so if the first occurrence printed is EDI,
            // then the next can only be R8 or later.
            *lastFound = r + 1;
            break;
        }
    }
}
