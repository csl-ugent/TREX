/*
 * File: print.cc
 * Code to print out a "reasonable" assembly code program for an
 * instruction trace summary.  This code assumes that the summary
 * list has been sorted by address and that function and exception
 * handler entry points have been marked.
 *
 * Author: Babak Yadegari, Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#include "print.h"

#include <udis86_create.h>
#include <flags.h>

#include <cinttypes>

using namespace deobf::library;

extern "C" {
#include "udis86/udis86.h"
}

#include "instr.h"
#include "persistent_storage.h"

/*********************************************************************
 *                              EXTERNS                              *
 *********************************************************************/

void fPrintMemTargets(FILE *f, const std::shared_ptr<InstrList>& iList, Instruction *ins) {
    auto memUsed = memoryUsed(iList, ins);
    auto memDef = memoryDefined(iList, ins);

    fprintf(f, "R: ");
    memUsed->fPrint(f);

    fprintf(f, "W: ");
    memDef->fPrint(f);
}

void PrintSimplifiedTrace(FILE *f, const std::shared_ptr<InstrList>& iList, bool printNonBaseInstructions, bool printDeadInstrs, bool printSigns, uint64_t start, uint64_t end) {
    bool printRegs = true;

    Instruction *next = nullptr, *nextPlus1 = nullptr;
    SetCurrentInstr(iList, start);
    while ((next = FetchNextInstr(iList)) != nullptr) { // = next->next) {
        if (static_cast<uint64_t>(next->order) == end) {
            return;
        }
        if (!printNonBaseInstructions && !instrHasFlag(next, INSTR_IN_BASE_MODULE)) {
            continue;
        }
        if (!printDeadInstrs && instrHasFlag(next, INSTR_IS_DELETED)) {
            continue;
        }

        if (printSigns) {
            if (instrHasFlag(next, INSTR_FLAG_FW_TAINED))
                fprintf(f, "@");
            if ((instrHasFlag(next, INSTR_FORWARD_TAINTED)))
                fprintf(f, "FT");
            if (instrHasFlag(next, INSTR_BACKWARD_TAINTED))
                fprintf(f, "BT ");
            if (instrHasFlag(next, INSTR_COND_CF))
                fprintf(f, "CF ");
            if (instrHasFlag(next, INSTR_IS_DELETED))
                fprintf(f, "#r");
            if (instrHasFlag(next, INSTR_TMP0))
                fprintf(f, "+c: ");
            if (instrHasFlag(next, INSTR_TMP1))
                fprintf(f, "+pp: ");
            if (instrHasFlag(next, INSTR_TMP2))
                fprintf(f, "+op: ");
            if (instrHasFlag(next, INSTR_TMP3))
                fprintf(f, "+d: ");
            if (instrHasFlag(next, INSTR_MEM_SIMP))
                fprintf(f, "+m: ");
            if (instrHasFlag(next, INSTR_SIMPLIFIED_IGNORED))
                fprintf(f, "+e");
            if (instrHasFlag(next, INSTR_IN_SHARED_MEM))
                fprintf(f, "SH");
            if (instrHasFlag(next, INSTR_UNTOUCHABLE))
                fprintf(f, "+u");
        }
        if (static_cast<uint64_t>(next->order) < iList->numInstrs - 1) {
            nextPlus1 = GetInstruction(iList, next->order + 1);
        }
        fprintf(f, "%8d: [0x%08" PRIx64 "] %-50.50s %-40.40s", next->order, next->addr, UDCreate::getStringRepresentationOfInstruction(next).c_str(),
                nextPlus1 == nullptr ? "\0" : persistentStorage.functionNameForIdx(nextPlus1->funcName).c_str());
        if (printRegs) {
            fprintf(f, "EAX:%08" PRIx64 " ECX:%08" PRIx64 " EDX:%08" PRIx64 " EBX:%08" PRIx64 " ESP:%08" PRIx64 " EBP:%08" PRIx64 " ESI:%08" PRIx64 " EDI:%08" PRIx64 "", static_cast<uint64_t>(next->eax),
                    static_cast<uint64_t>(next->ecx), static_cast<uint64_t>(next->edx), static_cast<uint64_t>(next->ebx), static_cast<uint64_t>(next->esp),
                    static_cast<uint64_t>(next->ebp), static_cast<uint64_t>(next->esi), static_cast<uint64_t>(next->edi));

            fprintf(f, "  ");
            fPrintMemTargets(f, iList, next);
            fprintf(f, "\n");
        }
    }
}

/*
 * PrintSimplifiedInstrListInternal prints a simplified trace. If includeAllIns is false only
 * the base module instructions are printed.
 */
void PrintTrace(FILE *f, const std::shared_ptr<InstrList>& iList, bool includeAllIns, bool includeDeletedIns, bool printSigns, uint64_t start, uint64_t end) {
    bool printRegs = true;
    uint64_t index = start;
    Instruction *next, *nextPlus1 = nullptr;
    while ((next = GetInstruction(iList, index)) != nullptr) {
        index = next->next;

        if ((uint64_t)next->order == end) {
            return;
        }
        if (!includeAllIns && !instrHasFlag(next, INSTR_IN_BASE_MODULE)) {
            continue;
        }
        if (!includeDeletedIns && instrHasFlag(next, INSTR_IS_DELETED)) {
            continue;
        }

        if (printSigns) {
            if (instrHasFlag(next, INSTR_FLAG_FW_TAINED))
                fprintf(f, "@");
            if ((instrHasFlag(next, INSTR_FORWARD_TAINTED)))
                fprintf(f, "FT");
            if (instrHasFlag(next, INSTR_BACKWARD_TAINTED))
                fprintf(f, "BT ");
            if (instrHasFlag(next, INSTR_COND_CF))
                fprintf(f, "CF ");
            if (instrHasFlag(next, INSTR_IS_DELETED))
                fprintf(f, "#r");
            if (instrHasFlag(next, INSTR_TMP0))
                fprintf(f, "+c: ");
            if (instrHasFlag(next, INSTR_TMP1))
                fprintf(f, "+pp: ");
            if (instrHasFlag(next, INSTR_TMP2))
                fprintf(f, "+op: ");
            if (instrHasFlag(next, INSTR_TMP3))
                fprintf(f, "+d: ");
            if (instrHasFlag(next, INSTR_MEM_SIMP))
                fprintf(f, "+m: ");
            if (instrHasFlag(next, INSTR_SIMPLIFIED_IGNORED))
                fprintf(f, "+e");
            if (instrHasFlag(next, INSTR_IN_SHARED_MEM))
                fprintf(f, "SH");
            if (instrHasFlag(next, INSTR_UNTOUCHABLE))
                fprintf(f, "+u");
        }
        if ((uint64_t)next->order < iList->numInstrs - 1) {
            nextPlus1 = GetInstruction(iList, next->order + 1);
        }
        fprintf(f, "%8d: [0x%08" PRIx64 "] %-50.50s %-40.40s", next->order, next->addr, UDCreate::getStringRepresentationOfInstruction(next).c_str(),
                nextPlus1 == nullptr ? "\0" : persistentStorage.functionNameForIdx(nextPlus1->funcName).c_str());
        if (printRegs) {
            fprintf(f, "EAX:%08" PRIx64 " ECX:%08" PRIx64 " EDX:%08" PRIx64 " EBX:%08" PRIx64 " ESP:%08" PRIx64 " EBP:%08" PRIx64 " ESI:%08" PRIx64 " EDI:%08" PRIx64 "", static_cast<uint64_t>(next->eax),
                    static_cast<uint64_t>(next->ecx), static_cast<uint64_t>(next->edx), static_cast<uint64_t>(next->ebx), static_cast<uint64_t>(next->esp),
                    static_cast<uint64_t>(next->ebp), static_cast<uint64_t>(next->esi), static_cast<uint64_t>(next->edi));

            fprintf(f, "  ");
            fPrintMemTargets(f, iList, next);
            fprintf(f, "\n");
        }
    }
}

void PrintEntireMultiThreadInstrListInternal(FILE *f, const std::shared_ptr<InstrList>& iList, bool full_list, bool printDeadInstrs, int tid) {
    uint64_t index;
    bool printRegs = true;
    Instruction *next, *nextPlus1 = nullptr;
    for (index = 0; index < static_cast<uint64_t>(iList->last); index++) {
        next = GetInstruction(iList, index);

        if (next->tid != tid) {
            continue;
        }

        if ((!instrHasFlag(next, INSTR_IN_BASE_MODULE) && !full_list)) {
            continue;
        }
        if (!printDeadInstrs && instrHasFlag(next, INSTR_IS_DELETED)) {
            continue;
        }
        if (instrHasFlag(next, INSTR_IN_BASE_MODULE)) {
            fprintf(f, "BB ");
        }

        if (instrHasFlag(next, INSTR_FORWARD_TAINTED)) {
            fprintf(f, "@");
        }
        if (instrHasFlag(next, INSTR_BACKWARD_TAINTED)) {
            fprintf(f, "BT ");
        }
        if (instrHasFlag(next, INSTR_COND_CF)) {
            fprintf(f, "CF ");
        }
        if (instrHasFlag(next, INSTR_IS_DELETED)) {
            fprintf(f, "#r");
        }
        if (instrHasFlag(next, INSTR_TMP0)) {
            fprintf(f, "+c: ");
        }
        if (instrHasFlag(next, INSTR_TMP1)) {
            fprintf(f, "+pp: ");
        }
        if (instrHasFlag(next, INSTR_TMP2)) {
            fprintf(f, "+op: ");
        }
        if (instrHasFlag(next, INSTR_TMP3)) {
            fprintf(f, "+d: ");
        }
        if (instrHasFlag(next, INSTR_MEM_SIMP)) {
            fprintf(f, "+m: ");
        }
        if (instrHasFlag(next, INSTR_SIMPLIFIED_IGNORED)) {
            fprintf(f, "+e");
        }
        if (instrHasFlag(next, INSTR_IN_SHARED_MEM)) {
            fprintf(f, "SH");
        }
        if (instrHasFlag(next, INSTR_UNTOUCHABLE)) {
            fprintf(f, "+u");
        }
        if (static_cast<uint64_t>(next->order) < iList->numInstrs - 1) {
            nextPlus1 = GetInstruction(iList, next->order + 1);
        }
        fprintf(f, "%8d: [0x%08" PRIx64 "] %-50.50s %-40.40s", next->order, next->addr, UDCreate::getStringRepresentationOfInstruction(next).c_str(),
                nextPlus1 == nullptr ? "\0" : persistentStorage.functionNameForIdx(nextPlus1->funcName).c_str());
        if (printRegs) {
            fprintf(f, "tid:%08d EAX:%08" PRIx64 " ECX:%08" PRIx64 " EDX:%08" PRIx64 " EBX:%08" PRIx64 " ESP:%08" PRIx64 " EBP:%08" PRIx64 " ESI:%08" PRIx64 " EDI:%08" PRIx64 "", next->tid, static_cast<uint64_t>(next->eax),
                    static_cast<uint64_t>(next->ecx), static_cast<uint64_t>(next->edx), static_cast<uint64_t>(next->ebx), static_cast<uint64_t>(next->esp),
                    static_cast<uint64_t>(next->ebp), static_cast<uint64_t>(next->esi), static_cast<uint64_t>(next->edi));
            fprintf(f, "  ");
            fPrintMemTargets(f, iList, next);
            fprintf(f, "\n");
        }
        if (next->next > iList->last) {
            Instruction *nextNew;

            int nextOrder = next->next;
            while (((nextNew = GetInstruction(iList, nextOrder)) != nullptr) && nextOrder > iList->last) {
                nextOrder = nextNew->next;
                if (instrHasFlag(nextNew, INSTR_FORWARD_TAINTED)) {
                    fprintf(f, "@");
                }
                if (instrHasFlag(nextNew, INSTR_BACKWARD_TAINTED)) {
                    fprintf(f, "BT ");
                }
                if (instrHasFlag(nextNew, INSTR_COND_CF)) {
                    fprintf(f, "CF ");
                }
                if (instrHasFlag(nextNew, INSTR_IS_DELETED)) {
                    fprintf(f, "#r");
                }
                if (instrHasFlag(nextNew, INSTR_TMP0)) {
                    fprintf(f, "+c: ");
                }
                if (instrHasFlag(nextNew, INSTR_TMP1)) {
                    fprintf(f, "+pp: ");
                }
                if (instrHasFlag(nextNew, INSTR_TMP2)) {
                    fprintf(f, "+op: ");
                }
                if (instrHasFlag(nextNew, INSTR_TMP3)) {
                    fprintf(f, "+d: ");
                }
                if (instrHasFlag(nextNew, INSTR_MEM_SIMP)) {
                    fprintf(f, "+m: ");
                }
                if (instrHasFlag(nextNew, INSTR_SIMPLIFIED_IGNORED)) {
                    fprintf(f, "+e");
                }
                if (instrHasFlag(next, INSTR_UNTOUCHABLE)) {
                    fprintf(f, "+u");
                }
                fprintf(f, "%8d: [0x%08" PRIx64 "] %-50.50s %-40.40s", nextNew->order, nextNew->addr, UDCreate::getStringRepresentationOfInstruction(nextNew).c_str(),
                        "\0");
                if (printRegs) {
                    fprintf(f, "tid:%08d EAX:%08" PRIx64 " ECX:%08" PRIx64 " EDX:%08" PRIx64 " EBX:%08" PRIx64 " ESP:%08" PRIx64 " EBP:%08" PRIx64 " ESI:%08" PRIx64 " EDI:%08" PRIx64 "", nextNew->tid,
                            static_cast<uint64_t>(next->eax), static_cast<uint64_t>(next->ecx), static_cast<uint64_t>(next->edx),
                            static_cast<uint64_t>(next->ebx), static_cast<uint64_t>(next->esp), static_cast<uint64_t>(next->ebp),
                            static_cast<uint64_t>(next->esi), static_cast<uint64_t>(next->edi));
                    fprintf(f, "  ");
                    fPrintMemTargets(f, iList, nextNew);
                    fprintf(f, "\n");
                }
            }
            SetCurrentInstr(iList, nextOrder);
        }
    }
}
