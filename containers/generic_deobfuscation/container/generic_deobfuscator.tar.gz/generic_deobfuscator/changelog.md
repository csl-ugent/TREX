| Commit                                   | Change type                                                                 |
|------------------------------------------|-----------------------------------------------------------------------------|
| 5ee958c3d23b590fadc5fc87c8148fa3d5b19071 | Feature addition (no algorithmic impact unless FIXME)                       |
| ea0bf52e618d18b61578374045c5f9831e24d0fb | Feature addition (no algorithmic impact unless FIXME)                       |
| e9cdb15cc18724b6ca72cc4ea879a7ead200678f | Feature addition (no algorithmic impact unless toggled)                     |
| 6040b1b7120643452121ebcac135ef47229e4cd2 | Feature addition (no algorithmic impact unless FIXME)                       |
| d1197fe14b3ad32c4b6f4bccb45c304810a257db | Code improvement (no algorithmic impact)                                    |
| b102da85741374234ffd0494e92f7f675199370f | Code improvement (no algorithmic impact)                                    |
| c5aea90232b094cbe0d8957bbc4ec83828f790ce | Code improvement (no algorithmic impact)                                    |
| a7f03cb730de393a92034dc91248a6a008772cfc | Code improvement (no algorithmic impact)                                    |
| 1e5b486959d67ad3368f0e5c70163c3bfe9a9b01 | Code improvement (no algorithmic impact)                                    |
| 5ac78a0db48280277a76d0156612e9b85360889f | Code improvement (no algorithmic impact)                                    |
| acf30b9b82bbb852685c66849a0ec58737d2c224 | Code improvement (no algorithmic impact)                                    |
| 69e7fbcb338d2c9556422c64c03e6962233166e3 | Code improvement (no algorithmic impact)                                    |
| 07c8ab157dd2161e1c5668490a94f20498c7de3c | Code improvement (no algorithmic impact)                                    |
| f4accf5b93640d586ddafa40784268b982f3c2e3 | Feature addition (no algorithmic impact unless FIXME)                       |
| 09ac972ac4535bee088dc34d5b96946ff95f50e2 | Feature addition (no algorithmic impact)                                    |
| 10336bc7767ce623783ccba1179f34ee4368a117 | Feature addition (no algorithmic impact unless toggled)                     |
| 8cf6d71064503c57314d8f70bd73e43a8e471194 | 64-bit support (no algorithmic FIXME)                                       |
| ee0b7843e77fdeedb43fa344649949c663186446 | Improvement of supported opcodes                                            |
| 00088a5ab1805a4b97365ba3fb85608a871b3ccc | 64-bit support (no algorithmic FIXME)                                       |
| 048e92ff94cc1f642198872dcfe33740c6054cd5 | Feature addition (no algorithmic impact unless toggled)                     |
| d29d1097c807756eb80b923ebd85f539e1f5a11a | Feature addition (no algorithmic impact unless toggled)                     |
| dc2f21dd71ef7a249f781d29280ea6eb9f5f27d6 | Improvement of supported opcodes                                            |
| 0ee72bc6368286b7fc84b499c699921a5b235259 | Code improvement (no algorithmic impact)                                    |
| 8d7303c83f77a5bfb0b2332add991d93962708f9 | Improvement of supported opcodes                                            |
| 0341f2762a043c576e47addb00923fedd4baa1d5 | Code improvement (no algorithmic impact) + improvement of supported opcodes |
| eb1fba66bb8ab1882d640b4294bf0998969f5533 | 64-bit support (no algorithmic impact)                                      |
| 9bcd7d1040eb824fd9ac64c5eead631b7f3fda61 | Algorithm fix                                                               |
| 47e495ea4ac6de28ad7ab2c461a7c3f5360d1132 | 64-bit support (no algorithmic FIXME)                                       |
| ce6db8c7f983db353b4a914bd057fde083b5d47a | 64-bit support (no algorithmic FIXME)                                       |
| 937319e70816b3fd07b45ee861468895b4b236b2 | Code improvement (no algorithmic impact)                                    |
| f5bf9b65a33eb1389086d17f5255d0eaf7c04cdb | 64-bit support (no algorithmic impact)                                      |
| 5358046354c4eab1fa68e20154dc2e71ffbf7653 | Code improvement (no algorithmic impact)                                    |
| a803becd2cb0f93ccaab3cc5450bab694e508caf | Code improvement (no algorithmic FIXME)                                     |
| b19d4922098acc447c002c032b7c753e106ed616 | Algorithm fix                                                               |
| 8252ffe9b4cd1c61bed70f7b69b5844acbca1cf9 | Code improvement (no algorithmic FIXME)                                     |
| 0589e322bf00b45b199c85cd2c61d38b18e27099 | FIXME: remove?                                                              |
| 4c5454fc04099adb4247039bb1fe82599ef4b608 | Improvement of supported opcodes                                            |
| 2be9c1f433caf963f20d83702db8bb2957286451 | Code improvement (no algorithmic FIXME)                                     |
| 058d3a1009fc501526cb3f5d49df819efe06d7c9 | Feature addition (no algorithmic impact unless toggled)                     |
| 785160d4ff8523de028731c74e5bf3ad8b7f134b | Code improvement (no algorithmic FIXME)                                     |
| ba60ac293384d61d4b30dc290dc5884011571dbb | Improvement of supported opcodes                                            |
| f431d70356c96d5bf8ad12d9636b1438bc214286 | Code improvement (no algorithmic impact)                                    |
| 2a7793b6569454045399201f244386fc810aaac8 | Code improvement (no algorithmic impact)                                    |
| fcc59680bb18ce6e3f114c84161e08d42d90d73f | Code improvement (no algorithmic impact)                                    |
| cc0141935b9a72f4cafaa402b740fd10816e2cb7 | Code improvement (no algorithmic impact)                                    |
| 72367c5210daa41e983941499cc9dd472f6c9498 | Code improvement (no algorithmic impact)                                    |
| 058d5b141ce24e1a637be239b489cf2b48aa2d0d | Feature addition (no algorithmic impact unless toggled)                     |
| 7bc1464457bd0173b637f231daae42cf2a2000c9 | Improvement of supported opcodes                                            |
| f6f6538a3c1a9707ef8047e10f173d77dbdcc0b6 | Improvement of supported opcodes                                            |
| fb225cd705a32dbc5bf8da6a67751cf725779c58 | Code improvement (no algorithmic impact)                                    |
| df37ba4670d24a1919e6c91df387ee3c1d2b9d80 | Code improvement (no algorithmic impact)                                    |
| 269bebedd7c9289cb46b9290f0f0322524c4c6c0 | Library update (algorithmic impact FIXME)                                   |
| 3275a1043c65f6fecc670a0379591c808c9d5171 | Library update (algorithmic impact FIXME)                                   |
| bbb1e28fb3a01cc88996ada57688ca773e464f74 | Code improvement (no algorithmic impact)                                    |
| afb0c42917286fd96e5dc7178d9624817b3361f8 | Code improvement (no algorithmic impact)                                    |
| fda90819ae8cddcb89c6960dea1d2656acaf4c70 | Code improvement (no algorithmic impact)                                    |
| e9a5321d639403f85764e7d7027830e6fbe77f5c | Improvement of supported opcodes                                            |
| 0d1ee35800722a792981c81b2270e92e4e915e69 | Compilation fixes                                                           |
| 9be3f7f89cb6283a131576cbfe5a7db7fc0babe4 | Compilation fixes                                                           |
| d24fee67c1549509ff643ef84d1cd39fc447aa57 | Compilation fixes                                                           |
| 4418848c7fff8684236c2ca080b4b00ccc0c2396 | Original source                                                             |
