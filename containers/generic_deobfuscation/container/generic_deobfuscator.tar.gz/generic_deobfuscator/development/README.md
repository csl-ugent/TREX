# Development for Generic Deobfuscator

Using Docker, compilation for development purposes becomes a lot easier.

Create the Docker container by executing the build command from within this folder:

```
docker build . -t generic_deobfuscator_dev
```

The environment comes with `gdb` pre-installed.

To run it, execute this (or a similar) command from the parent folder:
```
docker run -v $(pwd):/generic_deobfuscator -v $(pwd):/target -t -i --rm generic_deobfuscator_dev 
```

The first volume is the most important, as it makes your source code available inside the Docker container.
The second volume (mounted on /target) can be used to point to a location where you store your *\_std\_trace.txt files.

