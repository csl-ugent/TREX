#!/usr/bin/env bash

foldername=$(date +"%Y-%m-%d_%H%M%S")

get_untouchable_count() {
  local LOGFILE="${1}"
  local COUNT=$(($(grep "Untouchable instructions:" "$LOGFILE" | cut -d":" -f2)))
  echo $COUNT
}

get_untouchable_instr() {
  local LOGFILE="${1}"
  grep "Instructions to mark untouchable:" "$LOGFILE" | cut -d":" -f2
}


# Create folder, copy files to it
mkdir "${foldername}"
pushd "${foldername}" || exit

# Run deobf on normal trace
echo "Performing original run..."
mkdir ./files
mkdir ./comparison
../deobf -u "${@}" > ./log_deobf_original.log 2>&1 || exit 5
mv ./files ./original
cp ./original/*.dot ./comparison/
pushd comparison || exit
perl-rename 's/.dot/.bdot/' ./*.dot
perl-rename 's/.*_simplified.bdot/simplified_0.dot/' ./*.bdot
perl-rename 's/.*/original.dot/' ./*.bdot
popd || exit

count=$(get_untouchable_count ./log_deobf_original.log)
echo -e "\tCount: ${count}"
if [ ${count} -ne 0 ]; then
  untouchable=$(get_untouchable_instr ./log_deobf_original.log)
  echo -e "\tFound instructions: ${untouchable}"
fi
newcnt=0
run=1

# Recursively run
while [ $count -ne $newcnt ]
do
	folder="round_${run}"
	mkdir ./files
	echo "Performing run ${run} ..."
	count=$newcnt
	../deobf -n "${untouchable}" "${@}" > ./log_deobf_round_${run}.log 2>&1 || exit 5
	mv ./files "${folder}"
	cp ./${folder}/*_simplified.dot ./comparison/simplified_${run}.dot
	newcnt=$(get_untouchable_count log_deobf_round_${run}.log)
  echo -e "\tCount: ${newcnt}"
  if [ "$newcnt" -ne 0 ]; then
    untouchable=$(get_untouchable_instr log_deobf_round_${run}.log)
    echo -e "\tFound instructions: ${untouchable}"
  fi
	run=$((run+1))
done

# Cleanup in folder
rm ./*.instrFile function_n*mes module_names

popd || exit
