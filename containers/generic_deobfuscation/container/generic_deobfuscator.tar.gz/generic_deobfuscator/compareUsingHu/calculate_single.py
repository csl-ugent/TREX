#!/usr/bin/env python
import os
import sys
from os.path import basename

from CFG.CFG import CFG
from CFG_sim.CFGSimED import CFGSimED

if __name__ == "__main__":
    # Parse arguments
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} trace_name")
        exit()

    traceName = sys.argv[1]

    names = [
        f"{traceName}.dot",
        f"{traceName}_simplified.dot",
        f"{traceName}_new_merged.dot",
        f"{traceName}_new_simplified.dot",
        f"{traceName}_new_simplified_improved.dot"
    ]

    for row in names:
        result = []
        for column in names:
            cfgAName = os.path.join(os.getcwd(), row)
            cfgA = CFG(cfgAName)
            cfgBName = os.path.join(os.getcwd(), column)
            cfgB = CFG(cfgBName)
            algo = CFGSimED()
            similarity = algo.sim(cfgA, cfgB)
            result.append(str(round(similarity*100, 2)))
        print(" ".join(result))

