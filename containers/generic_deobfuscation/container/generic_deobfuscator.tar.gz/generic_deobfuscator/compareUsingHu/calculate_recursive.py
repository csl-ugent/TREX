#!/usr/bin/env python
import os
import sys
from os.path import basename

from CFG.CFG import CFG
from CFG_sim.CFGSimED import CFGSimED

if __name__ == "__main__":
    # Parse arguments
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} folder")
        exit()

    folder = sys.argv[1]
    comparisonFolder = os.path.join(os.getcwd(), folder, "comparison")

    simplified_files = [f for f in os.listdir(comparisonFolder) if f.startswith("simplified_")]
    simplified_files.sort(key=lambda x: int(x[11:-4]))  # Sort using the iteration rather than alphabetically (no _1, _10, _2)

    algo = CFGSimED()

    with open(os.path.join(comparisonFolder, "similarity.csv"), "w") as fh:
        compareTos = ["unprotected", "unprotected_simplified", "unprotected_improved", "original"]
        fh.write("\n")
        fh.write(f"Comparing vs,{','.join(simplified_files)},\n")
        for compareTo in compareTos:
            print(f"Comparing {compareTo}...")
            fullCompareTo = os.path.join(comparisonFolder, f"{compareTo}.dot")
            fh.write(f"{compareTo},")
            for simplified in simplified_files:
                print(f"\tto {simplified}... ", end="")
                fullSimplified = os.path.join(comparisonFolder, simplified)
                cfgA = CFG(fullCompareTo)
                cfgB = CFG(fullSimplified)
                similarity = algo.sim(cfgA, cfgB)
                fh.write(f"{round(similarity*100, 2)},")
                print("done")
            fh.write("\n")
