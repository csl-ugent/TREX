#!/usr/bin/python
from .CFGNode import CFGNode
import random
import pydot

import sys

class CFGParseError(Exception):
    pass

class CFG:
    """This class represents a CFG in terms of its nodes.
    
    If the class is constructed with file_path, it will read the CFG from the dot
    file at file_path. Otherwise, it will construct an empty CFG.
    
    Attributes:
        root: The root of the CFG.
        __edge_count: A counter of the edges in the CFG.
         __nodes: A list that stores the nodes of the CFG.
        __edit_history: edit_history is in the format
                        "[operation]:[location];[operation]:[location];..."
                        [operation] can be "an", "dn", "ae", and "de" which represent
                        add node, delete node, add edge, and delete edge respectively.
                        [location] can be "" (for add node), "[node index]" (for delete
                        node), and "[from node index],[to node index]" (for add/delete
                        edge).
    """
    
    def __init__(self, file_path=""):
        self.root = None
        self.__edge_count = 0
        self.__nodes = []
        self.__edit_history = ""
        if len(file_path) > 0:
            self.__get_cfg_from_dot_file(file_path)
            self.__find_and_set_root()
    
    @staticmethod
    def get_cfg_from_edit_history(root_cfg, edit_history):
        edits = edit_history.split(";")
        for i in range(len(edits)):
            if len(edits[i]) == 0:
                continue
            operation = edits[i].split(":")[0]
            location = edits[i].split(":")[1]
            if operation == "an":
                new_node = CFGNode(root_cfg.get_node_count(), 9999, 'new', None, None)
                root_cfg.add_node(new_node)
            elif operation == "dn":
                n = root_cfg.get_node(int(location))
                root_cfg.remove_node(n)
            elif operation == "ae":
                n1 = root_cfg.get_node(int(location.split(",")[0]))
                n2 = root_cfg.get_node(int(location.split(",")[1]))
                root_cfg.add_edge(n1, n2)
            elif operation == "de":
                n1 = root_cfg.get_node(int(location.split(",")[0]))
                n2 = root_cfg.get_node(int(location.split(",")[1]))
                root_cfg.remove_edge(n1, n2)
            root_cfg.append_edit_history(operation, location)
        return root_cfg
    
    def set_edit_history(self, edit_history):
        self.__edit_history = edit_history
    
    def append_edit_history(self, operation, location):
        self.__edit_history += ";" + operation + ":" + location
    
    def get_edit_history(self):
        return self.__edit_history
    
    def get_nodes(self):
        return self.__nodes
    
    def add_node(self, node):
        self.__nodes.append(node)
    
    def add_edge(self, from_node, to_node):
        from_node.add_child(to_node)
        to_node.add_parent(from_node)
        self.__edge_count += 1
    
    def add_edge_by_id(self, from_node_id, to_node_id):
        from_node = self.__getNodeById(from_node_id)
        to_node = self.__getNodeById(to_node_id)
        self.addEdge(from_node, to_node)
    
    def remove_node(self, node):
        # Remove incoming edges.
        for parent_index in range(node.get_parent_count()):
            parent = node.getParent(parent_index)
            self.remove_edge(parent, node)
        
        # Remove outgoing edges.
        for child_index in range(node.get_child_count()):
            child = node.get_child(child_index)
            self.remove_edge(node, child)
        
        # Decrement the indices of nodes whose indices are bigger than that of node
        for node_index in range(node.index + 1, self.get_node_count()):
            self.get_node(node_index).index -= 1
        self.__nodes.remove(node)
    
    def remove_edge(self, from_node, to_node):
        from_node.remove_child(to_node)
        to_node.remove_parent(from_node)
        self.__edge_count -= 1
    
    def get_node(self, index):
        return self.__nodes[index]
    
    def get_node_count(self):
        return len(self.__nodes)
    
    def get_edge_count(self):
        return self.__edge_count
    
    def export_light(self, f, index):
        """Export the CFG without using pydot library
        
        Args:
            f: The output dot file.
            index: The index of this CFG in the dot file.
        """
        f.write("digraph " + str(index) + " {\n")
        # Export nodes
        for node_index in range(self.get_node_count()):
            node = self.get_node(node_index)
            id = node.id
            label = node.name + '\\n'
            if not node.instr is None:
                label += '\\l'.join(node.instr)
            f.write(str(id) + " [label=\"" + label + "\"];\n")
        # Export edges
        for node_index in range(self.get_node_count()):
            node = self.get_node(node_index)
            for child_index in range(node.get_child_count()):
                child = node.get_child(child_index)
                f.write(str(node.id) + " -> " + str(child.id) + ";\n")
        f.write("}\n")
    
    def export(self, f, highlighted_node=None, highlighted_edge=None):
        """"Export the graph using pydot library
        
        Args:
            f: The output dot file.
            highlighted_node: Specifies the node that needs to be
            highlighted. It is in the format (node_index, True|False).
            The second value specifies whether or not the node should
            be in dotted style.
            highlighted_node: Specifies the edge that needs to be
            highlighted. It is in the format (from_node_index,
            to_node_index, True|False). The second value specifies
            whether or not the edge should be in dotted style.
        """
        graph = pydot.Dot('graphname', graph_type='digraph')
        # Add nodes to the graph.
        pydot_nodes = []
        for node_index in range(self.get_node_count()):
            node = self.get_node(node_index)
            label = node.name + '\\n'
            if not node.instr is None:
                label += '\\l'.join(node.instr)
            pydotNode = None
            if highlighted_node == (node_index, True):
                pydotNode = pydot.Node(node.id, label=label, style="dotted", color="red")
            elif highlighted_node == (node_index, False):
                pydotNode = pydot.Node(node.id, label=label, color="red")
            else:
                pydotNode = pydot.Node(node.id, label=label)
            graph.add_node(pydotNode)
            pydot_nodes.append(pydotNode)
        # Add edges to the graph.
        for nodeIndex in range(self.get_node_count()):
            node = self.get_node(nodeIndex)
            for childIndex in range(node.get_child_count()):
                child = node.get_child(childIndex)
                if highlighted_edge == (node.index, child.index, True):
                    graph.add_edge(pydot.Edge(pydot_nodes[node.index], pydot_nodes[child.index], color="red", style="dotted"))
                elif highlighted_edge == (node.index, child.index, False):
                    graph.add_edge(pydot.Edge(pydot_nodes[node.index], pydot_nodes[child.index], color="red"))
                else:
                    graph.add_edge(pydot.Edge(pydot_nodes[node.index], pydot_nodes[child.index]))
        graph.write_raw(f)
    
    def clone(self):
        cloned_graph = CFG()
        cloned_graph.set_edit_history(self.__edit_history)
        # Clone nodes
        for node_index in range(self.get_node_count()):
            n = self.get_node(node_index)
            instr = None
            if not n.instr is None:
                instr = n.instr[:]
            cloned_node = CFGNode(n.index, n.id, n.name, instr, n.get_color())
            cloned_graph.add_node(cloned_node)
        # Set root node
        cloned_graph.root = cloned_graph.get_node(self.root.index)
        # Clone edges
        for node_index in range(self.get_node_count()):
            n1 = self.get_node(node_index)
            for child_index in range(n1.get_child_count()):
                n2 = n1.get_child(child_index)
                cloned_graph.add_edge(cloned_graph.get_node(n1.index), cloned_graph.get_node(n2.index))
        return cloned_graph
    
    def __get_node_by_id(self, id):
        for node in self.__nodes:
            if node.id == id:
                return node
    
    def __get_cfg_from_dot_file(self, file_path):
        try:
            g = pydot.graph_from_dot_file(file_path)
            nodes = g[0].get_nodes()
            for i in range(len(nodes)):
                index = self.get_node_count()
                id = nodes[i].get_name()
                try:
                    label = nodes[i].get_attributes()['label'][1:-1]
                except:
                    continue
                name = None
                instr = None
                if '\\n' in label:
                    name = label[0:label.index('\\n')]
                    if not '\\l' in label:
                        instr = None
                    else:
                        instr = label[label.find('\\n') + len('\\n'):].split('\\l')
                elif '\\l' in label:
                    name = label[0:label.index('\\l')]
                    instr = label[label.find('\\l') + len('\\l'):].split('\\l')
                else:
                    #continue
                    name = label
                if not instr is None:
                    for j in range(len(instr)):
                        instr[j] = instr[j].strip()
                node = CFGNode(index, id, name, instr)
                self.add_node(node)
            edges = g[0].get_edges()
            for i in range(len(edges)):
                from_node = edges[i].get_source()
                to_node = edges[i].get_destination()
                self.add_edge(self.__get_node_by_id(from_node), self.__get_node_by_id(to_node))
                self.__edge_count += 1
        except Exception:
            raise CFGParseError
    
    def __find_and_set_root(self):
        for node in self.__nodes:
            if node.get_parent_count() == 0:
                self.root = node
                break