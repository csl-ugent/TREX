class CFGNode:
    """This class represents a CFG node.
    
    Attributes:
        index: The index of this node in the __nodes array of the CFG that contains
                 this node.
        id: The id of this node which is a unique number among the nodes in the CFG.
        name: The name of this node.
        instr: The instructions contained in this node.
        __parents: A list of nodes that point to this node.
        __children: A list of nodes pointed by this node.
        __color: The color of this node derived from the instructions contained in the
                 node.
    """
    
    def __init__(self, index, id, name, instr, color=None):
        self.index = index
        self.id = id
        self.name = name
        self.instr = instr
        self.__parents = []
        self.__children = []
        if color is None and instr is not None:
            self.__color = self.__getColorFromInstr(self.instr)
        else:
            self.__color = color
    
    def get_color(self):
        return self.__color
    
    def add_parent(self, parent):
        self.__parents.append(parent)
    
    def remove_parent(self, parent):
        self.__parents.remove(parent)
    
    def get_parent(self, index):
        return self.__parents[index]
    
    def get_parent_count(self):
        return len(self.__parents)
    
    def add_child(self, child):
        self.__children.append(child)
    
    def remove_child(self, child):
        self.__children.remove(child)
    
    def get_child(self, index):
        return self.__children[index]
    
    def get_child_count(self):
        return len(self.__children)
    
    def is_child_of(self, parent):
        if parent in self.__parents:
            return True
        else:
            return False
    
    def get_parents(self):
        return self.__parents
    
    def get_children(self):
        return self.__children
    
    def contrast_by_color(self, another_node):
        edit_distance = 0
        for i in range(len(self.color)):
            if not self.color[i] == another_node.color[i]:
                edit_distance += 1
        sim = 1 - (float(edit_distance) / len(self.color))
        return sim
    
    def contrast_by_instr(self, another_node):
        edit_distance = self.__levenshtein_distance_instr(self.instr, another_node.instr)
        if edit_distance == 0:
            return 1
        sim = 1 - (float(edit_distance) / max(len(self.instr), len(another_node.instr)))
        return sim
    
    def __get_color_from_instr(self, instr):
        color = ["0"] * 15
        for i in range(len(instr)):
            op = instr[i].split(' ')[0]
            op_class = self.__get_op_class(op)
            color[op_class] = '1'
        return "".join(color)
    
    def __get_op_class(self, op):
        instr_classes = [
            set(['add', 'adc', 'sbb', 'daa', 'sub', 'das', 'aaa', 'aas', 'inc', 'dec', 'imul', 'aam', 'aad', 'shld', 'shrd', 'addA', 'adcA', 'sbbA', 'subA', 'addQ', 'adcQ', 'sbbQ', 'subQ', 'rolA', 'rorA', 'rclA', 'rcrA', 'shlA', 'shrA', 'sarA', 'rolQ', 'rorQ', 'rclQ', 'rcrQ', 'shlQ', 'shrQ', 'sarQ', 'mulA', 'imulA', 'divA', 'idivA', 'mulQ', 'imulQ', 'divQ', 'idivQ', 'incA', 'decA', 'incQ', 'decQ']),
            set(['pushP', 'popP', 'push', 'pop', 'pushaP', 'popaP', 'popQ', 'pushT', 'popT']),
            set(['or', 'and', 'xor', 'seto', 'setno', 'setb', 'setae', 'sete', 'setne', 'setbe', 'seta', 'sets', 'setns', 'setp', 'setnp', 'setl', 'setge', 'setle', 'setg', 'bt', 'bts', 'btrS', 'btc', 'bsf', 'bsr', 'orA', 'andA', 'xorA', 'orQ', 'andQ', 'xorQ', 'notA', 'negA', 'notQ', 'negQ']),
            set(['cmp', 'test', 'cmpA', 'cmpQ', 'testA', 'testQ']),
            set(['bound', 'insb', 'insR', 'outsb', 'outsR', 'cWtR', 'cRtd', 'les', 'lds', 'enterP', 'leaveP', 'int3', 'into', 'xlat', 'in', 'out', 'icebp', 'hlt', 'lar', 'syscall', 'clts', 'sysretP', 'invd', 'wbinvd', 'ud2a', 'femms', 'sysexit', 'emms', 'cpuid', 'rsm', 'ud2b', 'bswap']),
            set(['jo', 'jno', 'jb', 'jae', 'je', 'jne', 'jbe', 'ja', 'js', 'jns', 'jp', 'jnp', 'jl', 'jge', 'jle', 'jg', 'nop', 'lcallP', 'retP', 'lretP', 'iretP', 'loopneF', 'loopeF', 'loopF', 'jEcxz', 'callP', 'jmpP', 'ljmpP', 'jmp', 'joH', 'jnoH', 'jbH', 'jaeH', 'jeH', 'jneH', 'jbeH', 'jaH', 'jsH', 'jnsH', 'jpH', 'jnpH', 'jlH', 'jgeH', 'jleH', 'jgH']),
            set(['xchg', 'lsl', 'cmovo', 'cmovno', 'cmovb', 'cmovae', 'cmove', 'cmovne', 'cmovbe', 'cmova', 'cmovs', 'cmovns', 'cmovp', 'cmovnp', 'cmovl', 'cmovge', 'cmovle', 'cmovg', 'cmpxchg', 'lss', 'lfs', 'lgs', 'xadd', 'movnti']),
            set(['mov', 'movQ', 'movsb', 'movsR', 'movA', 'movzbR', 'movzwR']),
            set(['lea']),
            set(['pushfP', 'popfP', 'sahf', 'lahf', 'cmc', 'clc', 'stc', 'cli', 'sti', 'cld', 'std']),
            set(['cmpsb', 'cmpsR', 'stos', 'lods', 'scas', 'movsbR', 'movswR']),
            set(['int', 'sysenter']),
            set(['wrmsr', 'rdtsc', 'rdmsr', 'rdpmc']),
            set(['fadd', 'fmul', 'fcom', 'fcomp', 'fsub', 'fsubr', 'fdiv', 'fdivr', 'fld', 'fxch', 'fcmovb', 'fcmove', 'fcmovbe', 'fcmovu', 'fcmovnb', 'fcmovne', 'fcmovnbe', 'fcmovnu', 'fucomi', 'fcomi', 'ffree', 'fst', 'fstp', 'fucom', 'fucomp', 'faddp', 'fmulp', 'fsubp', 'fsubrp', 'fdivp', 'fdivrp', 'ffreep', 'fucomip', 'fcomip']),
            set(['pushQ'])
        ]
        for instr_class_index in range(len(instr_classes)):
            if op in instr_classes[instr_class_index]:
                return instr_class_index
        op = op[0:len(op) - 1]
        for instr_class_index in range(len(instr_classes)):
            if op in instr_classes[instr_class_index]:
                return instr_class_index
        #for instrClassIndex in range(len(instrClasses)):
        #    for opIndex in range(len(instrClasses[instrClassIndex])):
        #        if instrClasses[instrClassIndex][opIndex].startswith(op):
        #            return instrClassIndex
        # Assign it to the class "NO_CLASS" (index 5) if op not found
        return 5
    
    def __levenshtein_distance_instr(self, first, second):
        if len(first) > len(second):
            first, second = second, first
        if len(second) == 0:
            return len(first)
        first_length = len(first) + 1
        second_length = len(second) + 1
        distance_matrix = [[0] * second_length for x in range(first_length)]
        for i in range(first_length):
            distance_matrix[i][0] = i
            for j in range(second_length):
                distance_matrix[0][j] = j
        for i in range(1, first_length):
            for j in range(1, second_length):
                deletion = distance_matrix[i - 1][j] + 1
                insertion = distance_matrix[i][j - 1] + 1
                substitution = distance_matrix[i - 1][j - 1]
                op1 = first[i - 1].split(' ')[0]
                op2 = second[j - 1].split(' ')[0]
                if op1 == 'call' and op2 == 'call':
                    if first[i - 1].split(' ')[1] != second[j - 1].split(' ')[1]:
                        substitution += 1
                else:
                    if op1 != op2:
                        substitution += 1
                distance_matrix[i][j] = min(insertion, deletion, substitution)
        return distance_matrix[first_length - 1][second_length - 1]

    def __getColorFromInstr(self, instr):
        # Not implemented in the original source code
        return None