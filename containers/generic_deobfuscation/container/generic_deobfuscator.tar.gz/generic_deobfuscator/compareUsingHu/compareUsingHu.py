#!/usr/bin/env python
import sys
from os.path import basename

from CFG.CFG import CFG
from CFG_sim.CFGSimED import CFGSimED

if __name__ == "__main__":
    # Parse arguments
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} cfgA cfgB")
        exit()

    cfgAName = sys.argv[1]
    cfgA = CFG(cfgAName)
    cfgBName = sys.argv[2]
    cfgB = CFG(cfgBName)
    algo = CFGSimED()
    similarity = algo.sim(cfgA, cfgB)
    print(f"Similarity between {basename(cfgAName)} and {basename(cfgBName)} is {similarity}")
