# Deobfuscator

Project homepage: https://www2.cs.arizona.edu/projects/lynx-project/

Deobfuscator is a tool that applies semantic preserving transformations on a
given execution trace to simplify the obfuscations away. For more information,
please refer to the paper:

B. Yadegari, B. Johannesmeyer, B. Whitely and S. Debray, "A Generic Approach 
to Automatic Deobfuscation of Executable Code," 2015 IEEE Symposium on Security
and Privacy, San Jose, CA, 2015, pp. 674-691.

For use in bibetex:
@inproceedings{yadegari2015generic,
  title={A generic approach to automatic deobfuscation of executable code},
  author={Yadegari, Babak and Johannesmeyer, Brian and Whitely, Ben and Debray, Saumya},
  booktitle={Security and Privacy (SP), 2015 IEEE Symposium on},
  pages={674--691},
  year={2015},
  organization={IEEE}
}

## Building

To build the Generic Deobfuscator software, you need to complete the following steps

* Build udis86
  * Ensure the submodule is initalised (`git submodule init; git submodule update`)
* Build Generic Deobfuscator with CMake using `mkdir build; cd build; cmake ..; make`

## Running Generic Deobfuscator

### Collecting Traces

You can use Pin tool to collect execution traces. The plug-in that records traces
using Pin in specific format readable by deobfuscator is provided in the InstructionTrace/
directory of this repository. For more information on downloading and compiling the
Pin and the plug-in, look at:
https://software.intel.com/en-us/articles/pin-a-dynamic-binary-instrumentation-tool.

**NOTE**: please use the following naming convention when creating traces:
`(program-name)_standard_trace.txt`. For example, if the binary name is `factorial.exe`, then
the appropriate trace file name should be `factorial_std_trace.txt`.

### How to interpret the output

After running the deobfuscator, the tool produces stores the results in the `files` directory.

For example, when running `./deobf program_std_trace.txt`, you'd get these files as output:
1) `program.dot`: is the CFG built from one execution trace of the original code in dot format
2) `program.trace`: a text file containing all the instructions in the trace in a more readable format
3) `program.simplified`: instructions after applying the simplification transformations
4) `program_simplified.dot`: the CFG of the simplified code that is built from the simplified trace in dot format

## Exporting for distribution

Install git-archive-all through pip (`pip install git-archive-all`), then archive using the following
command:

```
git-archive-all --force-submodules generic_deobfuscator.tar.gz
```
