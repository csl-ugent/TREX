/*
 * File: flowgraph.h
 * Author: Babak Yadegari, Saumya Debray
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_FLOWGRAPH_H
#define GENERIC_DEOBFUSCATOR_FLOWGRAPH_H

#include <cstdint>
#include <memory>

#include <register.h>
#include <types.h>
#include <writeset.h>

#include "array_list.h"
#include "lynx_types.h"

using deobf::library::DeobfRegisterUses;

/*
 * Flags definitions used to mark each block
 */

#define BBL_START (1 << 0)
#define BBL_END (1 << 1)
#define BBL_ENTRY (1 << 2)
#define BBL_FORWARD_TAINTED (1 << 3)
#define BBL_BACKWARD_TAINTED (1 << 4)
#define BBL_IS_CONDITIONAL (1 << 5)
#define BBL_EXIT (1 << 6)
#define BBL_DOES_UNPACKING (1 << 8)

#define NODE_HAS_FLAG(node, flag) ((node) ? (((node)->flags) & (flag)) : 0)
#define NODE_SET_FLAG(node, flag) ((node) ? (((node)->flags) |= (flag)) : 0)

#define FORWARD_TAINT_COLOR "turquoise"
#define BACKWARD_TAINT_COLOR "red"
#define FORWARD_TAINTED_CONDITIONAL "violet"
#define SYSTEM_CALL_COLOR "grey"

#define HASH_TAB_SZ 32768

/*
 * InsNode holds information about an instruction.
 */
typedef struct InsNode {
    Instruction *ins;
    int flags;
    struct iListNode *succs, *preds;
    int numSuccs, numPreds;
} InsNode;

/*
 * iListNode defines a doubly-linked list of pointers to instruction nodes.
 */
typedef struct iListNode {
    InsNode *iptr;
    struct iListNode *prev, *next; // links in the doubly-linked list of instructions
    struct iListNode *hnext;       // next node in the hash table
} iListNode;

/*
 * Bbl defines the data structure used to represent basic blocks
 */
typedef struct Bbl {
    int id;
    int flags;
    iListNode *ins_hd, *ins_tl; // first and last instruction in the block
    struct bListNode *succs, *pDoms, *preds, *ipDoms, *fakesuccs, *fakepreds;
    struct Bbl *next, *prev;
    int numSuccs; // number of successors
    int numPreds;
    int numInstrs;
    ArrayList *occurrences; // keeps the positions in the trace where the bbl is executed
    std::string mergedBBls{};
} Bbl;

typedef struct BblEdge {
    int id;
    Bbl *from;
    Bbl *to;
    struct BblEdge *next, *prev;
} BblEdge;

typedef struct bListNode {
    Bbl *bptr;
    struct bListNode *next;
    struct bListNode *reserved; // as a helper variable. it might be used in some functions
} bListNode;

/*
 * Internal data structures
 */

class ScopedConstants {
  public:
    DeobfRegisterUses registers {};
    std::unique_ptr<deobf::library::writeset::WriteSet> memory {new deobf::library::writeset::WriteSet()};
    uint64_t startIndex {};
};

typedef struct lastOp {
    iListNode *backToInstr; // last instruction [i.e trace line]
    Bbl *from, *to, *prevBbl, *lastFound;
    bool removeEdge;
    bListNode *otherSuccessors;
    ArrayList *bbls;
} lastOp;

void ConstructOriginalCFG(const std::shared_ptr<InstrList>& iList);
void ConstructCFG(const std::shared_ptr<InstrList>& iList, bool debugDot);
void PrintCFG(FILE *f, bool printInstructions, bool printTaint, const std::map<ADDRESS, uint8_t> &taintStatus);
void DependencyAnalysis(const std::shared_ptr<InstrList>& iList);
void CleanUpCFGData();
void MarkUnsimplifiableInstrs(const std::shared_ptr<InstrList>& iList);
void MergeBblsNew();
#endif /* GENERIC_DEOBFUSCATOR_FLOWGRAPH_H */
