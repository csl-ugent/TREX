/*
 * File: read.h
 * Author: Babak Yadegari, Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_READ_H
#define GENERIC_DEOBFUSCATOR_READ_H

#include <filesystem>
#include <memory>

#include "lynx_types.h"

namespace fs = std::filesystem;

std::shared_ptr<InstrList> InitInstrList(const fs::path &inPath, std::vector<ADDRESS> *dont_simplify, bool delete_existing_file);
void InitMMAP(const fs::path &, const std::shared_ptr<InstrList>& iList);

#endif /* GENERIC_DEOBFUSCATOR_READ_H */