/*
 * File: print.h
 * Code to print out a "reasonable" assembly code program for an
 * instruction trace summary.  This code assumes that the summary
 * list has been sorted by address and that function and exception
 * handler entry points have been marked.
 *
 * Author: Babak Yadegari, Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_PRINT_H
#define GENERIC_DEOBFUSCATOR_PRINT_H

#include <cstdint>
#include <cstdio>
#include <memory>

#include "lib/include/types.h"

#include "array_list.h"
#include "lynx_types.h"

void PrintTrace(FILE *f, const std::shared_ptr<InstrList>& iList, bool includeAllIns, bool includeDeletedIns, bool printSigns, uint64_t start, uint64_t end);
void fPrintMemTargets(FILE *f, const std::shared_ptr<InstrList>& iList, Instruction *ins);
void PrintSimplifiedTrace(FILE *f, const std::shared_ptr<InstrList>& iList, bool printNonBaseInstructions, bool printDeadInstrs, bool printSigns, uint64_t start, uint64_t end);
void PrintEntireMultiThreadInstrListInternal(FILE *f, const std::shared_ptr<InstrList>& iList, bool full_list, bool printDeadInstrs, int tid);
inline void PrintSimplifiedFullInstrList(FILE *f, const std::shared_ptr<InstrList>& iList, bool simple, bool printSigns, uint64_t start, uint64_t end) {
    PrintTrace(f, iList, !simple, !simple, printSigns, start, end);
}

#endif /* GENERIC_DEOBFUSCATOR_PRINT_H */
