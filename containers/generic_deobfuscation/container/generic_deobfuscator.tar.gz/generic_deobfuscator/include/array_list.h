/*
 * File: array_list.h
 * A fully functional, sortable ArrayList with set operations.
 * Also supports iteration.
 * Author: Kevin Coogan, Saumya Debray
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef ARRAY_LIST_H_
#define ARRAY_LIST_H_

typedef struct Iterator {
    void *it_dataStructure;
    void *it_current;
    void *it_opaque1;
    void *it_opaque2;
    void *(*it_next)(struct Iterator *);
    int (*it_hasNext)(struct Iterator *);
    void *(*it_remove)(struct Iterator *);
} Iterator;

typedef enum { AL_LIST_UNSORTED, AL_LIST_SORTED, AL_LIST_SET } ATYPE;

typedef struct ArrayList {
    void **al_elements;
    int al_size;
    int al_capacity;
    ATYPE al_type;
    int al_lock;
    int (*al_compare)(void *, void *);
    void (*al_print)(void *);
    void (*al_free)(void *);
} ArrayList;

ArrayList *al_new();
ArrayList *al_newPtr(ATYPE type);
ArrayList *al_newGeneric(ATYPE type, int (*compareFunc)(void *, void *), void (*printFunc)(void *), void (*freeFunc)(void *));
void al_free(ArrayList *list);
void al_freeWithElements(ArrayList *list);

void *al_add(ArrayList *list, void *val);
void al_clear(ArrayList *list);
void al_clearAndFreeElements(ArrayList *list);
int al_contains(ArrayList *list, void *val);
void *al_get(ArrayList *list, int index);
int al_indexOf(ArrayList *list, void *val);
void *al_insertAt(ArrayList *list, void *val, int index);
void *al_insertSorted(ArrayList *list, void *val);
Iterator *al_iterator(ArrayList *list);
void *al_removeAt(ArrayList *list, int index);
void *al_removeLast(ArrayList *list);
int al_size(ArrayList *list);
void al_sort(ArrayList *list);

#endif /*ARRAY_LIST_H_*/
