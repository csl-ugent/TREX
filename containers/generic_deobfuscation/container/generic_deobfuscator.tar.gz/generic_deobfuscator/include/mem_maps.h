/*
 * File: mem_maps.h
 * Author: Babak Yadegari
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_MEM_MAPS_H
#define GENERIC_DEOBFUSCATOR_MEM_MAPS_H

#include <mem_sim_utils.h>

inline void ClearConstantPages(const std::shared_ptr<InstrList>& iList) {
    deobf::library::memory_simulation::ClearConstantPages(iList);
}
inline bool MemLocIsConstant(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    return deobf::library::memory_simulation::MemLocIsConstant(iList, addr, numBytes);
}
inline void SetAddrAsConstWithValue(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, DEOBF_GENERIC_VALUE val, int line) {
    deobf::library::memory_simulation::SetAddrAsConstWithValue(iList, addr, numBytes, val, line);
}
inline uint GetMemoryLocValue(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    return deobf::library::memory_simulation::GetMemoryLocValue(iList, addr, numBytes);
}
inline void SetAddrAsConst(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    deobf::library::memory_simulation::SetAddrAsConst(iList, addr, numBytes);
}

inline void UnsetConstAddr(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, int line) {
    deobf::library::memory_simulation::UnsetConstAddr(iList, addr, numBytes, line);
}
inline void UnsetConstAddrWithoutMemReset(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, int line) {
    deobf::library::memory_simulation::UnsetConstAddrWithoutMemReset(iList, addr, numBytes, line);
}

/******************************************************/

inline uint64_t DependencyMemGetConstLocSrc(const std::shared_ptr<InstrList>& iList, ADDRESS addr) {
    return deobf::library::memory_simulation::DependencyMemGetConstLocSrc(iList, addr);
}
inline void DependencyMemSetConstWithSrc(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes, uint64_t src) {
    return deobf::library::memory_simulation::DependencyMemSetConstWithSrc(iList, addr, numBytes, src);
}

//////////// Dead Code Analysis ////

inline bool MemoryLocationIsLive(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    return deobf::library::memory_simulation::MemoryLocationIsLive(iList, addr, numBytes);
}
inline void SetMemoryLocationLive(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    deobf::library::memory_simulation::SetMemoryLocationLive(iList, addr, numBytes);
}
inline void SetMemoryLocationDead(const std::shared_ptr<InstrList>& iList, ADDRESS addr, uint8_t numBytes) {
    deobf::library::memory_simulation::SetMemoryLocationDead(iList, addr, numBytes);
}

#endif /* GENERIC_DEOBFUSCATOR_MEM_MAPS_H */

