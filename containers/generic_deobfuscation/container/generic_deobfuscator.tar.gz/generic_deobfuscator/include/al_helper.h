/*
 * File: al_helper.h
 * helper functions for data structure code.
 * Author: Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef HELPER_H_
#define HELPER_H_

void *alloc(unsigned long size);
void *zalloc(unsigned long size);
void dealloc(void *ptr);
void *resize(void *address, unsigned long newSize);

int refCompare(void *o1, void *o2);
int strCompare(void *o1, void *o2);
int insCompareByOrder(void *i1, void *i2);
void intPrint(void *item);
void refPrint(void *item);
void strPrint(void *key);

#endif /* HELPER_H_ */
