/*
 * File: lynx_types.h
 * Author: Babak Yadegari, Kevin Coogan
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_LYNX_TYPES_H
#define GENERIC_DEOBFUSCATOR_LYNX_TYPES_H

#include <pthread.h>
#include <unistd.h>

#ifdef __APPLE__
#include <sys/types.h>
#endif

#include <cassert>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>

extern "C" {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wregister"
#include "udis86/udis86.h"
#pragma GCC diagnostic pop
}
#include "lib/include/types.h"

#include "array_list.h"

#define PHASE_TAINT "Taint analysis"
#define PHASE_SIMPL "Simplifications"
#define PHASE_BTRk6 "Fix BBLs"
#define PHASE_DOTS "Creating dot file"

// set to true to store instruction objects in file database instead of memory
#define STORE_INSTRS_IN_FILE true // This is never false anymore -- kpc 6/8/12

// set to true if mmap'ing file to memory
#define USE_MMAP true

// marker for main function of program, Used for Cristian's binaries!
#define MAIN_MARKER 1

#define MARK_THREAD_BOUNDARIES 1

// set to true to ignore processing non-base_module instructions
#define IGNORE_API_CALLS 0

extern int DebugCounter;
extern bool DebugCounterUse;
extern bool handle_rop;
extern bool uGhentImprovements;

/*********************************************************************
 *                               MISC.                               *
 *********************************************************************/

typedef struct Thread {
    ArrayList *ranges;
    int tid;
    uint64_t numInstrs;
    int numRanges; // needed to recover thread structures from .InstrFile!
    uint64_t numBaseModuleInstrs;
} Thread;

typedef struct ThreadRange {
    uint64_t first;
    uint64_t last;
} ThreadRange;

/*
 * Function declarations
 */

bool InstrIsControlTransfer(const std::shared_ptr<InstrList>& iList, Instruction *iins);

#endif /* GENERIC_DEOBFUSCATOR_LYNX_TYPES_H */
