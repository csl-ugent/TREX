/*
 * Author: Willem Van Iseghem
 *
 * Copyright 2022 University of Ghent
 */

#ifndef GENERIC_DEOBFUSCATOR_TRACEMAPPING_H
#define GENERIC_DEOBFUSCATOR_TRACEMAPPING_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>

#include "types.h"

/**
 * Utility to match (sparse) traces coming from (Intel) Pin to the internal Instruction structure
 */
class TraceMapping {
  public:
    void initializeRegisterValues();
    void setRegistersInInstruction(Instruction *ins);
    void parseSparseRegisters(std::string changedReg, uint8_t *lastFound);

  private:
    /**
     * This mapping must correspond to the defines in the InstructionTrace.cpp file (Pin plugin)!
     */
    enum class Registers {
        RAX = 0,
        RCX,
        RDX,
        RBX,
        RSP,
        RBP,
        RSI,
        RDI,
        R8,
        R9,
        R10,
        R11,
        R12,
        R13,
        R14,
        R15,
        FS,
        XMM0_0,
        XMM0_1,
        XMM1_0,
        XMM1_1,
        XMM2_0,
        XMM2_1,
        XMM3_0,
        XMM3_1,
        XMM4_0,
        XMM4_1,
        XMM5_0,
        XMM5_1,
        XMM6_0,
        XMM6_1,
        XMM7_0,
        XMM7_1,
        XMM8_0,
        XMM8_1,
        XMM9_0,
        XMM9_1,
        XMM10_0,
        XMM10_1,
        XMM11_0,
        XMM11_1,
        XMM12_0,
        XMM12_1,
        XMM13_0,
        XMM13_1,
        XMM14_0,
        XMM14_1,
        XMM15_0,
        XMM15_1
    };
    Registers lastRegister = Registers::XMM15_1;

    std::map<Registers, DEOBF_REGISTER_VALUE> registerValues;
    std::map<Registers, std::function<void(Instruction *i, const DEOBF_REGISTER_VALUE val)>> mapToInstruction{
        {Registers::RAX, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->eax = val; }},
        {Registers::RCX, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->ecx = val; }},
        {Registers::RDX, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->edx = val; }},
        {Registers::RBX, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->ebx = val; }},
        {Registers::RSP, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->esp = val; }},
        {Registers::RBP, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->ebp = val; }},
        {Registers::RSI, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->esi = val; }},
        {Registers::RDI, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->edi = val; }},
        {Registers::R8, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r8 = val; }},
        {Registers::R9, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r9 = val; }},
        {Registers::R10, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r10 = val; }},
        {Registers::R11, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r11 = val; }},
        {Registers::R12, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r12 = val; }},
        {Registers::R13, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r13 = val; }},
        {Registers::R14, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r14 = val; }},
        {Registers::R15, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->r15 = val; }},
        {Registers::FS, [](Instruction *ins, const DEOBF_REGISTER_VALUE val) { ins->fs = val; }}};

    std::map<Registers, std::function<void(Instruction *i, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1)>> mapToXMMInstruction{
        {Registers::XMM0_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm0 = val0 << 64 | val1; }},
        {Registers::XMM1_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm1 = val0 << 64 | val1; }},
        {Registers::XMM2_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm2 = val0 << 64 | val1; }},
        {Registers::XMM3_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm3 = val0 << 64 | val1; }},
        {Registers::XMM4_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm4 = val0 << 64 | val1; }},
        {Registers::XMM5_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm5 = val0 << 64 | val1; }},
        {Registers::XMM6_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm6 = val0 << 64 | val1; }},
        {Registers::XMM7_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm7 = val0 << 64 | val1; }},
        {Registers::XMM8_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm8 = val0 << 64 | val1; }},
        {Registers::XMM9_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm9 = val0 << 64 | val1; }},
        {Registers::XMM10_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm10 = val0 << 64 | val1; }},
        {Registers::XMM11_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm11 = val0 << 64 | val1; }},
        {Registers::XMM12_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm12 = val0 << 64 | val1; }},
        {Registers::XMM13_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm13 = val0 << 64 | val1; }},
        {Registers::XMM14_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm14 = val0 << 64 | val1; }},
        {Registers::XMM15_0, [](Instruction *ins, const DEOBF_REGISTER_VALUE val0, const DEOBF_REGISTER_VALUE val1) { ins->xmm15 = val0 << 64 | val1; }},
    };
    std::map<Registers, std::string> mapToRegex{
        {Registers::RAX, "EAX="},         {Registers::RCX, "ECX="},         {Registers::RDX, "EDX="},         {Registers::RBX, "EBX="},         {Registers::RSP, "ESP="},         {Registers::RBP, "EBP="},
        {Registers::RSI, "ESI="},         {Registers::RDI, "EDI="},         {Registers::R8, "R8="},           {Registers::R9, "R9="},           {Registers::R10, "R10="},         {Registers::R11, "R11="},
        {Registers::R12, "R12="},         {Registers::R13, "R13="},         {Registers::R14, "R14="},         {Registers::R15, "R15="},         {Registers::FS, "FS="},           {Registers::XMM0_0, "XMM0_0="},
        {Registers::XMM0_1, "XMM0_1="},   {Registers::XMM1_0, "XMM1_0="},   {Registers::XMM1_1, "XMM1_1="},   {Registers::XMM2_0, "XMM2_0="},   {Registers::XMM2_1, "XMM2_1="},   {Registers::XMM3_0, "XMM3_0="},
        {Registers::XMM3_1, "XMM3_1="},   {Registers::XMM4_0, "XMM4_0="},   {Registers::XMM4_1, "XMM4_1="},   {Registers::XMM5_0, "XMM5_0="},   {Registers::XMM5_1, "XMM5_1="},   {Registers::XMM6_0, "XMM6_0="},
        {Registers::XMM6_1, "XMM6_1="},   {Registers::XMM7_0, "XMM7_0="},   {Registers::XMM7_1, "XMM7_1="},   {Registers::XMM8_0, "XMM8_0="},   {Registers::XMM8_1, "XMM8_1="},   {Registers::XMM9_0, "XMM9_0="},
        {Registers::XMM9_1, "XMM9_1="},   {Registers::XMM10_0, "XMM10_0="}, {Registers::XMM10_1, "XMM10_1="}, {Registers::XMM11_0, "XMM11_0="}, {Registers::XMM11_1, "XMM11_1="}, {Registers::XMM12_0, "XMM12_0="},
        {Registers::XMM12_1, "XMM12_1="}, {Registers::XMM13_0, "XMM13_0="}, {Registers::XMM13_1, "XMM13_1="}, {Registers::XMM14_0, "XMM14_0="}, {Registers::XMM14_1, "XMM14_1="}, {Registers::XMM15_0, "XMM15_0="},
        {Registers::XMM15_1, "XMM15_1="},
    };
    uint8_t fs_change_count = 0;
    bool fs_first = true;
};

#endif // GENERIC_DEOBFUSCATOR_TRACEMAPPING_H
