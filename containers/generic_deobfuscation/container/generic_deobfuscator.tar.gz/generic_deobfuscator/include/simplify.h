/*
 * File: simplify.h
 * Purpose: Semantics-preserving simplifications to the code.
 * Author: Babak Yadegari
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 * Copyright 2020 University of Ghent
 */
#ifndef GENERIC_DEOBFUSCATOR_SIMPLIFY_H
#define GENERIC_DEOBFUSCATOR_SIMPLIFY_H

#include <cstdint>

extern "C" {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wregister"
#include "udis86/udis86.h"
#pragma GCC diagnostic pop
}

#include "lynx_types.h"

void applySimplifications(const std::shared_ptr<InstrList>& iList);
unsigned int PropagateConstants(const std::shared_ptr<InstrList>& iList, int first, int last);
int SimplifyGlobalMems(const std::shared_ptr<InstrList>& iList);

#endif /* GENERIC_DEOBFUSCATOR_SIMPLIFY_H */