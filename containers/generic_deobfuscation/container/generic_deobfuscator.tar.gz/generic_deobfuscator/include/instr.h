/*
 * File: instr.h
 * functions related to instructions, their manipulation, or their characteristics
 * Author: Babak Yadegari, Kevin Coogan, Saumya Debray
 *
 * Copyright 2015 Arizona Board of Regents on behalf of the University of Arizona.
 *
 */

#ifndef GENERIC_DEOBFUSCATOR_INSTR_H
#define GENERIC_DEOBFUSCATOR_INSTR_H

#include <cstdlib>
#include <memory>

extern "C" {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wregister"
#include "udis86/udis86.h"
#pragma GCC diagnostic pop
}

#include <register.h>
#include <udis86_glue.h>
#include <utils.h>
#include <writeset.h>
#include <instr_utils.h>

#include "lynx_types.h"

using deobf::library::DeobfRegisterUses;
using namespace deobf::library::utils;
using namespace deobf::library::glue;

#define NO_INSTR (-1)

#define OFFSET_TO_REG false
#define REG_TO_OFFSET true

/* Instruction Characteristics */
void WriteInstrFileHeader(const std::shared_ptr<InstrList>& iList, FILE *file, bool mmap);
Instruction *AddInstruction(const std::shared_ptr<InstrList>& iList, Instruction *, int after);
inline void SetCurrentInstr(const std::shared_ptr<InstrList>& iList, uint64_t order) {
    return deobf::library::instruction_utils::setCurrentInstr(iList, order);
}
inline Instruction *FetchPrevInstr(const std::shared_ptr<InstrList>& iList) {
    return deobf::library::instruction_utils::fetchPrevInstr(iList);
}
inline Instruction *FetchNextInstr(const std::shared_ptr<InstrList>& iList) {
    return deobf::library::instruction_utils::fetchNextInstr(iList);
}

inline DeobfRegisterUses definedRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    return deobf::library::instruction_utils::definedRegistersForInstruction(iList, instr);
}
inline DeobfRegisterUses definedMemoryRegistersForInstruction(Instruction *instr) {
    return deobf::library::instruction_utils::definedMemoryRegistersForInstruction(instr);
}
inline DeobfRegisterUses definedNonMemoryRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    return deobf::library::instruction_utils::definedNonMemoryRegistersForInstruction(iList, instr);
}
inline DeobfRegisterUses usedRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    return deobf::library::instruction_utils::usedRegistersForInstruction(iList, instr);
}
inline PSW_BITVECTOR FlagsDef(Instruction *instr) {
    return deobf::library::instruction_utils::FlagsDef(instr);
}
inline PSW_BITVECTOR FlagsUsed(Instruction *instr) {
    return deobf::library::instruction_utils::FlagsUsed(instr);
}
inline std::unique_ptr<deobf::library::writeset::WriteSet> memoryDefined(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    return deobf::library::instruction_utils::memoryDefined(iList, instr);
}
inline std::unique_ptr<deobf::library::writeset::WriteSet> memoryUsed(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    return deobf::library::instruction_utils::memoryUsed(iList, instr);
}
inline void calculateFlagsAndRegistersForInstruction(const std::shared_ptr<InstrList>& iList, Instruction *instr) {
    deobf::library::instruction_utils::calculateFlagsAndRegistersForInstruction(iList, instr);
}
void CalcKnownDefsAndUses(const std::shared_ptr<InstrList>& iList);

DeobfRegisterUses usedRegistersForInstructionAndSP(const std::shared_ptr<InstrList>& iList, Instruction *instr);
DeobfRegisterUses definedRegistersForInstructionAndSP(const std::shared_ptr<InstrList>& iList, Instruction *instr);

/* List operations */
void AddInstrToFile(FILE *f, Instruction *instr);

/* helpers */
Instruction *InstrCreate();
Instruction *InstrClone(Instruction *instr);
uint64_t countInstructionsBetween(const std::shared_ptr<InstrList>& iList, Instruction *from, Instruction *to);
void MakeInstrAlive(const std::shared_ptr<InstrList>& iList, Instruction *instr);
bool InstrCompare(Instruction *ins1, Instruction *ins2);
bool InstrIsIndirectJump(Instruction *instr);
inline bool InstrIsSetOnCondition(ud_mnemonic_code opcode) {
    return deobf::library::instruction_utils::instrIsSetOnCondition(opcode);
}
bool IsMxcsrInstr(Instruction *instr);
bool IsStringCompare(Instruction *instr);
inline bool IsStringOperation(Instruction *instr) {
    return deobf::library::instruction_utils::isStringOperation(instr);
}
inline Instruction *GetInstruction(const std::shared_ptr<InstrList>& iList, uint64_t index) {
    return deobf::library::instruction_utils::fetchInstr(iList, index);
}
inline bool SaveInstrChange(const std::shared_ptr<InstrList>& iList, Instruction *instr, bool ignoreFtn = false) {
    return deobf::library::instruction_utils::SaveInstrChange(iList, instr, ignoreFtn);
}
std::shared_ptr<InstrList> InitInstructionCache(const std::shared_ptr<InstrList>& iList);
inline DEOBF_REGISTER_VALUE GetRegisterValue(Instruction *instr, DeobfRegister reg) {
    return deobf::library::instruction_utils::GetRegisterValue(instr, reg);
}
inline DEOBF_REGISTER_VALUE GetRegisterValue(Instruction *instr, ud_type reg) {
    return deobf::library::instruction_utils::GetRegisterValue(instr, reg);
}
DEOBF_REGISTER_VALUE SetRegisterValue(Instruction *instr, ud_type reg, DEOBF_REGISTER_VALUE val);
inline bool IsControlFlowInstr(Instruction *instr) {
    return deobf::library::instruction_utils::isControlFlowInstr(instr);
}
inline bool IsCondJump(Instruction *instr) {
    return deobf::library::instruction_utils::isCondJump(instr);
}
inline bool isPush(Instruction *instr) {
    return deobf::library::instruction_utils::isPush(instr);
}
inline bool isPop(Instruction *instr) {
    return deobf::library::instruction_utils::isPop(instr);
}
inline bool isMoveDataFromStringToString(Instruction *instr) {
    return deobf::library::instruction_utils::isMoveDataFromStringToString(instr);
}
Instruction *GetInstructionFromFile(std::shared_ptr<InstrList>& iList, uint64_t index);
size_t WriteInstrToFile(FILE *f, Instruction *instr);
unsigned int ArithOp(ud_mnemonic_code op, unsigned int val1, int val2, int size, PSW_BITVECTOR *flags);
int bSwap(int val);
int rotate(unsigned int in_value, int places, int direction, int size);
bool OpcodeIsArithWithNoEffect(ud_mnemonic_code opcode);
inline bool OpcodeIsArith(ud_mnemonic_code opcode) {
    return deobf::library::instruction_utils::opcodeIsArith(opcode);
}
inline void carefulCopyUDins2InsStr(const std::shared_ptr<InstrList>& iList, Instruction *instr, ins_structure *uIns, ud_t *udIns, bool doNotChangeFlags, int line) {
    deobf::library::instruction_utils::carefulCopyUDins2InsStr(iList, instr, uIns, udIns, doNotChangeFlags, line);
}
std::unique_ptr<deobf::library::writeset::WriteSet> memoryMask(uint64_t offset, DeobfRegister reg);
inline ud_type UDOpIsRegister(ud_operand_t *op) {
    return deobf::library::instruction_utils::UDOpIsRegister(op);
}
int floor_log2(PSW_BITVECTOR v);
int SignExtend(int value);
void ConstantMemoryMap(const std::shared_ptr<InstrList>& iList);
void FreeConstantMemoryMap(const std::shared_ptr<InstrList>& iList);

#endif /* GENERIC_DEOBFUSCATOR_INSTR_H */
